import { deprecate } from "./deprecate.js";

/**
 * Create an API client.
 *
 * @param {string|object} options Either a baseUrl string (deprecated positional
 *   form) or an options object: { baseUrl, token, timeoutMs, retries, headers }.
 */

const ALLOWED_OPTIONS = new Set(["baseUrl", "token", "timeoutMs", "retries", "headers"]);

function isPlainObject(value) {
  if (value === null || typeof value !== "object") return false;
  const proto = Object.getPrototypeOf(value);
  return proto === Object.prototype || proto === null;
}

export function createClient(first, token, timeoutMs, retries) {
  // Positional compatibility: first argument is a baseUrl string.
  let positional = false;
  let raw;
  if (typeof first === "string") {
    positional = true;
    deprecate(
      "CLIENT_POSITIONAL_ARGS",
      "createClient positional arguments are deprecated; use an options object instead"
    );
    raw = { baseUrl: first, token, timeoutMs, retries };
  } else if (isPlainObject(first)) {
    raw = first;
  } else {
    throw new TypeError("createClient expects a baseUrl string or an options object");
  }

  // Reject unknown option names.
  for (const key of Object.keys(raw)) {
    if (!ALLOWED_OPTIONS.has(key)) {
      throw new TypeError(`Unknown option: ${key}`);
    }
  }

  // Defaults: an explicit undefined counts as "not given".
  const baseUrl = raw.baseUrl;
  const tok = raw.token === undefined ? undefined : raw.token;
  const ms = raw.timeoutMs === undefined ? 5000 : raw.timeoutMs;
  const ret = raw.retries === undefined ? 0 : raw.retries;
  const headersIn = raw.headers === undefined ? {} : raw.headers;

  if (typeof baseUrl !== "string" || baseUrl === "") {
    throw new TypeError("baseUrl must be a non-empty string");
  }
  if (typeof ms !== "number" || !Number.isFinite(ms) || ms <= 0) {
    throw new RangeError("timeoutMs must be a finite number greater than 0");
  }
  if (!Number.isInteger(ret) || ret < 0) {
    throw new RangeError("retries must be an integer >= 0");
  }

  const headers = Object.freeze({ ...headersIn });
  const options = Object.freeze({
    baseUrl: baseUrl.replace(/\/+$/, ""),
    token: tok,
    timeoutMs: ms,
    retries: ret,
    headers,
  });

  return {
    options,
    request(transport, method, path, body) {
      const headers = { ...options.headers };
      headers.accept = "application/json";
      if (options.token) headers.authorization = `Bearer ${options.token}`;
      if (body !== undefined) headers["content-type"] = "application/json";
      return transport({
        method,
        url: options.baseUrl + (path.startsWith("/") ? path : `/${path}`),
        headers,
        body: body === undefined ? undefined : JSON.stringify(body),
        timeoutMs: options.timeoutMs,
        retries: options.retries,
      });
    },
  };
}
