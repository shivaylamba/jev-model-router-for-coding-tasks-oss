// Sign-up validation. Rules: docs/signup-rules.md
export type { SignupErrors, SignupInput, SignupResult } from "./types.ts";
import type { SignupInput, SignupResult, SignupErrors } from "./types.ts";
import { isLeapYear, daysInMonth } from "./dates.ts";

export function validateSignup(input: SignupInput, today: Date): SignupResult {
  const errors: SignupErrors = {};

  // ---- username ----
  let usernameTrimmed: string | undefined;
  let usernameValid = false;
  let usernameNormalized = "";
  const rawUsername = (input as Record<string, unknown>).username;
  if (typeof rawUsername !== "string" || rawUsername.trim() === "") {
    errors.username = "required";
  } else {
    usernameTrimmed = rawUsername.trim();
    if (usernameTrimmed.length < 3 || usernameTrimmed.length > 20) {
      errors.username = "length";
    } else if (!/^[A-Za-z][A-Za-z0-9_]*$/.test(usernameTrimmed)) {
      errors.username = "format";
    } else {
      usernameValid = true;
      usernameNormalized = usernameTrimmed.toLowerCase();
    }
  }

  // ---- email ----
  let emailNormalized = "";
  const rawEmail = (input as Record<string, unknown>).email;
  if (typeof rawEmail !== "string" || rawEmail.trim() === "") {
    errors.email = "required";
  } else {
    const emailTrimmed = rawEmail.trim();
    if (!isValidEmail(emailTrimmed)) {
      errors.email = "format";
    } else {
      emailNormalized = emailTrimmed.toLowerCase();
    }
  }

  // ---- password ----
  const rawPassword = (input as Record<string, unknown>).password;
  if (typeof rawPassword !== "string" || rawPassword === "") {
    errors.password = "required";
  } else if (rawPassword.length < 8 || rawPassword.length > 64) {
    errors.password = "length";
  } else if (!/[A-Za-z]/.test(rawPassword) || !/[0-9]/.test(rawPassword)) {
    errors.password = "weak";
  } else if (usernameValid && rawPassword.toLowerCase().includes(usernameTrimmed!.toLowerCase())) {
    errors.password = "contains_username";
  }

  // ---- confirmPassword ----
  const rawConfirm = (input as Record<string, unknown>).confirmPassword;
  if (typeof rawConfirm !== "string" || rawConfirm === "") {
    errors.confirmPassword = "required";
  } else if (typeof rawPassword === "string" && rawPassword !== "") {
    if (rawConfirm !== rawPassword) {
      errors.confirmPassword = "mismatch";
    }
  }

  // ---- birthDate ----
  let birthDateNormalized = "";
  const rawBirth = (input as Record<string, unknown>).birthDate;
  if (typeof rawBirth !== "string" || rawBirth.trim() === "") {
    errors.birthDate = "required";
  } else {
    const bdTrimmed = rawBirth.trim();
    const parsed = parseBirthDate(bdTrimmed);
    if (!parsed) {
      errors.birthDate = "format";
    } else {
      const ty = today.getUTCFullYear();
      const tm = today.getUTCMonth() + 1;
      const td = today.getUTCDate();
      if (compareDate(parsed.y, parsed.m, parsed.d, ty, tm, td) > 0) {
        errors.birthDate = "future";
      } else if (!isAtLeast13(parsed, ty, tm, td)) {
        errors.birthDate = "too_young";
      } else {
        birthDateNormalized = bdTrimmed;
      }
    }
  }

  if (Object.keys(errors).length > 0) {
    return { ok: false, errors };
  }
  return { ok: true, value: { username: usernameNormalized, email: emailNormalized, birthDate: birthDateNormalized } };
}

function isValidEmail(s: string): boolean {
  if (/\s/.test(s)) return false;
  const parts = s.split("@");
  if (parts.length !== 2) return false;
  if (parts[0] === "") return false;
  const domain = parts[1];
  if (domain.startsWith(".") || domain.endsWith(".")) return false;
  if (domain.includes("..")) return false;
  const labels = domain.split(".");
  if (labels.length < 2) return false;
  if (labels.some((l) => l === "")) return false;
  return true;
}

function parseBirthDate(s: string): { y: number; m: number; d: number } | null {
  const m = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return null;
  const y = Number(m[1]);
  const mo = Number(m[2]);
  const d = Number(m[3]);
  if (y < 1900) return null;
  if (mo < 1 || mo > 12) return null;
  const dim = daysInMonth(y, mo);
  if (d < 1 || d > dim) return null;
  return { y, m: mo, d };
}

function compareDate(y1: number, m1: number, d1: number, y2: number, m2: number, d2: number): number {
  if (y1 !== y2) return y1 - y2;
  if (m1 !== m2) return m1 - m2;
  return d1 - d2;
}

function isAtLeast13(birth: { y: number; m: number; d: number }, ty: number, tm: number, td: number): boolean {
  const ay = birth.y + 13;
  let am = birth.m;
  let ad = birth.d;
  if (birth.m === 2 && birth.d === 29 && !isLeapYear(ay)) {
    am = 3;
    ad = 1;
  }
  return compareDate(ay, am, ad, ty, tm, td) <= 0;
}
