import unittest, sys
sys.path.insert(0,'.')
from funcutil import memoize, CacheInfo

class T(unittest.TestCase):
    def test_basic(self):
        calls=[]
        @memoize
        def f(x,y=0):
            calls.append((x,y))
            return x+y
        self.assertEqual(f(1),1)
        self.assertEqual(f(1),1)
        self.assertEqual(calls,[(1,0)])
        self.assertEqual(f(1,2),3)
        self.assertEqual(f(1,y=2),3)
        self.assertEqual(len(calls),2)
    def test_kw_order(self):
        calls=[]
        @memoize
        def g(a=0,b=0):
            calls.append((a,b)); return (a,b)
        self.assertEqual(g(a=1,b=2), (1,2))
        self.assertEqual(g(b=2,a=1), (1,2))
        self.assertEqual(len(calls),1)
    def test_none(self):
        calls=[]
        @memoize
        def h(x):
            calls.append(x); return None
        self.assertIs(h(1),None)
        self.assertIs(h(1),None)
        self.assertEqual(len(calls),1)
        info=h.cache_info()
        self.assertEqual(info.hits,1)
        self.assertEqual(info.misses,1)
        self.assertEqual(info.size,1)
    def test_exc(self):
        calls=[]
        @memoize
        def bad(x):
            calls.append(x); raise ValueError("boom")
        with self.assertRaises(ValueError):
            bad(1)
        with self.assertRaises(ValueError):
            bad(1)
        self.assertEqual(len(calls),2)
        self.assertEqual(bad.cache_info().misses,2)
        self.assertEqual(bad.cache_info().size,0)
    def test_unhashable(self):
        calls=[]
        @memoize
        def u(x):
            calls.append(x); return x
        with self.assertRaises(TypeError):
            u([1,2])
        self.assertEqual(calls,[])
    def test_names(self):
        @memoize
        def docfunc(x):
            """doc"""
            return x
        self.assertEqual(docfunc.__name__,"docfunc")
        self.assertEqual(docfunc.__doc__,"doc")
    def test_clear(self):
        @memoize
        def c(x):
            return x*2
        c(1); c(2); c(1)
        c.cache_clear()
        info=c.cache_info()
        self.assertEqual((info.hits,info.misses,info.size),(0,0,0))
    def test_separate(self):
        @memoize
        def f(x): return x
        @memoize
        def g(x): return x
        f(1); g(1)
        self.assertEqual(f.cache_info().size,1)
        self.assertEqual(g.cache_info().size,1)
    def test_positional_keyword_distinct(self):
        calls=[]
        @memoize
        def add(a,b):
            calls.append((a,b)); return a+b
        add(1,2)
        add(1,b=2)
        self.assertEqual(add.cache_info().size,2)
        self.assertEqual(len(calls),2)
    def test_callstyle(self):
        @memoize()
        def f(x): return x+1
        self.assertEqual(f(2),3)

if __name__=="__main__":
    unittest.main(argv=["x","-v"],exit=False)
PY
python3 /private/var/folders/hq/j39c5kfd1y9dxvlnsrj6p7s40000gn/T/njb-jg3jyvkk/workspace/scratchpad/test_memoize.py