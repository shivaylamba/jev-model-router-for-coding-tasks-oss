"""Function decorators."""

import functools
from collections import namedtuple


CacheInfo = namedtuple("CacheInfo", ("hits", "misses", "size"))


def once(func):
    """Call `func` the first time only; later calls return the first result."""
    result = []

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        if not result:
            result.append(func(*args, **kwargs))
        return result[0]

    return wrapper


def _build_wrapper(func):
    cache = {}
    hits = 0
    misses = 0

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        nonlocal hits, misses
        key = (args, tuple(sorted(kwargs.items())))

        if key in cache:
            hits += 1
            return cache[key]

        misses += 1
        result = func(*args, **kwargs)
        cache[key] = result
        return result

    def cache_info():
        return CacheInfo(hits, misses, len(cache))

    def cache_clear():
        nonlocal hits, misses
        cache.clear()
        hits = 0
        misses = 0

    wrapper.cache_info = cache_info
    wrapper.cache_clear = cache_clear
    return wrapper


def memoize(func=None):
    """Cache the return value of *func* per distinct set of arguments."""
    if func is None:
        def decorator(f):
            return _build_wrapper(f)
        return decorator
    return _build_wrapper(func)
