export function defaultLayout({ title, content }) {
  return `<!doctype html>
<html>
<head><meta charset="utf-8"><title>${title}</title></head>
<body>
${content}
</body>
</html>
`;
}
