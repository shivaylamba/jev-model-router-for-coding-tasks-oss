/** Sum of a list of numbers; 0 for an empty list. */
export function sum(values: readonly number[]): number {
  let total = 0;
  for (const v of values) total += v;
  return total;
}

/** Arithmetic mean. Throws RangeError for an empty list. */
export function mean(values: readonly number[]): number {
  if (values.length === 0) throw new RangeError("mean of an empty list");
  return sum(values) / values.length;
}

/** Clamp `value` to the closed interval [min, max]. Throws RangeError if min > max. */
export function clamp(value: number, min: number, max: number): number {
  if (min > max) throw new RangeError("min must not exceed max");
  if (value < min) return min;
  if (value > max) return max;
  return value;
}

/** Python-style range returning an array of numbers. */
export function range(start: number, stop?: number, step?: number): number[] {
  let s: number;
  let st: number;
  let sp: number;
  if (stop === undefined) {
    s = 0;
    st = start;
    sp = 1;
  } else {
    s = start;
    st = stop;
    sp = step === undefined ? 1 : step;
  }
  if (sp === 0) throw new RangeError("range step must not be 0");
  const result: number[] = [];
  if (sp > 0) {
    for (let x = s; x < st; x += sp) result.push(x);
  } else {
    for (let x = s; x > st; x += sp) result.push(x);
  }
  return result;
}
