/**
 * True for objects created by `{}`, `Object.create(null)` or `new Object()`.
 * @param {unknown} value
 * @returns {boolean}
 */
export function isPlainObject(value) {
  if (value === null || typeof value !== "object") return false;
  const proto = Object.getPrototypeOf(value);
  return proto === null || proto === Object.prototype;
}

/**
 * A new object with the same own enumerable keys, each value passed through `fn(value, key)`.
 * @param {Record<string, unknown>} obj
 * @param {(value: unknown, key: string) => unknown} fn
 */
export function mapValues(obj, fn) {
  const out = {};
  for (const key of Object.keys(obj)) out[key] = fn(obj[key], key);
  return out;
}

/**
 * A new object with only the listed keys that are own enumerable properties of `obj`,
 * in the order they appear in `keys`.
 * @param {Record<string, unknown>} obj
 * @param {Array<string | symbol>} keys
 * @returns {Record<string, unknown>}
 */
export function pick(obj, keys) {
  const out = {};
  for (const key of keys) {
    if (Object.prototype.propertyIsEnumerable.call(obj, key)) {
      out[key] = obj[key];
    }
  }
  return out;
}

/**
 * A new object with every own enumerable string key of `obj` except the listed ones,
 * in the original key order.
 * @param {Record<string, unknown>} obj
 * @param {Array<string | symbol>} keys
 * @returns {Record<string, unknown>}
 */
export function omit(obj, keys) {
  const out = {};
  const listed = new Set(keys);
  for (const key of Object.keys(obj)) {
    if (!listed.has(key)) {
      out[key] = obj[key];
    }
  }
  return out;
}
