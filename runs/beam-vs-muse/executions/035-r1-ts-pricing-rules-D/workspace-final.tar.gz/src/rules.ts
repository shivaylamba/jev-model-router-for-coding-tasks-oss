import { percentOf } from "./money.ts";
import type { Coupon, CouponStatus, Discount, Order, Totals } from "./types.ts";
import { BUNDLES } from "./bundles.ts";
import type { Bundle } from "./types.ts";

export const VOLUME_MIN_QUANTITY = 10;
export const VOLUME_PERCENT = 10;
export const FREE_SHIPPING_THRESHOLD = 5000;
export const SHIPPING_FEE = 499;
export const TAX_PERCENT = 8;

export type PricedLine = {
  sku: string;
  unitPrice: number;
  quantity: number;
  gross: number;   // unitPrice * quantity
  bundled: number; // units of this line used in bundles; starts at 0
};

export type PricingContext = {
  order: Order;
  coupon: Coupon | undefined;
  lines: PricedLine[];
  subtotal: number;
  discounts: Discount[];
  couponStatus: CouponStatus;
  shipping: number;
  tax: number;
};

export type PricingRule = {
  name: string;
  apply(ctx: PricingContext): void;
};

export function merchandiseTotal(ctx: PricingContext): number {
  let sum = 0;
  for (const d of ctx.discounts) sum += d.amount;
  return ctx.subtotal - sum;
}

export function createPricer(rules: PricingRule[]): (order: Order, coupon?: Coupon) => Totals {
  return (order: Order, coupon?: Coupon): Totals => {
    for (const line of order.lines) {
      if (!Number.isInteger(line.quantity) || line.quantity < 1) {
        throw new RangeError(`bad quantity for ${line.sku}: ${line.quantity}`);
      }
      if (!Number.isInteger(line.unitPrice) || line.unitPrice < 0) {
        throw new RangeError(`bad unit price for ${line.sku}: ${line.unitPrice}`);
      }
    }

    const lines: PricedLine[] = order.lines.map((line) => ({
      sku: line.sku,
      unitPrice: line.unitPrice,
      quantity: line.quantity,
      gross: line.unitPrice * line.quantity,
      bundled: 0,
    }));
    let subtotal = 0;
    for (const l of lines) subtotal += l.gross;

    const ctx: PricingContext = {
      order,
      coupon,
      lines,
      subtotal,
      discounts: [],
      couponStatus: "none",
      shipping: 0,
      tax: 0,
    };

    for (const rule of rules) {
      rule.apply(ctx);
    }

    const merchandise = merchandiseTotal(ctx);
    return {
      subtotal: ctx.subtotal,
      discounts: ctx.discounts,
      merchandise,
      shipping: ctx.shipping,
      tax: ctx.tax,
      total: merchandise + ctx.shipping + ctx.tax,
      coupon: ctx.couponStatus,
    };
  };
}

export function bundleRule(bundles: Bundle[]): PricingRule {
  return {
    name: "bundle",
    apply(ctx: PricingContext): void {
      for (const bundle of bundles) {
        // Determine how many bundles can form.
        let count = Infinity;
        for (const sku of bundle.skus) {
          let unbundled = 0;
          for (const line of ctx.lines) {
            if (line.sku === sku) unbundled += line.quantity - line.bundled;
          }
          if (unbundled < count) count = unbundled;
        }
        if (!Number.isFinite(count) || count <= 0) continue;

        // Take units from earliest lines first for each sku.
        const takenByLine = new Map<number, number>();
        for (const sku of bundle.skus) {
          let remaining = count;
          for (let i = 0; i < ctx.lines.length; i++) {
            const line = ctx.lines[i];
            if (line.sku !== sku) continue;
            const avail = line.quantity - line.bundled;
            if (avail <= 0) continue;
            const take = Math.min(avail, remaining);
            line.bundled += take;
            takenByLine.set(i, (takenByLine.get(i) ?? 0) + take);
            remaining -= take;
            if (remaining <= 0) break;
          }
        }

        // Discount per line.
        let amount = 0;
        for (const [i, taken] of takenByLine) {
          const line = ctx.lines[i];
          amount += percentOf(line.unitPrice * taken, bundle.percent);
        }
        if (amount > 0) {
          ctx.discounts.push({ rule: `bundle:${bundle.id}`, amount });
        }
      }
    },
  };
}

export const volumeRule: PricingRule = {
  name: "volume",
  apply(ctx: PricingContext): void {
    let volume = 0;
    for (const line of ctx.lines) {
      if (line.quantity >= VOLUME_MIN_QUANTITY) {
        const unbundled = line.quantity - line.bundled;
        volume += percentOf(line.unitPrice * unbundled, VOLUME_PERCENT);
      }
    }
    if (volume > 0) {
      ctx.discounts.push({ rule: "volume", amount: volume });
    }
  },
};

export const couponRule: PricingRule = {
  name: "coupon",
  apply(ctx: PricingContext): void {
    const coupon = ctx.coupon;
    if (!coupon) {
      ctx.couponStatus = "none";
      return;
    }
    const hasBundleDiscount = ctx.discounts.some((d) => d.rule.startsWith("bundle:"));
    if (coupon.exclusive && hasBundleDiscount) {
      ctx.couponStatus = "excluded";
      return;
    }
    const merchandise = merchandiseTotal(ctx);
    if (merchandise < (coupon.minSubtotal ?? 0)) {
      ctx.couponStatus = "below-minimum";
      return;
    }
    const off =
      coupon.kind === "percent"
        ? percentOf(merchandise, coupon.value)
        : Math.min(coupon.value, merchandise);
    ctx.couponStatus = "applied";
    if (off > 0) {
      ctx.discounts.push({ rule: `coupon:${coupon.code}`, amount: off });
    }
  },
};

export const shippingRule: PricingRule = {
  name: "shipping",
  apply(ctx: PricingContext): void {
    const merchandise = merchandiseTotal(ctx);
    if (ctx.order.lines.length > 0 && merchandise < FREE_SHIPPING_THRESHOLD) {
      ctx.shipping = SHIPPING_FEE;
    } else {
      ctx.shipping = 0;
    }
  },
};

export const taxRule: PricingRule = {
  name: "tax",
  apply(ctx: PricingContext): void {
    const merchandise = merchandiseTotal(ctx);
    ctx.tax = percentOf(merchandise, TAX_PERCENT);
  },
};

export const defaultRules: PricingRule[] = [
  bundleRule(BUNDLES),
  volumeRule,
  couponRule,
  shippingRule,
  taxRule,
];