import { createPricer } from "../src/rules.ts";
import type { PricingRule, PricingContext } from "../src/rules.ts";
import { merchandiseTotal } from "../src/rules.ts";

const r1: PricingRule = { name: "r1", apply(ctx: PricingContext) { ctx.discounts.push({rule:"r1",amount:10}); } };
const r2: PricingRule = { name: "r2", apply(ctx: PricingContext) { console.log("merch at r2", merchandiseTotal(ctx)); } };
const price = createPricer([r1, r2]);
console.log(JSON.stringify(price({lines:[{sku:"A",unitPrice:100,quantity:2}]}, undefined)));
