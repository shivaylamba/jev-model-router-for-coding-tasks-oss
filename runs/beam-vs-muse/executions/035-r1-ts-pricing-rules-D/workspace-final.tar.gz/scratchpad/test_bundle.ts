
import { orderTotal } from "../src/pricing.ts";

const o = { lines: [
  { sku: "DESK", unitPrice: 10000, quantity: 1 },
  { sku: "CHAIR", unitPrice: 5000, quantity: 1 },
  { sku: "LAMP", unitPrice: 2000, quantity: 2 },
  { sku: "BULB", unitPrice: 500, quantity: 1 },
] };
console.log("basic:", JSON.stringify(orderTotal(o)));

const o2 = { lines: [
  { sku: "DESK", unitPrice: 10000, quantity: 1 },
  { sku: "CHAIR", unitPrice: 5000, quantity: 1 },
  { sku: "LAMP", unitPrice: 2000, quantity: 1 },
  { sku: "BULB", unitPrice: 500, quantity: 1 },
] };
console.log("lamp1:", JSON.stringify(orderTotal(o2)));

const c = { code: "EXCL", kind: "percent" as const, value: 10, exclusive: true };
console.log("excl:", JSON.stringify(orderTotal(o, c as any).coupon));
const c2 = { code: "NONEXCL", kind: "percent" as const, value: 10 };
console.log("nonexcl:", JSON.stringify(orderTotal(o, c2 as any).coupon), JSON.stringify(orderTotal(o, c2 as any).discounts));

const o3 = { lines: [
  { sku: "DESK", unitPrice: 10000, quantity: 1 },
  { sku: "DESK", unitPrice: 9000, quantity: 1 },
  { sku: "CHAIR", unitPrice: 5000, quantity: 1 },
  { sku: "LAMP", unitPrice: 2000, quantity: 1 },
] };
console.log("multilines:", JSON.stringify(orderTotal(o3).discounts));

const o4 = { lines: [{ sku: "PEN", unitPrice: 100, quantity: 10 }] };
console.log("volume only:", JSON.stringify(orderTotal(o4)));
