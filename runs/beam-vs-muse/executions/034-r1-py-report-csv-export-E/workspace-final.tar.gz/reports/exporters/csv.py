"""CSV output."""

class CsvExporter:
    name = "csv"
    extension = ".csv"

    def export(self, report):
        lines = []
        lines.append(_join([c.label for c in report.columns]))
        for row in report.rows:
            cells = []
            for col in report.columns:
                v = report.cell(row, col)
                cells.append(_format_value(v))
            lines.append(_join(cells))
        return "\n".join(lines) + "\n" if lines else ""


def _format_value(v):
    if v is None:
        return ""
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        return format(v, ".2f")
    return str(v)


def _escape_field(s):
    if any(c in s for c in (",", '"', "\n")):
        return '"' + s.replace('"', '""') + '"'
    return s


def _join(fields):
    return ",".join(_escape_field(f) for f in fields)
