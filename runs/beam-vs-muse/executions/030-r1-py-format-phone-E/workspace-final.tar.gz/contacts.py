"""Formatting helpers for contact records."""


def format_name(first, last):
    """'ada', 'LOVELACE' -> 'Ada Lovelace'. Blank parts are skipped."""
    parts = [p.strip().capitalize() for p in (first, last) if p and p.strip()]
    return " ".join(parts)


def normalize_email(email):
    """Trim and lowercase an e-mail address."""
    return email.strip().lower()

def format_us_phone(raw):
    allowed_ignore = set(" ()-+.")
    digits = []
    for ch in raw:
        if ch.isdigit():
            digits.append(ch)
        elif ch in allowed_ignore:
            continue
        else:
            raise ValueError(f"invalid character: {ch!r}")
    s = "".join(digits)
    if len(s) == 11:
        if s[0] != "1":
            raise ValueError("11-digit number must start with 1")
        s = s[1:]
    elif len(s) != 10:
        raise ValueError("phone number must have 10 digits (or 11 starting with 1)")
    if s[0] in "01":
        raise ValueError("area code may not start with 0 or 1")
    if s[3] in "01":
        raise ValueError("exchange may not start with 0 or 1")
    return f"({s[0:3]}) {s[3:6]}-{s[6:10]}"
