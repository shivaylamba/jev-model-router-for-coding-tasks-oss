"""CSV output for machines."""


def _cell(value):
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return format(value, ".2f")
    return str(value)


def _quote(field):
    if ("," in field) or ('"' in field) or ("\n" in field) or ("\r" in field):
        return '"' + field.replace('"', '""') + '"'
    return field


class CsvExporter:
    name = "csv"
    extension = ".csv"

    def export(self, report):
        lines = [",".join(_quote(column.label) for column in report.columns)]
        for row in report.rows:
            lines.append(",".join(_quote(_cell(report.cell(row, column))) for column in report.columns))
        return "".join(line + "\n" for line in lines)
