export interface Transport {
  send(recipient: string, message: string): void;
}

/** Records every send in memory. Handy in tests and dry runs. */
export class MemoryTransport implements Transport {
  sent: Array<{ recipient: string; message: string }> = [];

  send(recipient: string, message: string): void {
    this.sent.push({ recipient, message });
  }
}

export class Notifier {
  private transport: Transport;

  constructor(transport: Transport) {
    this.transport = transport;
  }

  /**
   * Send `message` to recipient(s). Each recipient is trimmed before sending.
   * Throws TypeError if any recipient is empty or only whitespace (before sending anything).
   * Duplicates (case-insensitive after trimming) are only sent once, keeping first spelling.
   * Returns number of messages actually sent.
   */
  notify(recipients: string | readonly string[], message: string): number {
    if (typeof recipients === "string") {
      const to = recipients.trim();
      if (to === "") {
        throw new TypeError("recipient must be a non-empty string");
      }
      this.transport.send(to, message);
      return 1;
    }

    // Validate all first to avoid partial sends
    const trimmed: string[] = [];
    for (const r of recipients) {
      const to = r.trim();
      if (to === "") {
        throw new TypeError("recipient must be a non-empty string");
      }
      trimmed.push(to);
    }

    // Deduplicate case-insensitively, keep first spelling
    const seen = new Set<string>();
    let count = 0;
    for (const to of trimmed) {
      const key = to.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      this.transport.send(to, message);
      count++;
    }
    return count;
  }
}
