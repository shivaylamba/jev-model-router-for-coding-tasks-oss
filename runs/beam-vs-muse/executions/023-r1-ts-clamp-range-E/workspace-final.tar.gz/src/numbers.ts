/** Sum of a list of numbers; 0 for an empty list. */
export function sum(values: readonly number[]): number {
  let total = 0;
  for (const v of values) total += v;
  return total;
}

/** Arithmetic mean. Throws RangeError for an empty list. */
export function mean(values: readonly number[]): number {
  if (values.length === 0) throw new RangeError("mean of an empty list");
  return sum(values) / values.length;
}

/** Clamp value to the closed interval [min, max]. Throws RangeError if min > max. */
export function clamp(value: number, min: number, max: number): number {
  if (min > max) throw new RangeError("min must not be greater than max");
  if (value < min) return min;
  if (value > max) return max;
  return value;
}

/** Generate a range of numbers like Python's range. Stop is excluded. Throws RangeError if step is 0. */
export function range(start: number, stop?: number, step?: number): number[] {
  if (stop === undefined) {
    stop = start;
    start = 0;
  }
  if (step === undefined) {
    step = 1;
  }
  if (step === 0) throw new RangeError("step must not be 0");

  const result: number[] = [];
  if (step > 0) {
    for (let v = start; v < stop; v += step) result.push(v);
  } else {
    for (let v = start; v > stop; v += step) result.push(v);
  }
  return result;
}
