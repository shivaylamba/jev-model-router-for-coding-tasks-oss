import { createPricer, defaultRules } from "./rules.ts";

export const orderTotal = createPricer(defaultRules);

// Re-export constants for backwards compat if needed
export { FREE_SHIPPING_THRESHOLD, SHIPPING_FEE, TAX_PERCENT, VOLUME_MIN_QUANTITY, VOLUME_PERCENT } from "./rules.ts";
