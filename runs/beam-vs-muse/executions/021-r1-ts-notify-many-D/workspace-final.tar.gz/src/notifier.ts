export interface Transport {
  send(recipient: string, message: string): void;
}

/** Records every send in memory. Handy in tests and dry runs. */
export class MemoryTransport implements Transport {
  sent: Array<{ recipient: string; message: string }> = [];

  send(recipient: string, message: string): void {
    this.sent.push({ recipient, message });
  }
}

export class Notifier {
  private transport: Transport;

  constructor(transport: Transport) {
    this.transport = transport;
  }

  /**
   * Send `message` to one or more recipients. A single string behaves as before;
   * an array sends to each recipient in order. Recipients are trimmed before
   * sending. Duplicates (case-insensitive after trimming) are sent only once,
   * using the first spelling. Throws TypeError if any recipient is blank, before
   * sending anything. Returns the number of messages actually sent.
   */
  notify(recipients: string | readonly string[], message: string): number {
    if (typeof recipients === "string") {
      const to = recipients.trim();
      if (to === "") {
        throw new TypeError("recipient must be a non-empty string");
      }
      this.transport.send(to, message);
      return 1;
    }

    const trimmed = recipients.map((recipient) => recipient.trim());
    for (const to of trimmed) {
      if (to === "") {
        throw new TypeError("recipient must be a non-empty string");
      }
    }

    const seen = new Set<string>();
    let sent = 0;
    for (const to of trimmed) {
      const key = to.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      this.transport.send(to, message);
      sent++;
    }
    return sent;
  }
}
