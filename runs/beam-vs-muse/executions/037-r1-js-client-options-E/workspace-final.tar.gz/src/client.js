import { deprecate } from "./deprecate.js";

const ALLOWED = new Set(["baseUrl", "token", "timeoutMs", "retries", "headers"]);

function isPlainObject(v) {
  return v !== null && typeof v === "object" && Object.getPrototypeOf(v) === Object.prototype;
}

function normalizeOptions(raw) {
  for (const k of Object.keys(raw)) {
    if (!ALLOWED.has(k)) throw new TypeError(`Unknown option: ${k}`);
  }
  let { baseUrl, token, timeoutMs, retries, headers } = raw;
  if (timeoutMs === undefined) timeoutMs = 5000;
  if (retries === undefined) retries = 0;
  if (headers === undefined) headers = {};
  // token stays undefined if not given

  if (typeof baseUrl !== "string" || baseUrl === "") {
    throw new TypeError("baseUrl must be a non-empty string");
  }
  if (typeof timeoutMs !== "number" || !Number.isFinite(timeoutMs) || timeoutMs <= 0) {
    throw new RangeError("timeoutMs must be a finite number greater than 0");
  }
  if (!Number.isInteger(retries) || retries < 0) {
    throw new RangeError("retries must be an integer >= 0");
  }

  return Object.freeze({
    baseUrl: baseUrl.replace(/\/+$/, ""),
    token,
    timeoutMs,
    retries,
    headers,
  });
}

export function createClient(arg1, token, timeoutMs = 5000, retries = 0) {
  let options;
  if (typeof arg1 === "string") {
    deprecate("CLIENT_POSITIONAL_ARGS", "createClient positional arguments are deprecated, use options object");
    const raw = { baseUrl: arg1 };
    if (token !== undefined) raw.token = token;
    if (timeoutMs !== undefined) raw.timeoutMs = timeoutMs;
    if (retries !== undefined) raw.retries = retries;
    // headers default
    options = normalizeOptions(raw);
  } else if (isPlainObject(arg1)) {
    // treat undefined values as not given
    const raw = {};
    for (const [k, v] of Object.entries(arg1)) {
      if (v !== undefined) raw[k] = v;
    }
    options = normalizeOptions(raw);
  } else {
    throw new TypeError("createClient requires a baseUrl string or options object");
  }

  return {
    options,
    request(transport, method, path, body) {
      const headers = { accept: "application/json", ...options.headers };
      if (options.token) headers.authorization = `Bearer ${options.token}`;
      if (body !== undefined) headers["content-type"] = "application/json";
      return transport({
        method,
        url: options.baseUrl + (path.startsWith("/") ? path : `/${path}`),
        headers,
        body: body === undefined ? undefined : JSON.stringify(body),
        timeoutMs: options.timeoutMs,
        retries: options.retries,
      });
    },
  };
}
