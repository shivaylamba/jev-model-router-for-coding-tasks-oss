import asyncio
import unittest

from ratelimit import RateLimiter
from tests.fake_time import FakeTime, settle


class LimiterTest(unittest.IsolatedAsyncioTestCase):
    def make(self, rate=2.0, burst=5, mc=10, start=0.0):
        ft = FakeTime(start)
        rl = RateLimiter(rate=rate, burst=burst, max_concurrent=mc, clock=ft.clock, sleep=ft.sleep)
        return ft, rl

    async def test_ctor_validation(self):
        ft = FakeTime()
        for kwargs in [
            dict(rate=0, burst=1, max_concurrent=1, clock=ft.clock, sleep=ft.sleep),
            dict(rate=-1, burst=1, max_concurrent=1, clock=ft.clock, sleep=ft.sleep),
            dict(rate=1, burst=0, max_concurrent=1, clock=ft.clock, sleep=ft.sleep),
            dict(rate=1, burst=1, max_concurrent=0, clock=ft.clock, sleep=ft.sleep),
        ]:
            with self.assertRaises(ValueError):
                RateLimiter(**kwargs)

    async def test_invalid_types(self):
        ft = FakeTime()
        with self.assertRaises(ValueError):
            RateLimiter(rate="1", burst=1, max_concurrent=1, clock=ft.clock, sleep=ft.sleep)
        with self.assertRaises(ValueError):
            RateLimiter(rate=1.0, burst=1.5, max_concurrent=1, clock=ft.clock, sleep=ft.sleep)
        with self.assertRaises(ValueError):
            RateLimiter(rate=1.0, burst=1, max_concurrent=1.0, clock=ft.clock, sleep=ft.sleep)

    async def test_release_nothing(self):
        ft, rl = self.make()
        with self.assertRaises(RuntimeError):
            rl.release()

    async def test_basic_grant(self):
        ft, rl = self.make()
        await rl.acquire("k")
        self.assertEqual(rl.in_use, 1)
        self.assertEqual(rl.tokens("k"), 4.0)
        self.assertEqual(rl.waiting("k"), 0)
        rl.release()
        self.assertEqual(rl.in_use, 0)

    async def test_never_used_tokens(self):
        ft, rl = self.make(burst=3)
        self.assertEqual(rl.tokens("missing"), 3.0)
        self.assertEqual(rl.waiting(), 0)

    async def test_limit_context_manager(self):
        ft, rl = self.make()
        async with rl.limit("k"):
            self.assertEqual(rl.in_use, 1)
        self.assertEqual(rl.in_use, 0)

    async def test_limit_releases_on_exception(self):
        ft, rl = self.make()
        try:
            async with rl.limit("k"):
                raise ValueError("boom")
        except ValueError:
            pass
        self.assertEqual(rl.in_use, 0)

    async def test_mc_cap_slot_wait(self):
        ft, rl = self.make(mc=1)
        await rl.acquire("a")
        self.assertEqual(rl.in_use, 1)

        # second acquires a token? bucket a has token but no slot -> waits
        async def second():
            await rl.acquire("b")
            return "done"

        task = asyncio.ensure_future(second())
        await settle()
        self.assertFalse(task.done())
        self.assertEqual(rl.waiting(), 1)
        # release frees slot -> grants b inside release, in_use stays 1
        rl.release()
        self.assertEqual(rl.in_use, 1)
        await settle()
        self.assertTrue(task.done())
        rl.release()
        self.assertEqual(rl.in_use, 0)

    async def test_token_wait_sleep(self):
        ft, rl = self.make(rate=2.0, burst=1, mc=10)
        await rl.acquire("k")  # consumes the one token
        rl.release()
        # now no token for k; capacity 1 with 0 tokens; need 0.5s
        async def second():
            await rl.acquire("k")
            return ft.now

        task = asyncio.ensure_future(second())
        # let it sleep
        await settle()
        self.assertFalse(task.done())
        # sleep called with 0.5
        self.assertEqual(ft.sleep_calls[-1], 0.5)
        # advance time enough
        await ft.advance(0.5)
        self.assertTrue(task.done())
        self.assertEqual(task.result(), 0.5)
        rl.release()

    async def test_exact_sleep_no_poll(self):
        ft, rl = self.make(rate=2.0, burst=1, mc=10)
        await rl.acquire("k")
        rl.release()
        ft.sleep_calls.clear()
        async def second():
            await rl.acquire("k")
        task = asyncio.ensure_future(second())
        await settle()
        # exactly one sleep call before cancellation/finish? let's inspect
        await ft.advance(0.5)
        await settle()
        # sleep_calls contains 0.5
        self.assertIn(0.5, ft.sleep_calls)
        rl.release()

    async def test_fifo_per_key(self):
        ft, rl = self.make(rate=100.0, burst=1, mc=1)  # one token, one slot
        # first grabs
        await rl.acquire("k")
        # queue two more; only one slot/token constraints
        async def r1():
            await rl.acquire("k")
            return "r1"

        async def r2():
            await rl.acquire("k")
            return "r2"

        t1 = asyncio.ensure_future(r1())
        t2 = asyncio.ensure_future(r2())
        await settle()
        # both waiting (token? after token consumed; head r1 waits token ~0.01s; r2 behind)
        self.assertEqual(rl.waiting("k"), 2)
        # advance time so a token is available for the head
        await ft.advance(0.05)
        await settle()
        # release slot; grant pass should grant r1 (earliest)
        rl.release()
        await settle()
        self.assertTrue(t1.done())
        self.assertFalse(t2.done())
        if rl.in_use:
            rl.release()
        await settle()
        # cleanup
        if rl.in_use:
            rl.release()

    async def test_cross_key_earliest(self):
        ft, rl = self.make(rate=1.0, burst=1, mc=1)
        # no initial tokens? set start 0, buckets full burst 1. Use one token each? We'll hold
        # Key a acquires first
        await rl.acquire("a")
        # b wants slot but has token
        async def b():
            await rl.acquire("b")
            return "b"
        bt = asyncio.ensure_future(b())
        await settle()
        # a still held (no release), b waiting slot
        self.assertFalse(bt.done())
        rl.release()  # grants b (slot + token)
        await settle()
        self.assertTrue(bt.done())
        rl.release()

    async def test_cancellation_ungranted(self):
        ft, rl = self.make(rate=1.0, burst=1, mc=1)
        await rl.acquire("a")  # hold slot

        async def waiter():
            await rl.acquire("b")

        task = asyncio.ensure_future(waiter())
        await settle()
        self.assertEqual(rl.waiting(), 1)
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        await settle()
        self.assertEqual(rl.waiting(), 0)
        # still held by a
        self.assertEqual(rl.in_use, 1)
        self.assertEqual(rl.tokens("b"), 1.0)  # never consumed
        rl.release()

    async def test_cancellation_granted_undo(self):
        ft, rl = self.make(rate=10.0, burst=1, mc=2)
        # Fill slot cap? mc=2, so auto grant. Need scenario granted but not returned:
        # Make head wait for token then becomes granted by another? Simpler:
        # mc=1, b waits slot with token. Then release a grants b inside release.
        # Cancel b's task after release but before it resumes? Hard to hit.
        # Instead use concurrency: acquire a; b waits slot holding? b's acquire running passive.
        ft2, rl2 = self.make(rate=10.0, burst=1, mc=1)
        await rl2.acquire("a")  # slot held
        # b has token, waits slot
        async def btask():
            await rl2.acquire("b")
            await asyncio.sleep(0)  # keep held
            return "ok"

        task = asyncio.ensure_future(btask())
        await settle()
        self.assertEqual(rl2.waiting(), 1)
        # cancel a? no. Release a grants b synchronously; btask scheduled but not run.
        rl2.release()
        # b now granted but not returned; in_use back to 1
        self.assertEqual(rl2.in_use, 1)
        self.assertEqual(rl2.waiting(), 0)
        # cancel before resume
        task.cancel()
        await asyncio.sleep(0)
        try:
            await task
        except asyncio.CancelledError:
            pass
        await settle()
        # grant undone: slot freed, token back
        self.assertEqual(rl2.in_use, 0)
        self.assertEqual(rl2.tokens("b"), 1.0)

    async def test_cancellation_head_starts_next(self):
        ft, rl = self.make(rate=1.0, burst=1, mc=10)
        await rl.acquire("x")  # consumes token
        rl.release()

        async def slow():
            await rl.acquire("x")  # token wait

        t = asyncio.ensure_future(slow())
        await settle()
        # cancel it
        t.cancel()
        try:
            await t
        except asyncio.CancelledError:
            pass
        await settle()
        # no waiters
        self.assertEqual(rl.waiting("x"), 0)

    async def test_waiting_key_none(self):
        ft, rl = self.make()
        await rl.acquire("a")
        # b waits slot if mc=1; use mc=1
        ft2, rl2 = self.make(mc=1)
        await rl2.acquire("a")

        async def b():
            await rl2.acquire("b")

        task = asyncio.ensure_future(b())
        await settle()
        self.assertEqual(rl2.waiting(), 1)
        self.assertEqual(rl2.waiting("b"), 1)
        self.assertEqual(rl2.waiting("a"), 0)
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        rl2.release()


if __name__ == "__main__":
    unittest.main()
