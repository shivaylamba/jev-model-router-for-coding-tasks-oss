"""Asyncio rate limiter: per-key token buckets plus a global concurrency cap.

See SPEC.md for the full behaviour.
"""

import asyncio

from ratelimit.bucket import TokenBucket


class _Request:
    __slots__ = ("key", "seq", "granted", "event")

    def __init__(self, key, seq):
        self.key = key
        self.seq = seq
        self.granted = False
        self.event = None


class RateLimiter:
    def __init__(self, rate, burst, max_concurrent, *, clock, sleep):
        if isinstance(rate, bool) or not isinstance(rate, (int, float)):
            raise ValueError("rate must be a number")
        if rate <= 0:
            raise ValueError("rate must be positive")
        if isinstance(burst, bool) or not isinstance(burst, int):
            raise ValueError("burst must be an int")
        if burst < 1:
            raise ValueError("burst must be at least 1")
        if isinstance(max_concurrent, bool) or not isinstance(max_concurrent, int):
            raise ValueError("max_concurrent must be an int")
        if max_concurrent < 1:
            raise ValueError("max_concurrent must be at least 1")

        self.rate = rate
        self.burst = burst
        self.max_concurrent = max_concurrent
        self._clock = clock
        self._sleep = sleep

        self._buckets = {}
        self._queues = {}
        self._held = 0
        self._seq = 0

    def _bucket(self, key):
        if key not in self._buckets:
            self._buckets[key] = TokenBucket(self.rate, self.burst, self._clock)
        return self._buckets[key]

    def _heads(self):
        heads = []
        for q in self._queues.values():
            for r in q:
                if not r.granted:
                    heads.append(r)
                    break
        return heads

    def _grant_pass(self):
        while True:
            best = None
            for r in self._heads():
                if r.granted:
                    continue
                bucket = self._buckets.get(r.key)
                if bucket is None:
                    continue
                if bucket.available() < 1:
                    continue
                if self._held >= self.max_concurrent:
                    continue
                if best is None or r.seq < best.seq:
                    best = r
            if best is None:
                break
            bucket = self._buckets[best.key]
            if not bucket.try_take():
                break
            self._held += 1
            best.granted = True
            q = self._queues.get(best.key)
            if q is not None and best in q:
                q.remove(best)
            if best.event is not None:
                best.event.set()
        for r in self._heads():
            if r.event is not None:
                r.event.set()

    def _undo_grant(self, req):
        bucket = self._buckets.get(req.key)
        if bucket is not None:
            bucket.return_token()
        self._held -= 1

    async def acquire(self, key):
        bucket = self._bucket(key)
        self._seq += 1
        req = _Request(key, self._seq)
        req.event = asyncio.Event()
        self._queues.setdefault(key, []).append(req)

        try:
            while True:
                self._grant_pass()
                if req.granted:
                    return
                q = self._queues.get(key, [])
                is_head = bool(q) and q[0] is req
                if is_head:
                    delay = bucket.time_until_available()
                    if delay and delay > 0:
                        await self._sleep(delay)
                        continue
                req.event.clear()
                await req.event.wait()
        except asyncio.CancelledError:
            if req.granted:
                self._undo_grant(req)
                req.granted = False
            else:
                q = self._queues.get(key)
                if q is not None and req in q:
                    q.remove(req)
            self._grant_pass()
            raise

    def release(self):
        if self._held <= 0:
            raise RuntimeError("no slot held")
        self._held -= 1
        self._grant_pass()

    def limit(self, key):
        limiter = self

        class _Ctx:
            async def __aenter__(self_inner):
                await limiter.acquire(key)
                return self_inner

            async def __aexit__(self_inner, exc_type, exc, tb):
                limiter.release()
                return False

        return _Ctx()

    @property
    def in_use(self):
        return self._held

    def tokens(self, key):
        bucket = self._bucket(key)
        return float(bucket.available())

    def waiting(self, key=None):
        if key is None:
            return sum(len(q) for q in self._queues.values())
        q = self._queues.get(key)
        return len(q) if q is not None else 0
