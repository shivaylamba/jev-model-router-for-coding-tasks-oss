def slugify(text):
    """Turn a title into a URL slug.

    - lowercase
    - letters and digits are kept; every run of other characters becomes one hyphen
    - no leading or trailing hyphen
    - an input with no letters or digits gives the empty string
    """
    parts = []
    kept = False
    for ch in text.lower():
        if ch.isalnum():
            parts.append(ch)
            kept = True
        elif kept:
            parts.append('-')
            kept = False
    return ''.join(parts).strip('-')
