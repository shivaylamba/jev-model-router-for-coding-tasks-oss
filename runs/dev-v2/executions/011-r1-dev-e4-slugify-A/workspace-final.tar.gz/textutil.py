def slugify(text):
    """Turn a title into a URL slug.

    - lowercase
    - letters and digits are kept; every run of other characters becomes one hyphen
    - no leading or trailing hyphen
    - an input with no letters or digits gives the empty string
    """
    parts = []
    current = []
    for ch in text.lower():
        if ch.isalnum():
            current.append(ch)
        elif current:
            parts.append("".join(current))
            current = []
    if current:
        parts.append("".join(current))
    return "-".join(parts)
