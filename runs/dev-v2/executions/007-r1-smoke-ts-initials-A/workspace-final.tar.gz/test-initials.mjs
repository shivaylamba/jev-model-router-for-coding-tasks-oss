import { initials } from './src/names.ts';

const cases = [
  ["mary-jane van der berg", "MJVDB"],
  ["  john   doe  ", "JD"],
  ["", ""],
  ["   ", ""],
  [" \t  ", ""],
  [" \t -  ", ""],
  ["anne-marie", "AM"],
  ["jean-luc  picard", "JP"],
  ["a", "A"],
  ["--x--y--", "XY"],
  ["mary - jane", "MJ"],
  ["  O'Brien ", "O"],
];
let ok = true;
for (const [input, want] of cases) {
  const got = initials(input);
  const pass = got === want;
  if (!pass) ok = false;
  console.log(`${pass ? "PASS" : "FAIL"} initials(${JSON.stringify(input)}) = ${JSON.stringify(got)} (want ${JSON.stringify(want)})`);
}
process.exit(ok ? 0 : 1);
