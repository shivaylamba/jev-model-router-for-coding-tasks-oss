from collections import OrderedDict


class TTLCache:
    """A small cache with a size limit and per-entry expiry.

    TTLCache(max_size, ttl, clock) where clock() returns the current time in seconds.

    - set(key, value): store the value; it expires `ttl` seconds after this call.
      Setting an existing key replaces the value and restarts its expiry.
    - get(key, default=None): return the value, or default if missing or expired.
      A successful get makes the key the most recently used.
    - When a set would exceed max_size, expired entries are dropped first; if it is
      still full, the least recently used entry is evicted.
    - len(cache) counts only entries that have not expired.
    - `key in cache` is True only for entries that have not expired, and does not
      change which entry is least recently used.
    """

    def __init__(self, max_size, ttl, clock):
        self._max_size = max_size
        self._ttl = ttl
        self._clock = clock
        # Maps key -> (value, expires_at). Order = least to most recently used.
        self._data = OrderedDict()

    def _drop_expired(self):
        now = self._clock()
        for key in [k for k, (_, exp) in self._data.items() if exp <= now]:
            del self._data[key]

    def _live_entry(self, key):
        """Return (value, expires_at) if key exists and is unexpired, else None.

        Removes the entry if it has expired. Never changes recency order.
        """
        entry = self._data.get(key)
        if entry is None:
            return None
        if entry[1] <= self._clock():
            del self._data[key]
            return None
        return entry

    def set(self, key, value):
        expires_at = self._clock() + self._ttl
        if key in self._data:
            # Replace value and restart expiry; recency order is unchanged.
            self._data[key] = (value, expires_at)
            return
        self._drop_expired()
        while len(self._data) >= self._max_size and self._data:
            self._data.popitem(last=False)  # evict least recently used
        if self._max_size > 0:
            self._data[key] = (value, expires_at)

    def get(self, key, default=None):
        entry = self._live_entry(key)
        if entry is None:
            return default
        self._data.move_to_end(key)
        return entry[0]

    def __len__(self):
        self._drop_expired()
        return len(self._data)

    def __contains__(self, key):
        # No move_to_end: membership checks must not affect recency.
        return self._live_entry(key) is not None
