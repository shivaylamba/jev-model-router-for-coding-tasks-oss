import argparse

def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", default="world")
    parser.add_argument("--upper", action="store_true",
                        help="print the greeting in uppercase")
    args = parser.parse_args(argv)
    greeting = f"Hello, {args.name}!"
    if args.upper:
        greeting = greeting.upper()
    return greeting

if __name__ == "__main__":
    print(main())
