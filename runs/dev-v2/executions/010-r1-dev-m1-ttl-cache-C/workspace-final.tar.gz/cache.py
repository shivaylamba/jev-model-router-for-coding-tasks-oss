from collections import OrderedDict


class TTLCache:
    """A small cache with a size limit and per-entry expiry.

    TTLCache(max_size, ttl, clock) where clock() returns the current time in seconds.

    - set(key, value): store the value; it expires `ttl` seconds after this call.
      Setting an existing key replaces the value and restarts its expiry.
    - get(key, default=None): return the value, or default if missing or expired.
      A successful get makes the key the most recently used.
    - When a set would exceed max_size, expired entries are dropped first; if it is
      still full, the least recently used entry is evicted.
    - len(cache) counts only entries that have not expired.
    - `key in cache` is True only for entries that have not expired, and does not
      change which entry is least recently used.
    """

    def __init__(self, max_size, ttl, clock):
        self.max_size = max_size
        self.ttl = ttl
        self.clock = clock
        # key -> (value, expire_at); insertion order tracks least-to-most recently used.
        self._data = OrderedDict()

    def set(self, key, value):
        now = self.clock()
        expire_at = now + self.ttl
        if key in self._data:
            # Replacing restarts expiry and makes the key the most recently used.
            del self._data[key]
        self._data[key] = (value, expire_at)

        if len(self._data) <= self.max_size:
            return

        # Drop expired entries first.
        expired = [k for k, (_, exp) in self._data.items() if exp <= now]
        for k in expired:
            del self._data[k]

        # If still full, evict least recently used until under the limit.
        while len(self._data) > self.max_size:
            self._data.popitem(last=False)

    def get(self, key, default=None):
        now = self.clock()
        item = self._data.get(key)
        if item is None:
            return default
        value, expire_at = item
        if expire_at <= now:
            del self._data[key]
            return default
        # A successful get makes the key the most recently used.
        self._data.move_to_end(key)
        return value

    def __len__(self):
        now = self.clock()
        return sum(1 for _, expire_at in self._data.values() if expire_at > now)

    def __contains__(self, key):
        now = self.clock()
        item = self._data.get(key)
        if item is None:
            return False
        if item[1] <= now:
            del self._data[key]
            return False
        return True