import users

# Paginacao com limit=4
r1 = users.list_users(limit=4)
print('page1 ids:', [u['id'] for u in r1['items']], 'next:', r1['next_cursor'])
r2 = users.list_users(limit=4, cursor=r1['next_cursor'])
print('page2 ids:', [u['id'] for u in r2['items']], 'next:', r2['next_cursor'])
r3 = users.list_users(limit=4, cursor=r2['next_cursor'])
print('page3 ids:', [u['id'] for u in r3['items']], 'next:', r3['next_cursor'])
r4 = users.list_users(limit=4, cursor=r3['next_cursor'])
print('page4 ids:', [u['id'] for u in r4['items']], 'next:', r4['next_cursor'])

# Default retorna todos, next_cursor None
d = users.list_users()
assert len(d['items']) == 11, 'default should return all'
assert d['next_cursor'] is None
print('default ok:', len(d['items']), [u['id'] for u in d['items']])

# Ordenacao por id
allids = [u['id'] for u in r1['items'] + r2['items'] + r3['items'] + r4['items']]
assert allids == sorted(allids), 'not sorted by id'
print('sorted ok:', allids)

# Bad cursors -> ValueError
for bad in ['not-a-cursor', '', 123, '!!!', 45.0, None]:
    try:
        users.list_users(cursor=bad)
        print('NO RAISE for cursor', repr(bad))
    except ValueError:
        pass
print('bad cursor ValueError ok')

# Bad limits -> ValueError
for L in [0, -1, 101, '5', 1.5, 200]:
    try:
        users.list_users(limit=L)
        print('NO RAISE for limit', repr(L))
    except ValueError:
        pass
print('bad limit ValueError ok')

# Inclusive bounds OK
users.list_users(limit=1)
users.list_users(limit=100)
print('bounds 1..100 ok')
print('ALL TESTS PASSED')