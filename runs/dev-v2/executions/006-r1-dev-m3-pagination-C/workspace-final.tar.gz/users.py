import base64
import binascii

USERS = [{"id": i, "name": f"user{i}"} for i in (7, 3, 12, 1, 9, 4, 15, 2, 20, 6, 11)]


def _encode_cursor(user_id):
    """Encode a user id into an opaque, stable cursor string."""
    return base64.urlsafe_b64encode(str(user_id).encode()).decode().rstrip("=")


def _decode_cursor(cursor):
    """Decode an opaque cursor back to a user id; malformed cursors raise ValueError."""
    if not isinstance(cursor, str):
        raise ValueError("invalid cursor")
    try:
        padded = cursor + "=" * (-len(cursor) % 4)
        user_id = int(base64.urlsafe_b64decode(padded.encode()).decode())
    except (ValueError, UnicodeDecodeError, binascii.Error):
        raise ValueError("invalid cursor")
    return user_id


def list_users(limit=20, cursor=None):
    if not isinstance(limit, int) or isinstance(limit, bool) or not 1 <= limit <= 100:
        raise ValueError("limit must be an integer between 1 and 100")

    by_id = sorted(USERS, key=lambda u: u["id"])
    start_id = _decode_cursor(cursor) if cursor is not None else 0
    filtered = [u for u in by_id if u["id"] > start_id]
    page = filtered[:limit]

    next_cursor = None
    if len(filtered) > limit:
        next_cursor = _encode_cursor(page[-1]["id"])

    return {"items": page, "next_cursor": next_cursor}