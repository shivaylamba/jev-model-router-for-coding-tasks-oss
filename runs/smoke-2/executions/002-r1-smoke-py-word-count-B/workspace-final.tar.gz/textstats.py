"""Text statistics."""

import re


def word_counts(text):
    """Return a dict mapping each lowercase word to its count."""
    words = re.findall(r"[a-z0-9']+", text.lower())
    counts = {}
    for word in words:
        counts[word] = counts.get(word, 0) + 1
    return counts
