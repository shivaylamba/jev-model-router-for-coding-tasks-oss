export function fullName(first: string, last: string): string {
  return `${first} ${last}`.trim();
}

export function initials(name: string): string {
  return (name.match(/[^ -]+/g) ?? [])
    .map((word) => word[0].toUpperCase())
    .join("");
}
