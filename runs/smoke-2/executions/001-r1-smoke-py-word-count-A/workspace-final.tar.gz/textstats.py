"""Text statistics."""

import re


def word_counts(text):
    """Return a dict mapping each lowercase word to its occurrence count.

    Words are maximal runs of letters, digits, or apostrophes; every other
    character acts as a separator.
    """
    counts = {}
    for match in re.findall(r"[A-Za-z0-9']+", text):
        word = match.lower()
        counts[word] = counts.get(word, 0) + 1
    return counts
