/**
 * Units from largest to smallest, with their abbreviation and long name.
 * `key` is the abbreviation used in compact style and for the `smallest` option.
 */
const UNITS = [
  { key: "d", name: "day", size: 86_400_000 },
  { key: "h", name: "hour", size: 3_600_000 },
  { key: "m", name: "minute", size: 60_000 },
  { key: "s", name: "second", size: 1_000 },
  { key: "ms", name: "millisecond", size: 1 },
];

const KEY_INDEX = new Map(UNITS.map((unit, i) => [unit.key, i]));

/**
 * Format a number of milliseconds into a readable duration string.
 *
 * @param {number} ms The duration in milliseconds (floored, then split).
 * @param {{units?: number, style?: "long"|"compact", smallest?:
 *   "d"|"h"|"m"|"s"|"ms"}} options
 *   - `units`   max non-zero units to show (largest first), default 2.
 *   - `style`   "long" (`1 hour, 5 minutes`) or "compact" (`1h 5m`).
 *   - `smallest` (default "s") smallest unit that may appear.
 * @returns {string}
 */
export function formatDuration(ms, options = {}) {
  if (typeof ms !== "number") throw new TypeError("ms must be a number");
  if (!Number.isFinite(ms) || ms < 0) {
    throw new RangeError("ms must be a finite, non-negative number");
  }

  const { units = 2, style = "long", smallest = "s" } = options;

  if (!Number.isInteger(units) || units < 1) {
    throw new RangeError("units must be a positive integer");
  }
  if (style !== "long" && style !== "compact") {
    throw new RangeError("style must be 'long' or 'compact'");
  }
  const smallestIndex = KEY_INDEX.get(smallest);
  if (smallestIndex === undefined) {
    throw new RangeError("smallest must be one of 'd', 'h', 'm', 's', 'ms'");
  }

  // Floor first, then split down to (and including) `smallest`. Whatever is
  // left below the smallest shown unit is dropped, never rounded.
  const value = Math.floor(ms);
  let rest = value;
  const counts = [];
  for (let i = 0; i <= smallestIndex; i++) {
    const unit = UNITS[i];
    counts.push({ unit, count: Math.floor(rest / unit.size) });
    rest = rest % unit.size;
  }

  // Only the largest `units` non-zero units appear (they are already
  // largest-first). If none survive, show zero in the smallest unit.
  const shown = counts.filter((c) => c.count > 0).slice(0, units);

  if (shown.length === 0) {
    const unit = UNITS[smallestIndex];
    return style === "compact" ? `0${unit.key}` : `0 ${unit.name}s`;
  }

  const parts = shown.map(({ unit, count }) =>
    style === "compact"
      ? `${count}${unit.key}`
      : `${count} ${count === 1 ? unit.name : `${unit.name}s`}`
  );
  return parts.join(style === "compact" ? " " : ", ");
}