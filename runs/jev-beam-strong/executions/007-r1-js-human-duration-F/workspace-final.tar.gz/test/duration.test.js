import { test } from "node:test";
import assert from "node:assert/strict";
import { formatDuration } from "../src/duration.js";

const MIN = 60_000;
const HOUR = 3_600_000;
const DAY = 86_400_000;

test("long style, default options", () => {
  assert.equal(formatDuration(1_500), "1 second");
  assert.equal(formatDuration(0), "0 seconds");
  assert.equal(formatDuration(2_000), "2 seconds");
  assert.equal(formatDuration(HOUR + 5 * MIN), "1 hour, 5 minutes");
  assert.equal(formatDuration(59 * MIN + 59_999), "59 minutes, 59 seconds");
});

test("milliseconds only appear with smallest: ms", () => {
  assert.equal(formatDuration(1_500, { smallest: "ms" }), "1 second, 500 milliseconds");
  assert.equal(formatDuration(1500), "1 second");
  assert.equal(formatDuration(1_750, { smallest: "ms" }), "1 second, 750 milliseconds");
});

test("smallest drops sub-units, never rounds", () => {
  assert.equal(formatDuration(59 * MIN + 59_999), "59 minutes, 59 seconds");
  assert.equal(formatDuration(HOUR + 30_000, { smallest: "m" }), "1 hour");
  assert.equal(formatDuration(MIN + 999, { smallest: "s" }), "1 minute");
});

test("units shows only the largest non-zero units", () => {
  assert.equal(formatDuration(DAY + 5 * MIN, { units: 2 }), "1 day, 5 minutes");
  assert.equal(formatDuration(HOUR + MIN + 1_000, { units: 1 }), "1 hour");
  assert.equal(formatDuration(HOUR + MIN + 1_000, { units: 3 }), "1 hour, 1 minute, 1 second");
});

test("zero falls back to the smallest unit", () => {
  assert.equal(formatDuration(500), "0 seconds");
  assert.equal(formatDuration(30_000, { smallest: "m" }), "0 minutes");
  assert.equal(formatDuration(50_000, { smallest: "d" }), "0 days");
  assert.equal(formatDuration(0.5, { smallest: "ms" }), "0 milliseconds");
});

test("singular only when the number is 1", () => {
  assert.equal(formatDuration(1_000), "1 second");
  assert.equal(formatDuration(2_000), "2 seconds");
  assert.equal(formatDuration(60_000), "1 minute");
  assert.equal(formatDuration(12 * HOUR), "12 hours");
  assert.equal(formatDuration(1), "0 seconds");
});

test("compact style", () => {
  assert.equal(formatDuration(HOUR + 5 * MIN, { style: "compact" }), "1h 5m");
  assert.equal(formatDuration(HOUR + MIN + 1_000, { style: "compact", units: 3 }), "1h 1m 1s");
  assert.equal(formatDuration(500, { style: "compact" }), "0s");
  assert.equal(formatDuration(30_000, { style: "compact", smallest: "m" }), "0m");
  assert.equal(formatDuration(DAY + 5 * MIN, { style: "compact" }), "1d 5m");
});

test("throws on bad ms", () => {
  assert.throws(() => formatDuration("5"), TypeError);
  assert.throws(() => formatDuration(null), TypeError);
  assert.throws(() => formatDuration(-5), RangeError);
  assert.throws(() => formatDuration(NaN), RangeError);
  assert.throws(() => formatDuration(Infinity), RangeError);
  assert.throws(() => formatDuration(-Infinity), RangeError);
});

test("throws on bad options", () => {
  assert.throws(() => formatDuration(1000, { units: 0 }), RangeError);
  assert.throws(() => formatDuration(1000, { units: -1 }), RangeError);
  assert.throws(() => formatDuration(1000, { units: 1.5 }), RangeError);
  assert.throws(() => formatDuration(1000, { units: "2" }), RangeError);
  assert.throws(() => formatDuration(1000, { style: "longhand" }), RangeError);
  assert.throws(() => formatDuration(1000, { smallest: "y" }), RangeError);
});