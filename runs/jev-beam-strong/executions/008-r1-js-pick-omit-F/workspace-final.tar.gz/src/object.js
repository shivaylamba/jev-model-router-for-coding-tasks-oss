/**
 * True for objects created by `{}`, `Object.create(null)` or `new Object()`.
 * @param {unknown} value
 * @returns {boolean}
 */
export function isPlainObject(value) {
  if (value === null || typeof value !== "object") return false;
  const proto = Object.getPrototypeOf(value);
  return proto === null || proto === Object.prototype;
}

/**
 * A new object with the same own enumerable keys, each value passed through `fn(value, key)`.
 * @param {Record<string, unknown>} obj
 * @param {(value: unknown, key: string) => unknown} fn
 */
export function mapValues(obj, fn) {
  const out = {};
  for (const key of Object.keys(obj)) out[key] = fn(obj[key], key);
  return out;
}

/**
 * A new object with only the listed keys that are own enumerable properties of `obj`,
 * in the order they appear in `keys`. Keys `obj` lacks are ignored. A key whose value
 * is `undefined` is kept.
 * @param {Record<string, unknown>} obj
 * @param {string[]} keys
 */
export function pick(obj, keys) {
  const out = {};
  for (const key of keys) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      const d = Object.getOwnPropertyDescriptor(obj, key);
      if (d && d.enumerable) out[key] = obj[key];
    }
  }
  return out;
}

/**
 * A new object with every own enumerable string key of `obj` except the listed ones,
 * in the original key order. Listed keys `obj` lacks are ignored. Returns a new object
 * even when nothing is omitted.
 * @param {Record<string, unknown>} obj
 * @param {string[]} keys
 */
export function omit(obj, keys) {
  const excluded = {};
  for (const key of keys) excluded[key] = true;
  const out = {};
  for (const key of Object.keys(obj)) {
    if (!Object.prototype.hasOwnProperty.call(excluded, key)) out[key] = obj[key];
  }
  return out;
}
