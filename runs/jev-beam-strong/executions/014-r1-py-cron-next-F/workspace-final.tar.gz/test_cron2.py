from datetime import datetime
from cron import next_run

# Test invalid expressions that should raise ValueError
invalid_cases = [
    "0 0 0 * *",        # day 0 out of range
    "60 * * * *",       # minute 60 out of range
    "* * * 13 *",       # month 13 out of range
    "* * * * 8",        # dow 8 out of range
    "0 0 1-31 * 2-1",   # range start > end
    "*/0 * * * *",      # zero step
    "*/-1 * * * *",     # negative step
    "1, * * * *",       # empty item
    "",                 # empty expression
    "* * * *",          # 4 fields
    "* * * * * *",      # 6 fields
    "@unknown",         # unknown macro
    "*/mon * * * *",    # name as step
    "0 0 0-MAR * *",    # month name in wrong field?
]

for expr in invalid_cases:
    try:
        next_run(expr, datetime(2026, 10, 17, 10, 0, 0))
        print(f"FAIL: {expr!r} should have raised ValueError")
    except ValueError as e:
        print(f"OK: {expr!r} -> ValueError")
    except Exception as e:
        print(f"FAIL: {expr!r} raised {type(e).__name__}: {e}")

print("\n--- Valid cases ---")

# Feb 29 on leap year
print("Feb 29 leap:", next_run("0 0 29 2 *", datetime(2026, 10, 17, 10, 0, 0)))

# Tab-separated
print("Tab-separated:", next_run("0\t0\t*\t*\t*", datetime(2026, 10, 17, 10, 0, 0)))

# Whitespace trimmed
print("Trimmed:", next_run("  0 0 * * *  ", datetime(2026, 10, 17, 10, 0, 0)))

# Macro case-insensitive
print("Macro Yearly:", next_run("@yearly", datetime(2026, 10, 17, 10, 0, 0)))
print("Macro MONTHLY:", next_run("@MONTHLY", datetime(2026, 10, 17, 10, 0, 0)))

# 5-7 weekday range (Friday-Sunday)
print("5-7 range:", next_run("0 0 * * 5-7", datetime(2026, 10, 17, 10, 0, 0)))  # Oct 17 is Saturday

# N/S pattern - every S-th starting at N
print("5/20 minutes:", next_run("5/20 * * * *", datetime(2026, 10, 17, 10, 0, 0)))
print("9-17/4 hours:", next_run("0 9-17/4 * * *", datetime(2026, 10, 17, 10, 0, 0)))

# When both DOM and DOW unrestricted: both must match (same as ignoring one)
print("*/2 + MON:", next_run("0 0 */2 * MON", datetime(2026, 10, 17, 10, 0, 0)))

# When both restricted: either matches
print("13 + FRI:", next_run("0 0 13 * FRI", datetime(2026, 10, 17, 10, 0, 0)))

# Sundays with @weekly
print("@weekly:", next_run("@weekly", datetime(2026, 10, 17, 10, 0, 0)))  # Oct 17 is Saturday

# Step in day-of-month
print("*/2 DOM:", next_run("0 0 */2 * *", datetime(2026, 10, 17, 10, 0, 0)))
