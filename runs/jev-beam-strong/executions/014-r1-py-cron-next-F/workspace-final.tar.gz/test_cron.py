from datetime import datetime
from cron import next_run

print("Test 1:", next_run("* * * * *", datetime(2026, 10, 17, 10, 0, 30)))
print("Test 2:", next_run("30 9 * * *", datetime(2026, 10, 17, 9, 30, 0)))
print("Test 3:", next_run("30 9 * * *", datetime(2026, 10, 17, 9, 30, 1)))
print("Test 4:", next_run("@daily", datetime(2026, 10, 17, 10, 0, 0)))
print("Test 5:", next_run("@hourly", datetime(2026, 10, 17, 10, 0, 0)))
print("Test 6:", next_run("0 9 * * MON", datetime(2026, 10, 17, 10, 0, 0)))
print("Test 7:", next_run("0 0 1 JAN *", datetime(2026, 10, 17, 10, 0, 0)))
print("Test 8:", next_run("*/15 * * * *", datetime(2026, 10, 17, 10, 0, 0)))
print("Test 9:", next_run("* 0 */2 * *", datetime(2026, 10, 17, 10, 0, 0)))
print("Test 10:", next_run("0 0 13 * FRI", datetime(2026, 10, 17, 10, 0, 0)))
print("Test 11:", next_run("0 0 */2 * MON", datetime(2026, 10, 17, 10, 0, 0)))
print("Test 12:", next_run("0 0 * * 0", datetime(2026, 10, 17, 10, 0, 0)))
print("Test 13:", next_run("0 0 * * 7", datetime(2026, 10, 17, 10, 0, 0)))
print("Test 14:", next_run("0 0 * * 5-7", datetime(2026, 10, 17, 10, 0, 0)))
print("Test 15:", next_run("0 0 30 2 *", datetime(2026, 10, 17, 10, 0, 0)))
