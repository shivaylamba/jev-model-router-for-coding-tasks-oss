from datetime import datetime, timezone, timedelta
from cron import next_run

# Zone info preservation
utc = timezone.utc
est = timezone(timedelta(hours=-5))

after = datetime(2026, 10, 17, 10, 0, 30, tzinfo=utc)
result = next_run("* * * * *", after)
print(f"UTC: after={after}, next={result}, tz={result.tzinfo}")
assert result.tzinfo is utc, "UTC tzinfo should be preserved"

after = datetime(2026, 10, 17, 10, 0, 30, tzinfo=est)
result = next_run("* * * * *", after)
print(f"EST: after={after}, next={result}, tz={result.tzinfo}")
assert result.tzinfo is est, "EST tzinfo should be preserved"

# Seconds and microseconds should be zero
assert result.second == 0
assert result.microsecond == 0

print("All timezone tests passed!")
