from datetime import datetime
from cron import next_run

# Comprehensive edge cases

# Case: 0/5 in minutes -> 0, 5, 10, ..., 55
print("0/5 minutes (expect 00:00:00 next day):", next_run("0/5 0 * * *", datetime(2026, 10, 17, 0, 1, 0)))

# Case: */* should be invalid (empty step? or empty base?)
try:
    next_run("*/* * * * *", datetime(2026, 10, 17, 0, 0, 0))
    print("FAIL: */* should raise")
except ValueError:
    print("OK: */* raises ValueError")

# Case: */2 in day-of-month (starts at 1, odd days)
print("*/2 DOM next:", next_run("0 0 */2 * *", datetime(2026, 10, 1, 0, 0, 0)))
print("*/2 DOM next (after Oct 1 00:01):", next_run("0 0 */2 * *", datetime(2026, 10, 1, 0, 1, 0)))

# Case: month names in range
print("JAN-MAR:", next_run("0 0 1 JAN-MAR *", datetime(2026, 10, 17, 10, 0, 0)))
print("JUL-AUG:", next_run("0 0 1 JUL-AUG *", datetime(2026, 10, 17, 10, 0, 0)))

# Case: day-of-week names in range
print("MON-FRI:", next_run("0 0 * * MON-FRI", datetime(2026, 10, 17, 10, 0, 0)))
print("SAT-SUN:", next_run("0 0 * * SAT-SUN", datetime(2026, 10, 17, 10, 0, 0)))

# Case: mixed case day/month names
print("Mixed case:", next_run("0 0 * * Mon", datetime(2026, 10, 17, 10, 0, 0)))
print("Mixed case month:", next_run("0 0 1 Jan *", datetime(2026, 10, 17, 10, 0, 0)))

# Test that Feb 30 is impossible
print("\nFeb 30 impossible:", end=" ")
try:
    next_run("0 0 30 2 *", datetime(2026, 10, 17, 10, 0, 0))
    print("FAIL - should have raised")
except ValueError:
    print("OK (raises ValueError)")

# Test Feb 29 is fine (2028 is leap year)
print("Feb 29 leap year:", next_run("0 0 29 2 *", datetime(2026, 10, 17, 10, 0, 0)))

# Verify Feb 29 is skipped on non-leap year properly
print("Feb 29 -> next is 2028:", next_run("0 0 29 2 *", datetime(2026, 10, 17, 10, 0, 0)))

# Day matching: both restricted - either matches
print("\nBoth restricted:")
print("  13 or FRI (Oct 17 is Sat):", next_run("0 0 13 * FRI", datetime(2026, 10, 17, 10, 0, 0)))  # Should be Nov 13 (2026-11-13)
print("  17 or FRI:", next_run("0 0 17 * FRI", datetime(2026, 10, 17, 10, 0, 0)))  # Should be Nov 17 (2026-11-17)

# Day matching: one restricted, one unrestricted - must match both
print("\nOne restricted, one unrestricted:")
print("  */2 DOM + MON:", next_run("0 0 */2 * MON", datetime(2026, 10, 17, 10, 0, 0)))  # Oct 19 is Monday (odd day)

# Exact examples from SPEC
print("\nExact spec examples:")
print("  next_run('* * * * *', 10:00:30):", next_run("* * * * *", datetime(2026, 10, 17, 10, 0, 30)))
print("  next_run('30 9 * * *', 09:30:00):", next_run("30 9 * * *", datetime(2026, 10, 17, 9, 30, 0)))
