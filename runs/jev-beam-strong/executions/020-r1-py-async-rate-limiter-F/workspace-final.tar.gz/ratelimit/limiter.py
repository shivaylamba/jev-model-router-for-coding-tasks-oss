"""Asyncio rate limiter: per-key token buckets plus a global concurrency cap.

See SPEC.md for the full behaviour.
"""

import asyncio


class _Req:
    __slots__ = ("key", "seq", "granted", "cancelled", "future", "waiter")

    def __init__(self, key, seq, loop):
        self.key = key
        self.seq = seq
        self.granted = False
        self.cancelled = False
        self.future = loop.create_future()
        self.waiter = None


class _LimitContext:
    def __init__(self, limiter, key):
        self._limiter = limiter
        self._key = key

    async def __aenter__(self):
        await self._limiter.acquire(self._key)
        return self

    async def __aexit__(self, exc_type, exc, tb):
        self._limiter.release()
        return False


class RateLimiter:
    def __init__(self, rate, burst, max_concurrent, *, clock, sleep):
        try:
            if rate <= 0:
                raise ValueError("rate must be positive")
            if burst < 1:
                raise ValueError("burst must be at least 1")
            if max_concurrent < 1:
                raise ValueError("max_concurrent must be at least 1")
        except TypeError:
            raise ValueError("invalid constructor arguments")
        self.rate = rate
        self.burst = burst
        self.max_concurrent = max_concurrent
        self._clock = clock
        self._sleep = sleep
        from ratelimit.bucket import TokenBucket

        self._TokenBucket = TokenBucket
        self._buckets = {}
        self._queues = {}
        self._seq = 0
        self._in_use = 0

    def _bucket(self, key):
        bucket = self._buckets.get(key)
        if bucket is None:
            bucket = self._TokenBucket(self.rate, self.burst, self._clock)
            self._buckets[key] = bucket
        return bucket

    def _queue(self, key):
        q = self._queues.get(key)
        if q is None:
            q = []
            self._queues[key] = q
        return q

    def _grant_pass(self):
        while True:
            candidate = None
            candidate_key = None
            candidate_bucket = None
            for key, q in list(self._queues.items()):
                if not q:
                    continue
                while q and q[0].cancelled:
                    q.pop(0)
                if not q:
                    continue
                head = q[0]
                if head.granted:
                    continue
                bucket = self._bucket(key)
                if bucket.available() >= 1 and self._in_use < self.max_concurrent:
                    if candidate is None or head.seq < candidate.seq:
                        candidate = head
                        candidate_key = key
                        candidate_bucket = bucket
            if candidate is None:
                break
            assert candidate_bucket.try_take()
            self._in_use += 1
            candidate.granted = True
            q = self._queues.get(candidate_key)
            if q and q and q[0] is candidate:
                q.pop(0)
            elif q is not None and candidate in q:
                q.remove(candidate)
            if not candidate.future.done():
                candidate.future.set_result(None)
        self._ensure_waiters()

    def _ensure_waiters(self):
        for key, q in list(self._queues.items()):
            if not q:
                continue
            while q and q[0].cancelled:
                q.pop(0)
            if not q:
                continue
            head = q[0]
            if head.granted or head.cancelled:
                continue
            bucket = self._bucket(key)
            if bucket.available() < 1:
                if head.waiter is None or head.waiter.done():
                    head.waiter = asyncio.ensure_future(self._token_waiter(head))

    async def _token_waiter(self, req):
        try:
            while True:
                if req.cancelled or req.granted:
                    return
                q = self._queues.get(req.key)
                if not q or q[0] is not req:
                    return
                bucket = self._bucket(req.key)
                d = bucket.time_until_available()
                if d <= 0:
                    self._grant_pass()
                    return
                await self._sleep(d)
                if req.cancelled or req.granted:
                    return
                self._grant_pass()
        except asyncio.CancelledError:
            return

    async def acquire(self, key):
        loop = asyncio.get_running_loop()
        self._seq += 1
        req = _Req(key, self._seq, loop)
        q = self._queue(key)
        q.append(req)
        self._grant_pass()
        try:
            await req.future
        except BaseException:
            self._cancel_request(req)
            raise
        return

    def _cancel_request(self, req):
        if req.cancelled:
            return
        req.cancelled = True
        if req.waiter is not None and not req.waiter.done():
            req.waiter.cancel()
        q = self._queues.get(req.key)
        if q is not None and req in q:
            try:
                q.remove(req)
            except ValueError:
                pass
        elif req.granted:
            self._in_use -= 1
            if self._in_use < 0:
                self._in_use = 0
            bucket = self._bucket(req.key)
            bucket.refund(1.0)
            req.granted = False
        self._grant_pass()

    def release(self):
        if self._in_use <= 0:
            raise RuntimeError("no slot held")
        self._in_use -= 1
        self._grant_pass()

    def limit(self, key):
        return _LimitContext(self, key)

    @property
    def in_use(self):
        return self._in_use

    def tokens(self, key):
        return float(self._bucket(key).available())

    def waiting(self, key=None):
        if key is None:
            return sum(len(q) for q in self._queues.values())
        return len(self._queues.get(key, []))
