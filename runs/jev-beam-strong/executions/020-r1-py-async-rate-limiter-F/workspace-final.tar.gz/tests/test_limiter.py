import asyncio
import unittest

try:
    from fake_time import FakeTime, settle
except ModuleNotFoundError:  # pragma: no cover - depends on invocation
    from tests.fake_time import FakeTime, settle

from ratelimit import RateLimiter


def run(coro):
    return asyncio.run(coro)


class ConstructionTests(unittest.TestCase):
    def test_invalid_args_raise_value_error(self):
        ft = FakeTime()
        cases = [
            dict(rate=0),
            dict(rate=-1),
            dict(burst=0),
            dict(burst=-1),
            dict(max_concurrent=0),
            dict(max_concurrent=-1),
        ]
        for bad in cases:
            kwargs = dict(rate=1, burst=1, max_concurrent=1, clock=ft.clock, sleep=ft.sleep)
            kwargs.update(bad)
            with self.assertRaises(ValueError):
                RateLimiter(**kwargs)
        # release with nothing held
        rl = RateLimiter(rate=1, burst=1, max_concurrent=1, clock=ft.clock, sleep=ft.sleep)
        with self.assertRaises(RuntimeError):
            rl.release()


class BasicTests(unittest.TestCase):
    def test_acquire_release_and_context_manager(self):
        async def body():
            ft = FakeTime()
            rl = RateLimiter(rate=2.0, burst=5, max_concurrent=2, clock=ft.clock, sleep=ft.sleep)
            self.assertEqual(rl.in_use, 0)
            await rl.acquire("k")
            self.assertEqual(rl.in_use, 1)
            rl.release()
            self.assertEqual(rl.in_use, 0)
            async with rl.limit("k"):
                self.assertEqual(rl.in_use, 1)
            self.assertEqual(rl.in_use, 0)
        run(body())

    def test_release_on_exception_in_context(self):
        async def body():
            ft = FakeTime()
            rl = RateLimiter(rate=2.0, burst=5, max_concurrent=2, clock=ft.clock, sleep=ft.sleep)
            try:
                async with rl.limit("k"):
                    raise ValueError("boom")
            except ValueError:
                pass
            self.assertEqual(rl.in_use, 0)
        run(body())

    def test_tokens_never_used(self):
        async def body():
            ft = FakeTime()
            rl = RateLimiter(rate=2.0, burst=5, max_concurrent=2, clock=ft.clock, sleep=ft.sleep)
            self.assertEqual(rl.tokens("never"), 5.0)
        run(body())

    def test_waiting_counts(self):
        async def body():
            ft = FakeTime()
            rl = RateLimiter(rate=10.0, burst=1, max_concurrent=1, clock=ft.clock, sleep=ft.sleep)
            await rl.acquire("A")  # holds the only slot
            async def w():
                await rl.acquire("B")
            task = asyncio.create_task(w())
            await settle()
            self.assertEqual(rl.waiting("B"), 1)
            self.assertEqual(rl.waiting("A"), 0)
            self.assertEqual(rl.waiting(), 1)
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
            await settle()
            self.assertEqual(rl.waiting(), 0)
        run(body())


class TokenWaitTests(unittest.TestCase):
    def test_sleeps_exact_delay(self):
        async def body():
            ft = FakeTime()
            rl = RateLimiter(rate=2.0, burst=1, max_concurrent=10, clock=ft.clock, sleep=ft.sleep)
            await rl.acquire("k")
            rl.release()
            async def w():
                await rl.acquire("k")
            task = asyncio.create_task(w())
            await settle()
            self.assertEqual(rl.waiting("k"), 1)
            self.assertIn(0.5, ft.sleep_calls)
            await ft.advance(0.5)
            await settle()
            self.assertTrue(task.done())
            task.result()
        run(body())

    def test_fifo_per_key(self):
        async def body():
            ft = FakeTime()
            rl = RateLimiter(rate=2.0, burst=1, max_concurrent=10, clock=ft.clock, sleep=ft.sleep)
            await rl.acquire("k")
            rl.release()
            results = []

            async def w(label):
                await rl.acquire("k")
                results.append((label, ft.now))

            t1 = asyncio.create_task(w("first"))
            await settle()
            t2 = asyncio.create_task(w("second"))
            await settle()
            self.assertEqual(rl.waiting("k"), 2)
            await ft.advance(0.5)
            await settle()
            self.assertEqual(len(results), 1)
            self.assertEqual(results[0][0], "first")
            await ft.advance(0.5)
            await settle()
            self.assertEqual(len(results), 2)
            self.assertEqual(results[1][0], "second")
            t1.result(); t2.result()
        run(body())

    def test_grant_pass_across_keys_by_acquire_order(self):
        async def body():
            ft = FakeTime()
            rl = RateLimiter(rate=10.0, burst=5, max_concurrent=1, clock=ft.clock, sleep=ft.sleep)
            await rl.acquire("A")
            granted = []

            async def w(key):
                await rl.acquire(key)
                granted.append(key)

            tb = asyncio.create_task(w("B"))
            await settle()
            tc = asyncio.create_task(w("C"))
            await settle()
            rl.release()
            await settle()
            self.assertEqual(granted, ["B"])
            rl.release()
            await settle()
            self.assertEqual(granted, ["B", "C"])
            tb.result(); tc.result()
        run(body())


class CancellationTests(unittest.TestCase):
    def test_cancel_not_granted_removes_request(self):
        async def body():
            ft = FakeTime()
            rl = RateLimiter(rate=10.0, burst=5, max_concurrent=1, clock=ft.clock, sleep=ft.sleep)
            await rl.acquire("A")
            async def w():
                await rl.acquire("B")
            task = asyncio.create_task(w())
            await settle()
            self.assertEqual(rl.waiting("B"), 1)
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
            await settle()
            self.assertEqual(rl.waiting("B"), 0)
            rl.release()
            await settle()
            self.assertEqual(rl.in_use, 0)
        run(body())

    def test_cancel_granted_undoes(self):
        async def body():
            ft = FakeTime()
            rl = RateLimiter(rate=10.0, burst=5, max_concurrent=1, clock=ft.clock, sleep=ft.sleep)
            await rl.acquire("A")
            async def w():
                await rl.acquire("B")
            task = asyncio.create_task(w())
            await settle()
            rl.release()  # grants B, not yet resumed
            self.assertEqual(rl.in_use, 1)
            self.assertLessEqual(rl.tokens("B"), 5.0)
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
            await settle()
            self.assertEqual(rl.in_use, 0)
            self.assertEqual(rl.tokens("B"), 5.0)
            self.assertEqual(rl.waiting("B"), 0)
        run(body())


if __name__ == "__main__":
    unittest.main()
