import { percentOf } from "./money.ts";
import { BUNDLES } from "./bundles.ts";
import type {
  Bundle,
  Coupon,
  CouponStatus,
  Discount,
  Order,
  Totals,
} from "./types.ts";

export type PricedLine = {
  sku: string;
  unitPrice: number;
  quantity: number;
  gross: number; // unitPrice * quantity
  bundled: number; // units of this line used in bundles; starts at 0
};

export type PricingContext = {
  order: Order;
  coupon: Coupon | undefined;
  lines: PricedLine[]; // one per order line, in order
  subtotal: number; // sum of gross
  discounts: Discount[]; // starts empty; rules push onto it
  couponStatus: CouponStatus; // starts "none"; only the coupon rule changes it
  shipping: number; // starts 0
  tax: number; // starts 0
};

export type PricingRule = {
  name: string;
  apply(ctx: PricingContext): void;
};

export function merchandiseTotal(ctx: PricingContext): number {
  let sum = 0;
  for (const d of ctx.discounts) {
    sum += d.amount;
  }
  return ctx.subtotal - sum;
}

export function createPricer(
  rules: PricingRule[],
): (order: Order, coupon?: Coupon) => Totals {
  return (order: Order, coupon?: Coupon): Totals => {
    // Validation
    for (const line of order.lines) {
      if (!Number.isInteger(line.quantity) || line.quantity < 1) {
        throw new RangeError(`bad quantity for ${line.sku}: ${line.quantity}`);
      }
      if (!Number.isInteger(line.unitPrice) || line.unitPrice < 0) {
        throw new RangeError(`bad unit price for ${line.sku}: ${line.unitPrice}`);
      }
    }

    const lines: PricedLine[] = order.lines.map((line) => ({
      ...line,
      gross: line.unitPrice * line.quantity,
      bundled: 0,
    }));
    let subtotal = 0;
    for (const line of lines) {
      subtotal += line.gross;
    }

    const ctx: PricingContext = {
      order,
      coupon,
      lines,
      subtotal,
      discounts: [],
      couponStatus: "none",
      shipping: 0,
      tax: 0,
    };

    for (const rule of rules) {
      rule.apply(ctx);
    }

    const merchandise = merchandiseTotal(ctx);
    return {
      subtotal: ctx.subtotal,
      discounts: ctx.discounts,
      merchandise,
      shipping: ctx.shipping,
      tax: ctx.tax,
      total: merchandise + ctx.shipping + ctx.tax,
      coupon: ctx.couponStatus,
    };
  };
}

export function bundleRule(bundles: Bundle[]): PricingRule {
  return {
    name: "bundle",
    apply(ctx: PricingContext) {
      for (const bundle of bundles) {
        while (true) {
          // Try to form one bundle
          // Returns null if any SKU can't be satisfied
          const selections = bundle.skus.map((sku) => {
            let remainingNeeded = 1;
            const lineSelections: { lineIdx: number; take: number }[] = [];
            for (let i = 0; i < ctx.lines.length && remainingNeeded > 0; i++) {
              const line = ctx.lines[i];
              if (line.sku !== sku) continue;
              const available = line.quantity - line.bundled;
              if (available <= 0) continue;
              const take = Math.min(remainingNeeded, available);
              lineSelections.push({ lineIdx: i, take });
              remainingNeeded -= take;
            }
            if (remainingNeeded > 0) return null;
            return lineSelections;
          });

          // If any SKU couldn't be satisfied, stop forming this bundle type
          if (selections.some((s) => s === null)) break;

          // Apply bundle: assign units to lines and compute discount per line
          let totalDiscount = 0;
          for (const skuSelections of selections) {
            for (const sel of skuSelections!) {
              const line = ctx.lines[sel.lineIdx];
              line.bundled += sel.take;
              totalDiscount += percentOf(line.unitPrice * sel.take, bundle.percent);
            }
          }

          if (totalDiscount > 0) {
            ctx.discounts.push({
              rule: `bundle:${bundle.id}`,
              amount: totalDiscount,
            });
          }
        }
      }
    },
  };
}

export const volumeRule: PricingRule = {
  name: "volume",
  apply(ctx: PricingContext) {
    let total = 0;
    for (const line of ctx.lines) {
      const unbundled = line.quantity - line.bundled;
      if (line.quantity >= 10 && unbundled > 0) {
        total += percentOf(line.unitPrice * unbundled, 10);
      }
    }
    if (total > 0) {
      ctx.discounts.push({ rule: "volume", amount: total });
    }
  },
};

export const couponRule: PricingRule = {
  name: "coupon",
  apply(ctx: PricingContext) {
    if (!ctx.coupon) {
      ctx.couponStatus = "none";
      return;
    }

    // Exclusive coupon check: can't combine with bundles
    if (ctx.coupon.exclusive) {
      for (const d of ctx.discounts) {
        if (d.rule.startsWith("bundle:")) {
          ctx.couponStatus = "excluded";
          return;
        }
      }
    }

    const merchandise = merchandiseTotal(ctx);
    if (merchandise < (ctx.coupon.minSubtotal ?? 0)) {
      ctx.couponStatus = "below-minimum";
      return;
    }

    const off =
      ctx.coupon.kind === "percent"
        ? percentOf(merchandise, ctx.coupon.value)
        : Math.min(ctx.coupon.value, merchandise);
    ctx.couponStatus = "applied";
    if (off > 0) {
      ctx.discounts.push({ rule: `coupon:${ctx.coupon.code}`, amount: off });
    }
  },
};

export const shippingRule: PricingRule = {
  name: "shipping",
  apply(ctx: PricingContext) {
    if (ctx.order.lines.length === 0) {
      ctx.shipping = 0;
      return;
    }
    const merchandise = merchandiseTotal(ctx);
    ctx.shipping = merchandise < 5000 ? 499 : 0;
  },
};

export const taxRule: PricingRule = {
  name: "tax",
  apply(ctx: PricingContext) {
    const merchandise = merchandiseTotal(ctx);
    ctx.tax = percentOf(merchandise, 8);
  },
};

export const defaultRules: PricingRule[] = [
  bundleRule(BUNDLES),
  volumeRule,
  couponRule,
  shippingRule,
  taxRule,
];
