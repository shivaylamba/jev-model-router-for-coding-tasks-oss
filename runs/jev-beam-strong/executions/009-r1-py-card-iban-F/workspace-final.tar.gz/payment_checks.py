"""Card and bank-account helpers for the checkout service."""

from iban_countries import IBAN_LENGTHS  # noqa: F401  (used by the IBAN check)


def strip_separators(text, separators=" -"):
    """Return text with every character in `separators` removed."""
    return "".join(ch for ch in text if ch not in separators)


def mask_card(number):
    """Mask all but the last four digits: '4111 1111 1111 1111' -> '************1111'.

    Spaces and hyphens are ignored. Raises ValueError if fewer than four digits remain.
    """
    digits = strip_separators(number)
    if len(digits) < 4 or not digits.isdigit():
        raise ValueError("not a card number")
    return "*" * (len(digits) - 4) + digits[-4:]


def _luhn_valid(digits):
    """Return True if `digits` (all digits, no separators) passes the Luhn checksum."""
    total = 0
    for i, digit in enumerate(reversed(digits)):
        value = int(digit)
        if i % 2:
            value *= 2
            if value > 9:
                value -= 9
        total += value
    return total % 10 == 0


def card_brand(number):
    """Return the brand of a card number: 'visa', 'mastercard', 'amex' or 'discover'.

    Spaces and hyphens are ignored. Any other non-digit character, a number that
    fails the Luhn checksum, or a number that matches no @brand@ prefix/length
    combo returns None. An empty string returns None.
    """
    if not isinstance(number, str):
        raise TypeError("card number must be a str")
    for ch in number:
        if not (ch.isdigit() or ch in " -"):
            return None
    digits = strip_separators(number)
    if not digits or not _luhn_valid(digits):
        return None
    length = len(digits)

    if digits[:2] in ("34", "37") and length == 15:
        return "amex"
    if digits[0] == "4" and length in (13, 16, 19):
        return "visa"
    if length == 16 and (
        digits[:2] in ("51", "52", "53", "54", "55")
        or "2221" <= digits[:4] <= "2720"
    ):
        return "mastercard"
    if length in (16, 19) and (
        digits.startswith("6011")
        or digits.startswith("65")
        or digits[:3] in ("644", "645", "646", "647", "648", "649")
    ):
        return "discover"
    return None


def is_valid_iban(iban):
    """Return True if `iban` is a well-formed IBAN for a supported country.

    Spaces are ignored and letters may be either case; any other separator (hyphen,
    dot, ...) is invalid. The country must be listed in IBAN_LENGTHS and match its
    exact length, and the standard mod-97 check must pass.
    """
    if not isinstance(iban, str):
        raise TypeError("iban must be a str")
    if any(ch not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 " for ch in iban):
        return False
    compact = iban.replace(" ", "")
    if len(compact) < 4:
        return False
    country = compact[:2].upper()
    if not (compact[0].isalpha() and compact[1].isalpha()):
        return False
    if country not in IBAN_LENGTHS or len(compact) != IBAN_LENGTHS[country]:
        return False
    if not (compact[2:4].isdigit() and compact[4:].isalnum()):
        return False

    rearranged = compact[4:] + compact[:4]
    expanded = "".join(
        ch if ch.isdigit() else str(ord(ch.upper()) - ord("A") + 10)
        for ch in rearranged
    )
    return int(expanded) % 97 == 1
