import unittest

from payment_checks import card_brand, is_valid_iban, mask_card, strip_separators


class MaskCardTest(unittest.TestCase):
    def test_masks_all_but_last_four(self):
        self.assertEqual(mask_card("4111 1111 1111 1111"), "************1111")

    def test_rejects_short_input(self):
        with self.assertRaises(ValueError):
            mask_card("12-3")

    def test_strip_separators(self):
        self.assertEqual(strip_separators("12 34-56"), "123456")


class CardBrandTest(unittest.TestCase):
    def test_visa(self):
        self.assertEqual(card_brand("4111 1111 1111 1111"), "visa")
        self.assertEqual(card_brand("4532 5212 5595 195"), "visa")
        self.assertEqual(card_brand("4111 1111 1111 1111 111"), "visa")

    def test_mastercard(self):
        self.assertEqual(card_brand("5500 0000 0000 0004"), "mastercard")
        self.assertEqual(card_brand("2221 0000 0000 0009"), "mastercard")
        self.assertEqual(card_brand("2720 9999 9999 9996"), "mastercard")

    def test_amex(self):
        self.assertEqual(card_brand("3782 822463 10005"), "amex")
        self.assertEqual(card_brand("3400 0000 0000 009"), "amex")

    def test_discover(self):
        self.assertEqual(card_brand("6011 0000 0000 0004"), "discover")
        self.assertEqual(card_brand("6500 0000 0000 0002"), "discover")
        self.assertEqual(card_brand("6440 0000 0000 0004"), "discover")
        self.assertEqual(card_brand("6490 0000 0000 0006"), "discover")

    def test_hyphens_are_separators(self):
        self.assertEqual(card_brand("4111-1111-1111-1111"), "visa")

    def test_empty_returns_none(self):
        self.assertIsNone(card_brand(""))

    def test_failed_luhn_returns_none(self):
        self.assertIsNone(card_brand("4111 1111 1111 1112"))

    def test_bad_character_returns_none(self):
        self.assertIsNone(card_brand("4111.1111.1111.1111"))
        self.assertIsNone(card_brand("4111x11111111111"))

    def test_right_prefix_wrong_length_returns_none(self):
        # 4-prefix but not a valid visa length
        self.assertIsNone(card_brand("4222 2222"))
        # 37-prefix but 16 digits, not 15
        self.assertIsNone(card_brand("3782 822463 1000 55"))

    def test_rejects_non_string(self):
        with self.assertRaises(TypeError):
            card_brand(4111)


class IbanValidTest(unittest.TestCase):
    def test_valid_gb(self):
        self.assertTrue(is_valid_iban("GB82 WEST 1234 5698 7654 32"))

    def test_lowercase_letters(self):
        self.assertTrue(is_valid_iban("gb82 west 1234 5698 7654 32"))

    def test_other_separator_invalid(self):
        self.assertFalse(is_valid_iban("GB82-WEST-1234-5698-7654-32"))
        self.assertFalse(is_valid_iban("GB82.WEST.1234.5698.7654.32"))

    def test_unknown_country_invalid(self):
        self.assertFalse(is_valid_iban("ZZ82 WEST 1234 5698 7654 32"))

    def test_wrong_length_invalid(self):
        self.assertFalse(is_valid_iban("GB8 WEST 1234 5698 7654 32"))

    def test_bad_check_digits_invalid(self):
        self.assertFalse(is_valid_iban("GB00 WEST 1234 5698 7654 32"))

    def test_rejects_non_string(self):
        with self.assertRaises(TypeError):
            is_valid_iban(123456)


if __name__ == "__main__":
    unittest.main()
