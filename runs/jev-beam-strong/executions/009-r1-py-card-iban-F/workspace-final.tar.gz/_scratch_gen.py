def luhn_check(digits):
    total = 0
    for i, digit in enumerate(reversed(digits)):
        value = int(digit)
        if i % 2:
            value *= 2
            if value > 9:
                value -= 9
        total += value
    return total % 10 == 0

def luhn_fix(prefix):
    for d in range(10):
        if luhn_check(prefix + str(d)):
            return prefix + str(d)
    return None

tests = {
 'visa13': luhn_fix('453252125595'),       # 12 + 1 = 13
 'visa19': luhn_fix('411111111111111111'), # 18 + 1 = 19
 'mc2221': luhn_fix('222100000000000'),    # 15 + 1 = 16
 'mc2720': luhn_fix('272099999999999'),
 'mc55': luhn_fix('55000000000000'),
 'mc2200below': luhn_fix('22000000000000'),
 'disc6011': luhn_fix('60110000000000'),
 'disc65': luhn_fix('65000000000000'),
 'disc649': luhn_fix('64900000000000'),
 'disc644': luhn_fix('64400000000000'),
 'disc643below': luhn_fix('64300000000000'),
 'disc649_19': luhn_fix('649000000000000000'),
 'disc6011_19': luhn_fix('601100000000000000'),
}
from payment_checks import card_brand
for k, v in tests.items():
    print(k, len(v), '->', card_brand(v))