import { deprecate } from "./deprecate.js";

const ALLOWED_OPTIONS = new Set(["baseUrl", "token", "timeoutMs", "retries", "headers"]);

/**
 * Create an API client.
 *
 * @param {object} options
 * @param {string} options.baseUrl   e.g. "https://api.internal.example"; a trailing slash is ignored
 * @param {string} [options.token]   bearer token; no Authorization header when omitted
 * @param {number} [options.timeoutMs=5000]
 * @param {number} [options.retries=0]
 * @param {object} [options.headers] extra headers added to every request
 *
 * For backwards compatibility the legacy positional form
 * `createClient(baseUrl, token, timeoutMs, retries)` is still accepted, but it
 * reports a deprecation warning. New calls should use the options object.
 */
export function createClient(first, token, timeoutMs = 5000, retries = 0) {
  let given;
  if (typeof first === "string") {
    deprecate(
      "CLIENT_POSITIONAL_ARGS",
      "createClient positional arguments are deprecated; pass an options object instead",
    );
    given = { baseUrl: first, token, timeoutMs, retries };
  } else if (first !== null && typeof first === "object" && !Array.isArray(first)) {
    given = first;
  } else {
    throw new TypeError("createClient expects a baseUrl string or a plain options object");
  }

  for (const key of Object.keys(given)) {
    if (!ALLOWED_OPTIONS.has(key)) {
      throw new TypeError(`unknown createClient option "${key}"`);
    }
  }

  const baseUrl = given.baseUrl;
  if (typeof baseUrl !== "string" || baseUrl === "") {
    throw new TypeError("baseUrl must be a non-empty string");
  }

  const resolTimeoutMs = given.timeoutMs === undefined ? 5000 : given.timeoutMs;
  if (typeof resolTimeoutMs !== "number" || !Number.isFinite(resolTimeoutMs) || resolTimeoutMs <= 0) {
    throw new RangeError("timeoutMs must be a finite number greater than 0");
  }

  const retriesCount = given.retries === undefined ? 0 : given.retries;
  if (!Number.isInteger(retriesCount) || retriesCount < 0) {
    throw new RangeError("retries must be an integer >= 0");
  }

  const headers = given.headers === undefined ? {} : given.headers;

  const options = Object.freeze({
    baseUrl: baseUrl.replace(/\/+$/, ""),
    token: given.token,
    timeoutMs: resolTimeoutMs,
    retries: retriesCount,
    headers,
  });

  return {
    options,
    /**
     * Describe a request and pass it to `transport`, returning whatever the transport returns.
     */
    request(transport, method, path, body) {
      const headers = { ...options.headers, accept: "application/json" };
      if (options.token) headers.authorization = `Bearer ${options.token}`;
      if (body !== undefined) headers["content-type"] = "application/json";
      return transport({
        method,
        url: options.baseUrl + (path.startsWith("/") ? path : `/${path}`),
        headers,
        body: body === undefined ? undefined : JSON.stringify(body),
        timeoutMs: options.timeoutMs,
        retries: options.retries,
      });
    },
  };
}