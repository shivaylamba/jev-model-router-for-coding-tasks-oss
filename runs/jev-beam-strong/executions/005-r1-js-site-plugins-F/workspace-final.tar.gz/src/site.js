import { defaultLayout } from "./layout.js";
import { renderMarkdown } from "./markdown.js";

/** "guide/intro.md" -> "guide/intro.html" */
export function outputPath(sourcePath) {
  return sourcePath.replace(/\.md$/, "") + ".html";
}

export class PluginError extends Error {
  constructor(plugin, hook, cause) {
    super(`Plugin "${plugin}" failed in ${hook} hook`);
    this.plugin = plugin;
    this.hook = hook;
    this.cause = cause;
  }
}

const HOOKS = ["beforeRender", "afterRender", "onComplete"];

export function createSite({ layout = defaultLayout } = {}) {
  const plugins = [];

  function use(plugin) {
    if (typeof plugin !== "object" || plugin === null) {
      throw new TypeError("Plugin must be an object");
    }
    if (typeof plugin.name !== "string" || plugin.name === "") {
      throw new TypeError("Plugin name must be a non-empty string");
    }
    for (const hook of HOOKS) {
      if (hook in plugin && typeof plugin[hook] !== "function") {
        throw new TypeError(`Plugin hook "${hook}" must be a function`);
      }
    }
    if (plugins.some((p) => p.name === plugin.name)) {
      throw new Error(`Plugin "${plugin.name}" is already registered`);
    }
    plugins.push(plugin);
    return site;
  }

  async function build(pages) {
    const outputs = new Map();
    const beforeRenderPlugins = plugins.filter((p) => typeof p.beforeRender === "function");
    const afterRenderPlugins = plugins.filter((p) => typeof p.afterRender === "function");
    const onCompletePlugins = plugins.filter((p) => typeof p.onComplete === "function");

    for (const originalPage of pages) {
      // Shallow copy so plugins can mutate without affecting caller's data
      let page = { ...originalPage };

      for (const plugin of beforeRenderPlugins) {
        let result;
        try {
          result = await plugin.beforeRender(page);
        } catch (cause) {
          throw new PluginError(plugin.name, "beforeRender", cause);
        }
        if (result !== undefined) {
          if (typeof result !== "object" || result === null) {
            throw new PluginError(
              plugin.name,
              "beforeRender",
              new TypeError("beforeRender must return undefined or an object"),
            );
          }
          page = result;
        }
      }

      const content = renderMarkdown(page.body);
      let html = layout({ title: page.title, content, path: page.path });

      for (const plugin of afterRenderPlugins) {
        let result;
        try {
          result = await plugin.afterRender(html, page);
        } catch (cause) {
          throw new PluginError(plugin.name, "afterRender", cause);
        }
        if (result !== undefined) {
          if (typeof result !== "string") {
            throw new PluginError(
              plugin.name,
              "afterRender",
              new TypeError("afterRender must return undefined or a string"),
            );
          }
          html = result;
        }
      }

      outputs.set(outputPath(page.path), html);
    }

    for (const plugin of onCompletePlugins) {
      try {
        await plugin.onComplete(outputs);
      } catch (cause) {
        throw new PluginError(plugin.name, "onComplete", cause);
      }
    }

    return outputs;
  }

  const site = { use, build };
  return site;
}

/**
 * Render every page. Pages are { path, title, body }; the result maps each
 * output path to its HTML, in page order.
 */
export async function buildSite(pages, options = {}) {
  return createSite(options).build(pages);
}
