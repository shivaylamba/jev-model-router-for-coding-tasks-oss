import unittest

from urlbits import build_query, parse_query


class ParseQueryTest(unittest.TestCase):
    def test_leading_question_mark_ignored(self):
        self.assertEqual(parse_query("?a=1"), {"a": ["1"]})
        self.assertEqual(parse_query("a=1"), {"a": ["1"]})

    def test_empty_segments_skipped(self):
        self.assertEqual(parse_query("a=1&&b=2"), {"a": ["1"], "b": ["2"]})
        self.assertEqual(parse_query(""), {})
        self.assertEqual(parse_query("&"), {})

    def test_bare_key_and_empty_value(self):
        self.assertEqual(parse_query("flag&x="), {"flag": [None], "x": [""]})

    def test_repeated_keys_order(self):
        self.assertEqual(
            parse_query("a=1&flag&a=2"),
            {"a": ["1", "2"], "flag": [None]},
        )

    def test_split_on_first_equals(self):
        self.assertEqual(parse_query("a=b=c"), {"a": ["b=c"]})

    def test_plus_is_space(self):
        self.assertEqual(parse_query("q=a+b"), {"q": ["a b"]})

    def test_percent_decoding(self):
        self.assertEqual(parse_query("q=a%26b"), {"q": ["a&b"]})
        self.assertEqual(parse_query("q=%C3%A9"), {"q": ["é"]})

    def test_literal_percent_kept(self):
        self.assertEqual(parse_query("q=100%25"), {"q": ["100%"]})
        # A '%' without valid hex following is kept as-is.
        self.assertEqual(parse_query("q=100%"), {"q": ["100%"]})
        self.assertEqual(parse_query("q=%4"), {"q": ["%4"]})

    def test_invalid_utf8_becomes_replacement(self):
        self.assertEqual(parse_query("q=%FF"), {"q": ["�"]})

    def test_hex_case_insensitive(self):
        self.assertEqual(parse_query("q=%41"), {"q": ["A"]})
        self.assertEqual(parse_query("q=%4a"), {"q": ["J"]})


class BuildQueryTest(unittest.TestCase):
    def test_none_and_empty(self):
        self.assertEqual(build_query({"flag": None}), "flag")
        self.assertEqual(build_query({"x": ""}), "x=")
        self.assertEqual(build_query({"flag": None, "x": ""}), "flag&x=")

    def test_list_order_and_empty_list(self):
        self.assertEqual(build_query({"a": ["1", "2"]}), "a=1&a=2")
        self.assertEqual(build_query({"a": [], "b": "1"}), "b=1")

    def test_key_order(self):
        self.assertEqual(build_query({"b": "1", "a": "2"}), "b=1&a=2")

    def test_encoding(self):
        self.assertEqual(build_query({"q": "a b&c"}), "q=a+b%26c")
        self.assertEqual(build_query({"q": "é"}), "q=%C3%A9")

    def test_list_of_none(self):
        self.assertEqual(build_query({"flag": [None, "x"]}), "flag&flag=x")

    def test_type_error_on_bad_value(self):
        with self.assertRaises(TypeError):
            build_query({"a": 1})
        with self.assertRaises(TypeError):
            build_query({"a": [1]})
        with self.assertRaises(TypeError):
            build_query({"a": object()})


class RoundTripTest(unittest.TestCase):
    def test_build_then_parse(self):
        for params in [
            {"a": ["1", "2"], "flag": [None]},
            {"flag": [None]},
            {"x": [""]},
            {"q": ["a b&c"]},
            {"q": ["a+b", "c"]},  # '+' round-trips to space
            {"e": ["é"]},
        ]:
            self.assertEqual(parse_query(build_query(params)), params)

    def test_parse_then_build(self):
        # Round-trip eligible: a repeated key's pairs are adjacent (see spec).
        for s in ["", "a=1", "flag", "a=1&a=2&flag", "q=a+b%26c"]:
            self.assertEqual(build_query(parse_query(s)), s)

    def test_parse_then_build_normalizes_separated_repeats(self):
        # Separated repeats reorder so each key's pairs are emitted together.
        self.assertEqual(
            build_query(parse_query("a=1&flag&a=2")), "a=1&a=2&flag"
        )


if __name__ == "__main__":
    unittest.main()