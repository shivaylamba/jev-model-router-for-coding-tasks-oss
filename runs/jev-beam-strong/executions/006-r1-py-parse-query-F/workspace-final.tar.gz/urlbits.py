"""URL helpers for the link checker."""


def split_url(url):
    """Split a URL into (base, query, fragment).

    The query is the text after the first "?" (without the "?") and the
    fragment is the text after the first "#". Missing parts are "".

    >>> split_url("https://x.test/a?b=1#top")
    ('https://x.test/a', 'b=1', 'top')
    """
    base, _, fragment = url.partition("#")
    base, _, query = base.partition("?")
    return base, query, fragment


def _decode(value):
    """Decode a percent-encoded segment: '+' is space, %XX is UTF-8.

    A '%' not followed by two hex digits is kept as-is. Bytes that don't
    decode as UTF-8 become U+FFFD.
    """
    buf = bytearray()
    i = 0
    n = len(value)
    while i < n:
        ch = value[i]
        if ch == "+":
            buf.append(0x20)  # '+' becomes space
            i += 1
        elif ch == "%" and i + 3 <= n and all(
            c in "0123456789abcdefABCDEF" for c in value[i + 1 : i + 3]
        ):
            buf.append(int(value[i + 1 : i + 3], 16))
            i += 3
        else:
            # Keep the raw byte of this char; ascii chars are 1 byte.
            buf.extend(ch.encode("utf-8", "surrogatepass"))
            i += 1
    return buf.decode("utf-8", "replace")


def parse_query(query):
    """Parse a query string into an ordered dict of key -> list of values.

    An optional leading "?" is ignored. Pairs are split on "&" with empty
    segments skipped. A segment with no "=" is a bare key whose value is None;
    "x=" gives the value "". Keys keep first-appearance order and each maps to
    all its values in order.
    """
    if query.startswith("?"):
        query = query[1:]
    result = {}
    for segment in query.split("&"):
        if not segment:
            continue
        key, sep, value = segment.partition("=")
        if sep:
            value = _decode(value)
        else:
            value = None
        key = _decode(key)
        result.setdefault(key, []).append(value)
    return result


# Characters left un-escaped by build_query; everything else is percent-encoded.
_UNRESERVED = frozenset(
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~"
)


def _encode(text):
    """Percent-encode text for a query component, with space as '+'."""
    out = []
    for byte in text.encode("utf-8"):
        if byte == 0x20:
            out.append("+")
        elif chr(byte) in _UNRESERVED:
            out.append(chr(byte))
        else:
            out.append("%%%02X" % byte)
    return "".join(out)


def build_query(params):
    """Build a query string (no leading '?') from an ordered mapping.

    Values may be a str, None, or a list of str/None. None writes a bare key
    ("flag"), "" writes "key=". An empty list writes nothing for that key. Keys
    and list values are emitted in their given order.
    """
    pairs = []
    for key, value in params.items():
        if isinstance(value, list):
            if not value:
                continue
            for item in value:
                pairs.append(_pair(key, item))
        else:
            pairs.append(_pair(key, value))
    return "&".join(pairs)


def _pair(key, value):
    """Return the 'key=value' or bare-key text for one (key, value) pair."""
    if value is None:
        return _encode(key)
    if not isinstance(value, str):
        raise TypeError(
            "query value must be str, None, or a list of str/None, got %r" % (value,)
        )
    return _encode(key) + "=" + _encode(value)
