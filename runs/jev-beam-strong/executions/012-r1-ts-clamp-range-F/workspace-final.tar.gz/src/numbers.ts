/** Sum of a list of numbers; 0 for an empty list. */
export function sum(values: readonly number[]): number {
  let total = 0;
  for (const v of values) total += v;
  return total;
}

/** Arithmetic mean. Throws RangeError for an empty list. */
export function mean(values: readonly number[]): number {
  if (values.length === 0) throw new RangeError("mean of an empty list");
  return sum(values) / values.length;
}

/** Returns `value` limited to the closed interval [min, max]. Throws RangeError if min > max. */
export function clamp(value: number, min: number, max: number): number {
  if (min > max) throw new RangeError("min must be <= max");
  return Math.min(max, Math.max(min, value));
}

/**
 * Returns an array of numbers from `start` up to (but excluding) `stop`, stepping by `step`.
 * Behaves like Python's `range`. `stop` is exclusive, and a single argument is the stop with an
 * implicit start of 0. Negative steps count down. Throws RangeError when step is 0. When the step
 * points away from `stop`, or start already equals stop, returns an empty array.
 */
export function range(start: number, stop?: number, step?: number): number[] {
  const [begin, end, stepBy] =
    stop === undefined ? [0, start, 1] : [start, stop, step ?? 1];

  if (stepBy === 0) throw new RangeError("step must not be 0");

  const result: number[] = [];
  if (stepBy > 0) {
    for (let i = begin; i < end; i += stepBy) result.push(i);
  } else {
    for (let i = begin; i > end; i += stepBy) result.push(i);
  }
  return result;
}