from notes import create_note, add_tag

# Repro 1: pinned leak and new notes getting prior tags
pinned = create_note("Standup", pinned=True)
plain = create_note("Groceries")
print("Repro 1 - plain tags:", plain["tags"])  # should be []

# Repro 2: add_tag on one note leaking to others
note_a = create_note("A")
add_tag(note_a, "work")
note_b = create_note("B")
print("Repro 2 - note_a tags:", note_a["tags"])  # should be ["work"]
print("Repro 2 - note_b tags:", note_b["tags"])  # should be []

# Repro 3: shared list mutation
shared = ["HOME", "URGENT"]
create_note("Batch 1", tags=shared)
print("Repro 3 - shared after first call:", shared)  # should be ["HOME", "URGENT"]
create_note("Batch 2", tags=shared)
print("Repro 3 - shared after second call:", shared)  # should still be ["HOME", "URGENT"]
