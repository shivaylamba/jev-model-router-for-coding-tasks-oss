"""Comma-separated values (for machines, not people)."""


def _quote(field):
    """Apply standard CSV quoting: only quote when the field contains a comma,
    double quote or line break; double any embedded double quotes."""
    if "," in field or '"' in field or "\n" in field or "\r" in field:
        return '"' + field.replace('"', '""') + '"'
    return field


def _cell(value):
    """Format a raw cell value for CSV."""
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return format(value, ".2f")
    return str(value)


class CsvExporter:
    name = "csv"
    extension = ".csv"

    def export(self, report):
        lines = [_quote(column.label) for column in report.columns]
        for row in report.rows:
            lines.append(",".join(_quote(_cell(report.cell(row, c))) for c in report.columns))
        return "\n".join(lines) + "\n"