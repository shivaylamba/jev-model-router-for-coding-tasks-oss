"""Function decorators."""

import functools
from collections import namedtuple

CacheInfo = namedtuple("CacheInfo", "hits misses size")


def once(func):
    """Call `func` the first time only; later calls return the first result."""
    result = []

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        if not result:
            result.append(func(*args, **kwargs))
        return result[0]

    return wrapper


def memoize(func):
    """Cache `func`'s return value per distinct set of arguments."""
    cache = {}
    hits = 0
    misses = 0

    def key(*args, **kwargs):
        if kwargs:
            items = tuple(sorted(kwargs.items()))
            return (*args, items)
        return args

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        nonlocal hits, misses
        try:
            result = cache[key(*args, **kwargs)]
        except TypeError:
            # Unhashable argument: the function is never called.
            raise
        except KeyError:
            # Miss: call the function and store its result.
            misses += 1
            result = func(*args, **kwargs)
            cache[key(*args, **kwargs)] = result
            return result
        hits += 1
        return result

    def cache_info():
        return CacheInfo(hits, misses, len(cache))

    def cache_clear():
        nonlocal hits, misses
        cache.clear()
        hits = 0
        misses = 0

    wrapper.cache_info = cache_info
    wrapper.cache_clear = cache_clear
    return wrapper
