import datetime
import traceback
from shop.orders import Order, InvalidTransition, Transition
import collections

errors = []

def check(name, got, expected):
    if got != expected:
        errors.append(f"FAIL: {name}: got {got!r}, expected {expected!r}")

# 1. Default clock: timestamps are timezone-aware UTC
order = Order("O1", [("PEN", 1, 100)])

calls_executed = []
base_time = datetime.datetime(2024, 1, 1, 12, 0, 0, tzinfo=datetime.timezone.utc)
call_times = [base_time + datetime.timedelta(days=5-i) for i in range(6)]

def make_clock():
    idx = [0]
    def clock():
        t = call_times[idx[0]]
        idx[0] += 1
        calls_executed.append(t)
        return t
    return clock

clock = make_clock()
order = Order("O1", [("PEN", 1, 100)], clock=clock)
check("clock/status pending", order.status, "pending")
check("history empty", order.history, [])

# 2. Happy path with history
order.pay()
check("history len after pay", len(order.history), 1)
entry = order.history[0]
check("entry type", isinstance(entry, Transition), True)
check("entry.event", entry.event, "pay")
check("entry.from_state", entry.from_state, "pending")
check("entry.to_state", entry.to_state, "paid")
check("entry.at", entry.at, base_time + datetime.timedelta(days=5))

order.pack()
order.ship(" 1Z999 ")
check("tracking_number stripped", order.tracking_number, "1Z999")
order.deliver()
check("delivered_at is set", order.delivered_at is not None, True)
check("delivered_at value", order.delivered_at, base_time + datetime.timedelta(days=3))
check("is_terminal after deliver", order.is_terminal, False)

# 3. Refund within window
order.refund()
check("is_terminal after refund", order.is_terminal, True)

# 4. Events from terminal raise InvalidTransition
for evt in ['pay', 'pack', 'ship', 'deliver', 'cancel', 'refund']:
    try:
        if evt == 'ship':
            order.ship('T')
            errors.append(f"FAIL: should raise InvalidTransition from terminal for {evt}")
        elif evt == 'cancel':
            order.cancel('R')
            errors.append(f"FAIL: should raise InvalidTransition from terminal for {evt}")
        else:
            getattr(order, evt)()
            errors.append(f"FAIL: should raise InvalidTransition from terminal for {evt}")
    except InvalidTransition as e:
        check(f"terminal {evt} state", e.state, "refunded")
        check(f"terminal {evt} event", e.event, evt)

# 5. Refund window: exactly 30 days is allowed, 31 days is not
order2 = Order("O2", [("PEN", 1, 100)])
order2._clock = lambda: base_time
order2._delivered_at = base_time
check("can refund at exactly 30 days", order2.can("refund"), True)
order2._clock = lambda: base_time + datetime.timedelta(days=30)
check("refund at 30 days", order2.can("refund"), True)
order2._clock = lambda: base_time + datetime.timedelta(days=31)
check("can refund at 31 days", order2.can("refund"), False)
try:
    order2.refund()
    errors.append("FAIL: should raise InvalidTransition at 31 days")
except InvalidTransition as e:
    check("31-day refund state", e.state, "delivered")
    check("31-day refund event", e.event, "refund")

# Also verify cancelled terminal
try:
    order2.cancel('reason')
except InvalidTransition as e:
    check("cancel from delivered state", e.state, "delivered")

# 6. Unknown events can() returns False, allowed_events excludes them
try:
    result = order2.can("destroy")
    check("can unknown event", result, False)
except Exception as e:
    errors.append(f"FAIL: can(destroy) raised: {e}")

# 7. ValueError on ship with bad tracking number, but status check first
order3 = Order("O3", [("PEN", 1, 100)])
try:
    order3.ship(None)
    errors.append("FAIL: ship(None) should raise InvalidTransition")
except InvalidTransition as e:
    check("ship None from pending raises InvalidTransition", e.state, "pending")
    check("ship None event", e.event, "ship")
except ValueError:
    errors.append("FAIL: ship(None) from pending should be InvalidTransition, not ValueError")

# Good transition, bad argument
order3.pay()
order3.pack()
try:
    order3.ship(None)
    errors.append("FAIL: ship(None) should raise ValueError from packed")
except ValueError:
    pass
except Exception as e:
    errors.append(f"FAIL: ship(None) raised wrong: {e}")
check("status after failed ship", order3.status, "packed")
check("tracking_number after failed ship", order3.tracking_number, None)
check("history after failed ship", len(order3.history), 2)  # pay + pack only

# 8. ValueError on cancel with bad reason
order4 = Order("O4", [("PEN", 1, 100)])
try:
    order4.cancel(123)
    errors.append("FAIL: cancel(123) should raise ValueError")
except ValueError:
    pass

try:
    order4.cancel("  ")
    errors.append("FAIL: cancel('  ') should raise ValueError")
except ValueError:
    pass

# cancel from terminal should be InvalidTransition before ValueError
order4.pay()
order4.cancel("ok")
try:
    order4.cancel("bad")
    errors.append("FAIL: cancel from cancelled should raise")
except InvalidTransition as e:
    check("cancel from cancelled event", e.event, "cancel")

# 9. allowed_events
order5 = Order("O5", [("PEN", 1, 100)])
check("allowed_events pending", order5.allowed_events(), ["cancel", "pay"])
order5.pay()
check("allowed_events paid", order5.allowed_events(), ["cancel", "pack", "refund"])

# 10. Check clock default produces tz-aware UTC
order6 = Order("O6", [("PEN", 1, 100)])
order6.pay()
own_aware = order6.history[0].at
check("default clock tz-aware", own_aware.tzinfo is not None, True)
import time
# Simple sanity that it's a real datetime
check("default clock is datetime", isinstance(own_aware, datetime.datetime), True)

# 11. refund only allowed up to 30 days
order7 = Order("O7", [("PEN", 1, 100)])
order7.pay()
order7.pack()
try:
    order7.refund()
    check("refund from packed", order7.status, "refunded")
except Exception as e:
    errors.append(f"FAIL: refund from packed raised: {e}")

# 12. Refund after delivery checks delivered_at
order8 = Order("O8", [("PEN", 1, 100)])
order8.pay()
order8.pack()
order8.ship('TRACK')
order8.deliver()
check("delivered_at set", order8.delivered_at is not None, True)

# 13. A call that raises InvalidTransition changes nothing
order9 = Order("O9", [("PEN", 1, 100)])
order9.pay()
hist_before = list(order9.history)
try:
    order9.pack()  # valid
    order9.cancel("r")
except:
    pass
order9.refund()
check("refund from cancelled should raise", "skip", "skip")
# Can't refund from cancelled! Actually we cancelled in the middle.
order10 = Order("O10", [("PEN", 1, 100)])
order10.pay()
hist_before = list(order10.history)
status_before = order10.status
tn_before = order10.tracking_number
cr_before = order10.cancel_reason
try:
    order10.ship('bad')
except InvalidTransition:
    pass
check("history unchanged after failed transition", order10.history, hist_before)
check("status unchanged after failed transition", order10.status, status_before)
check("tracking_number unchanged", order10.tracking_number, tn_before)
check("cancel_reason unchanged", order10.cancel_reason, cr_before)

# 14. Empty clock argument
try:
    order_empty = Order("E1", [], clock=None)
    order_empty.pay()
    check("clock=None works", order_empty.status, "paid")
except Exception as e:
    errors.append(f"FAIL: clock=None raised: {e}")

# 15. Test all transitions forbidden
order11 = Order("O11", [("PEN", 1, 100)])
check("is_terminal new order", order11.is_terminal, False)
check("can pay from pending", order11.can("pay"), True)
check("can cancel from pending", order11.can("cancel"), True)
check("can refund from pending", order11.can("refund"), False)
check("can ship from pending", order11.can("ship"), False)
check("can pack from pending", order11.can("pack"), False)
check("can deliver from pending", order11.can("deliver"), False)

# Summary
if errors:
    print(f"\n{len(errors)} ERRORS:")
    for e in errors:
        print(" ", e)
else:
    print("All checks passed!")
