"""Orders and their lifecycle."""

import datetime
from typing import NamedTuple


class Transition(NamedTuple):
    event: str
    from_state: str
    to_state: str
    at: datetime.datetime


class InvalidTransition(Exception):
    def __init__(self, state, event):
        self.state = state
        self.event = event
        super().__init__(f"Invalid transition: {event} from {state}")


class Order:
    """A customer order.

    `items` is a list of (sku, quantity, unit_price_cents) tuples.
    """

    # transition table: event -> {from_state: to_state}
    _TRANSITIONS = {
        "pay": {"pending": "paid"},
        "pack": {"paid": "packed"},
        "ship": {"packed": "shipped"},
        "deliver": {"shipped": "delivered"},
        "cancel": {"pending": "cancelled", "paid": "cancelled", "packed": "cancelled"},
        "refund": {"paid": "refunded", "packed": "refunded", "delivered": "refunded"},
    }

    _TERMINAL_STATES = {"cancelled", "refunded"}

    _REFUND_WINDOW_DAYS = 30

    def __init__(self, order_id, items, clock=None):
        self.order_id = order_id
        self.items = list(items)
        self.status = "pending"
        self.tracking_number = None
        self.cancel_reason = None
        self._clock = clock if clock is not None else datetime.datetime.now(datetime.timezone.utc)
        self._history = []
        self._delivered_at = None

    def total_cents(self):
        return sum(quantity * price for _sku, quantity, price in self.items)

    @property
    def history(self):
        return list(self._history)

    @property
    def delivered_at(self):
        return self._delivered_at

    @property
    def is_terminal(self):
        return self.status in self._TERMINAL_STATES

    def can(self, event):
        if self.is_terminal:
            return False
        allowed = self.allowed_events()
        return event in allowed

    def allowed_events(self):
        if self.is_terminal:
            return []
        events = set()
        for event, transitions in self._TRANSITIONS.items():
            if self.status in transitions:
                if event == "refund":
                    if self.status == "delivered":
                        if self._delivered_at is None:
                            continue
                        now = self._clock() if callable(self._clock) else self._clock
                        if (now - self._delivered_at).days > self._REFUND_WINDOW_DAYS:
                            continue
                events.add(event)
        return sorted(events)

    def _get_time(self):
        return self._clock() if callable(self._clock) else self._clock

    def _validate_transition(self, event):
        if self.is_terminal:
            raise InvalidTransition(self.status, event)

        transitions = self._TRANSITIONS.get(event)
        if transitions is None or self.status not in transitions:
            raise InvalidTransition(self.status, event)

        if event == "refund" and self.status == "delivered":
            if self._delivered_at is None:
                raise InvalidTransition(self.status, event)
            now = self._get_time()
            if (now - self._delivered_at).days > self._REFUND_WINDOW_DAYS:
                raise InvalidTransition(self.status, event)

    def _do_transition(self, event):
        to_state = self._TRANSITIONS[event][self.status]
        at = self._get_time()
        self._history.append(Transition(event, self.status, to_state, at))
        self.status = to_state
        return at

    def pay(self):
        self._validate_transition("pay")
        self._do_transition("pay")

    def pack(self):
        self._validate_transition("pack")
        self._do_transition("pack")

    def ship(self, tracking_number):
        self._validate_transition("ship")
        if not isinstance(tracking_number, str) or not tracking_number.strip():
            raise ValueError("tracking_number must be a non-empty string")
        self.tracking_number = tracking_number.strip()
        self._do_transition("ship")

    def deliver(self):
        self._validate_transition("deliver")
        at = self._do_transition("deliver")
        self._delivered_at = at

    def cancel(self, reason):
        self._validate_transition("cancel")
        if not isinstance(reason, str) or not reason.strip():
            raise ValueError("reason must be a non-empty string")
        self.cancel_reason = reason.strip()
        self._do_transition("cancel")

    def refund(self):
        self._validate_transition("refund")
        self._do_transition("refund")
