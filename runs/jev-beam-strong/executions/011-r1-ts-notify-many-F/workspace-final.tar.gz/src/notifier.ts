export interface Transport {
  send(recipient: string, message: string): void;
}

/** Records every send in memory. Handy in tests and dry runs. */
export class MemoryTransport implements Transport {
  sent: Array<{ recipient: string; message: string }> = [];

  send(recipient: string, message: string): void {
    this.sent.push({ recipient, message });
  }
}

export class Notifier {
  private transport: Transport;

  constructor(transport: Transport) {
    this.transport = transport;
  }

  /**
   * Send `message` to one recipient or to each recipient in a list.
   *
   * A `string` recipient is trimmed and sent once. When given an array, each
   * recipient is trimmed and sent in the order given. Duplicates are sent only
   * once: two recipients are the same if their trimmed values match
   * case-insensitively, and the first spelling is the one sent.
   *
   * Returns how many messages were actually sent (1 for a single string, the
   * number of unique recipients for an array, 0 for an empty array).
   *
   * Throws TypeError if any recipient is empty or only whitespace. Validation
   * happens before anything is sent, so a bad list never results in a partial
   * send.
   */
  notify(recipients: string | readonly string[], message: string): number {
    const list = Array.isArray(recipients) ? recipients : [recipients];

    const toSend: string[] = [];
    const seen = new Set<string>();
    for (const raw of list) {
      const to = raw.trim();
      if (to === "") {
        throw new TypeError("recipient must be a non-empty string");
      }
      const key = to.toLowerCase();
      if (!seen.has(key)) {
        seen.add(key);
        toSend.push(to);
      }
    }

    for (const to of toSend) {
      this.transport.send(to, message);
    }
    return toSend.length;
  }
}
