import { test } from "node:test";
import assert from "node:assert/strict";
import { parseIni, stringifyIni } from "../src/ini.js";

test("parses the basic example", () => {
  assert.deepEqual(parseIni("[server]\nport = 8080\n"), { server: { port: "8080" } });
});

test("keys before the first header go to the '' section; comments and \r\n", () => {
  const text = "name = api\r\n; note\r\n# other\r\n[s]\r\nx = 1\r\n";
  assert.deepEqual(parseIni(text), { "": { name: "api" }, s: { x: "1" } });
});

test("the '' section only appears when it has keys", () => {
  assert.deepEqual(parseIni("# c\n\n[s]\nx = 1\n"), { s: { x: "1" } });
});

test("duplicate sections merge, last value wins; empty section and value kept", () => {
  const text = "[a]\nk = 1\n[b]\n[a]\nk = 2\ne =\n";
  assert.deepEqual(parseIni(text), { a: { k: "2", e: "" }, b: {} });
});

test("section order follows first appearance", () => {
  assert.deepEqual(Object.keys(parseIni("[b]\nx = 1\n[a]\ny = 2\n[b]\nz = 3\n")), ["b", "a"]);
});

test("no inline comments: ';' and '#' mid-line are ordinary text", () => {
  assert.deepEqual(parseIni("[s]\nx = a;b # c\n"), { s: { x: "a;b # c" } });
});

test("quoted values: four escapes, whitespace inside kept", () => {
  const text = '[s]\nv = " hi \\"x\\"\\\\\\n\\t "\n';
  assert.deepEqual(parseIni(text), { s: { v: ' hi "x"\\\n\t ' } });
});

test("a value starting with a real quote must then parse as quoted", () => {
  const text = '[s]\nv = ""\n';
  assert.deepEqual(parseIni(text), { s: { v: "" } });
});

test("line continuation joins trimmed lines with one space and chains", () => {
  const text = "[s]\na = one\\\n two\\\n;three\nb = x\\\n[not-a-header]\n";
  assert.deepEqual(parseIni(text), { s: { a: "one two ;three", b: "x [not-a-header]" } });
});

test("continuation backslash on the last line throws at that line", () => {
  assert.throws(
    () => parseIni("ok = 1\n\ncont = a\\\n"),
    (e) => e instanceof SyntaxError && e.line === 3,
  );
});

test("errors are SyntaxError with a numeric 1-based line property", () => {
  const cases = [
    ["[]\n", 1],
    ["[  ]\n", 1],
    ["[oops\n", 1],
    ["= v\n", 1],
    ["just text\n", 1],
    ['[s]\nv = "x" tail\n', 2],
    ['[s]\nv = "x\n', 2],
    ['[s]\nv = "\\q"\n', 2],
  ];
  for (const [text, line] of cases) {
    assert.throws(
      () => parseIni(text),
      (e) => e instanceof SyntaxError && typeof e.line === "number" && e.line === line,
      JSON.stringify(text),
    );
  }
});

test("round-trip: parseIni(stringifyIni(data)) returns the data", () => {
  const data = {
    "": { name: "api", padded: " x " },
    server: { port: "8080", motd: ' hi "there"\nnext\ttab\\' },
  };
  assert.deepEqual(parseIni(stringifyIni(data)), data);
});
