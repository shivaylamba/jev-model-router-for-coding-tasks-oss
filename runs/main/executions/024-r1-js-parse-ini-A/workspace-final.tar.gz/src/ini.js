/**
 * INI reading and writing. See docs/INI_FORMAT.md for the dialect.
 */

function quote(value) {
  const escaped = value
    .replace(/\\/g, "\\\\")
    .replace(/"/g, '\\"')
    .replace(/\n/g, "\\n")
    .replace(/\t/g, "\\t");
  return `"${escaped}"`;
}

function needsQuotes(value) {
  return value !== value.trim() || /["\\\n\t]/.test(value) || value.startsWith('"');
}

function fail(line, message) {
  const error = new SyntaxError(`Line ${line}: ${message}`);
  error.line = line;
  return error;
}

const ESCAPES = { '"': '"', "\\": "\\", n: "\n", t: "\t" };

/** Parse a quoted value starting at the opening quote. Line is for errors. */
function unquote(text, line) {
  let value = "";
  let index = 1;
  while (index < text.length) {
    const char = text[index];
    if (char === '"') {
      if (text.slice(index + 1).trim() !== "") {
        throw fail(line, "unexpected text after the closing quote");
      }
      return value;
    }
    if (char === "\\") {
      const escaped = ESCAPES[text[index + 1]];
      if (escaped === undefined) {
        throw fail(line, "unsupported escape in quoted value");
      }
      value += escaped;
      index += 2;
    } else {
      value += char;
      index += 1;
    }
  }
  throw fail(line, "missing closing quote");
}

/**
 * Parse INI text to { section: { key: value } }, the dialect stringifyIni
 * writes (see docs/INI_FORMAT.md). Keys before the first header land in the
 * "" section. Duplicate sections merge; a repeated key keeps its last value.
 * Throws a SyntaxError with a numeric 1-based `line` property on bad input.
 */
export function parseIni(text) {
  const lines = text.replace(/\r\n/g, "\n").split("\n");
  // A single trailing empty element is just the final newline terminator, not a line
  const lastLine = lines[lines.length - 1] === "" ? lines.length - 1 : lines.length;
  const result = {};
  let section = null;

  for (let index = 0; index < lines.length; index += 1) {
    const number = index + 1;
    const line = lines[index].trim();
    if (line === "" || line.startsWith(";") || line.startsWith("#")) continue;

    if (line.startsWith("[")) {
      if (!line.endsWith("]")) {
        throw fail(number, "section header does not end with ']'");
      }
      const name = line.slice(1, -1).trim();
      if (name === "") {
        throw fail(number, "section name must not be empty");
      }
      if (!(name in result)) result[name] = {};
      section = name;
      continue;
    }

    const split = line.indexOf("=");
    if (split === -1) {
      throw fail(number, "expected a section header or 'key = value'");
    }

    const key = line.slice(0, split).trim();
    if (key === "") {
      throw fail(number, "key must not be empty");
    }

    let value = line.slice(split + 1).trim();
    if (value.startsWith('"')) {
      value = unquote(value, number);
    } else {
      while (value.endsWith("\\")) {
        if (index + 1 >= lastLine) {
          throw fail(index + 1, "line continuation on the last line of the file");
        }
        index += 1;
        value = `${value.slice(0, -1).trimEnd()} ${lines[index].trim()}`;
      }
    }

    const target = section === null ? "" : section;
    if (!(target in result)) result[target] = {};
    result[target][key] = value;
  }

  if ("" in result && Object.keys(result[""]).length === 0) {
    delete result[""];
  }
  return result;
}

/**
 * Serialize { section: { key: value } } to INI text. Keys of the "" section
 * are written first, without a header. Values are converted with String().
 */
export function stringifyIni(data) {
  const lines = [];
  const sections = Object.keys(data);
  const ordered = sections.includes("") ? ["", ...sections.filter((s) => s !== "")] : sections;
  for (const section of ordered) {
    if (section !== "") {
      if (lines.length > 0) lines.push("");
      lines.push(`[${section}]`);
    }
    for (const [key, raw] of Object.entries(data[section])) {
      const value = String(raw);
      lines.push(`${key} = ${needsQuotes(value) ? quote(value) : value}`);
    }
  }
  return lines.join("\n") + "\n";
}
