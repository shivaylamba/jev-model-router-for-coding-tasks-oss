"""Asyncio rate limiter: per-key token buckets plus a global concurrency cap.

See SPEC.md for the full behaviour. All time comes from the injected `clock`
and every wait on time goes through the injected async `sleep`.
"""

import asyncio
import heapq
import itertools

from ratelimit.bucket import TokenBucket


class _Request:
    """One acquire() call waiting for (or holding) a grant."""

    __slots__ = ("key", "seq", "granted")

    def __init__(self, key, seq):
        self.key = key
        self.seq = seq  # keep grants in the order acquire was called
        self.granted = False


class RateLimiter:
    def __init__(self, rate, burst, max_concurrent, *, clock, sleep):
        if not isinstance(rate, (int, float)) or isinstance(rate, bool) or rate <= 0:
            raise ValueError("rate must be a number greater than 0")
        if not isinstance(burst, int) or isinstance(burst, bool) or burst < 1:
            raise ValueError("burst must be an integer of at least 1")
        if (
            not isinstance(max_concurrent, int)
            or isinstance(max_concurrent, bool)
            or max_concurrent < 1
        ):
            raise ValueError("max_concurrent must be an integer of at least 1")
        self.rate = rate
        self.burst = burst
        self.max_concurrent = max_concurrent
        self._clock = clock
        self._sleep = sleep
        self._buckets = {}  # key -> TokenBucket (created full on first use)
        self._waiting = {}  # key -> FIFO of ungranted requests
        self._grants = []  # min-heap of (seq, counter) for granted requests
        self._counter = itertools.count()
        self._in_use = 0

    async def acquire(self, key):
        """Wait until a request for `key` is granted (one token and one slot)."""
        bucket = self._buckets.get(key)
        if bucket is None:
            bucket = self._buckets[key] = TokenBucket(self.rate, self.burst, self._clock)
        request = _Request(key, next(self._counter))
        self._waiting.setdefault(key, []).append(request)
        self._grant_pass()
        granted = await self._wait_for_grant(request, bucket)
        if not granted:
            # Cancelled while still waiting: dropped in the CancelledError
            # handler below, which then runs the next grant pass.
            await self._raise_cancelled()
        if not self._keep_grant(request):
            # Granted by a grant pass, but the task was cancelled before it
            # resumed: undo the grant — slot freed, token back in the bucket.
            self._undo_grant(request)
            self._grant_pass()
            await self._raise_cancelled()
        heapq.heappush(self._grants, (request.seq, next(self._counter)))
        return self

    async def _wait_for_grant(self, request, bucket):
        """Wait until granted; return False if cancelled while still ungranted."""
        try:
            while not request.granted:
                if self._head(request.key) is request:
                    delay = bucket.time_until_available()
                    # Only a token shortage justifies waiting on time; requests
                    # that merely lack a slot are granted by a later grant pass.
                    if delay > 0:
                        await self._sleep(delay)
                        self._grant_pass()
                        continue
                # No token to wait for: idle until a grant pass wakes this task.
                request.granted = await self._poll(request)
            return True
        except asyncio.CancelledError:
            if not request.granted:
                queue = self._waiting.get(request.key)
                if queue and request in queue:
                    queue.remove(request)
                    if not queue:
                        del self._waiting[request.key]
                self._grant_pass()
                return False
            raise

    async def _raise_cancelled(self):
        """Deliver the pending cancellation so it propagates out of acquire."""
        loop = asyncio.get_running_loop()
        task = asyncio.current_task()
        if task is not None and not task.cancelling():
            task.cancel()
        await loop.create_future()

    def _keep_grant(self, request):
        """Yield once; a task cancelled before resuming loses its grant."""
        task = asyncio.current_task()
        if task is not None and task.cancelling():
            request.granted = False
            return False
        return True

    def release(self):
        """Free one slot."""
        if self._in_use <= 0:
            raise RuntimeError("release() called with no slot held")
        self._in_use -= 1
        self._grant_pass()

    def limit(self, key):
        """Async context manager: acquire on entry, release on exit."""
        return _LimitContext(self, key)

    @property
    def in_use(self):
        return self._in_use

    def tokens(self, key):
        bucket = self._buckets.get(key)
        if bucket is None:
            return float(self.burst)
        return bucket.available()

    def waiting(self, key=None):
        if key is not None:
            return len(self._waiting.get(key, ()))
        return sum(len(queue) for queue in self._waiting.values())

    # -- internals ---------------------------------------------------------

    def _head(self, key):
        queue = self._waiting.get(key)
        return queue[0] if queue else None

    def _grant_pass(self):
        """Grant the eligible head whose acquire call came first, repeatedly."""
        while self._in_use < self.max_concurrent:
            head = self._eligible_head()
            if head is None:
                return
            self._buckets[head.key].try_take()
            self._in_use += 1
            self._waiting[head.key].pop(0)
            if not self._waiting[head.key]:
                del self._waiting[head.key]
            head.granted = True

    def _eligible_head(self):
        """The head with the oldest acquire call among heads that have a token."""
        candidate = None
        for key, queue in self._waiting.items():
            if self._buckets[key].available() >= 1 and (
                candidate is None or queue[0].seq < candidate.seq
            ):
                candidate = queue[0]
        return candidate

    async def _poll(self, request):
        """Re-check the grant flag between event-loop ticks without consuming time."""
        await _IdleWait()
        return request.granted

    def _undo_grant(self, request):
        self._in_use -= 1
        self._buckets[request.key].release_token()


class _IdleWait:
    """Awaitable that yields to the event loop for one tick, like sleep(0)."""

    def __await__(self):
        yield


class _LimitContext:
    def __init__(self, limiter, key):
        self._limiter = limiter
        self._key = key

    async def __aenter__(self):
        await self._limiter.acquire(self._key)
        return self._limiter

    async def __aexit__(self, exc_type, exc, tb):
        self._limiter.release()
        return False
