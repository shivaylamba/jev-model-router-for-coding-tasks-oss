"""Username helpers."""

RESERVED = frozenset({"admin", "root", "support", "moderator"})
SEPARATORS = frozenset("._-")


def normalize_username(raw):
    """Trim surrounding whitespace and lowercase a username as typed at signup."""
    return raw.strip().lower()


def is_valid_username(name):
    """Whether a (normalized) username meets the signup format rules.

    A valid username is 3-20 characters, starts with a lowercase letter,
    and contains only lowercase letters, digits and the separators
    ".", "_" and "-". Separators may not sit next to each other or at
    the end. Anything that is not a str is invalid.
    """
    if not isinstance(name, str) or not 3 <= len(name) <= 20:
        return False
    if not ("a" <= name[0] <= "z"):
        return False
    if name[-1] in SEPARATORS:
        return False
    previous_was_separator = False
    for char in name:
        is_separator = char in SEPARATORS
        if is_separator and previous_was_separator:
            return False
        if not is_separator and not ("a" <= char <= "z" or "0" <= char <= "9"):
            return False
        previous_was_separator = is_separator
    return True


def is_reserved(name):
    """Whether a (normalized) username is reserved for staff accounts."""
    return name in RESERVED
