import unittest

from accounts.usernames import is_reserved, is_valid_username, normalize_username


class NormalizeTest(unittest.TestCase):
    def test_normalize(self):
        self.assertEqual(normalize_username("  Ada.L "), "ada.l")

    def test_reserved(self):
        self.assertTrue(is_reserved("admin"))
        self.assertFalse(is_reserved("ada"))


class IsValidUsernameTest(unittest.TestCase):
    def test_valid_names(self):
        for name in ["ada", "ada.l", "a-b_c", "user123", "a1.b2-c3", "a" * 20]:
            self.assertTrue(is_valid_username(name), name)

    def test_length_out_of_range(self):
        for name in ["", "ab", "a" * 21]:
            self.assertFalse(is_valid_username(name), name)

    def test_bad_first_character(self):
        for name in ["1ada", "_ada", ".ada", "-ada", "Ada", "éada"]:
            self.assertFalse(is_valid_username(name), name)

    def test_disallowed_characters(self):
        for name in ["ad a", "ad+a", "aDa", "café", "ada~", "a\tb"]:
            self.assertFalse(is_valid_username(name), name)

    def test_adjacent_separators(self):
        for name in ["a..b", "a._b", "a-.b", "a_-.b"]:
            self.assertFalse(is_valid_username(name), name)

    def test_trailing_separator(self):
        for name in ["ada.", "ada_", "ada-", "a.b-"]:
            self.assertFalse(is_valid_username(name), name)

    def test_non_string_input(self):
        for name in [None, 42, 3.14, b"ada", ["ada"], True]:
            self.assertFalse(is_valid_username(name), repr(name))


if __name__ == "__main__":
    unittest.main()
