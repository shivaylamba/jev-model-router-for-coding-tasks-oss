function channel(value: number): string {
  if (!Number.isInteger(value) || value < 0 || value > 255) {
    throw new RangeError(`colour channel out of range: ${value}`);
  }
  return value.toString(16).padStart(2, "0");
}

/** Format RGB channels (0-255) as a lowercase "#rrggbb" string. */
export function rgbToHex(r: number, g: number, b: number): string {
  return `#${channel(r)}${channel(g)}${channel(b)}`;
}

/**
 * Normalize a pasted hex colour to a lowercase "#rrggbb" or "#rrggbbaa"
 * string, expanding 3- or 4-digit shorthand by doubling each digit.
 * Returns null for anything that is not a valid hex colour.
 */
export function normalizeHexColor(input: string): string | null {
  const match = /^#([0-9a-f]+)$/i.exec(input.trim());
  if (!match || ![3, 4, 6, 8].includes(match[1].length)) {
    return null;
  }
  const digits = match[1].toLowerCase();
  if (digits.length <= 4) {
    return `#${digits.replace(/./g, (d) => d + d)}`;
  }
  return `#${digits}`;
}
