import { test } from "node:test";
import assert from "node:assert/strict";
import { normalizeHexColor, rgbToHex } from "../src/color.ts";

test("rgbToHex", () => {
  assert.equal(rgbToHex(255, 136, 0), "#ff8800");
  assert.throws(() => rgbToHex(256, 0, 0), RangeError);
});

test("normalizeHexColor accepts 6 and 8 digits, lowercased", () => {
  assert.equal(normalizeHexColor("#FF8800"), "#ff8800");
  assert.equal(normalizeHexColor("#ff8800"), "#ff8800");
  assert.equal(normalizeHexColor("#11223344"), "#11223344");
  assert.equal(normalizeHexColor("#112233FF"), "#112233ff");
});

test("normalizeHexColor expands 3 and 4 digit shorthand", () => {
  assert.equal(normalizeHexColor("#AbC"), "#aabbcc");
  assert.equal(normalizeHexColor("#f0e"), "#ff00ee");
  assert.equal(normalizeHexColor("#abcd"), "#aabbccdd");
  assert.equal(normalizeHexColor("#1af"), "#11aaff");
});

test("normalizeHexColor ignores surrounding whitespace", () => {
  assert.equal(normalizeHexColor("  #ff8800\n"), "#ff8800");
  assert.equal(normalizeHexColor("\t#AbC "), "#aabbcc");
});

test("normalizeHexColor returns null for invalid input", () => {
  // Missing or doubled "#".
  assert.equal(normalizeHexColor("ff8800"), null);
  assert.equal(normalizeHexColor("##ff8800"), null);
  // Wrong digit counts.
  for (const digits of ["1", "12", "12345", "1234567", "123456789"]) {
    assert.equal(normalizeHexColor(`#${digits}`), null, `#${digits}`);
  }
  // Non-hex characters, whitespace inside the value.
  assert.equal(normalizeHexColor("#ff88gg"), null);
  assert.equal(normalizeHexColor("#ff 8800"), null);
  // Named colours and empty input.
  assert.equal(normalizeHexColor("orange"), null);
  assert.equal(normalizeHexColor(""), null);
  assert.equal(normalizeHexColor("#"), null);
});
