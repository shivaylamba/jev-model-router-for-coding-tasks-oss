export interface Transport {
  send(recipient: string, message: string): void;
}

/** Records every send in memory. Handy in tests and dry runs. */
export class MemoryTransport implements Transport {
  sent: Array<{ recipient: string; message: string }> = [];

  send(recipient: string, message: string): void {
    this.sent.push({ recipient, message });
  }
}

export class Notifier {
  private transport: Transport;

  constructor(transport: Transport) {
    this.transport = transport;
  }

  /**
   * Send `message` to one or more recipients, each trimmed before sending.
   * Throws TypeError if any recipient is empty or only whitespace; for an
   * array the check runs before anything is sent, so a bad list never
   * results in a partial send. Duplicate recipients (matching
   * case-insensitively after trimming) are sent once, using the first
   * spelling. Returns how many messages were actually sent.
   */
  notify(recipients: string | readonly string[], message: string): number {
    const list = typeof recipients === "string" ? [recipients] : recipients;
    const trimmed = list.map((recipient) => {
      const to = recipient.trim();
      if (to === "") {
        throw new TypeError("recipient must be a non-empty string");
      }
      return to;
    });
    if (typeof recipients === "string") {
      this.transport.send(trimmed[0], message);
      return 1;
    }
    const seen = new Set<string>();
    let sent = 0;
    for (const to of trimmed) {
      const key = to.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      this.transport.send(to, message);
      sent += 1;
    }
    return sent;
  }
}
