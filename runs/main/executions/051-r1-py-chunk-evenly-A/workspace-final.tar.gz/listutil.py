"""List helpers."""


def flatten(nested):
    """Flatten one level of nesting: [[1, 2], [3]] -> [1, 2, 3]."""
    return [item for group in nested for item in group]


def chunk_evenly(items, n):
    """Split items into exactly n consecutive chunks with sizes differing by
    at most one, longer chunks first. Extra chunks are empty when n exceeds
    len(items). Raise ValueError if n < 1. Does not modify items."""
    if n < 1:
        raise ValueError("n must be at least 1")
    count = len(items)
    base, extra = divmod(count, n)
    chunks = []
    start = 0
    for i in range(n):
        size = base + (1 if i < extra else 0)
        chunks.append(list(items[start:start + size]))
        start += size
    return chunks
