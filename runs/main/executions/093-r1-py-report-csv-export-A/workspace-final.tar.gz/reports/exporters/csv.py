"""CSV export for machines: no display formatting, standard quoting, \n newlines."""


def _format_value(value):
    """Format a raw cell value for CSV; display formatting does not apply."""
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return format(value, ".2f")
    return str(value)


def _quote(field):
    if any(ch in field for ch in (",", '"', "\n", "\r")):
        return '"' + field.replace('"', '""') + '"'
    return field


class CsvExporter:
    name = "csv"
    extension = ".csv"

    def export(self, report):
        lines = [",".join(_quote(c.label) for c in report.columns)]
        for row in report.rows:
            lines.append(",".join(_quote(_format_value(report.cell(row, c))) for c in report.columns))
        return "".join(line + "\n" for line in lines)
