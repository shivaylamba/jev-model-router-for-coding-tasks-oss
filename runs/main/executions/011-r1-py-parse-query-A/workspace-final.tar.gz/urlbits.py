"""Lossless URL query-string parsing and building.

Unlike urllib.parse, this preserves bare keys (flag -> None), empty
values (x= -> ""), key order, and repeated-key order, so callers like a
link checker can rewrite a query string without changing anything they
don't intend to.
"""

_HEX = frozenset("0123456789abcdefABCDEF")
_UNRESERVED = frozenset(
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~"
)


def _decode_piece(text: str) -> str:
    """Percent-decode one query key/value.

    Valid %XX triples are raw bytes through the UTF-8 decoder; everything
    else stays exactly as typed. "+" becomes a space. A "%" without two
    trailing hex digits ("100%", "%zz", a trailing "%2") is kept as-is.
    """
    parts: list[bytes | str] = []
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        if (
            ch == "%"
            and i + 2 < n
            and text[i + 1] in _HEX
            and text[i + 2] in _HEX
        ):
            parts.append(int(text[i + 1 : i + 3], 16).to_bytes(1, "big"))
            i += 3
        else:
            parts.append(" " if ch == "+" else ch)
            i += 1

    out: list[str] = []
    buf = bytearray()

    def flush() -> None:
        if buf:
            out.append(bytes(buf).decode("utf-8", "replace"))
            buf.clear()

    for part in parts:
        if isinstance(part, bytes):
            buf += part
        else:
            flush()
            out.append(part)
    flush()
    return "".join(out)


def _encode_piece(text: str) -> str:
    """Percent-encode one query key/value (build_query's encoding)."""
    out: list[str] = []
    for byte in text.encode("utf-8"):
        ch = chr(byte)
        if ch in _UNRESERVED:
            out.append(ch)
        elif byte == 0x20:
            out.append("+")
        else:
            out.append("%%%02X" % byte)
    return "".join(out)


def parse_query(query: str) -> dict[str, list[str | None]]:
    """Parse a query string into an insertion-ordered dict of value lists.

    A leading "?" is ignored. Bare keys map to None, "key=" maps to "".
    """
    result: dict[str, list[str | None]] = {}
    if query.startswith("?"):
        query = query[1:]
    for segment in query.split("&"):
        if not segment:
            continue
        raw_key, sep, raw_value = segment.partition("=")
        key = _decode_piece(raw_key)
        value = _decode_piece(raw_value) if sep else None
        result.setdefault(key, []).append(value)
    return result


def build_query(params: dict[str, list[str | None] | str | None]) -> str:
    """Build a query string from parse_query-shaped params.

    Keys keep mapping order, list items keep list order; an empty list
    writes nothing. None values become bare keys. Values (and list items)
    that are neither str nor None raise TypeError.
    """
    pairs: list[str] = []
    for key, value in params.items():
        if not isinstance(key, str):
            raise TypeError(f"query key must be str, got {type(key).__name__}")
        encoded_key = _encode_piece(key)
        values = value if isinstance(value, list) else [value]
        for item in values:
            if item is None:
                pairs.append(encoded_key)
            elif isinstance(item, str):
                pairs.append(f"{encoded_key}={_encode_piece(item)}")
            else:
                raise TypeError(
                    f"query value for {key!r} must be str or None, "
                    f"got {type(item).__name__}"
                )
    return "&".join(pairs)
