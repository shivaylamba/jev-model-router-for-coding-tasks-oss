"""Spec tests for urlbits.parse_query / build_query.

Run with an isolated interpreter:
    python3 -I test_urlbits.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from urlbits import parse_query, build_query

passed = 0
failed = 0


def check(label, cond):
    global passed, failed
    if cond:
        passed += 1
    else:
        failed += 1
        print("FAIL:", label)


# ---- parse_query: structure ----
check("empty string", parse_query("") == {})
check("only question mark", parse_query("?") == {})
check("leading ? ignored", parse_query("?a=1") == {"a": ["1"]})
check(
    "spec example",
    parse_query("a=1&flag&a=2") == {"a": ["1", "2"], "flag": [None]},
)
check(
    "key order is first appearance",
    list(parse_query("b=1&a=2&b=3").keys()) == ["b", "a"],
)
check("empty value x=", parse_query("x=") == {"x": [""]})
check("bare key vs empty value", parse_query("x&y=") == {"x": [None], "y": [""]})
check(
    "empty segments skipped",
    parse_query("&&a=1&&&b=2&") == {"a": ["1"], "b": ["2"]},
)
check("split on first = only", parse_query("x=a=b") == {"x": ["a=b"]})

# ---- parse_query: decoding ----
check("plus becomes space", parse_query("q=a+b") == {"q": ["a b"]})
check("uppercase hex", parse_query("q=a%20b") == {"q": ["a b"]})
check("lowercase hex", parse_query("q=a%2fb") == {"q": ["a/b"]})
check(
    "utf-8 sequence",
    parse_query("name=%D0%BA%D0%BE%D1%82") == {"name": ["кот"]},
)
check("lone percent kept", parse_query("x=100%") == {"x": ["100%"]})
check("non-hex escape kept", parse_query("x=%zz") == {"x": ["%zz"]})
check("truncated escape kept", parse_query("x=%2") == {"x": ["%2"]})
check("trailing percent kept", parse_query("x=%") == {"x": ["%"]})
check("invalid utf-8 becomes U+FFFD", parse_query("x=%C3") == {"x": ["�"]})
check("keys decoded too", parse_query("a+b=c+d") == {"a b": ["c d"]})
check(
    "decoded keys merge into one list",
    parse_query("a+b=1&a%20b=2") == {"a b": ["1", "2"]},
)

# ---- build_query: output ----
check("bare key", build_query({"flag": [None]}) == "flag")
check("empty value", build_query({"x": [""]}) == "x=")
check("plain pair", build_query({"a": ["1"]}) == "a=1")
check(
    "mapping and list order",
    build_query({"b": ["1"], "a": ["2", "3"]}) == "b=1&a=2&a=3",
)
check(
    "empty list writes nothing",
    build_query({"a": [], "b": ["1"]}) == "b=1",
)
check("scalar str accepted", build_query({"a": "1"}) == "a=1")
check("scalar None accepted", build_query({"flag": None}) == "flag")
check(
    "space plus and ampersand",
    build_query({"q": "a b&c"}) == "q=a+b%26c",
)
check("uppercase hex", build_query({"x": "/"}) == "x=%2F")
check(
    "unreserved untouched",
    build_query({"k": "AZaz09-._~"}) == "k=AZaz09-._~",
)
check(
    "utf-8 percent-encoded",
    build_query({"name": "кот"}) == "name=%D0%BA%D0%BE%D1%82",
)
check("key encoded", build_query({"a b": ["1"]}) == "a+b=1")
check("no leading ?", not build_query({"a": ["1"]}).startswith("?"))

# ---- build_query: TypeError ----
for bad, label in [(42, "int"), (3.5, "float"), (b"x", "bytes"), (True, "bool")]:
    try:
        build_query({"a": [bad]})
        check("TypeError for list item " + label, False)
    except TypeError:
        check("TypeError for list item " + label, True)
    try:
        build_query({"a": bad})
        check("TypeError for scalar " + label, False)
    except TypeError:
        check("TypeError for scalar " + label, True)

# ---- round-trips ----
p = {"a": ["1", "2"], "flag": [None], "x": [""], "q": ["a b&c"]}
check("parse(build(p)) == p", parse_query(build_query(p)) == p)

s = "b=1&a=2&a=3&flag&x=&q=a+b%26c"
check("build(parse(s)) == s", build_query(parse_query(s)) == s)

s_utf8 = "name=%D0%BA%D0%BE%D1%82&flag"
check(
    "utf-8 round-trip",
    build_query(parse_query(s_utf8)) == s_utf8,
)

print()
print(passed, "passed,", failed, "failed")
raise SystemExit(1 if failed else 0)
