import { test } from "node:test";
import assert from "node:assert/strict";
import { formatCents, totalCents, type Currency } from "../src/money.ts";

test("totalCents", () => {
  assert.equal(totalCents([]), 0);
  assert.equal(
    totalCents([
      { description: "widget", quantity: 3, unitCents: 250 },
      { description: "gadget", quantity: 1, unitCents: 1999 },
    ]),
    2749,
  );
});

test("formatCents", () => {
  assert.equal(formatCents(123456, "USD"), "$1,234.56");
  assert.equal(formatCents(5, "USD"), "$0.05");
  assert.equal(formatCents(0, "GBP"), "£0.00");
  assert.equal(formatCents(123456789, "EUR"), "€1,234,567.89");
  assert.equal(formatCents(-123456, "USD"), "-$1,234.56");
  assert.equal(formatCents(-5, "GBP"), "-£0.05");
});

test("formatCents rejects non-integer cents", () => {
  for (const bad of [1.5, NaN, Infinity, -Infinity, "100" as unknown as number]) {
    assert.throws(() => formatCents(bad, "USD"), TypeError);
  }
});

test("formatCents rejects unsupported currency", () => {
  assert.throws(() => formatCents(100, "JPY" as unknown as Currency), RangeError);
  assert.throws(() => formatCents(100, undefined as unknown as Currency), RangeError);
});
