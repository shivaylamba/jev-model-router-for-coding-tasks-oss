export type Currency = "USD" | "EUR" | "GBP";

export interface LineItem {
  description: string;
  quantity: number;
  unitCents: number;
}

/** Total of all line items, in cents. */
export function totalCents(items: readonly LineItem[]): number {
  return items.reduce((acc, item) => acc + item.quantity * item.unitCents, 0);
}

const CURRENCY_SYMBOLS: Record<Currency, string> = {
  USD: "$",
  EUR: "€",
  GBP: "£",
};

/** Insert commas every three digits, e.g. "1234567" -> "1,234,567". */
function groupThousands(digits: string): string {
  let grouped = "";
  for (let i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 === 0) {
      grouped += ",";
    }
    grouped += digits[i];
  }
  return grouped;
}

/**
 * Format an integer amount of cents for display on invoices, e.g.
 * formatCents(123456, "USD") === "$1,234.56". Locale-independent.
 *
 * @throws TypeError if cents is not an integer number
 * @throws RangeError if currency is not supported
 */
export function formatCents(cents: number, currency: Currency): string {
  if (typeof cents !== "number" || !Number.isInteger(cents)) {
    throw new TypeError(`formatCents: cents must be an integer, got ${String(cents)}`);
  }
  const symbol = (CURRENCY_SYMBOLS as Record<string, string | undefined>)[currency];
  if (symbol === undefined) {
    throw new RangeError(`formatCents: unsupported currency ${String(currency)}`);
  }

  const magnitude = Math.abs(cents);
  const whole = Math.floor(magnitude / 100);
  const fraction = magnitude % 100;
  const sign = cents < 0 ? "-" : "";
  return (
    sign + symbol + groupThousands(String(whole)) + "." + String(fraction).padStart(2, "0")
  );
}
