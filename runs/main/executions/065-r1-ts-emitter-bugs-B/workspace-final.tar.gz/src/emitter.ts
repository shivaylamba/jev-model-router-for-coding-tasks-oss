export type Listener = (...args: unknown[]) => void;

interface Registration {
  /** The listener as recorded in the registry. May be a wrapper for `once`. */
  fn: Listener;
  /** The function the caller passed to `on`/`once`, used by `off` to match. */
  original: Listener;
  /** Set to false when removed (by `off`, unsubscribe, or a once firing). */
  active: boolean;
}

/**
 * A minimal event emitter.
 *
 * Each call to `on` or `once` creates one registration, so the same function
 * registered twice is called twice per emit.
 */
export class Emitter {
  private listeners = new Map<string, Registration[]>();

  /** Register `listener` for `event`. Returns a function that removes this registration. */
  on(event: string, listener: Listener): () => void {
    const reg: Registration = { fn: listener, original: listener, active: true };
    const list = this.listeners.get(event) ?? [];
    list.push(reg);
    this.listeners.set(event, list);
    return () => this.removeRegistration(event, reg);
  }

  /**
   * Register `listener` to be called on the next emit of `event` only. The
   * registration is removed just before the listener is called. Until then it
   * counts in `listenerCount` and can be removed with `off(event, listener)` or
   * with the returned function.
   */
  once(event: string, listener: Listener): () => void {
    // `reg` is referenced by `wrapper` before it is assigned; `wrapper` is only
    // called later, from `emit`, by which time `reg` is defined.
    let reg!: Registration;
    const wrapper: Listener = (...args) => {
      this.removeRegistration(event, reg);
      listener(...args);
    };
    reg = { fn: wrapper, original: listener, active: true };
    const list = this.listeners.get(event) ?? [];
    list.push(reg);
    this.listeners.set(event, list);
    return () => this.removeRegistration(event, reg);
  }

  /**
   * Remove the earliest registration of `listener` for `event`, whether it was
   * added with `on` or `once`. Does nothing if it is not registered.
   */
  off(event: string, listener: Listener): void {
    const list = this.listeners.get(event);
    if (!list) return;
    const index = list.findIndex(
      (reg) => reg.original === listener || reg.fn === listener,
    );
    if (index === -1) return;
    this.removeRegistration(event, list[index]);
  }

  /**
   * Call the listeners registered for `event`, in registration order, with
   * `args`. Returns true if `event` had at least one listener when emit started.
   *
   * The listeners called by one emit are fixed when it starts: listeners
   * registered while the emit is running are first called by the next emit,
   * and a listener removed while the emit is running is not called by it if
   * its turn has not come yet. Removing a listener never causes another
   * listener to be skipped.
   */
  emit(event: string, ...args: unknown[]): boolean {
    const list = this.listeners.get(event);
    if (!list || list.length === 0) return false;
    // Snapshot so that listeners added during this emit are not called by it,
    // and so that removals during it cannot shift the iteration order. Each
    // registration is consulted for `active` at the moment its turn comes, so
    // a listener removed mid-emit (by a prior listener, by unsubscribe, or by
    // its own once-wrapper) is skipped without affecting anything after it.
    const snapshot = list.slice();
    for (const reg of snapshot) {
      if (reg.active) reg.fn(...args);
    }
    return true;
  }

  /** Number of registrations for `event`. */
  listenerCount(event: string): number {
    return this.listeners.get(event)?.length ?? 0;
  }

  /** Deactivate `reg` and drop it from the live list for `event`. */
  private removeRegistration(event: string, reg: Registration): void {
    if (!reg.active) return;
    reg.active = false;
    const list = this.listeners.get(event);
    if (!list) return;
    const index = list.indexOf(reg);
    if (index !== -1) list.splice(index, 1);
  }
}
