"""Errors shared by the service and API layers."""


class ValidationError(ValueError):
    """A request parameter is invalid. The API turns it into a 400 response."""


class InvalidCursorError(ValidationError):
    """A cursor string is not a cursor produced by list_articles, does not
    decode to one, or was created with different author/status filters."""
