"""Queries against the article store."""


def _sort_key(article):
    # Newest first; articles with the same published_at by id descending,
    # so ties come out in the same order on every request.
    return (-article.published_at, -article.id)


class ArticleRepository:
    def __init__(self, store):
        self._store = store

    def _sorted(self, author=None, status=None):
        rows = self._store.scan()
        if author is not None:
            rows = [a for a in rows if a.author == author]
        if status is not None:
            rows = [a for a in rows if a.status == status]
        return sorted(rows, key=_sort_key)

    def count(self, author=None, status=None):
        return len(self._sorted(author, status))

    def list_offset(self, offset, limit, author=None, status=None):
        """Newest first, deterministic on ties."""
        return self._sorted(author, status)[offset:offset + limit]

    def list_after(self, position, limit, author=None, status=None):
        """Every matching article strictly after (published_at, id) `position`,
        in listing order. `position=None` reads from the start. Deletes and
        inserts before the position cannot shift or repeat later articles."""
        rows = self._sorted(author, status)
        if position is not None:
            rows = [a for a in rows if _sort_key(a) > position]
        return rows[:limit]
