"""Listing rules for articles."""

import base64
import binascii
import json
import warnings
from dataclasses import dataclass
from typing import List, Optional

from .errors import InvalidCursorError, ValidationError
from .store import Article, STATUSES

MAX_PER_PAGE = 100

_CURSOR_PREFIX = "v1."


@dataclass
class Page:
    """One cursor-paginated page of articles."""

    items: List[Article]
    next_cursor: Optional[str]


def _encode_cursor(published_at, article_id, author, status):
    payload = json.dumps(
        {"p": published_at, "i": article_id, "a": author, "s": status},
        separators=(",", ":"),
    ).encode("utf-8")
    return _CURSOR_PREFIX + base64.urlsafe_b64encode(payload).decode("ascii").rstrip("=")


def _decode_cursor(raw):
    """Parse an opaque cursor; anything that is not one of ours raises."""
    try:
        if not raw.startswith(_CURSOR_PREFIX):
            raise InvalidCursorError("cursor is not a valid cursor")
        body = raw[len(_CURSOR_PREFIX):]
        body += "=" * (-len(body) % 4)
        payload = json.loads(base64.urlsafe_b64decode(body.encode("ascii")))
        if (
            not isinstance(payload, dict)
            or not isinstance(payload["p"], int)
            or not isinstance(payload["i"], int)
            or not (payload["a"] is None or isinstance(payload["a"], str))
            or not (payload["s"] is None or isinstance(payload["s"], str))
        ):
            raise InvalidCursorError("cursor is not a valid cursor")
        return payload
    except InvalidCursorError:
        raise
    except (binascii.Error, UnicodeDecodeError, ValueError, KeyError, TypeError):
        raise InvalidCursorError("cursor is not a valid cursor")


class ArticleService:
    def __init__(self, repository):
        self._repo = repository

    def _check_filters(self, author, status):
        if status is not None and status not in STATUSES:
            raise ValidationError(f"status must be one of {', '.join(STATUSES)}")

    def list_articles(self, limit=20, cursor=None, author=None, status=None):
        """One cursor-paginated page, newest first.

        The cursor marks a position in the order rather than an offset, so
        articles inserted or deleted while a client pages cannot produce
        duplicates or skips.
        """
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= MAX_PER_PAGE:
            raise ValidationError(f"limit must be an integer from 1 to {MAX_PER_PAGE}")
        self._check_filters(author, status)

        position = None
        if cursor is not None:
            payload = _decode_cursor(cursor)
            if payload["a"] != author or payload["s"] != status:
                raise InvalidCursorError(
                    "cursor was created with different author/status filters"
                )
            position = (-payload["p"], -payload["i"])

        items = self._repo.list_after(position, limit, author, status)

        next_cursor = None
        more = bool(items) and self._repo.list_after(
            (-items[-1].published_at, -items[-1].id), 1, author, status
        )
        if more:
            last = items[-1]
            next_cursor = _encode_cursor(last.published_at, last.id, author, status)
        return Page(items=items, next_cursor=next_cursor)

    def list_page(self, page=1, per_page=20, author=None, status=None):
        """One page of articles, newest first.

        Returns {"items": [Article, ...], "page": page, "per_page": per_page, "total": total}
        where total counts every article matching the filters.
        """
        warnings.warn(
            "list_page is deprecated; use list_articles (cursor pagination)",
            DeprecationWarning,
            stacklevel=2,
        )
        if not isinstance(page, int) or page < 1:
            raise ValidationError("page must be an integer >= 1")
        if not isinstance(per_page, int) or not 1 <= per_page <= MAX_PER_PAGE:
            raise ValidationError(f"per_page must be an integer from 1 to {MAX_PER_PAGE}")
        self._check_filters(author, status)
        items = self._repo.list_offset((page - 1) * per_page, per_page, author, status)
        return {"items": items, "page": page, "per_page": per_page, "total": self._repo.count(author, status)}
