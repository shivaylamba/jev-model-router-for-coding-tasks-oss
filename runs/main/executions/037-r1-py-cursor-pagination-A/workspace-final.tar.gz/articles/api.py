"""GET /articles."""

from .errors import ValidationError


def serialize(article):
    return {
        "id": article.id,
        "title": article.title,
        "author": article.author,
        "status": article.status,
        "published_at": article.published_at,
    }


def _int_param(params, name, default):
    raw = params.get(name)
    if raw is None:
        return default
    if not raw.isdigit():
        raise ValidationError(f"{name} must be a positive integer")
    return int(raw)


class ArticlesApi:
    def __init__(self, service):
        self._service = service

    def handle_list(self, params):
        """`params` maps query-string names to string values. Returns (status, body)."""
        legacy_requested = "page" in params or "per_page" in params
        cursor_requested = "cursor" in params or "limit" in params
        if legacy_requested and cursor_requested:
            return 400, {"error": "Cannot combine cursor parameters (cursor/limit) with legacy paging (page/per_page)"}

        try:
            if legacy_requested:
                result = self._service.list_page(
                    page=_int_param(params, "page", 1),
                    per_page=_int_param(params, "per_page", 20),
                    author=params.get("author"),
                    status=params.get("status"),
                )
                body = dict(result)
                body["items"] = [serialize(a) for a in result["items"]]
                return 200, body

            # Cursor mode (default)
            cursor_raw = params.get("cursor")
            cursor = cursor_raw if cursor_raw else None
            limit_raw = params.get("limit")
            if limit_raw is None:
                limit = 20
            elif not limit_raw.isdigit():
                raise ValidationError("limit must be a positive integer")
            else:
                limit = int(limit_raw)
            result = self._service.list_articles(
                limit=limit,
                cursor=cursor,
                author=params.get("author"),
                status=params.get("status"),
            )
        except ValidationError as err:
            return 400, {"error": str(err)}
        return 200, {
            "items": [serialize(a) for a in result.items],
            "next_cursor": result.next_cursor,
        }
