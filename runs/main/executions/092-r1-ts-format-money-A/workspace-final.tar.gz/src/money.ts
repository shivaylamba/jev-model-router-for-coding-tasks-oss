export type Currency = "USD" | "EUR" | "GBP";

export interface LineItem {
  description: string;
  quantity: number;
  unitCents: number;
}

const CURRENCY_SYMBOLS: Record<Currency, string> = {
  USD: "$",
  EUR: "€",
  GBP: "£",
};

/**
 * Format an integer amount of cents for display on invoices,
 * e.g. formatCents(123456, "USD") === "$1,234.56".
 * Locale-independent; negatives render as "-$1,234.56".
 */
export function formatCents(cents: number, currency: Currency): string {
  if (typeof cents !== "number" || !Number.isInteger(cents)) {
    throw new TypeError("cents must be an integer number of cents");
  }
  if (!Object.prototype.hasOwnProperty.call(CURRENCY_SYMBOLS, currency)) {
    throw new RangeError(`unsupported currency: ${String(currency)}`);
  }

  const symbol = CURRENCY_SYMBOLS[currency];
  const negative = cents < 0;
  const abs = Math.abs(cents);
  const fraction = String(abs % 100).padStart(2, "0");
  const whole = String(Math.floor(abs / 100)).replace(/\B(?=(\d{3})+(?!\d))/g, ",");

  return `${negative ? "-" : ""}${symbol}${whole}.${fraction}`;
}

/** Total of all line items, in cents. */
export function totalCents(items: readonly LineItem[]): number {
  return items.reduce((acc, item) => acc + item.quantity * item.unitCents, 0);
}
