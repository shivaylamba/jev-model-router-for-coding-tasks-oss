import { test } from "node:test";
import assert from "node:assert/strict";
import { formatCents, totalCents } from "../src/money.ts";

test("totalCents", () => {
  assert.equal(totalCents([]), 0);
  assert.equal(
    totalCents([
      { description: "widget", quantity: 3, unitCents: 250 },
      { description: "gadget", quantity: 1, unitCents: 1999 },
    ]),
    2749,
  );
});

test("formatCents", () => {
  assert.equal(formatCents(123456, "USD"), "$1,234.56");
  assert.equal(formatCents(5, "USD"), "$0.05");
  assert.equal(formatCents(0, "GBP"), "£0.00");
  assert.equal(formatCents(-123456, "USD"), "-$1,234.56");
  assert.equal(formatCents(999, "EUR"), "€9.99");
  assert.equal(formatCents(100000000, "GBP"), "£1,000,000.00");

  assert.throws(() => formatCents(1.5, "USD"), TypeError);
  assert.throws(() => formatCents(NaN, "USD"), TypeError);
  assert.throws(() => formatCents(Infinity, "USD"), TypeError);
  // @ts-expect-error runtime misuse with a non-number
  assert.throws(() => formatCents("123", "USD"), TypeError);
  // @ts-expect-error runtime misuse with an unsupported code
  assert.throws(() => formatCents(100, "JPY"), RangeError);
});
