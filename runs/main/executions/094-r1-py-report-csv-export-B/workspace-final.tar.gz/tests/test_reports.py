import io
import os
import tempfile
import unittest

from reports.cli import main
from reports.exporters import UnknownFormatError, format_names, get_exporter
from reports.model import load_report, report_from_dict

EXAMPLE = os.path.join(os.path.dirname(__file__), "..", "examples", "sales.json")


class ExporterTest(unittest.TestCase):
    def test_text(self):
        out = get_exporter("text").export(load_report(EXAMPLE))
        self.assertIn("North            1,204  98,213.50  yes", out)

    def test_markdown(self):
        out = get_exporter("markdown").export(load_report(EXAMPLE))
        self.assertIn("| West | 0 | - | - |", out)

    def test_unknown(self):
        with self.assertRaises(UnknownFormatError):
            get_exporter("pdf")

    def test_csv(self):
        out = get_exporter("csv").export(load_report(EXAMPLE))
        self.assertEqual(
            out,
            "Region,Orders,Revenue,Target met\n"
            "North,1204,98213.50,true\n"
            '"South, coastal",87,4410.00,false\n'
            "West,0,,\n",
        )

    def test_csv_quoting(self):
        report = report_from_dict(
            {"columns": [{"key": "note", "label": 'Note, "etc"'}], "rows": [{"note": 'a,b\n"c"'}]}
        )
        self.assertEqual(get_exporter("csv").export(report), '"Note, ""etc"""\n"a,b\n""c"""\n')

    def test_csv_no_rows(self):
        report = report_from_dict({"columns": [{"key": "a", "label": "A"}]})
        self.assertEqual(get_exporter("csv").export(report), "A\n")


class CliTest(unittest.TestCase):
    def test_default_text(self):
        buf = io.StringIO()
        self.assertEqual(main([EXAMPLE], stdout=buf), 0)
        self.assertTrue(buf.getvalue().startswith("Q3 sales\n"))

    def test_list_formats(self):
        buf = io.StringIO()
        self.assertEqual(main(["--list-formats"], stdout=buf), 0)
        self.assertEqual(buf.getvalue().split(), format_names())

    def test_csv_stdout(self):
        buf = io.StringIO()
        self.assertEqual(main(["--format", "csv", EXAMPLE], stdout=buf), 0)
        self.assertEqual(buf.getvalue(), get_exporter("csv").export(load_report(EXAMPLE)))

    def test_csv_output_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "out.csv")
            buf = io.StringIO()
            self.assertEqual(main(["--format", "csv", "--output", path, EXAMPLE], stdout=buf), 0)
            self.assertEqual(buf.getvalue(), "")
            with open(path, encoding="utf-8", newline="") as handle:
                content = handle.read()
        self.assertEqual(content, get_exporter("csv").export(load_report(EXAMPLE)))
        self.assertNotIn("\r", content)


if __name__ == "__main__":
    unittest.main()
