"""Comma-separated values for machines, so no display formatting from ..formatting."""

_QUOTE_TRIGGERS = (",", '"', "\n", "\r")


def _field(value):
    """Format a cell for machines: plain ints, two-decimal floats, true/false, empty for null."""
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return format(value, ".2f")
    return str(value)


def _quote(field):
    if any(trigger in field for trigger in _QUOTE_TRIGGERS):
        return '"' + field.replace('"', '""') + '"'
    return field


def _line(fields):
    return ",".join(_quote(field) for field in fields)


class CsvExporter:
    name = "csv"
    extension = ".csv"

    def export(self, report):
        lines = [_line(column.label for column in report.columns)]
        for row in report.rows:
            lines.append(_line(_field(report.cell(row, column)) for column in report.columns))
        return "\n".join(lines) + "\n"
