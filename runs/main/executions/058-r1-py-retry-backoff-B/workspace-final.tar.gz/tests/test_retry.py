import unittest

from retry import retry, retrying


class Boom(Exception):
    pass


class Ignore(Exception):
    pass


class Script:
    """Callable that raises the given exceptions in order, then returns."""

    def __init__(self, outcomes):
        self.outcomes = list(outcomes)
        self.calls = 0

    def __call__(self):
        self.calls += 1
        item = self.outcomes.pop(0)
        if isinstance(item, Exception):
            raise item
        return item


class RetryTest(unittest.TestCase):
    def test_success_returns_without_sleeping(self):
        sleeps = []
        result = retry(Script(["ok"]), sleep=sleeps.append)
        self.assertEqual(result, "ok")
        self.assertEqual(sleeps, [])

    def test_retries_then_succeeds(self):
        sleeps = []
        script = Script([Boom(), Boom(), "ok"])
        result = retry(script, base_delay=0.5, max_delay=4.0, sleep=sleeps.append)
        self.assertEqual(result, "ok")
        self.assertEqual(script.calls, 3)
        self.assertEqual(sleeps, [0.5, 1.0])

    def test_backoff_doubles_and_caps(self):
        sleeps = []
        script = [Boom()] * 5 + ["ok"]
        retry(Script(script), attempts=6, base_delay=0.1, max_delay=0.3, sleep=sleeps.append)
        self.assertEqual(sleeps, [0.1, 0.2, 0.3, 0.3, 0.3])

    def test_last_failure_reraises_same_exception_without_final_wait(self):
        sleeps = []
        retries = []
        exc = Boom()
        with self.assertRaises(Boom) as ctx:
            retry(
                Script([exc, exc, exc]),
                attempts=3,
                sleep=sleeps.append,
                on_retry=lambda attempt, e, d: retries.append(attempt),
            )
        self.assertIs(ctx.exception, exc)
        self.assertEqual(sleeps, [0.1, 0.2])
        self.assertEqual(retries, [1, 2])

    def test_unmatched_exception_propagates_immediately(self):
        sleeps = []
        script = Script([Ignore(), Boom(), "ok"])
        with self.assertRaises(Ignore):
            retry(script, retry_on=Boom, sleep=sleeps.append)
        self.assertEqual(script.calls, 1)
        self.assertEqual(sleeps, [])

    def test_on_retry_runs_before_each_wait(self):
        events = []
        exc = Boom()
        retry(
            Script([exc, exc, "ok"]),
            base_delay=0.2,
            sleep=lambda d: events.append(("sleep", d)),
            on_retry=lambda attempt, e, d: events.append(("retry", attempt, e, d)),
        )
        self.assertEqual(events, [
            ("retry", 1, exc, 0.2),
            ("sleep", 0.2),
            ("retry", 2, exc, 0.4),
            ("sleep", 0.4),
        ])


class ValidationTest(unittest.TestCase):
    def test_attempts_below_one_raises_before_calling_fn(self):
        script = Script(["ok"])
        with self.assertRaises(ValueError):
            retry(script, attempts=0)
        self.assertEqual(script.calls, 0)

    def test_negative_delays_raise_before_calling_fn(self):
        script = Script(["ok"])
        with self.assertRaises(ValueError):
            retry(script, base_delay=-1)
        with self.assertRaises(ValueError):
            retry(script, max_delay=-0.1)
        self.assertEqual(script.calls, 0)


class RetryingTest(unittest.TestCase):
    def test_forwards_arguments_and_retries(self):
        sleeps = []
        calls = []

        @retrying(attempts=3, base_delay=0.1, retry_on=Boom, sleep=sleeps.append)
        def divide(n, by):
            calls.append((n, by))
            if len(calls) < 2:
                raise Boom()
            return n / by

        self.assertEqual(divide(6, by=3), 2.0)
        self.assertEqual(calls, [(6, 3), (6, 3)])
        self.assertEqual(sleeps, [0.1])

    def test_keeps_name_and_doc(self):
        @retrying()
        def fetch():
            """Fetch it."""

        self.assertEqual(fetch.__name__, "fetch")
        self.assertEqual(fetch.__doc__, "Fetch it.")


if __name__ == "__main__":
    unittest.main()
