"""Retry a call with exponential backoff."""

import functools
import time


def retry(fn, *, attempts=3, base_delay=0.1, max_delay=5.0,
          retry_on=(Exception,), sleep=time.sleep, on_retry=None):
    """Call `fn()` and return its result, retrying matching failures.

    `attempts` is the total number of calls, including the first. A failed
    call leads to another only if its exception is an instance of `retry_on`
    (a class or tuple of classes); anything else propagates immediately.
    Before each wait, calls `on_retry(attempt, exc, delay)` when given, where
    `attempt` is the 1-based number of the call that just failed and `delay`
    grows from `base_delay` by powers of two, capped at `max_delay`.
    """
    if attempts < 1:
        raise ValueError("attempts must be at least 1")
    if base_delay < 0 or max_delay < 0:
        raise ValueError("delays must be non-negative")

    for attempt in range(1, attempts + 1):
        try:
            return fn()
        except retry_on as exc:
            if attempt == attempts:
                raise
            delay = min(max_delay, base_delay * 2 ** (attempt - 1))
            if on_retry is not None:
                on_retry(attempt, exc, delay)
            sleep(delay)


def retrying(**options):
    """Decorate a function so its calls run through `retry`."""
    def decorate(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            return retry(lambda: fn(*args, **kwargs), **options)
        return wrapper
    return decorate
