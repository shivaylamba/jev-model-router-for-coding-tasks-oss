import { test } from "node:test";
import assert from "node:assert/strict";
import { buildSite, createSite, PluginError } from "../src/site.js";

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const PAGES = [
  { path: "index.md", title: "Home", body: "Hello" },
  { path: "about.md", title: "About", body: "About us." },
];

test("createSite().build() matches buildSite() when there are no plugins", async () => {
  assert.deepEqual(await createSite().build(PAGES), await buildSite(PAGES));
  const layout = ({ title, content }) => `${title}|${content}`;
  assert.deepEqual(await createSite({ layout }).build(PAGES), await buildSite(PAGES, { layout }));
  assert.ok((await createSite().build([])) instanceof Map);
});

test("use() returns the site so registrations chain", () => {
  const site = createSite();
  assert.equal(site.use({ name: "a" }), site);
  assert.equal(site.use({ name: "b" }).use({ name: "c" }), site);
});

test("use() throws a TypeError for plugins that are not objects", () => {
  const site = createSite();
  for (const bad of [null, undefined, "plugin", 42, true, () => {}]) {
    assert.throws(() => site.use(bad), TypeError);
  }
});

test("use() throws a TypeError unless name is a non-empty string", () => {
  const site = createSite();
  for (const bad of [{}, { name: "" }, { name: 42 }, { name: null }, { name: ["x"] }]) {
    assert.throws(() => site.use(bad), TypeError);
  }
});

test("use() throws a TypeError when a hook property is not a function", () => {
  const site = createSite();
  for (const hook of ["beforeRender", "afterRender", "onComplete"]) {
    assert.throws(() => site.use({ name: "p", [hook]: "nope" }), TypeError);
    assert.throws(() => site.use({ name: "p", [hook]: null }), TypeError);
  }
  // a hook set to undefined is simply absent
  site.use({ name: "ok", beforeRender: undefined });
});

test("use() throws an Error for a duplicate plugin name", () => {
  const site = createSite();
  site.use({ name: "dupe" });
  assert.throws(() => site.use({ name: "dupe", onComplete() {} }), (err) => err instanceof Error && /dupe/.test(err.message));
});

test("unknown properties on a plugin are ignored", async () => {
  const outputs = await createSite()
    .use({ name: "extra", version: "1.2.3", unrelated: { deep: true }, afterRender: () => {} })
    .build(PAGES);
  assert.deepEqual(outputs, await buildSite(PAGES));
});

test("beforeRender hooks run in registration order, each on the previous one's page", async () => {
  const seen = [];
  const outputs = await createSite()
    .use({
      name: "first",
      beforeRender(page) {
        seen.push(page.title);
        return { ...page, title: "from first" };
      },
    })
    .use({
      name: "second",
      async beforeRender(page) {
        await delay(1);
        seen.push(page.title);
      },
    })
    .build([{ path: "a.md", title: "original", body: "x" }]);
  assert.deepEqual(seen, ["original", "from first"]);
  assert.match(outputs.get("a.html"), /<title>from first<\/title>/);
});

test("the output path, title and body come from the final page", async () => {
  const outputs = await createSite()
    .use({
      name: "renamer",
      beforeRender: (page) => ({ path: "moved/deeper.md", title: "New Title", body: "New **body**" }),
    })
    .build([{ path: "old.md", title: "Old", body: "old" }]);
  assert.deepEqual([...outputs.keys()], ["moved/deeper.html"]);
  assert.match(outputs.get("moved/deeper.html"), /<title>New Title<\/title>/);
  assert.match(outputs.get("moved/deeper.html"), /<p>New <strong>body<\/strong><\/p>/);
});

test("the first beforeRender gets a shallow copy of the caller's page", async () => {
  const pages = [{ path: "a.md", title: "Original", body: "x" }];
  const outputs = await createSite()
    .use({
      name: "mutator",
      beforeRender(page) {
        page.title = "Changed";
      },
    })
    .build(pages);
  // the caller's object is untouched, though the build saw the changes
  assert.equal(pages[0].title, "Original");
  assert.equal(pages[0].path, "a.md");
  assert.match(outputs.get("a.html"), /<title>Changed<\/title>/);
});

test("each page finishes all of its hooks before the next page starts", async () => {
  const log = [];
  await createSite()
    .use({
      name: "order",
      async beforeRender(page) {
        await delay(2);
        log.push(`before:${page.path}`);
      },
      async afterRender(html, page) {
        await delay(2);
        log.push(`after:${page.path}`);
      },
    })
    .build([
      { path: "a.md", title: "A", body: "x" },
      { path: "b.md", title: "B", body: "y" },
    ]);
  assert.deepEqual(log, ["before:a.md", "after:a.md", "before:b.md", "after:b.md"]);
});

test("afterRender hooks see the previous one's html and the final page", async () => {
  const seenHtml = [];
  const seenTitles = [];
  const outputs = await createSite()
    .use({
      name: "first",
      beforeRender: (page) => ({ ...page, title: "final title" }),
      afterRender(html, page) {
        seenHtml.push(html);
        seenTitles.push(page.title);
        return "first html";
      },
    })
    .use({
      name: "second",
      afterRender(html, page) {
        seenHtml.push(html);
        seenTitles.push(page.title);
      },
    })
    .build([{ path: "a.md", title: "A", body: "x" }]);
  assert.match(seenHtml[0], /<title>final title<\/title>/); // the layout output
  assert.equal(seenHtml[1], "first html");
  assert.deepEqual(seenTitles, ["final title", "final title"]);
  assert.equal(outputs.get("a.html"), "first html"); // second kept what it was given
});

test("onComplete runs once after all pages, in order, awaited", async () => {
  const log = [];
  await createSite()
    .use({
      name: "pages",
      beforeRender() {
        log.push("page");
      },
    })
    .use({
      name: "a",
      async onComplete() {
        await delay(5);
        log.push("a");
      },
    })
    .use({
      name: "b",
      async onComplete() {
        await delay(1);
        log.push("b");
      },
    })
    .build([{ path: "a.md", title: "A", body: "x" }]);
  assert.deepEqual(log, ["page", "a", "b"]);
});

test("onComplete may add, change and delete entries of the outputs map", async () => {
  const outputs = await createSite()
    .use({
      name: "sitemap",
      onComplete(outputs) {
        outputs.delete("about.html");
        outputs.set("index.html", outputs.get("index.html").toUpperCase());
        outputs.set("sitemap.txt", [...outputs.keys()].join(","));
      },
    })
    .build(PAGES);
  assert.deepEqual([...outputs.keys()], ["index.html", "sitemap.txt"]);
  assert.equal(outputs.get("index.html"), (await buildSite(PAGES)).get("index.html").toUpperCase());
  // the hook built this after the delete, when only index.html was left
  assert.equal(outputs.get("sitemap.txt"), "index.html");
});

test("a throwing hook rejects build() with a PluginError naming plugin and hook", async () => {
  const failure = new Error("network down");
  const site = createSite().use({
    name: "links",
    beforeRender: () => {
      throw failure;
    },
  });
  await assert.rejects(site.build(PAGES), (err) => {
    assert.ok(err instanceof PluginError);
    assert.ok(err instanceof Error);
    assert.equal(err.plugin, "links");
    assert.equal(err.hook, "beforeRender");
    assert.equal(err.cause, failure);
    assert.ok(err.message.includes("links"));
    return true;
  });
});

test("a rejecting hook promise is wrapped the same way", async () => {
  const failure = new Error("timeout");
  const site = createSite().use({
    name: "slow",
    async afterRender() {
      throw failure;
    },
  });
  await assert.rejects(site.build(PAGES), (err) =>
    err instanceof PluginError && err.hook === "afterRender" && err.cause === failure,
  );
});

test("a rejecting onComplete rejects build() too", async () => {
  const failure = new Error("unwritable");
  const site = createSite().use({
    name: "writer",
    async onComplete() {
      throw failure;
    },
  });
  await assert.rejects(site.build(PAGES), (err) =>
    err instanceof PluginError && err.hook === "onComplete" && err.cause === failure,
  );
});

test("a hook throwing a non-error still yields a PluginError with it as the cause", async () => {
  const site = createSite().use({ name: "odd", afterRender: () => {
    throw "just a string";
  } });
  await assert.rejects(site.build(PAGES), (err) =>
    err instanceof PluginError && err.plugin === "odd" && err.cause === "just a string",
  );
});

test("a beforeRender returning a non-object is a PluginError with a TypeError cause", async () => {
  for (const returned of ["nope", 42, null]) {
    const site = createSite({ layout: () => "unused" }).use({
      name: "bad",
      async beforeRender() {
        await delay(1);
        return returned;
      },
    });
    await assert.rejects(site.build(PAGES), (err) => {
      assert.ok(err instanceof PluginError);
      assert.equal(err.hook, "beforeRender");
      assert.ok(err.cause instanceof TypeError);
      return true;
    });
  }
});

test("an afterRender returning a non-string is a PluginError with a TypeError cause", async () => {
  for (const returned of [{ html: true }, 42, null]) {
    const site = createSite().use({ name: "bad", afterRender: () => returned });
    await assert.rejects(site.build(PAGES), (err) => {
      assert.ok(err instanceof PluginError);
      assert.equal(err.hook, "afterRender");
      assert.ok(err.cause instanceof TypeError);
      return true;
    });
  }
});

test("a failing hook stops the run: later hooks and onComplete never run", async () => {
  const log = [];
  const site = createSite()
    .use({
      name: "first",
      beforeRender: () => {
        throw new Error("stop");
      },
    })
    .use({
      name: "second",
      beforeRender: () => log.push("second beforeRender"),
      afterRender: () => log.push("second afterRender"),
      onComplete: () => log.push("second onComplete"),
    })
    .use({ name: "third", onComplete: () => log.push("third onComplete") });
  await assert.rejects(site.build(PAGES), PluginError);
  assert.deepEqual(log, []);
});
