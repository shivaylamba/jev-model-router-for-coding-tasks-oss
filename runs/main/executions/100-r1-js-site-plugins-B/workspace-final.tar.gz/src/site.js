import { defaultLayout } from "./layout.js";
import { renderMarkdown } from "./markdown.js";

/** "guide/intro.md" -> "guide/intro.html" */
export function outputPath(sourcePath) {
  return sourcePath.replace(/\.md$/, "") + ".html";
}

const HOOKS = ["beforeRender", "afterRender", "onComplete"];

/**
 * A hook threw, rejected, or returned the wrong type: `plugin` is the plugin's
 * name, `hook` the hook's name, `cause` the original error.
 */
export class PluginError extends Error {
  constructor(plugin, hook, cause) {
    const reason = cause instanceof Error ? cause.message : String(cause);
    super(`Plugin "${plugin}" failed in its ${hook} hook: ${reason}`, { cause });
    this.name = "PluginError";
    this.plugin = plugin;
    this.hook = hook;
  }
}

/** Run one hook, turning any throw or rejection into a PluginError. */
async function callHook(plugin, hook, ...args) {
  try {
    return await plugin[hook](...args);
  } catch (cause) {
    throw new PluginError(plugin.name, hook, cause);
  }
}

/** The type of a value for error messages; null is not "object" here. */
function typeOf(value) {
  return value === null ? "null" : typeof value;
}

/**
 * A site under construction: `use()` registers plugins (and chains), `build()`
 * renders the pages through them. `options` is the same as for `buildSite`
 * (`{ layout }`); the plugin contract is in docs/plugins.md.
 */
export function createSite({ layout = defaultLayout } = {}) {
  const plugins = [];

  const site = {
    /** Register a plugin; returns the site so registrations chain. */
    use(plugin) {
      if (plugin === null || typeof plugin !== "object") {
        throw new TypeError(`plugin must be an object, got ${typeOf(plugin)}`);
      }
      if (typeof plugin.name !== "string" || plugin.name === "") {
        throw new TypeError("plugin name must be a non-empty string");
      }
      for (const hook of HOOKS) {
        if (plugin[hook] !== undefined && typeof plugin[hook] !== "function") {
          throw new TypeError(`plugin "${plugin.name}" has a ${hook} property that is not a function`);
        }
      }
      if (plugins.some((registered) => registered.name === plugin.name)) {
        throw new Error(`plugin "${plugin.name}" is already registered`);
      }
      plugins.push(plugin);
      return site;
    },

    /** Render every page, running each plugin's hooks around the render. */
    async build(pages) {
      const outputs = new Map();
      for (const page of pages) {
        // A shallow copy, so a hook that mutates its page never touches the
        // objects the caller passed to build().
        let current = { ...page };
        for (const plugin of plugins) {
          if (plugin.beforeRender === undefined) continue;
          const returned = await callHook(plugin, "beforeRender", current);
          if (returned === undefined) continue;
          if (typeOf(returned) !== "object") {
            throw new PluginError(
              plugin.name,
              "beforeRender",
              new TypeError(`beforeRender must return a page object or undefined, got ${typeOf(returned)}`),
            );
          }
          current = returned;
        }
        const content = renderMarkdown(current.body);
        let html = layout({ title: current.title, content, path: current.path });
        for (const plugin of plugins) {
          if (plugin.afterRender === undefined) continue;
          const returned = await callHook(plugin, "afterRender", html, current);
          if (returned === undefined) continue;
          if (typeof returned !== "string") {
            throw new PluginError(
              plugin.name,
              "afterRender",
              new TypeError(`afterRender must return a string or undefined, got ${typeOf(returned)}`),
            );
          }
          html = returned;
        }
        outputs.set(outputPath(current.path), html);
      }
      for (const plugin of plugins) {
        if (plugin.onComplete === undefined) continue;
        await callHook(plugin, "onComplete", outputs);
      }
      return outputs;
    },
  };

  return site;
}

/**
 * Render every page. Pages are { path, title, body }; the result maps each
 * output path to its HTML, in page order. Equivalent to
 * createSite(options).build(pages) with no plugins.
 */
export async function buildSite(pages, options) {
  return createSite(options).build(pages);
}
