import { isEmpty, normalizeSelection, replaceRange, type Selection } from "./text.ts";
import { DEFAULT_HISTORY_LIMIT, History, type State } from "./history.ts";

export interface EditorOptions {
  /** Milliseconds clock used by undo grouping. Defaults to Date.now. */
  clock?: () => number;
  /** Maximum number of undo steps kept. Defaults to 100. */
  historyLimit?: number;
}

export class Editor {
  private content: string;
  private sel: Selection;
  private history: History;

  constructor(text: string = "", options: EditorOptions = {}) {
    this.content = text;
    this.sel = { start: text.length, end: text.length };
    this.history = new History(
      options.historyLimit ?? DEFAULT_HISTORY_LIMIT,
      options.clock ?? Date.now,
    );
  }

  get text(): string {
    return this.content;
  }

  /** A copy of the current selection. */
  get selection(): Selection {
    return { ...this.sel };
  }

  private state(): State {
    return { text: this.content, selection: { ...this.sel } };
  }

  /** Set the selection; offsets are clamped to the text and ordered. `end` defaults to `start`. */
  select(start: number, end: number = start): void {
    // Selection changes create no step and never clear redo, but close any open typing group.
    this.history.closeGroup();
    this.sel = normalizeSelection(this.content.length, start, end);
  }

  /** Replace the selection with `str` and put the cursor right after it. */
  insert(str: string): void {
    const before = this.state();
    const { start, end } = this.sel;
    this.content = replaceRange(this.content, start, end, str);
    const cursor = start + str.length;
    this.sel = { start: cursor, end: cursor };
    // Typing = empty selection + exactly one character other than "\n".
    const typing = isEmpty(before.selection) && str.length === 1 && str !== "\n";
    this.history.record(before, this.state(), typing);
    if (!typing) {
      this.history.closeGroup();
    }
  }

  /** Delete the selection, or the character before the cursor when the selection is empty. */
  deleteBackward(): void {
    const before = this.state();
    const { start, end } = this.sel;
    if (!isEmpty(this.sel)) {
      this.content = replaceRange(this.content, start, end, "");
      this.sel = { start, end: start };
    } else if (start > 0) {
      this.content = replaceRange(this.content, start - 1, start, "");
      this.sel = { start: start - 1, end: start - 1 };
    }
    this.history.record(before, this.state(), false);
    this.history.closeGroup();
  }

  /** Delete the selection, or the character after the cursor when the selection is empty. */
  deleteForward(): void {
    const before = this.state();
    const { start, end } = this.sel;
    if (!isEmpty(this.sel)) {
      this.content = replaceRange(this.content, start, end, "");
      this.sel = { start, end: start };
    } else if (start < this.content.length) {
      this.content = replaceRange(this.content, start, start + 1, "");
    }
    this.history.record(before, this.state(), false);
    this.history.closeGroup();
  }

  canUndo(): boolean {
    return this.history.canUndo();
  }

  canRedo(): boolean {
    return this.history.canRedo();
  }

  /** Revert the most recent undo step, restoring text and selection. */
  undo(): boolean {
    if (this.history.inTransaction) {
      throw new Error("undo() cannot be called during a transaction");
    }
    this.history.closeGroup();
    const restored = this.history.undo(this.state());
    if (restored === null) {
      return false;
    }
    this.content = restored.text;
    this.sel = restored.selection;
    return true;
  }

  /** Re-apply the most recently undone step, restoring text and selection. */
  redo(): boolean {
    if (this.history.inTransaction) {
      throw new Error("redo() cannot be called during a transaction");
    }
    this.history.closeGroup();
    const restored = this.history.redo(this.state());
    if (restored === null) {
      return false;
    }
    this.content = restored.text;
    this.sel = restored.selection;
    return true;
  }

  /** Run `fn` so that everything it changes becomes a single undo step. */
  transact<T>(fn: () => T): T {
    this.history.closeGroup();
    try {
      return this.history.transact(
        fn,
        () => this.state(),
        (state) => {
          this.content = state.text;
          this.sel = state.selection;
        },
      );
    } finally {
      this.history.closeGroup();
    }
  }
}
