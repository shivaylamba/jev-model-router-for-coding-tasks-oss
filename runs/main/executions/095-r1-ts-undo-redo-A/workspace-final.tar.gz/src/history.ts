import type { Selection } from "./text.ts";

/** A snapshot of the editor state (text and selection). */
export interface State {
  text: string;
  selection: Selection;
}

export interface UndoStep {
  before: State;
  after: State;
  /** Whether this step is an open typing group that may still be extended. */
  openTypingGroup: boolean;
  /** Time of the last typing insert in this group, by the injected clock. */
  lastTypingTime: number;
}

export const DEFAULT_HISTORY_LIMIT = 100;
export const TYPING_GROUP_INTERVAL = 1000;

/** Undo/redo bookkeeping for the editor. Editing itself stays in editor.ts. */
export class History {
  private undoStack: UndoStep[] = [];
  private redoStack: UndoStep[] = [];
  private transactionDepth = 0;
  private transactionBefore: State | null = null;
  private transactionDiverged = false;

  constructor(
    private readonly limit: number,
    private readonly clock: () => number,
  ) {
    if (!Number.isInteger(limit) || limit < 0) {
      throw new RangeError("historyLimit must be an integer >= 0");
    }
  }

  get inTransaction(): boolean {
    return this.transactionDepth > 0;
  }

  canUndo(): boolean {
    return this.undoStack.length > 0;
  }

  canRedo(): boolean {
    return this.redoStack.length > 0;
  }

  /**
   * Record a change. `typing` marks a single-character typing insert.
   * No-op edits (unchanged text) create no step and leave redo alone.
   */
  record(before: State, after: State, typing: boolean): void {
    if (before.text === after.text) {
      return;
    }

    if (this.inTransaction) {
      if (!this.transactionDiverged) {
        this.transactionDiverged = true;
        this.redoStack = [];
      }
      return; // the outermost transaction creates the step
    }

    const now = this.clock();
    const top = this.undoStack[this.undoStack.length - 1];
    if (
      typing &&
      top !== undefined &&
      top.openTypingGroup &&
      now - top.lastTypingTime < TYPING_GROUP_INTERVAL
    ) {
      top.after = cloneState(after);
      top.lastTypingTime = now;
    } else {
      this.pushStep({
        before: cloneState(before),
        after: cloneState(after),
        openTypingGroup: typing,
        lastTypingTime: typing ? now : 0,
      });
    }
    this.redoStack = [];
  }

  /** Close any open typing group. */
  closeGroup(): void {
    const top = this.undoStack[this.undoStack.length - 1];
    if (top !== undefined) {
      top.openTypingGroup = false;
    }
  }

  /**
   * Run `fn` as one undo step. Nested calls join the outermost one.
   * On throw, restores the state from when this transact call started,
   * creates no step, leaves the redo stack alone, and rethrows.
   */
  transact<T>(fn: () => T, getState: () => State, apply: (state: State) => void): T {
    this.transactionDepth++;
    let startedWith: State | null = null;
    if (this.transactionBefore === null) {
      this.transactionBefore = cloneState(getState());
      this.transactionDiverged = false;
    } else {
      startedWith = cloneState(getState());
    }
    const outer = this.transactionDepth === 1;
    try {
      const result = fn();
      if (outer && this.transactionBefore !== null) {
        const beforeTx = this.transactionBefore;
        const after = getState();
        if (after.text !== beforeTx.text) {
          this.pushStep({
            before: cloneState(beforeTx),
            after: cloneState(after),
            openTypingGroup: false,
            lastTypingTime: 0,
          });
        }
      }
      return result;
    } catch (error) {
      apply(startedWith !== null ? startedWith : (this.transactionBefore as State));
      throw error;
    } finally {
      this.transactionDepth--;
      if (this.transactionDepth === 0) {
        this.transactionBefore = null;
        this.transactionDiverged = false;
      }
    }
  }

  /** Pop the most recent undo step; returns the state to restore, or null. */
  undo(current: State): State | null {
    void current;
    const step = this.undoStack.pop();
    if (step === undefined) {
      return null;
    }
    step.openTypingGroup = false;
    this.redoStack.push(step);
    return cloneState(step.before);
  }

  /** Pop the most recently undone step; returns the state to restore, or null. */
  redo(current: State): State | null {
    void current;
    const step = this.redoStack.pop();
    if (step === undefined) {
      return null;
    }
    step.openTypingGroup = false;
    this.undoStack.push(step);
    return cloneState(step.after);
  }

  private pushStep(step: UndoStep): void {
    if (this.limit === 0) {
      return;
    }
    this.undoStack.push(step);
    if (this.undoStack.length > this.limit) {
      this.undoStack.shift();
    }
  }
}

function cloneState(state: State): State {
  return { text: state.text, selection: { ...state.selection } };
}
