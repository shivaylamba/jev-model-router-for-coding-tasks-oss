import { test } from "node:test";
import assert from "node:assert/strict";
import { run } from "../src/cli.js";
import { count } from "../src/count.js";

function fakeIo(files) {
  const io = { out: "", err: "" };
  io.readFile = (path) => {
    if (!(path in files)) throw new Error("ENOENT");
    return files[path];
  };
  io.stdout = (text) => { io.out += text; };
  io.stderr = (text) => { io.err += text; };
  return io;
}

test("count", () => {
  assert.deepEqual(count("one two\nthree\n"), { lines: 2, words: 3, chars: 14 });
});

test("single file", () => {
  const io = fakeIo({ "a.txt": "hello world\n" });
  assert.equal(run(["a.txt"], io), 0);
  assert.equal(io.out, "      1       2      12 a.txt\n");
});

test("several files with a total and a missing file", () => {
  const io = fakeIo({ "a.txt": "a b\n", "b.txt": "c\n" });
  assert.equal(run(["a.txt", "nope.txt", "b.txt"], io), 1);
  assert.equal(io.out, "      1       2       4 a.txt\n      1       1       2 b.txt\n      2       3       6 total\n");
  assert.equal(io.err, "tally: cannot read nope.txt\n");
});

test("json output for a single file", () => {
  const io = fakeIo({ "a.txt": "hello world\n" });
  assert.equal(run(["--json", "a.txt"], io), 0);
  assert.equal(io.out, '{"files":[{"path":"a.txt","lines":1,"words":2,"chars":12}],"total":{"lines":1,"words":2,"chars":12}}\n');
  assert.equal(io.err, "");
});

test("json output with several files, flag anywhere, and a missing file", () => {
  const io = fakeIo({ "a.txt": "a b\n", "b.txt": "c\n" });
  assert.equal(run(["a.txt", "--json", "nope.txt", "b.txt"], io), 1);
  assert.equal(io.out, '{"files":[{"path":"a.txt","lines":1,"words":2,"chars":4},{"path":"b.txt","lines":1,"words":1,"chars":2}],"total":{"lines":2,"words":3,"chars":6}}\n');
  assert.equal(io.err, "tally: cannot read nope.txt\n");
});

test("json output with no files", () => {
  const io = fakeIo({});
  assert.equal(run(["--json"], io), 0);
  assert.equal(io.out, '{"files":[],"total":{"lines":0,"words":0,"chars":0}}\n');
});

test("unknown option", () => {
  const io = fakeIo({});
  assert.equal(run(["-x"], io), 2);
  assert.equal(io.out, "");
});
