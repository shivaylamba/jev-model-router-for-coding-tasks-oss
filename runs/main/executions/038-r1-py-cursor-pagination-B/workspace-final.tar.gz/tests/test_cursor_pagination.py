import base64
import json
import unittest
import warnings

from articles.api import ArticlesApi
from articles.errors import InvalidCursorError, ValidationError
from articles.repository import ArticleRepository
from articles.service import ArticleService
from articles.store import ArticleStore


def build():
    store = ArticleStore()
    store.insert("Hello", "ana", "published", 1000)
    store.insert("Draft notes", "ana", "draft", 2000)
    store.insert("Release 2", "bo", "published", 3000)
    store.insert("Old news", "bo", "archived", 500)
    service = ArticleService(ArticleRepository(store))
    return store, service, ArticlesApi(service)


def walk(service, **kwargs):
    """Collect every page of a cursor walk; fails on a cursor that loops forever."""
    items, cursor, steps = [], None, 0
    while True:
        page = service.list_articles(cursor=cursor, **kwargs)
        items.extend(page.items)
        cursor = page.next_cursor
        steps += 1
        if cursor is None:
            return items
        assert steps < 100, "cursor walk did not terminate"


class CursorListingTest(unittest.TestCase):
    def setUp(self):
        warnings.simplefilter("ignore", DeprecationWarning)
        self.addCleanup(warnings.resetwarnings)

    def test_order_descends_published_at_then_id(self):
        store, service, _ = build()
        for title in ("tie a", "tie b", "tie c"):  # same published_at, increasing ids
            store.insert(title, "ana", "published", 2500)
        page = service.list_articles(limit=100)
        # 3000, the 2500 ties by id descending, then 2000, 1000, 500.
        self.assertEqual([a.id for a in page.items], [3, 7, 6, 5, 2, 1, 4])

    def test_walk_is_complete_and_terminates(self):
        store, service, _ = build()
        items = walk(service, limit=2)
        self.assertEqual([a.id for a in items], [3, 2, 1, 4])
        self.assertEqual(len(items), len({a.id for a in items}))

    def test_next_cursor_none_exactly_at_the_end(self):
        _, service, _ = build()
        self.assertIsNone(service.list_articles(limit=100).next_cursor)
        page = service.list_articles(limit=3)
        self.assertIsNotNone(page.next_cursor)
        self.assertIsNone(service.list_articles(limit=3, cursor=page.next_cursor).next_cursor)

    def test_newer_insert_while_paging_is_never_reshown(self):
        _, service, _ = build()
        first = service.list_articles(limit=2)
        self.assertEqual([a.title for a in first.items], ["Release 2", "Draft notes"])
        store = service._repo._store
        store.insert("Breaking", "bo", "published", 4000)
        store.insert("Flashback", "bo", "published", 400)
        second = service.list_articles(limit=2, cursor=first.next_cursor)
        third = service.list_articles(limit=2, cursor=second.next_cursor)
        seen = [a.title for a in first.items] + [a.title for a in second.items] + [a.title for a in third.items]
        # "Breaking" sorts before the cursor's position and never appears;
        # "Flashback" sorts after it and shows up on a later page.
        self.assertEqual(seen, ["Release 2", "Draft notes", "Hello", "Old news", "Flashback"])

    def test_cursor_survives_deleting_its_article(self):
        _, service, _ = build()
        page = service.list_articles(limit=2)
        service._repo._store.delete(page.items[-1].id)  # the article the cursor points at
        following = service.list_articles(cursor=page.next_cursor)
        self.assertEqual([a.title for a in following.items], ["Hello", "Old news"])

    def test_limit_may_change_between_pages(self):
        _, service, _ = build()
        first = service.list_articles(limit=1)
        rest = service.list_articles(limit=100, cursor=first.next_cursor)
        self.assertEqual([a.title for a in rest.items], ["Draft notes", "Hello", "Old news"])

    def test_cursor_is_opaque_base64url(self):
        _, service, _ = build()
        cursor = service.list_articles(limit=1).next_cursor
        self.assertTrue(cursor)
        self.assertTrue(all(c.isalnum() or c in "-_" for c in cursor))

    def test_cursor_rejects_different_filters(self):
        _, service, _ = build()
        for kwargs, changed in [
            ({"author": "bo"}, {}),
            ({"author": "bo"}, {"author": "ana"}),
            ({"status": "published"}, {}),
            ({"status": "published"}, {"status": "draft"}),
            ({}, {"author": "bo"}),
        ]:
            cursor = service.list_articles(limit=1, **kwargs).next_cursor
            with self.assertRaises(InvalidCursorError):
                service.list_articles(cursor=cursor, **changed)

    def test_cursor_keeps_working_with_same_filters(self):
        _, service, _ = build()
        first = service.list_articles(limit=1, author="bo")
        rest = service.list_articles(cursor=first.next_cursor, author="bo", limit=10)
        self.assertEqual([a.title for a in rest.items], ["Old news"])

    def test_bad_cursors_raise_invalid_cursor_error(self):
        _, service, _ = build()

        def forge(payload):
            raw = json.dumps(payload).encode("utf-8")
            return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")

        junk_b64 = base64.urlsafe_b64encode(b"not json").rstrip(b"=").decode("ascii")
        for cursor in [
            "",
            "abc",
            "wrong-length-b64",
            forge({"version": 1, "id": 1}),  # well-formed base64, not a cursor payload
            forge({"version": 2, "published_at": 1, "id": 1, "author": None, "status": None}),
            forge({"version": 1, "published_at": 1.5, "id": 1, "author": None, "status": None}),
            forge({"version": 1, "published_at": 1, "id": 1, "author": None, "status": "nonsense"}),
            junk_b64,
        ]:
            with self.assertRaises(InvalidCursorError):
                service.list_articles(cursor=cursor)

    def test_invalid_cursor_error_is_a_validation_error(self):
        from articles.errors import ValidationError

        self.assertTrue(issubclass(InvalidCursorError, ValidationError))

    def test_limit_validation(self):
        _, service, _ = build()
        for bad in (0, 101, -1, True, "20", 1.5, None):
            with self.assertRaises(ValidationError):
                service.list_articles(limit=bad)
        self.assertEqual(len(service.list_articles(limit=1).items), 1)
        self.assertEqual(len(service.list_articles(limit=100).items), 4)

    def test_status_validation(self):
        _, service, _ = build()
        with self.assertRaises(ValidationError):
            service.list_articles(status="deleted")

    def test_list_page_deprecated_on_every_call(self):
        _, service, _ = build()
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            service.list_page(page=1)
            service.list_page(page=2)
        messages = [str(w.message) for w in caught if issubclass(w.category, DeprecationWarning)]
        self.assertEqual(len(messages), 2)
        self.assertIn("list_articles", messages[0])


class CursorApiTest(unittest.TestCase):
    def setUp(self):
        warnings.simplefilter("ignore", DeprecationWarning)
        self.addCleanup(warnings.resetwarnings)

    def test_cursor_mode_is_the_default(self):
        _, _, api = build()
        status, body = api.handle_list({})
        self.assertEqual(status, 200)
        self.assertEqual(set(body), {"items", "next_cursor"})
        self.assertEqual([a["id"] for a in body["items"]], [3, 2, 1, 4])
        self.assertIsNone(body["next_cursor"])

    def test_pages_follow_next_cursor(self):
        _, _, api = build()
        _, first = api.handle_list({"limit": "2"})
        self.assertEqual([a["id"] for a in first["items"]], [3, 2])
        status, second = api.handle_list({"limit": "2", "cursor": first["next_cursor"]})
        self.assertEqual(status, 200)
        self.assertEqual([a["id"] for a in second["items"]], [1, 4])
        self.assertIsNone(second["next_cursor"])

    def test_empty_cursor_param_means_no_cursor(self):
        _, _, api = build()
        status, body = api.handle_list({"cursor": ""})
        self.assertEqual(status, 200)
        self.assertEqual([a["id"] for a in body["items"]], [3, 2, 1, 4])

    def test_filters_flow_through(self):
        _, _, api = build()
        status, body = api.handle_list({"author": "bo", "limit": "1"})
        self.assertEqual(status, 200)
        self.assertEqual([a["id"] for a in body["items"]], [3])
        status, body = api.handle_list({"author": "bo", "limit": "1", "cursor": body["next_cursor"]})
        self.assertEqual([a["id"] for a in body["items"]], [4])

    def test_invalid_parameters_answer_400(self):
        _, _, api = build()
        cursor = api.handle_list({"limit": "1"})[1]["next_cursor"]
        for params in [
            {"limit": "abc"},
            {"limit": "0"},
            {"limit": "101"},
            {"limit": ""},
            {"status": "deleted"},
            {"cursor": "garbage"},
            {"cursor": cursor, "author": "bo"},  # cursor created without the filter
            {"page": "1", "cursor": cursor},
            {"per_page": "5", "limit": "5"},
        ]:
            status, body = api.handle_list(params)
            self.assertEqual((status, "error" in body), (400, True), params)

    def test_legacy_mode_kept(self):
        _, _, api = build()
        status, body = api.handle_list({"page": "2", "per_page": "2"})
        self.assertEqual(status, 200)
        self.assertEqual(set(body), {"items", "page", "per_page", "total"})
        self.assertEqual([a["id"] for a in body["items"]], [1, 4])
        self.assertEqual((body["page"], body["per_page"], body["total"]), (2, 2, 4))


if __name__ == "__main__":
    unittest.main()
