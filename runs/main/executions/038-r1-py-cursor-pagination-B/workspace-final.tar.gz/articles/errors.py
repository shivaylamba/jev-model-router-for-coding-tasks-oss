"""Errors shared by the service and API layers."""


class ValidationError(ValueError):
    """A request parameter is invalid. The API turns it into a 400 response."""


class InvalidCursorError(ValidationError):
    """A cursor string is not one produced by `list_articles`, or does not match the filters it was created with."""
