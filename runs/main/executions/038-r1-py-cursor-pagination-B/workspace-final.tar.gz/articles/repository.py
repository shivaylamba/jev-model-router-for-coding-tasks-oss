"""Queries against the article store."""


class ArticleRepository:
    def __init__(self, store):
        self._store = store

    def _filtered(self, author=None, status=None):
        rows = self._store.scan()
        if author is not None:
            rows = [a for a in rows if a.author == author]
        if status is not None:
            rows = [a for a in rows if a.status == status]
        return rows

    def _ordered(self, author=None, status=None):
        """Matching articles in listing order: published_at descending, id descending."""
        return sorted(self._filtered(author, status), key=lambda a: (a.published_at, a.id), reverse=True)

    def count(self, author=None, status=None):
        return len(self._filtered(author, status))

    def list_offset(self, offset, limit, author=None, status=None):
        """A window of the listing starting at `offset`."""
        return self._ordered(author, status)[offset:offset + limit]

    def list_first(self, limit, author=None, status=None):
        """The first `limit` matching articles of the listing."""
        return self._ordered(author, status)[:limit]

    def list_after(self, published_at, article_id, limit, author=None, status=None):
        """Up to `limit` matching articles strictly after the (published_at, article_id) position."""
        position = (published_at, article_id)
        out = []
        for article in self._ordered(author, status):
            if (article.published_at, article.id) < position:
                out.append(article)
                if len(out) == limit:
                    break
        return out
