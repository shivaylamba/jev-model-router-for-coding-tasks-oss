"""GET /articles."""

from .errors import ValidationError


def serialize(article):
    return {
        "id": article.id,
        "title": article.title,
        "author": article.author,
        "status": article.status,
        "published_at": article.published_at,
    }


def _int_param(params, name, default):
    raw = params.get(name)
    if raw is None:
        return default
    if not raw.isdigit():
        raise ValidationError(f"{name} must be a positive integer")
    return int(raw)


def _limit_param(params):
    raw = params.get("limit")
    if raw is None:
        return 20
    if not raw.isascii() or not raw.isdigit():
        raise ValidationError("limit must be a positive integer")
    return int(raw)


class ArticlesApi:
    def __init__(self, service):
        self._service = service

    def handle_list(self, params):
        """`params` maps query-string names to string values. Returns (status, body)."""
        try:
            return self._list(params)
        except ValidationError as err:
            return 400, {"error": str(err)}

    def _list(self, params):
        legacy = "page" in params or "per_page" in params
        cursor = params.get("cursor") or None  # an empty cursor value means no cursor
        if legacy:
            if cursor is not None or "limit" in params:
                raise ValidationError("page/per_page cannot be combined with cursor/limit")
            return self._legacy_list(params)
        return self._cursor_list(params, cursor)

    def _legacy_list(self, params):
        result = self._service.list_page(
            page=_int_param(params, "page", 1),
            per_page=_int_param(params, "per_page", 20),
            author=params.get("author"),
            status=params.get("status"),
        )
        body = dict(result)
        body["items"] = [serialize(a) for a in result["items"]]
        return 200, body

    def _cursor_list(self, params, cursor):
        result = self._service.list_articles(
            limit=_limit_param(params),
            cursor=cursor,
            author=params.get("author"),
            status=params.get("status"),
        )
        return 200, {"items": [serialize(a) for a in result.items], "next_cursor": result.next_cursor}
