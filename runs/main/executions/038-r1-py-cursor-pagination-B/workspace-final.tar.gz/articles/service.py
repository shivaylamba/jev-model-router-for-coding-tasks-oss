"""Listing rules for articles."""

import base64
import json
import re
import warnings
from dataclasses import dataclass

from .errors import InvalidCursorError, ValidationError
from .store import STATUSES

MAX_PER_PAGE = 100

_CURSOR_RE = re.compile(r"[A-Za-z0-9_-]+")
_CURSOR_VERSION = 1


@dataclass
class Page:
    """One page of the listing; `next_cursor` continues it, or is None at the end."""

    items: list
    next_cursor: str | None


def _encode_cursor(published_at, article_id, author, status):
    """Opaque cursor for a listing position and the filters it belongs to."""
    payload = {
        "version": _CURSOR_VERSION,
        "published_at": published_at,
        "id": article_id,
        "author": author,
        "status": status,
    }
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _is_int(value):
    return isinstance(value, int) and not isinstance(value, bool)


def _decode_cursor(cursor):
    """Return ((published_at, id), author, status) for a cursor from `list_articles`.

    Raises InvalidCursorError for anything else, including strings that decode
    as base64 or JSON but are not a cursor we produced.
    """
    if not isinstance(cursor, str) or not _CURSOR_RE.fullmatch(cursor):
        raise InvalidCursorError("cursor is not a valid cursor")
    padded = cursor + "=" * (-len(cursor) % 4)
    try:
        payload = json.loads(base64.urlsafe_b64decode(padded.encode("ascii")))
    except (ValueError, RecursionError):  # bad base64, bad JSON, or pathologically nested JSON
        raise InvalidCursorError("cursor is not a valid cursor") from None
    if not isinstance(payload, dict) or not _is_int(payload.get("version")) or payload["version"] != _CURSOR_VERSION:
        raise InvalidCursorError("cursor is not a valid cursor")
    if not _is_int(payload.get("published_at")) or not _is_int(payload.get("id")):
        raise InvalidCursorError("cursor is not a valid cursor")
    author = payload.get("author")
    status = payload.get("status")
    if author is not None and not isinstance(author, str):
        raise InvalidCursorError("cursor is not a valid cursor")
    if status is not None and status not in STATUSES:
        raise InvalidCursorError("cursor is not a valid cursor")
    position = (payload["published_at"], payload["id"])
    return position, author, status


class ArticleService:
    def __init__(self, repository):
        self._repo = repository

    def _check_filters(self, author, status):
        if status is not None and status not in STATUSES:
            raise ValidationError(f"status must be one of {', '.join(STATUSES)}")

    def _check_limit(self, limit):
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= MAX_PER_PAGE:
            raise ValidationError(f"limit must be an integer from 1 to {MAX_PER_PAGE}")

    def list_articles(self, limit=20, cursor=None, author=None, status=None):
        """One page of articles, newest first, continuing at `cursor` when given.

        Returns a Page. `next_cursor` continues the listing after the last item
        of `items`, or is None when no matching article is left.
        """
        self._check_limit(limit)
        self._check_filters(author, status)
        position = None
        if cursor is not None:
            position, cursor_author, cursor_status = _decode_cursor(cursor)
            if cursor_author != author or cursor_status != status:
                raise InvalidCursorError("cursor does not match the author/status filters it was created with")
        if position is None:
            rows = self._repo.list_first(limit + 1, author, status)
        else:
            rows = self._repo.list_after(position[0], position[1], limit + 1, author, status)
        has_more = len(rows) > limit
        items = rows[:limit]
        next_cursor = None
        if has_more:
            last = items[-1]
            next_cursor = _encode_cursor(last.published_at, last.id, author, status)
        return Page(items=items, next_cursor=next_cursor)

    def list_page(self, page=1, per_page=20, author=None, status=None):
        """One page of articles, newest first.

        Returns {"items": [Article, ...], "page": page, "per_page": per_page, "total": total}
        where total counts every article matching the filters.
        """
        warnings.warn(
            "list_page is deprecated; use list_articles for cursor-based paging",
            DeprecationWarning,
            stacklevel=2,
        )
        if not isinstance(page, int) or page < 1:
            raise ValidationError("page must be an integer >= 1")
        if not isinstance(per_page, int) or not 1 <= per_page <= MAX_PER_PAGE:
            raise ValidationError(f"per_page must be an integer from 1 to {MAX_PER_PAGE}")
        self._check_filters(author, status)
        items = self._repo.list_offset((page - 1) * per_page, per_page, author, status)
        return {"items": items, "page": page, "per_page": per_page, "total": self._repo.count(author, status)}
