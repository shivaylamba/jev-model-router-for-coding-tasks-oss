/**
 * Parse text pasted into the invite dialog into valid and invalid addresses.
 * The text is split on any run of commas, semicolons and whitespace; each
 * piece is checked as-is, with no trimming or unwrapping (so
 * "<ada@example.com>" is simply invalid). `valid` holds each address once,
 * spelled as first typed (addresses differing only in case are the same);
 * `invalid` holds every invalid piece in input order, repeats included.
 * @param {string} text
 * @returns {{ valid: string[], invalid: string[] }}
 */
export function parseEmailList(text) {
  const valid = [];
  const invalid = [];
  const seen = new Set();

  for (const piece of text.split(/[\s,;]+/)) {
    if (!piece) continue;
    if (isValidAddress(piece)) {
      const key = piece.toLowerCase();
      if (!seen.has(key)) {
        seen.add(key);
        valid.push(piece);
      }
    } else {
      invalid.push(piece);
    }
  }

  return { valid, invalid };
}

const LOCAL_PART = /^[A-Za-z0-9._%+-]+$/;
const LABEL = /^[A-Za-z0-9-]+$/;
const LAST_LABEL = /^[A-Za-z]{2,}$/;

function isValidAddress(piece) {
  const at = piece.indexOf("@");
  if (at === -1 || piece.indexOf("@", at + 1) !== -1) {
    return false;
  }
  return isValidLocalPart(piece.slice(0, at)) && isValidDomain(piece.slice(at + 1));
}

function isValidLocalPart(local) {
  return (
    local.length <= 64 &&
    LOCAL_PART.test(local) &&
    !local.startsWith(".") &&
    !local.endsWith(".") &&
    !local.includes("..")
  );
}

function isValidDomain(domain) {
  const labels = domain.split(".");
  if (labels.length < 2) {
    return false;
  }
  return labels.every((label, i) => {
    if (label.length > 63 || !LABEL.test(label)) return false;
    if (label.startsWith("-") || label.endsWith("-")) return false;
    if (i === labels.length - 1 && !LAST_LABEL.test(label)) return false;
    return true;
  });
}
