import { test } from "node:test";
import assert from "node:assert/strict";
import { parseEmailList } from "../src/emails.js";

test("splits on any run of commas, semicolons and whitespace", () => {
  const { valid, invalid } = parseEmailList("a@x.io,, ;;b@y.io \t c@z.io\n\n d@w.io");
  assert.deepEqual(valid, ["a@x.io", "b@y.io", "c@z.io", "d@w.io"]);
  assert.deepEqual(invalid, []);
});

test("ignores empty pieces", () => {
  const { valid, invalid } = parseEmailList(", a@x.io , ;;\n\t");
  assert.deepEqual(valid, ["a@x.io"]);
  assert.deepEqual(invalid, []);
});

test("empty text parses to empty lists", () => {
  assert.deepEqual(parseEmailList(""), { valid: [], invalid: [] });
  assert.deepEqual(parseEmailList(" ,;\t\n"), { valid: [], invalid: [] });
});

test("checks each piece as-is, with no trimming or unwrapping", () => {
  const { valid, invalid } = parseEmailList(" <ada@x.io> ada@x.io ");
  assert.deepEqual(valid, ["ada@x.io"]);
  assert.deepEqual(invalid, ["<ada@x.io>"]);
});

test("requires exactly one @", () => {
  const { valid, invalid } = parseEmailList("a@b@x.io @@x.io a@@x.io");
  assert.deepEqual(valid, []);
  assert.deepEqual(invalid, ["a@b@x.io", "@@x.io", "a@@x.io"]);
});

test("local part: allowed characters and dot placement", () => {
  const { valid, invalid } = parseEmailList(
    "a.b@x.io a+b%c_d-e@x.io .a@x.io a.@x.io a..b@x.io a!b@x.io @x.io"
  );
  assert.deepEqual(valid, ["a.b@x.io", "a+b%c_d-e@x.io"]);
  assert.deepEqual(invalid, [".a@x.io", "a.@x.io", "a..b@x.io", "a!b@x.io", "@x.io"]);
});

test("local part: 1-64 characters", () => {
  const sixtyFour = "a".repeat(64);
  const sixtyFive = "a".repeat(65);
  const { valid, invalid } = parseEmailList(`${sixtyFour}@x.io ${sixtyFive}@x.io`);
  assert.deepEqual(valid, [`${sixtyFour}@x.io`]);
  assert.deepEqual(invalid, [`${sixtyFive}@x.io`]);
});

test("domain: two or more labels", () => {
  const { valid, invalid } = parseEmailList("a@x a@x.io a@x.y.io");
  assert.deepEqual(valid, ["a@x.io", "a@x.y.io"]);
  assert.deepEqual(invalid, ["a@x"]);
});

test("domain: label characters, hyphens and final label", () => {
  const { valid, invalid } = parseEmailList("a@x-y.io a@1.io a@-x.io a@x-.io a@x..io a@x.i1 a@x.i");
  assert.deepEqual(valid, ["a@x-y.io", "a@1.io"]);
  assert.deepEqual(invalid, ["a@-x.io", "a@x-.io", "a@x..io", "a@x.i1", "a@x.i"]);
});

test("domain: labels are 1-63 characters", () => {
  const sixtyThree = "a".repeat(63);
  const sixtyFour = "a".repeat(64);
  const { valid, invalid } = parseEmailList(`a@${sixtyThree}.io a@${sixtyFour}.io`);
  assert.deepEqual(valid, [`a@${sixtyThree}.io`]);
  assert.deepEqual(invalid, [`a@${sixtyFour}.io`]);
});

test("valid: first spelling wins, case-insensitive, no duplicates", () => {
  const { valid, invalid } = parseEmailList("Ada@X.IO ada@x.io ADA@x.io bob@x.io");
  assert.deepEqual(valid, ["Ada@X.IO", "bob@x.io"]);
  assert.deepEqual(invalid, []);
});

test("invalid: keeps input order and repeats", () => {
  const { valid, invalid } = parseEmailList("nope a@x.io bad nope a@x.io b@y.io");
  assert.deepEqual(valid, ["a@x.io", "b@y.io"]);
  assert.deepEqual(invalid, ["nope", "bad", "nope"]);
});
