"""Profile editing."""

from .errors import ValidationError
from . import validators

EDITABLE = ("display_name", "email", "phone", "username")


def update_profile(profile, changes):
    """Return a new profile dict with `changes` applied. Unknown keys raise ValidationError.

    An empty or blank phone clears it (None). Other fields cannot be blank.
    """
    updated = dict(profile)
    for key, value in changes.items():
        if key not in EDITABLE:
            raise ValidationError(key, "cannot be changed")

        if key == "display_name":
            updated["display_name"] = validators.validate_display_name(value)
        elif key == "email":
            updated["email"] = validators.validate_email(value)
        elif key == "phone":
            if not value.strip():
                updated["phone"] = None
                continue
            updated["phone"] = validators.validate_phone(value)
        elif key == "username":
            updated["username"] = validators.validate_username(value)
    return updated
