import unittest

from latency import fastest, slowest
from leaderboard import Player, format_podium
from ranking import rank_positions, top_n


class TopNTest(unittest.TestCase):
    def test_largest_first(self):
        self.assertEqual(top_n([4, 9, 1, 7], 2), [9, 7])

    def test_smallest_first_with_reverse(self):
        self.assertEqual(top_n([4, 9, 1, 7], 2, reverse=True), [1, 4])

    def test_reverse_is_keyword_only(self):
        with self.assertRaises(TypeError):
            top_n([4, 9, 1, 7], 2, True)

    def test_key(self):
        self.assertEqual(top_n(["bb", "a", "ccc"], 2, key=len), ["ccc", "bb"])

    def test_key_positional(self):
        self.assertEqual(top_n(["bb", "a", "ccc"], 2, len), ["ccc", "bb"])

    def test_key_with_reverse(self):
        self.assertEqual(top_n(["bb", "a", "ccc"], 2, len, reverse=True), ["a", "bb"])

    def test_equal_items_keep_original_order(self):
        items = [(3, "a"), (1, "b"), (3, "c")]
        self.assertEqual(top_n(items, 3, key=lambda p: p[0]), [(3, "a"), (3, "c"), (1, "b")])
        self.assertEqual(top_n(items, 3, key=lambda p: p[0], reverse=True), [(1, "b"), (3, "a"), (3, "c")])

    def test_more_than_available(self):
        self.assertEqual(top_n([3, 1], 5), [3, 1])

    def test_more_than_available_with_reverse(self):
        self.assertEqual(top_n([3, 1], 5, reverse=True), [1, 3])

    def test_zero_n(self):
        self.assertEqual(top_n([4, 9, 1, 7], 0), [])
        self.assertEqual(top_n([4, 9, 1, 7], 0, reverse=True), [])

    def test_negative_n(self):
        with self.assertRaises(ValueError):
            top_n([4, 9, 1, 7], -1)

    def test_input_not_modified(self):
        items = [4, 9, 1, 7]
        top_n(items, 2, reverse=True)
        self.assertEqual(items, [4, 9, 1, 7])

    def test_rank_positions(self):
        self.assertEqual(rank_positions([10, 20, 20, 5]), {20: 1, 10: 3, 5: 4})


class CallersTest(unittest.TestCase):
    def test_podium(self):
        players = [Player("ana", 12), Player("bo", 30), Player("cy", 18), Player("di", 2)]
        self.assertEqual(format_podium(players), "1. bo (30)\n2. cy (18)\n3. ana (12)")

    def test_slowest(self):
        self.assertEqual(slowest([120, 40, 980, 300], count=2), [980, 300])

    def test_fastest(self):
        self.assertEqual(fastest([120, 40, 980, 300], count=2), [40, 120])


if __name__ == "__main__":
    unittest.main()
