import { deprecate } from "./deprecate.js";

const KNOWN_OPTIONS = ["baseUrl", "token", "timeoutMs", "retries", "headers"];

/**
 * Create an API client.
 *
 * @param {object} options
 * @param {string} options.baseUrl   e.g. "https://api.internal.example"; trailing slashes are removed
 * @param {string} [options.token]   bearer token; no Authorization header when omitted
 * @param {number} [options.timeoutMs=5000]
 * @param {number} [options.retries=0]
 * @param {object} [options.headers] extra headers added to every request description, alongside the
 *                                   accept/authorization/content-type headers the client sets itself
 *
 * An option whose value is `undefined` counts as not given, so its default applies.
 * The old positional form `createClient(baseUrl, token, timeoutMs, retries)` still works, with the
 * same defaults and validation, but reports the CLIENT_POSITIONAL_ARGS deprecation.
 */
export function createClient(optionsOrBaseUrl, token, timeoutMs, retries) {
  const positional = typeof optionsOrBaseUrl === "string";
  let given;
  if (positional) {
    given = { baseUrl: optionsOrBaseUrl, token, timeoutMs, retries };
  } else if (isPlainObject(optionsOrBaseUrl)) {
    given = optionsOrBaseUrl;
  } else {
    throw new TypeError(
      "createClient requires an options object: createClient({ baseUrl, token, timeoutMs, retries, headers })",
    );
  }

  const options = normalizeOptions(given);

  if (positional) {
    deprecate(
      "CLIENT_POSITIONAL_ARGS",
      "createClient(baseUrl, token, timeoutMs, retries) is deprecated; use createClient({ baseUrl, token, timeoutMs, retries, headers }) instead",
    );
  }

  return {
    options,
    /**
     * Describe a request and pass it to `transport`, returning whatever the transport returns.
     */
    request(transport, method, path, body) {
      const headers = { ...options.headers, accept: "application/json" };
      if (options.token) headers.authorization = `Bearer ${options.token}`;
      if (body !== undefined) headers["content-type"] = "application/json";
      return transport({
        method,
        url: options.baseUrl + (path.startsWith("/") ? path : `/${path}`),
        headers,
        body: body === undefined ? undefined : JSON.stringify(body),
        timeoutMs: options.timeoutMs,
        retries: options.retries,
      });
    },
  };
}

/** True for object literals and `Object.create(null)` — not arrays, class instances, etc. */
function isPlainObject(value) {
  if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === null || prototype === Object.prototype;
}

/** Validate the given options and turn them into the frozen, normalized form. */
function normalizeOptions(given) {
  const unknown = Object.keys(given).filter((name) => !KNOWN_OPTIONS.includes(name));
  if (unknown.length > 0) {
    throw new TypeError(`Unknown createClient option${unknown.length === 1 ? "" : "s"}: ${unknown.join(", ")}`);
  }

  if (typeof given.baseUrl !== "string" || given.baseUrl === "") {
    throw new TypeError("baseUrl must be a non-empty string");
  }

  const timeoutMs = given.timeoutMs === undefined ? 5000 : given.timeoutMs;
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0) {
    throw new RangeError("timeoutMs must be a finite number greater than 0");
  }

  const retries = given.retries === undefined ? 0 : given.retries;
  if (!Number.isInteger(retries) || retries < 0) {
    throw new RangeError("retries must be an integer >= 0");
  }

  return Object.freeze({
    baseUrl: given.baseUrl.replace(/\/+$/, ""),
    token: given.token,
    timeoutMs,
    retries,
    headers: Object.freeze({ ...given.headers }),
  });
}
