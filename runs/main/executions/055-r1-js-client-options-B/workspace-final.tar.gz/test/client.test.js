import { test } from "node:test";
import assert from "node:assert/strict";
import { createClient } from "../src/client.js";
import { createUsersApi } from "../src/users.js";
import { createBillingApi } from "../src/billing.js";
import { createReportsApi } from "../src/reports.js";
import { resetDeprecations, setDeprecationHandler } from "../src/deprecate.js";

const echo = (req) => req;
const silence = () => {};
setDeprecationHandler(silence);

/** Run `fn` with deprecations recorded instead of reported; returns the recorded [code, message] pairs. */
function captureDeprecations(fn) {
  const seen = [];
  setDeprecationHandler((code, message) => seen.push([code, message]));
  try {
    fn();
  } finally {
    setDeprecationHandler(silence);
  }
  return seen;
}

test("request description", () => {
  const client = createClient({ baseUrl: "https://api.example/", token: "t0k", timeoutMs: 1000, retries: 1 });
  assert.deepEqual(client.request(echo, "POST", "items", { a: 1 }), {
    method: "POST",
    url: "https://api.example/items",
    headers: { accept: "application/json", authorization: "Bearer t0k", "content-type": "application/json" },
    body: '{"a":1}',
    timeoutMs: 1000,
    retries: 1,
  });
});

test("defaults", () => {
  const client = createClient({ baseUrl: "https://api.example" });
  assert.deepEqual(client.options, {
    baseUrl: "https://api.example",
    token: undefined,
    timeoutMs: 5000,
    retries: 0,
    headers: {},
  });
  assert.equal(client.request(echo, "GET", "/x").headers.authorization, undefined);
});

test("undefined options count as not given", () => {
  const client = createClient({
    baseUrl: "https://api.example",
    token: undefined,
    timeoutMs: undefined,
    retries: undefined,
    headers: undefined,
  });
  assert.equal(client.options.token, undefined);
  assert.equal(client.options.timeoutMs, 5000);
  assert.equal(client.options.retries, 0);
  assert.deepEqual(client.options.headers, {});
});

test("options are frozen and headers are copied", () => {
  const headers = { "x-api-key": "k" };
  const client = createClient({ baseUrl: "https://api.example", headers });
  headers["x-api-key"] = "changed";
  assert.equal(client.options.headers["x-api-key"], "k");
  assert.ok(Object.isFrozen(client.options));
  assert.ok(Object.isFrozen(client.options.headers));
});

test("extra headers are added to every request description", () => {
  const client = createClient({
    baseUrl: "https://api.example",
    token: "t0k",
    headers: { "x-api-key": "k", "x-trace-id": "t1" },
  });
  assert.deepEqual(client.request(echo, "POST", "/items", { a: 1 }).headers, {
    "x-api-key": "k",
    "x-trace-id": "t1",
    accept: "application/json",
    authorization: "Bearer t0k",
    "content-type": "application/json",
  });
  const bare = createClient({ baseUrl: "https://api.example", headers: { "x-api-key": "k" } });
  assert.deepEqual(bare.request(echo, "GET", "/x").headers, { "x-api-key": "k", accept: "application/json" });
});

test("services", () => {
  const config = { apiUrl: "https://u.example", billingUrl: "https://b.example", reportsUrl: "https://r.example", token: "s3cret" };
  assert.equal(createUsersApi(config).getUser(echo, "a b").url, "https://u.example/users/a%20b");
  const charge = createBillingApi(config).charge(echo, "c1", 500);
  assert.equal(charge.timeoutMs, 15000);
  assert.equal(charge.retries, 3);
  const report = createReportsApi(config).monthly(echo, "2026-01");
  assert.equal(report.timeoutMs, 60000);
  assert.equal(report.headers.authorization, undefined);
});

test("baseUrl must be a non-empty string", () => {
  assert.throws(() => createClient(), TypeError);
  assert.throws(() => createClient({}), /baseUrl must be a non-empty string/);
  assert.throws(() => createClient({ baseUrl: "" }), /baseUrl must be a non-empty string/);
  assert.throws(() => createClient({ baseUrl: 42 }), /baseUrl must be a non-empty string/);
  assert.throws(() => createClient({ baseUrl: null }), /baseUrl must be a non-empty string/);
});

test("timeoutMs must be a finite number greater than 0", () => {
  for (const timeoutMs of [0, -1000, Infinity, -Infinity, NaN, "1000", null]) {
    assert.throws(() => createClient({ baseUrl: "https://x", timeoutMs }), RangeError);
  }
  assert.doesNotThrow(() => createClient({ baseUrl: "https://x", timeoutMs: 0.5 }));
});

test("retries must be an integer >= 0", () => {
  for (const retries of [-1, 1.5, Infinity, NaN, "3", null]) {
    assert.throws(() => createClient({ baseUrl: "https://x", retries }), RangeError);
  }
  assert.doesNotThrow(() => createClient({ baseUrl: "https://x", retries: 0 }));
});

test("unknown option names are rejected", () => {
  assert.throws(() => createClient({ baseUrl: "https://x", timeout: 1000 }), /timeout/);
  assert.throws(
    () => createClient({ baseUrl: "https://x", tokn: "t", heders: {} }),
    (error) => error instanceof TypeError && /tokn/.test(error) && /heders/.test(error),
  );
});

test("the argument must be a string or a plain object", () => {
  for (const bad of [undefined, null, 42, true, [], ["https://x"], () => {}, new Date(), new (class C {})()]) {
    assert.throws(() => createClient(bad), TypeError);
  }
});

test("positional form still works and reports CLIENT_POSITIONAL_ARGS", () => {
  resetDeprecations();
  let client;
  const seen = captureDeprecations(() => {
    client = createClient("https://api.example/", "t0k", 1000, 1);
  });
  assert.equal(seen.length, 1);
  assert.equal(seen[0][0], "CLIENT_POSITIONAL_ARGS");
  assert.match(seen[0][1], /deprecated/);
  assert.deepEqual(client.options, {
    baseUrl: "https://api.example",
    token: "t0k",
    timeoutMs: 1000,
    retries: 1,
    headers: {},
  });
  assert.deepEqual(client.request(echo, "POST", "items", { a: 1 }).headers, {
    accept: "application/json",
    authorization: "Bearer t0k",
    "content-type": "application/json",
  });
});

test("positional form keeps the old defaults and validation", () => {
  resetDeprecations();
  captureDeprecations(() => {
    const client = createClient("https://api.example");
    assert.equal(client.options.baseUrl, "https://api.example");
    assert.equal(client.options.token, undefined);
    assert.equal(client.options.timeoutMs, 5000);
    assert.equal(client.options.retries, 0);
    assert.deepEqual(client.options.headers, {});
    assert.throws(() => createClient("https://api.example", "t", 0), RangeError);
    assert.throws(() => createClient("https://api.example", "t", 5000, -1), RangeError);
    assert.throws(() => createClient("", "t"), TypeError);
  });
});

test("positional form warns at most once per process", () => {
  resetDeprecations();
  const seen = captureDeprecations(() => {
    createClient("https://a.example");
    createClient("https://b.example");
    createClient("https://c.example", "t");
  });
  assert.equal(seen.length, 1);
});

test("options form never warns", () => {
  resetDeprecations();
  const seen = captureDeprecations(() => {
    createClient({ baseUrl: "https://api.example" });
    createClient({ baseUrl: "https://api.example", token: "t", timeoutMs: 100, retries: 2, headers: { "x-a": "b" } });
  });
  assert.deepEqual(seen, []);
});
