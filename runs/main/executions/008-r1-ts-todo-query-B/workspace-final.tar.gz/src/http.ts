import type { TodoQuery, TodoService } from "./todos.ts";

export interface Response {
  status: number;
  body: unknown;
}

/** Handle GET /todos. `url` is the request path plus query string, e.g. "/todos?status=open". */
export function handleTodos(service: TodoService, url: string): Response {
  const parsed = new URL(url, "http://localhost");
  if (parsed.pathname !== "/todos") {
    return { status: 404, body: { error: "not found" } };
  }

  const params = parsed.searchParams;
  const query: TodoQuery = {};
  if (params.has("status")) query.status = params.get("status") as TodoQuery["status"];
  const tags = params.getAll("tag").filter((tag) => tag !== "");
  if (tags.length > 0) query.tags = tags;
  if (params.has("q")) query.text = params.get("q") as string;
  if (params.has("dueBefore")) query.dueBefore = params.get("dueBefore") as string;
  if (params.has("sort")) query.sort = params.get("sort") as TodoQuery["sort"];
  if (params.has("order")) query.order = params.get("order") as TodoQuery["order"];

  let items;
  try {
    items = service.query(query);
  } catch (err) {
    if (err instanceof RangeError) {
      return { status: 400, body: { error: err.message } };
    }
    throw err;
  }
  return { status: 200, body: { items, count: items.length } };
}
