import { test } from "node:test";
import assert from "node:assert/strict";
import { parseEmailList } from "../src/emails.js";

test("splits on runs of commas, semicolons and whitespace, ignores empties", () => {
  const { valid, invalid } = parseEmailList(
    "a@x.io, ;b@y.io\t\n,,\n  c@z.io;;"
  );
  assert.deepEqual(valid, ["a@x.io", "b@y.io", "c@z.io"]);
  assert.deepEqual(invalid, []);
});

test("pieces are checked as-is, no unwrapping", () => {
  const { valid, invalid } = parseEmailList("<ada@example.com>");
  assert.deepEqual(valid, []);
  assert.deepEqual(invalid, ["<ada@example.com>"]);
});

test("exactly one @ required", () => {
  assert.deepEqual(parseEmailList("a@@x.io").invalid, ["a@@x.io"]);
  assert.deepEqual(parseEmailList("ax.io").invalid, ["ax.io"]);
});

test("local part rules", () => {
  assert.deepEqual(parseEmailList("a.b+c%-d_e@x.io").valid, ["a.b+c%-d_e@x.io"]);
  assert.deepEqual(parseEmailList(".a@x.io").invalid, [".a@x.io"]);
  assert.deepEqual(parseEmailList("a.@x.io").invalid, ["a.@x.io"]);
  assert.deepEqual(parseEmailList("a..b@x.io").invalid, ["a..b@x.io"]);
  assert.deepEqual(parseEmailList(`${"a".repeat(65)}@x.io`).invalid.length, 1);
  assert.deepEqual(parseEmailList(`${"a".repeat(64)}@x.io`).valid.length, 1);
});

test("domain rules", () => {
  assert.deepEqual(parseEmailList("a@io").invalid, ["a@io"]); // one label
  assert.deepEqual(parseEmailList("a@x.i").invalid, ["a@x.i"]); // TLD < 2
  assert.deepEqual(parseEmailList("a@x.1o").invalid, ["a@x.1o"]); // TLD digit
  assert.deepEqual(parseEmailList("a@-x.io").invalid, ["a@-x.io"]); // leading hyphen
  assert.deepEqual(parseEmailList("a@x-.io").invalid, ["a@x-.io"]); // trailing hyphen
  assert.deepEqual(parseEmailList("a@x..io").invalid, ["a@x..io"]); // empty label
  assert.deepEqual(
    parseEmailList(`a@${"b".repeat(64)}.io`).invalid.length,
    1
  ); // label > 63
  assert.deepEqual(parseEmailList("a@sub.x.io").valid, ["a@sub.x.io"]);
  assert.deepEqual(parseEmailList("a@x-y.io").valid, ["a@x-y.io"]);
});

test("valid list dedupes case-insensitively, first spelling wins, order kept", () => {
  const { valid } = parseEmailList("Ada@X.io bob@y.io ada@x.io BOB@Y.io");
  assert.deepEqual(valid, ["Ada@X.io", "bob@y.io"]);
});

test("invalid list keeps every invalid piece, including repeats", () => {
  const { invalid } = parseEmailList("nope nope, a@x.io, nope");
  assert.deepEqual(invalid, ["nope", "nope", "nope"]);
});

test("empty input", () => {
  assert.deepEqual(parseEmailList(""), { valid: [], invalid: [] });
  assert.deepEqual(parseEmailList(" , ; \n"), { valid: [], invalid: [] });
});
