/**
 * Parse the pasted text from the invite dialog into valid and invalid
 * e-mail addresses.
 *
 * The text is split on any run of commas, semicolons and whitespace.
 * Pieces are checked as-is (no trimming beyond the split, no unwrapping).
 * `valid` holds each valid address once, in input order, spelled as first
 * typed (deduped case-insensitively); `invalid` holds every invalid piece
 * in input order, including repeats.
 *
 * @param {string} text
 * @returns {{ valid: string[], invalid: string[] }}
 */
export function parseEmailList(text) {
  const pieces = text.split(/[,;\s]+/).filter(Boolean);

  const valid = [];
  const invalid = [];
  const seen = new Set();

  for (const piece of pieces) {
    if (isValidEmail(piece)) {
      const key = piece.toLowerCase();
      if (!seen.has(key)) {
        seen.add(key);
        valid.push(piece);
      }
    } else {
      invalid.push(piece);
    }
  }

  return { valid, invalid };
}

const LOCAL_RE = /^[A-Za-z0-9._%+-]{1,64}$/;
const DOMAIN_LABEL_RE = /^[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?$/;
const TLD_RE = /^[A-Za-z]{2,}$/;

function isValidEmail(piece) {
  const at = piece.indexOf("@");
  if (at === -1 || at !== piece.lastIndexOf("@")) return false;

  const local = piece.slice(0, at);
  const domain = piece.slice(at + 1);

  if (!LOCAL_RE.test(local)) return false;
  if (local.startsWith(".") || local.endsWith(".") || local.includes("..")) {
    return false;
  }

  const labels = domain.split(".");
  if (labels.length < 2) return false;
  if (!TLD_RE.test(labels[labels.length - 1])) return false;
  return labels.every((label) => DOMAIN_LABEL_RE.test(label));
}
