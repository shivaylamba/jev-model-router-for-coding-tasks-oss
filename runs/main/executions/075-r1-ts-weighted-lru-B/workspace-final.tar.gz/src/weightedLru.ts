/**
 * A least-recently-used cache bounded by the total weight of its entries
 * rather than their count. Each entry's weight comes from `weigh` (1 by
 * default); whenever the combined weight would exceed `maxWeight`, entries
 * are evicted least recently used first.
 */
export interface WeightedLRUOptions<K, V> {
  /** Total weight the cache may hold; must be a positive finite number. */
  maxWeight: number;
  /** Returns an entry's weight (default: 1). May be 0 or fractional. */
  weigh?: (value: V, key: K) => number;
  /** Called with each entry removed to make room, after its removal. */
  onEvict?: (key: K, value: V) => void;
}

interface Entry<V> {
  value: V;
  weight: number;
}

export class WeightedLRU<K, V> {
  readonly maxWeight: number;
  #weigh: (value: V, key: K) => number;
  #onEvict?: (key: K, value: V) => void;
  #entries = new Map<K, Entry<V>>();
  #totalWeight = 0;
  #hits = 0;
  #misses = 0;
  #evictions = 0;

  constructor({ maxWeight, weigh, onEvict }: WeightedLRUOptions<K, V>) {
    if (!Number.isFinite(maxWeight) || maxWeight <= 0) {
      throw new RangeError(`maxWeight must be a positive finite number, got ${maxWeight}`);
    }
    this.maxWeight = maxWeight;
    this.#weigh = weigh ?? (() => 1);
    this.#onEvict = onEvict;
  }

  get size(): number {
    return this.#entries.size;
  }

  get totalWeight(): number {
    return this.#totalWeight;
  }

  set(key: K, value: V): boolean {
    // Weigh before touching any state so a rejected or throwing set
    // leaves the cache exactly as it was.
    const weight = this.#weigh(value, key);
    if (!Number.isFinite(weight) || weight < 0) {
      throw new RangeError(`weigh must return a non-negative finite number, got ${weight}`);
    }
    if (weight > this.maxWeight) {
      return false;
    }
    const existing = this.#entries.get(key);
    if (existing !== undefined) {
      this.#entries.delete(key);
      this.#totalWeight -= existing.weight;
    }
    // A Map keeps insertion order, so the entry just set is the most
    // recently used and the first key is always the oldest.
    this.#entries.set(key, { value, weight });
    this.#totalWeight += weight;
    while (this.#totalWeight > this.maxWeight) {
      const [oldestKey, oldest] = this.#entries.entries().next().value as [K, Entry<V>];
      // The entry just set always fits on its own, so the loop runs out of
      // other entries first; the guard only covers floating-point drift in
      // the running total.
      if (oldestKey === key) {
        break;
      }
      this.#entries.delete(oldestKey);
      this.#totalWeight -= oldest.weight;
      this.#evictions++;
      this.#onEvict?.(oldestKey, oldest.value);
    }
    return true;
  }

  get(key: K): V | undefined {
    const entry = this.#entries.get(key);
    if (entry === undefined) {
      this.#misses++;
      return undefined;
    }
    this.#entries.delete(key);
    this.#entries.set(key, entry);
    this.#hits++;
    return entry.value;
  }

  peek(key: K): V | undefined {
    return this.#entries.get(key)?.value;
  }

  has(key: K): boolean {
    return this.#entries.has(key);
  }

  delete(key: K): boolean {
    const entry = this.#entries.get(key);
    if (entry === undefined) {
      return false;
    }
    this.#entries.delete(key);
    this.#totalWeight -= entry.weight;
    return true;
  }

  clear(): void {
    this.#entries.clear();
    this.#totalWeight = 0;
  }

  keys(): K[] {
    return [...this.#entries.keys()];
  }

  stats(): { hits: number; misses: number; evictions: number } {
    return { hits: this.#hits, misses: this.#misses, evictions: this.#evictions };
  }
}
