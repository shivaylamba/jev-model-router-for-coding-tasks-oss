import unittest
from datetime import datetime, timedelta, timezone

from shop.orders import InvalidTransition, Order, Transition
from shop.reports import open_value_cents, status_counts


class OrderTest(unittest.TestCase):
    def test_happy_path(self):
        order = Order("A1", [("PEN", 2, 150)])
        order.pay()
        order.pack()
        order.ship("1Z999")
        order.deliver()
        self.assertEqual(order.status, "delivered")
        self.assertEqual(order.tracking_number, "1Z999")

    def test_cancel(self):
        order = Order("A2", [])
        order.cancel("customer request")
        self.assertEqual(order.status, "cancelled")
        self.assertEqual(order.cancel_reason, "customer request")


class FakeClock:
    """A configurable stand-in for the order's clock."""

    def __init__(self, start):
        self.now = start

    def __call__(self):
        return self.now

    def advance(self, delta):
        self.now += delta


class StateMachineTest(unittest.TestCase):
    def make_delivered(self, clock):
        order = Order("D1", [], clock=clock)
        order.pay()
        order.pack()
        order.ship("1Z9")
        order.deliver()
        return order

    def test_default_clock_is_aware_utc(self):
        order = Order("A1", [])
        order.pay()
        stamp = order.history[0].at
        self.assertIsNotNone(stamp.tzinfo)
        self.assertEqual(stamp.utcoffset(), timedelta(0))

    def test_history_records_every_transition(self):
        start = datetime(2026, 10, 1, 12, 0, tzinfo=timezone.utc)
        clock = FakeClock(start)
        order = Order("A1", [("PEN", 2, 150)], clock=clock)
        self.assertEqual(order.history, [])
        self.assertIsNone(order.delivered_at)

        clock.advance(timedelta(hours=1))
        order.pay()
        self.assertEqual(order.history, [Transition("pay", "pending", "paid", start + timedelta(hours=1))])

        clock.advance(timedelta(days=1))
        order.pack()
        clock.advance(timedelta(days=1))
        order.ship("1Z999")
        clock.advance(timedelta(days=2))
        order.deliver()

        self.assertEqual(
            order.history,
            [
                Transition("pay", "pending", "paid", start + timedelta(hours=1)),
                Transition("pack", "paid", "packed", start + timedelta(hours=1, days=1)),
                Transition("ship", "packed", "shipped", start + timedelta(hours=1, days=2)),
                Transition("deliver", "shipped", "delivered", start + timedelta(hours=1, days=4)),
            ],
        )
        self.assertEqual(order.delivered_at, start + timedelta(hours=1, days=4))

    def test_disallowed_event_raises_and_changes_nothing(self):
        order = Order("A1", [])
        with self.assertRaises(InvalidTransition) as ctx:
            order.pack()
        self.assertEqual((ctx.exception.state, ctx.exception.event), ("pending", "pack"))
        self.assertEqual(order.status, "pending")
        self.assertEqual(order.history, [])

        with self.assertRaises(InvalidTransition) as ctx:
            order.refund()
        self.assertEqual((ctx.exception.state, ctx.exception.event), ("pending", "refund"))
        self.assertEqual(order.status, "pending")

    def test_terminal_states_allow_nothing(self):
        cancelled = Order("A1", [])
        cancelled.cancel("customer request")
        self.assertTrue(cancelled.is_terminal)
        self.assertEqual(cancelled.allowed_events(), [])
        self.assertFalse(cancelled.can("pay"))
        with self.assertRaises(InvalidTransition) as ctx:
            cancelled.pay()
        self.assertEqual((ctx.exception.state, ctx.exception.event), ("cancelled", "pay"))

        refunded = Order("A2", [])
        refunded.pay()
        refunded.refund()
        self.assertTrue(refunded.is_terminal)
        with self.assertRaises(InvalidTransition) as ctx:
            refunded.refund()
        self.assertEqual((ctx.exception.state, ctx.exception.event), ("refunded", "refund"))
        self.assertEqual(refunded.status, "refunded")

    def test_shipped_orders_cannot_be_cancelled_or_refunded(self):
        order = Order("A1", [])
        order.pay()
        order.pack()
        order.ship("1Z999")
        for event, call in (
            ("cancel", lambda: order.cancel("customer request")),
            ("refund", order.refund),
        ):
            with self.assertRaises(InvalidTransition) as ctx:
                call()
            self.assertEqual((ctx.exception.state, ctx.exception.event), ("shipped", event))
        self.assertEqual(order.status, "shipped")

    def test_status_check_precedes_argument_validation(self):
        pending = Order("A1", [])  # ship is disallowed from pending
        with self.assertRaises(InvalidTransition):
            pending.ship(None)
        self.assertEqual(pending.status, "pending")
        self.assertIsNone(pending.tracking_number)
        self.assertEqual(pending.history, [])

        delivered = self.make_delivered(FakeClock(datetime(2026, 10, 1, tzinfo=timezone.utc)))
        with self.assertRaises(InvalidTransition):  # cancel is disallowed from delivered
            delivered.cancel(None)
        self.assertEqual(delivered.status, "delivered")
        self.assertIsNone(delivered.cancel_reason)
        self.assertEqual(len(delivered.history), 4)

    def test_ship_requires_a_tracking_number(self):
        order = Order("A1", [])
        order.pay()
        order.pack()
        for bad in (None, 5, "", "   "):
            with self.assertRaises(ValueError):
                order.ship(bad)
            self.assertEqual(order.status, "packed")
            self.assertIsNone(order.tracking_number)
            self.assertEqual(len(order.history), 2)
        order.ship("  1Z999  ")
        self.assertEqual(order.tracking_number, "1Z999")
        self.assertEqual(order.status, "shipped")

    def test_cancel_requires_a_reason(self):
        order = Order("A1", [])
        for bad in (None, 5, "", " \t "):
            with self.assertRaises(ValueError):
                order.cancel(bad)
            self.assertEqual(order.status, "pending")
            self.assertIsNone(order.cancel_reason)
            self.assertEqual(order.history, [])
        order.cancel(" customer request ")
        self.assertEqual(order.cancel_reason, "customer request")
        self.assertEqual(order.status, "cancelled")

    def test_refund_from_delivered_within_30_days(self):
        clock = FakeClock(datetime(2026, 10, 1, tzinfo=timezone.utc))
        order = self.make_delivered(clock)
        clock.advance(timedelta(days=29, hours=23))
        self.assertTrue(order.can("refund"))
        order.refund()
        self.assertEqual(order.status, "refunded")
        self.assertTrue(order.is_terminal)

    def test_refund_allowed_at_exactly_30_days(self):
        clock = FakeClock(datetime(2026, 10, 1, tzinfo=timezone.utc))
        order = self.make_delivered(clock)
        clock.advance(timedelta(days=30))
        self.assertTrue(order.can("refund"))
        self.assertEqual(order.allowed_events(), ["refund"])
        order.refund()
        self.assertEqual(order.status, "refunded")

    def test_refund_rejected_after_30_days(self):
        clock = FakeClock(datetime(2026, 10, 1, tzinfo=timezone.utc))
        order = self.make_delivered(clock)
        clock.advance(timedelta(days=30) + timedelta(microseconds=1))
        self.assertFalse(order.can("refund"))
        self.assertEqual(order.allowed_events(), [])
        with self.assertRaises(InvalidTransition) as ctx:
            order.refund()
        self.assertEqual((ctx.exception.state, ctx.exception.event), ("delivered", "refund"))
        self.assertEqual(order.status, "delivered")
        self.assertEqual(len(order.history), 4)

    def test_refund_without_delivery(self):
        order = Order("A1", [])
        order.pay()
        order.refund()
        self.assertEqual(order.status, "refunded")

        order = Order("A2", [])
        order.pay()
        order.pack()
        order.refund()
        self.assertEqual(order.status, "refunded")

    def test_can_and_allowed_events(self):
        clock = FakeClock(datetime(2026, 10, 1, tzinfo=timezone.utc))
        order = Order("A1", [], clock=clock)
        self.assertFalse(order.is_terminal)
        self.assertEqual(order.allowed_events(), ["cancel", "pay"])
        order.pay()
        self.assertEqual(order.allowed_events(), ["cancel", "pack", "refund"])
        order.pack()
        self.assertEqual(order.allowed_events(), ["cancel", "refund", "ship"])
        order.ship("1Z999")
        self.assertEqual(order.allowed_events(), ["deliver"])
        self.assertFalse(order.can("cancel"))
        order.deliver()
        self.assertEqual(order.allowed_events(), ["refund"])
        self.assertFalse(order.can("deliver"))
        self.assertFalse(order.can("bogus"))

    def test_can_ignores_ship_and_cancel_arguments(self):
        order = Order("A1", [])
        self.assertFalse(order.can("ship"))
        order.pay()
        order.pack()
        self.assertTrue(order.can("ship"))
        self.assertTrue(order.can("cancel"))


class ReportsTest(unittest.TestCase):
    def test_counts_and_open_value(self):
        a = Order("A1", [("PEN", 2, 150)])
        b = Order("A2", [("INK", 1, 900)])
        c = Order("A3", [("PAD", 1, 400)])
        a.pay()
        b.pay()
        b.pack()
        self.assertEqual(status_counts([a, b, c]), {"paid": 1, "packed": 1, "pending": 1})
        self.assertEqual(open_value_cents([a, b, c]), 1200)


if __name__ == "__main__":
    unittest.main()
