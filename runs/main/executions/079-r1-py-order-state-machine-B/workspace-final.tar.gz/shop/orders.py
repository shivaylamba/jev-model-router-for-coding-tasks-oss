"""Orders and their lifecycle."""

from datetime import datetime, timedelta, timezone
from typing import NamedTuple


class Transition(NamedTuple):
    """One successful lifecycle event, as recorded in `Order.history`."""

    event: str
    from_state: str
    to_state: str
    at: datetime


class InvalidTransition(Exception):
    """An event that is not allowed from the order's current status."""

    def __init__(self, state, event):
        super().__init__(f"cannot {event} an order in {state}")
        self.state = state
        self.event = event


# (event, from_status) -> to_status, per docs/ORDER_LIFECYCLE.md.
_TRANSITIONS = {
    ("pay", "pending"): "paid",
    ("pack", "paid"): "packed",
    ("ship", "packed"): "shipped",
    ("deliver", "shipped"): "delivered",
    ("cancel", "pending"): "cancelled",
    ("cancel", "paid"): "cancelled",
    ("cancel", "packed"): "cancelled",
    ("refund", "paid"): "refunded",
    ("refund", "packed"): "refunded",
    ("refund", "delivered"): "refunded",
}

_TERMINAL_STATUSES = frozenset({"cancelled", "refunded"})
_REFUND_WINDOW = timedelta(days=30)


def _utcnow():
    return datetime.now(timezone.utc)


def _required_text(label, value):
    """Reject non-strings and empty or whitespace-only strings."""
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{label} must be a non-empty string")
    return value.strip()


class Order:
    """A customer order.

    `items` is a list of (sku, quantity, unit_price_cents) tuples. `clock` is a
    zero-argument callable returning the current datetime; every timestamp the
    order records comes from it.
    """

    def __init__(self, order_id, items, clock=None):
        self.order_id = order_id
        self.items = list(items)
        self.status = "pending"
        self.tracking_number = None
        self.cancel_reason = None
        self.delivered_at = None
        self.history = []
        self._clock = _utcnow if clock is None else clock

    def total_cents(self):
        return sum(quantity * price for _sku, quantity, price in self.items)

    @property
    def is_terminal(self):
        return self.status in _TERMINAL_STATUSES

    def can(self, event):
        """Whether `event` is allowed right now, ignoring ship/cancel arguments."""
        return self._next_state(event) is not None

    def allowed_events(self):
        """The event names allowed right now, sorted alphabetically."""
        return sorted(
            event
            for event, from_state in _TRANSITIONS
            if from_state == self.status and self.can(event)
        )

    # Each lifecycle method checks the transition table first (InvalidTransition),
    # then its arguments (ValueError). A call that raises changes nothing.

    def pay(self):
        self._fire("pay")

    def pack(self):
        self._fire("pack")

    def ship(self, tracking_number):
        to_state = self._require_transition("ship")
        tracking_number = _required_text("tracking number", tracking_number)
        self._commit("ship", to_state, tracking_number=tracking_number)

    def deliver(self):
        self._fire("deliver")

    def cancel(self, reason):
        to_state = self._require_transition("cancel")
        reason = _required_text("reason", reason)
        self._commit("cancel", to_state, cancel_reason=reason)

    def refund(self):
        self._fire("refund")

    def _next_state(self, event):
        """The status `event` would move to, or None if it is not allowed."""
        to_state = _TRANSITIONS.get((event, self.status))
        if (
            to_state is not None
            and event == "refund"
            and self.status == "delivered"
            and self._clock() - self.delivered_at > _REFUND_WINDOW
        ):
            return None
        return to_state

    def _require_transition(self, event):
        to_state = self._next_state(event)
        if to_state is None:
            raise InvalidTransition(self.status, event)
        return to_state

    def _fire(self, event):
        self._commit(event, self._require_transition(event))

    def _commit(self, event, to_state, **attributes):
        # Everything that can raise happens before the first mutation.
        at = self._clock()
        if event == "deliver":
            self.delivered_at = at
        for name, value in attributes.items():
            setattr(self, name, value)
        self.history.append(Transition(event, self.status, to_state, at))
        self.status = to_state
