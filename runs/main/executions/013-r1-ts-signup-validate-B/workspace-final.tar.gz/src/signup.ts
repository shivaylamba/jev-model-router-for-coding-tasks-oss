// Sign-up validation. Rules: docs/signup-rules.md
import { daysInMonth, isLeapYear } from "./dates.ts";
import type { SignupErrors, SignupInput, SignupResult, SignupValue } from "./types.ts";

export type { SignupErrors, SignupInput, SignupResult } from "./types.ts";

/** A calendar date as [year, month (1-12), day]. */
type CalendarDate = [year: number, month: number, day: number];

const USERNAME_PATTERN = /^[A-Za-z][A-Za-z0-9_]*$/;
const BIRTH_DATE_PATTERN = /^(\d{4})-(\d{2})-(\d{2})$/;

/** The UTC calendar date of `today`; only that matters, never its time of day. */
function utcCalendarDate(today: Date): CalendarDate {
  return [today.getUTCFullYear(), today.getUTCMonth() + 1, today.getUTCDate()];
}

/** Whether `a` falls strictly after `b` on the calendar. */
function isAfter(a: CalendarDate, b: CalendarDate): boolean {
  return a[0] > b[0] || (a[0] === b[0] && (a[1] > b[1] || (a[1] === b[1] && a[2] > b[2])));
}

/** The birthday `years` years after `birth`. A Feb 29 birthday is held on
 * Mar 1 in non-leap years. */
function birthday(birth: CalendarDate, years: number): CalendarDate {
  const [year, month, day] = birth;
  const target = year + years;
  return month === 2 && day === 29 && !isLeapYear(target) ? [target, 3, 1] : [target, month, day];
}

/** Whether the trimmed email has no whitespace, exactly one `@`, a non-empty
 * local part, and a domain of at least two non-empty `.`-separated labels. */
function hasValidEmailFormat(email: string): boolean {
  if (/\s/.test(email)) return false;
  const parts = email.split("@");
  if (parts.length !== 2) return false;
  const [local, domain] = parts;
  if (local === "") return false;
  const labels = domain.split(".");
  return labels.length >= 2 && labels.every((label) => label !== "");
}

/** Parse a trimmed `YYYY-MM-DD` string into a real calendar date from 1900 on. */
function parseBirthDate(birthDate: string): CalendarDate | null {
  const match = BIRTH_DATE_PATTERN.exec(birthDate);
  if (match === null) return null;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  if (year < 1900 || month < 1 || month > 12 || day < 1 || day > daysInMonth(year, month)) {
    return null;
  }
  return [year, month, day];
}

export function validateSignup(input: SignupInput, today: Date): SignupResult {
  const errors: SignupErrors = {};
  const value: Partial<SignupValue> = {};
  const now = utcCalendarDate(today);

  // username: required, length, format.
  const username = typeof input.username === "string" ? input.username.trim() : undefined;
  let usernameValid = false;
  if (username === undefined || username === "") {
    errors.username = "required";
  } else if (username.length < 3 || username.length > 20) {
    errors.username = "length";
  } else if (!USERNAME_PATTERN.test(username)) {
    errors.username = "format";
  } else {
    value.username = username.toLowerCase();
    usernameValid = true;
  }

  // email: required, format.
  const email = typeof input.email === "string" ? input.email.trim() : undefined;
  if (email === undefined || email === "") {
    errors.email = "required";
  } else if (!hasValidEmailFormat(email)) {
    errors.email = "format";
  } else {
    value.email = email.toLowerCase();
  }

  // password: required, length, weak, contains_username. Never trimmed.
  const password = typeof input.password === "string" ? input.password : undefined;
  if (password === undefined || password === "") {
    errors.password = "required";
  } else if (password.length < 8 || password.length > 64) {
    errors.password = "length";
  } else if (!/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) {
    errors.password = "weak";
  } else if (usernameValid && password.toLowerCase().includes(username.toLowerCase())) {
    errors.password = "contains_username";
  }

  // confirmPassword: required, mismatch. Never trimmed. Mismatch is checked
  // even when password has its own error, but not when password is missing or
  // not a string.
  const confirmPassword =
    typeof input.confirmPassword === "string" ? input.confirmPassword : undefined;
  if (confirmPassword === undefined || confirmPassword === "") {
    errors.confirmPassword = "required";
  } else if (password !== undefined && confirmPassword !== password) {
    errors.confirmPassword = "mismatch";
  }

  // birthDate: required, format, future, too_young.
  const birthDate = typeof input.birthDate === "string" ? input.birthDate.trim() : undefined;
  if (birthDate === undefined || birthDate === "") {
    errors.birthDate = "required";
  } else {
    const birth = parseBirthDate(birthDate);
    if (birth === null) {
      errors.birthDate = "format";
    } else if (isAfter(birth, now)) {
      errors.birthDate = "future";
    } else if (isAfter(birthday(birth, 13), now)) {
      errors.birthDate = "too_young";
    } else {
      value.birthDate = birthDate;
    }
  }

  if (Object.keys(errors).length > 0) {
    return { ok: false, errors };
  }
  // Every field passed, so the normalized values are all set.
  return { ok: true, value: value as SignupValue };
}
