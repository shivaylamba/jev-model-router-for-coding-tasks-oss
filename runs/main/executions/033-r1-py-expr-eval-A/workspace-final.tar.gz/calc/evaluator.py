"""Evaluator for parsed formulas (see SPEC.md, "Evaluation").

Evaluation runs left to right: the left operand of a binary operator is
evaluated before the right one, and call arguments in order. The first
error met in that order is the one raised.
"""

import math

from calc.ast_nodes import Binary, Call, Name, Number, Unary
from calc.errors import ExprError
from calc.functions import CONSTANTS, FUNCTIONS, arity_ok


def evaluate_node(node, variables):
    if isinstance(node, Number):
        return node.value
    if isinstance(node, Name):
        return _lookup_name(node, variables)
    if isinstance(node, Unary):
        value = evaluate_node(node.operand, variables)
        return -value if node.op == "-" else value
    if isinstance(node, Call):
        return _evaluate_call(node, variables)
    if isinstance(node, Binary):
        return _evaluate_binary(node, variables)
    raise TypeError(f"unknown node {node!r}")


def _lookup_name(node, variables):
    if variables is not None and node.name in variables:
        return float(variables[node.name])
    if node.name in CONSTANTS:
        return float(CONSTANTS[node.name])
    raise ExprError(f"unknown name {node.name!r}", node.position)


def _evaluate_call(node, variables):
    entry = FUNCTIONS.get(node.name)
    if entry is None:
        raise ExprError(f"unknown function {node.name!r}", node.position)
    if not arity_ok(node.name, len(node.args)):
        low, high, _ = entry
        expected = f"{low}" if high == low else f"{low} to {high or 'unlimited'}"
        raise ExprError(
            f"function {node.name!r} takes {expected} argument(s), "
            f"got {len(node.args)}",
            node.position,
        )
    args = [evaluate_node(arg, variables) for arg in node.args]
    try:
        result = entry[2](*args)
    except ExprError:
        raise
    except (ValueError, OverflowError, ZeroDivisionError) as exc:
        raise ExprError(
            f"function {node.name!r} failed: {exc}", node.position
        ) from exc
    return float(result)


def _evaluate_binary(node, variables):
    left = evaluate_node(node.left, variables)
    right = evaluate_node(node.right, variables)
    if node.op == "+":
        return left + right
    if node.op == "-":
        return left - right
    if node.op == "*":
        return left * right
    if node.op == "/":
        if right == 0:
            raise ExprError("division by zero", node.position)
        return left / right
    if node.op == "%":
        if right == 0:
            raise ExprError("modulo by zero", node.position)
        return left % right
    if node.op == "^":
        return _evaluate_power(left, right, node.position)
    raise TypeError(f"unknown operator {node.op!r}")


def _evaluate_power(base, exponent, position):
    """`base ** exponent`, raising ExprError if the result is not a finite
    real number (e.g. 0^-1, (-8)^(1/3), 10^400)."""
    try:
        result = base**exponent
    except (ZeroDivisionError, OverflowError) as exc:
        raise ExprError(f"invalid power: {exc}", position) from exc
    if isinstance(result, complex) or not math.isfinite(result):
        raise ExprError("power result is not a finite real number", position)
    return result
