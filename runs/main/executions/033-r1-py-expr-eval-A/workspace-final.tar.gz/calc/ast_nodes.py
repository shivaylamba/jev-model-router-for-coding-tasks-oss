"""AST node definitions for parsed formulas."""


class Number:
    __slots__ = ("value", "position")

    def __init__(self, value, position):
        self.value = value
        self.position = position


class Name:
    __slots__ = ("name", "position")

    def __init__(self, name, position):
        self.name = name
        self.position = position


class Call:
    __slots__ = ("name", "args", "position")

    def __init__(self, name, args, position):
        self.name = name
        self.args = args
        self.position = position  # position of the function name


class Unary:
    __slots__ = ("op", "operand", "position")

    def __init__(self, op, operand, position):
        self.op = op
        self.operand = operand
        self.position = position


class Binary:
    __slots__ = ("op", "left", "right", "position")

    def __init__(self, op, left, right, position):
        self.op = op
        self.left = left
        self.right = right
        self.position = position  # position of the operator
