"""Tokenizer for the formula language (see SPEC.md, "Tokens")."""

from calc.errors import ExprError

# Token kinds
NUMBER = "number"
NAME = "name"
OP = "op"
LPAREN = "lparen"
RPAREN = "rparen"
COMMA = "comma"
END = "end"

_OPERATOR_CHARS = "+-*/%^"


class Token:
    """One lexical token with its 0-based start position in the formula."""

    __slots__ = ("kind", "value", "position")

    def __init__(self, kind, value, position):
        self.kind = kind
        self.value = value
        self.position = position

    def __repr__(self):
        return f"Token({self.kind}, {self.value!r}, {self.position})"


def tokenize(expr):
    """Split `expr` into a list of tokens, ending with an END token.

    The END token's position is len(expr). Any character that is not part
    of the language raises ExprError at that character's position.
    """
    tokens = []
    i = 0
    n = len(expr)
    while i < n:
        ch = expr[i]
        if ch in " \t":
            i += 1
        elif ch.isdigit() or (ch == "." and i + 1 < n and expr[i + 1].isdigit()):
            i = _scan_number(expr, i, tokens)
        elif ch.isalpha() or ch == "_":
            start = i
            i += 1
            while i < n and (expr[i].isalnum() or expr[i] == "_"):
                i += 1
            tokens.append(Token(NAME, expr[start:i], start))
        elif ch in _OPERATOR_CHARS:
            tokens.append(Token(OP, ch, i))
            i += 1
        elif ch == "(":
            tokens.append(Token(LPAREN, ch, i))
            i += 1
        elif ch == ")":
            tokens.append(Token(RPAREN, ch, i))
            i += 1
        elif ch == ",":
            tokens.append(Token(COMMA, ch, i))
            i += 1
        else:
            raise ExprError(f"unexpected character {ch!r}", i)
    tokens.append(Token(END, None, n))
    return tokens


def _scan_number(expr, start, tokens):
    """Scan one number token starting at `start`; return the next index.

    A trailing `.` without digits is not consumed (`5.` is `5` then an
    unexpected `.`). An `e` not followed by digits (after an optional
    sign) is not part of the number (`2e` is `2` then the name `e`).
    """
    n = len(expr)
    i = start
    while i < n and expr[i].isdigit():
        i += 1
    if i < n and expr[i] == "." and i + 1 < n and expr[i + 1].isdigit():
        i += 1
        while i < n and expr[i].isdigit():
            i += 1
    if i < n and expr[i] in "eE":
        j = i + 1
        if j < n and expr[j] in "+-":
            j += 1
        if j < n and expr[j].isdigit():
            j += 1
            while j < n and expr[j].isdigit():
                j += 1
            i = j
    tokens.append(Token(NUMBER, float(expr[start:i]), start))
    return i
