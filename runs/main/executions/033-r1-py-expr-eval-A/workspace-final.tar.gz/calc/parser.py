"""Parser for the formula language (see SPEC.md, "Grammar and precedence").

Precedence, lowest to highest: binary `+ -`, then `* / %`, then prefix
unary `- +`, then `^`. `^` is right-associative and binds more tightly
than unary, so `-2^2` is `-(2^2)`; the right operand of `^` is a unary
expression, so `2^-1` is 0.5.
"""

from calc.ast_nodes import Binary, Call, Name, Number, Unary
from calc.errors import ExprError
from calc.tokens import COMMA, END, LPAREN, NAME, NUMBER, OP, RPAREN

_PREFIX_OPS = "+-"


class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.index = 0

    def peek(self):
        return self.tokens[self.index]

    def advance(self):
        token = self.tokens[self.index]
        self.index += 1
        return token

    def expect_operand(self):
        """Raise because the current token cannot start an operand."""
        token = self.peek()
        if token.kind == END:
            raise ExprError("expected an operand, found end of input", token.position)
        raise ExprError(
            f"expected an operand, found {token.value!r}", token.position
        )

    def parse_formula(self):
        """Parse a complete formula; the next token must be end of input."""
        node = self.parse_additive()
        token = self.peek()
        if token.kind != END:
            if token.kind in (NUMBER, NAME, LPAREN):
                raise ExprError("two operands in a row", token.position)
            if token.kind == RPAREN:
                raise ExprError("unexpected ')'", token.position)
            if token.kind == COMMA:
                raise ExprError("comma outside a function call", token.position)
            raise ExprError(f"unexpected {token.value!r}", token.position)
        return node

    def parse_additive(self):
        node = self.parse_multiplicative()
        while True:
            token = self.peek()
            if token.kind == OP and token.value in ("+", "-"):
                self.advance()
                right = self.parse_multiplicative()
                node = Binary(token.value, node, right, token.position)
            else:
                return node

    def parse_multiplicative(self):
        node = self.parse_unary()
        while True:
            token = self.peek()
            if token.kind == OP and token.value in ("*", "/", "%"):
                self.advance()
                right = self.parse_unary()
                node = Binary(token.value, node, right, token.position)
            else:
                return node

    def parse_unary(self):
        token = self.peek()
        if token.kind == OP and token.value in _PREFIX_OPS:
            self.advance()
            operand = self.parse_unary()
            return Unary(token.value, operand, token.position)
        return self.parse_power()

    def parse_power(self):
        base = self.parse_primary()
        token = self.peek()
        if token.kind == OP and token.value == "^":
            self.advance()
            exponent = self.parse_unary()  # right-associative, allows 2^-1
            return Binary("^", base, exponent, token.position)
        return base

    def parse_primary(self):
        token = self.peek()
        if token.kind == NUMBER:
            self.advance()
            return Number(token.value, token.position)
        if token.kind == NAME:
            self.advance()
            if self.peek().kind == LPAREN:
                self.advance()
                args = self.parse_arguments(token)
                return Call(token.value, args, token.position)
            return Name(token.value, token.position)
        if token.kind == LPAREN:
            self.advance()
            node = self.parse_additive()
            closing = self.peek()
            if closing.kind != RPAREN:
                if closing.kind == END:
                    raise ExprError(
                        "expected ')', found end of input", closing.position
                    )
                if closing.kind in (NUMBER, NAME, LPAREN):
                    raise ExprError("two operands in a row", closing.position)
                raise ExprError(
                    f"expected ')', found {closing.value!r}", closing.position
                )
            self.advance()
            return node
        self.expect_operand()

    def parse_arguments(self, name_token):
        """Parse the argument list after `(`; the RPAREN is consumed."""
        args = []
        if self.peek().kind == RPAREN:
            self.advance()
            return args
        while True:
            if self.peek().kind in (COMMA, RPAREN, END):
                self.expect_operand()
            args.append(self.parse_additive())
            token = self.peek()
            if token.kind == COMMA:
                self.advance()
                continue
            if token.kind == RPAREN:
                self.advance()
                return args
            if token.kind == END:
                raise ExprError("expected ')', found end of input", token.position)
            if token.kind in (NUMBER, NAME, LPAREN):
                raise ExprError("two operands in a row", token.position)
            raise ExprError(f"expected ',' or ')', found {token.value!r}", token.position)


def parse(tokens):
    """Parse the token list into an AST (raises ExprError on syntax errors)."""
    return Parser(tokens).parse_formula()
