import math
import unittest

import calc
from calc.errors import ExprError


class ValueTest(unittest.TestCase):
    def test_precedence(self):
        self.assertEqual(calc.evaluate("1 + 2 * 3"), 7.0)
        self.assertEqual(calc.evaluate("-2^2"), -4.0)
        self.assertEqual(calc.evaluate("2^-1"), 0.5)
        self.assertEqual(calc.evaluate("-2^-2"), -0.25)
        self.assertEqual(calc.evaluate("2^3^2"), 512.0)
        self.assertEqual(calc.evaluate("--2"), 2.0)
        self.assertEqual(calc.evaluate("-7 % 3"), 2.0)

    def test_numbers(self):
        self.assertEqual(calc.evaluate("12"), 12.0)
        self.assertEqual(calc.evaluate("3.5"), 3.5)
        self.assertEqual(calc.evaluate(".5"), 0.5)
        self.assertEqual(calc.evaluate("1e3"), 1000.0)
        self.assertEqual(calc.evaluate("2.5E-2"), 0.025)

    def test_variables_and_constants(self):
        self.assertEqual(calc.evaluate("x * 2", {"x": 3}), 6.0)
        self.assertAlmostEqual(calc.evaluate("pi"), math.pi)
        self.assertAlmostEqual(calc.evaluate("e"), math.e)
        self.assertEqual(calc.evaluate("pi", {"pi": 3}), 3.0)

    def test_functions(self):
        self.assertEqual(calc.evaluate("abs(-3)"), 3.0)
        self.assertEqual(calc.evaluate("sqrt(9)"), 3.0)
        self.assertEqual(calc.evaluate("min(3, 1, 2)"), 1.0)
        self.assertEqual(calc.evaluate("max(3, 1, 2)"), 3.0)
        self.assertEqual(calc.evaluate("round(2.7)"), 3.0)
        self.assertEqual(calc.evaluate("hypot(3, 4)"), 5.0)

    def test_returns_float(self):
        self.assertIsInstance(calc.evaluate("2"), float)


class SyntaxErrorTest(unittest.TestCase):
    def assert_pos(self, expr, position):
        with self.assertRaises(ExprError) as ctx:
            calc.evaluate(expr)
        self.assertEqual(ctx.exception.position, position)

    def test_spec_table(self):
        self.assert_pos("", 0)
        self.assert_pos("   ", 3)
        self.assert_pos("1 +", 3)
        self.assert_pos("(1 + 2", 6)
        self.assert_pos("1 + 2)", 5)
        self.assert_pos("2 3", 2)
        self.assert_pos("2x", 1)
        self.assert_pos("1 * * 2", 4)
        self.assert_pos("min(1,)", 6)
        self.assert_pos("1, 2", 1)
        self.assert_pos("3 $ 4", 2)

    def test_extra(self):
        self.assert_pos("5.", 1)
        self.assert_pos("2e", 1)


class EvalErrorTest(unittest.TestCase):
    def test_unknown_name(self):
        with self.assertRaises(ExprError) as ctx:
            calc.evaluate("foo")
        self.assertEqual(ctx.exception.position, 0)

    def test_unknown_function(self):
        with self.assertRaises(ExprError) as ctx:
            calc.evaluate("foo(1)")
        self.assertEqual(ctx.exception.position, 0)

    def test_arity(self):
        with self.assertRaises(ExprError) as ctx:
            calc.evaluate("abs(1, 2)")
        self.assertEqual(ctx.exception.position, 0)
        with self.assertRaises(ExprError) as ctx:
            calc.evaluate("sqrt()")
        self.assertEqual(ctx.exception.position, 0)

    def test_division_by_zero(self):
        with self.assertRaises(ExprError) as ctx:
            calc.evaluate("1 / 0")
        self.assertEqual(ctx.exception.position, 2)
        with self.assertRaises(ExprError) as ctx:
            calc.evaluate("1 % 0")
        self.assertEqual(ctx.exception.position, 2)

    def test_bad_powers(self):
        with self.assertRaises(ExprError) as ctx:
            calc.evaluate("0 ^ -1")
        self.assertEqual(ctx.exception.position, 2)
        with self.assertRaises(ExprError) as ctx:
            calc.evaluate("(-8) ^ (1/3)")
        self.assertEqual(ctx.exception.position, 5)
        with self.assertRaises(ExprError) as ctx:
            calc.evaluate("10 ^ 400")
        self.assertEqual(ctx.exception.position, 3)

    def test_failing_function_at_name(self):
        with self.assertRaises(ExprError) as ctx:
            calc.evaluate("1 + sqrt(-1)")
        self.assertEqual(ctx.exception.position, 4)

    def test_evaluation_order(self):
        # Left side evaluated first: 1/0 wins over sqrt(-1)
        with self.assertRaises(ExprError) as ctx:
            calc.evaluate("1/0 + sqrt(-1)")
        self.assertEqual(ctx.exception.position, 1)


if __name__ == "__main__":
    unittest.main()
