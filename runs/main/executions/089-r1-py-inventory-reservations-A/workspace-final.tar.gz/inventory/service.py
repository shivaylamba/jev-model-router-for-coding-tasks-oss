"""Reservation service used by checkout."""

from collections import defaultdict

from .errors import (HoldExpiredError, HoldNotFoundError, HoldStateError,
                     IdempotencyConflictError, InsufficientStockError)
from .holds import HoldStore


class ReservationService:
    def __init__(self, ledger, clock, hold_ttl=900):
        self._ledger = ledger
        self._clock = clock
        self._ttl = hold_ttl
        self._holds = HoldStore()
        self._reserved = defaultdict(int)

    def _expire_stale_holds(self):
        """Lazily flip any ``"held"`` hold whose time is up to ``"expired"``.

        Expiry should be observable the instant the clock reaches the hold's
        expiry — no background sweep required — so every read path goes
        through this.
        """
        now = self._clock.now()
        changed = False
        for hold in self._holds.all():
            if hold.status == "held" and hold.is_expired(now):
                hold.status = "expired"
                changed = True
        if changed:
            self._sync_reserved()
        return changed

    def _sync_reserved(self):
        """Rebuild reserved counters from the hold statuses in the store.

        Keeping the counters derived (rather than maintained incrementally)
        means they can never drift, no matter how many times a hold is
        touched after it has left the ``"held"`` state.
        """
        self._reserved.clear()
        for hold in self._holds.all():
            if hold.status == "held":
                self._reserved[hold.sku] += hold.quantity

    def available(self, sku):
        self._expire_stale_holds()
        return self._ledger.on_hand(sku) - self._reserved[sku]

    def reserve(self, sku, quantity, request_id):
        if not isinstance(quantity, int) or isinstance(quantity, bool) or quantity < 1:
            raise ValueError("quantity must be a positive integer")
        if not isinstance(request_id, str) or not request_id:
            raise ValueError("request_id must be a non-empty string")
        existing = self._holds.by_request(request_id)
        if existing is not None:
            if (existing.sku, existing.quantity) != (sku, quantity):
                raise IdempotencyConflictError(request_id)
            self._expire_stale_holds()
            return existing
        if quantity > self.available(sku):
            raise InsufficientStockError(f"only {self.available(sku)} of {sku} available")
        now = self._clock.now()
        hold = self._holds.create(sku, quantity, request_id, now, now + self._ttl)
        self._reserved[sku] += quantity
        return hold

    def get_hold(self, hold_id):
        hold = self._holds.get(hold_id)
        if hold is None:
            raise HoldNotFoundError(hold_id)
        self._expire_stale_holds()
        return hold

    def release(self, hold_id):
        hold = self.get_hold(hold_id)
        if hold.status == "held":
            hold.status = "released"
            self._sync_reserved()
            return True
        if hold.status == "confirmed":
            raise HoldStateError(f"hold {hold_id} was already confirmed")
        # Already "released" or "expired" — nothing changes.
        return False

    def confirm(self, hold_id):
        hold = self.get_hold(hold_id)
        if hold.status == "held":
            self._ledger.remove(hold.sku, hold.quantity)
            hold.status = "confirmed"
            self._sync_reserved()
            return hold
        if hold.status == "confirmed":
            # Double click on "Pay" is safe — the stock was already taken.
            return hold
        if hold.status == "expired":
            raise HoldExpiredError(f"hold {hold_id} has expired")
        raise HoldStateError(f"hold {hold_id} was released")

    def sweep_expired(self):
        """Mark expired holds and give their units back. Run by the nightly cleanup job."""
        now = self._clock.now()
        marked = 0
        for hold in self._holds.all():
            if hold.status == "held" and hold.is_expired(now):
                hold.status = "expired"
                marked += 1
        if marked:
            self._sync_reserved()
        return marked
