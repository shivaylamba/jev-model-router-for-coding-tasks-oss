"""List helpers."""


def flatten(nested):
    """Flatten one level of nesting: [[1, 2], [3]] -> [1, 2, 3]."""
    return [item for group in nested for item in group]


def chunk_evenly(items, n):
    """Split items into n consecutive chunks, longer chunks first.

    chunk_evenly([1, 2, 3, 4, 5], 3) -> [[1, 2], [3, 4], [5]]
    Extra chunks are empty lists when n exceeds len(items).
    """
    if n < 1:
        raise ValueError("n must be at least 1")
    base, extra = divmod(len(items), n)
    chunks = []
    start = 0
    for i in range(n):
        size = base + (1 if i < extra else 0)
        chunks.append(items[start:start + size])
        start += size
    return chunks
