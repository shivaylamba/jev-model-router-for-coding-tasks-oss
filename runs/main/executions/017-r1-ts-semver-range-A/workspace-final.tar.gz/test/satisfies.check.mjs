import { satisfies } from "../src/semver.ts";

const cases = [
  ["1.4.0", "^1.2.3", true],
  ["0.3.0", "^0.2.3", false],
  ["2.3.9", "1.2.3 - 2.3", true],
  ["1.3.0", ">1.2", true],
  ["1.2.9", ">1.2", false],
  ["1.2.5", "1.2", true],
  ["1.3.0", "1.2", false],
  ["1.9.9", "1", true],
  ["2.0.0", "1", false],
  ["0.2.9", "^0.2", true],
  ["0.3.0", "^0.2", false],
  ["0.0.4", "~0.0.3", false],
  ["0.0.3", "~0.0.3", true],
  ["1.9.9", "~1", true],
  ["2.0.0", "~1", false],
  ["1.2.0", "~1.2", true],
  ["1.3.0", "~1.2", false],
  ["1.0.0", "^0", false],
  ["0.9.9", "^0", true],
  ["1.9.9", "^1", true],
  ["0.3.9", "<=1.2", true],
  ["1.3.0", "<=1.2", false],
  ["1.2.0", "<1.2", false],
  ["1.1.9", "<1.2", true],
  ["1.2.3", "<=*", true],
  ["1.2.3", ">*", false],
  ["1.2.3", "<*", false],
  ["1.2.3", "~*", true],
  ["1.2.3", "^*", true],
  ["2.0.0", ">=*", true],
  ["5.5.5", ">=1.0.0 <2.0.0", false],
  ["1.5.0", ">=1.0.0 <2.0.0", true],
  ["2.3.0", "1.2 - 2.3", true],
  ["2.4.0", "1.2 - 2.3", false],
  ["1.2.0", "1.2 - 2.3", true],
  ["0.9.0", "1.2 - 2.3", false],
  ["3.0.0", "1.2 - 2", false],
  ["2.9.9", "1.2 - 2", true],
  ["1.2.3", "1.2.3 - 2.3.4", true],
  ["2.3.4", "1.2.3 - 2.3.4", true],
  ["2.3.5", "1.2.3 - 2.3.4", false],
  ["1.2.2", "1.2.3 - 2.3.4", false],
  ["9.9.9", "* - 2.0", true],
  ["0.0.1", "2.0 - *", false],
  ["2.0.0", "2.0 - *", true],
  ["1.0.0", "", true],
  ["2.5.0", "1.0.0 || 2.0.0 - 3.0.0", true],
  ["1.5.0", "1.0.0 || 2.0.0 - 3.0.0", false],
  ["1.0.0", "1.0.0 || 2.0.0 - 3.0.0", true],
  ["1.2.3", ">= 1.2.3", true],
  ["1.0.0", "  1.x  ||  2.x  ", true],
  ["1.2.3", "=1.2.3", true],
  ["1.2.3", "=1.2", true],
  ["v1.2.3", "1.2.3", true],
  ["1.2.3", "v1.2.3", true],
  ["1.2.3", "1.X.x", true],
];

const bad = [
  ["1.2", "1.2.3"],
  ["1.2.3-rc.1", "*"],
  ["1.2.3", ">=1.2.3.4"],
  ["1.2.3", "~>1.2"],
  ["1.2.3", "1.2.3 -"],
  ["1.2.3", ">="],
  ["1.2.3", "1.x.3"],
  ["1.2.3", "01.2.3"],
  ["1.2.3", "1.2.3-beta"],
  ["1.2.3", "abc"],
  ["1.2.3", "1.2.3 - 2.0.0 - 3.0.0"],
  ["1.2.3", "~"],
  ["1.2.3", "^"],
  ["1.2.3", "="],
  ["1.2.3", ">1.2.3 - 2.0.0"],
  ["1.2.3", "1.2.3 - >2.0.0"],
];

let fails = 0;
for (const [v, r, expected] of cases) {
  let got;
  try { got = satisfies(v, r); } catch (e) { got = "THREW " + e.message; }
  if (got !== expected) {
    console.log(`FAIL satisfies(${JSON.stringify(v)}, ${JSON.stringify(r)}) = ${got}, expected ${expected}`);
    fails++;
  }
}
for (const [v, r] of bad) {
  let threw = false;
  try { satisfies(v, r); } catch (e) { threw = e instanceof TypeError; }
  if (!threw) {
    console.log(`FAIL expected TypeError: satisfies(${JSON.stringify(v)}, ${JSON.stringify(r)})`);
    fails++;
  }
}
console.log(fails === 0 ? `ALL ${cases.length + bad.length} CHECKS PASSED` : `${fails} FAILURES`);
