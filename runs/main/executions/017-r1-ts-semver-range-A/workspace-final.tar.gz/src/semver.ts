export type Version = { major: number; minor: number; patch: number };

const VERSION_PATTERN = /^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/;

/**
 * Parse a release version "MAJOR.MINOR.PATCH" (an optional leading "v" is
 * allowed). Throws a TypeError for anything else, including prerelease or
 * build suffixes and numbers with leading zeros.
 */
export function parseVersion(text: string): Version {
  const match = VERSION_PATTERN.exec(text.trim());
  if (!match) {
    throw new TypeError(`invalid version: ${JSON.stringify(text)}`);
  }
  return { major: Number(match[1]), minor: Number(match[2]), patch: Number(match[3]) };
}

/** Compare two versions: negative if a < b, zero if equal, positive if a > b. */
export function compareVersions(a: Version | string, b: Version | string): number {
  const left = typeof a === "string" ? parseVersion(a) : a;
  const right = typeof b === "string" ? parseVersion(b) : b;
  return left.major - right.major || left.minor - right.minor || left.patch - right.patch;
}

/* ------------------------------------------------------------------ */
/* Range parsing (see docs/RANGES.md).                                */
/* ------------------------------------------------------------------ */

const WILDCARDS = new Set(["x", "X", "*"]);
const PART_PATTERN = /^(0|[1-9]\d*|[xX*])$/;
const OPERATORS = ["=", "<=", ">=", "<", ">", "~", "^"] as const;

type ComparatorOp = (typeof OPERATORS)[number];

/** A partial version: up to three parts, each a number or wildcard. */
type PartialVersion = {
  parts: number[]; // numeric parts before the first wildcard
};

/** Inclusive-on-v semantics: predicate over a parsed version. */
type Predicate = (v: Version) => boolean;

function invalidRange(range: string): TypeError {
  return new TypeError(`invalid range: ${JSON.stringify(range)}`);
}

/**
 * Parse a partial version ("1", "1.2", "1.x.x", "v2"). Returns the numeric
 * parts that appear before the first wildcard. Throws a TypeError if the
 * grammar in docs/RANGES.md is violated (bad part, wildcard before a number,
 * more than three parts, ...).
 */
function parsePartialVersion(text: string, range: string): PartialVersion {
  let body = text;
  if (body.startsWith("v")) {
    body = body.slice(1);
  }
  const rawParts = body.split(".");
  if (rawParts.length > 3) {
    throw invalidRange(range);
  }
  const parts: number[] = [];
  let sawWildcard = false;
  for (const raw of rawParts) {
    if (!PART_PATTERN.test(raw)) {
      throw invalidRange(range);
    }
    if (WILDCARDS.has(raw)) {
      sawWildcard = true;
    } else {
      if (sawWildcard) {
        // e.g. "1.x.3": a numeric part after a wildcard is not allowed.
        throw invalidRange(range);
      }
      parts.push(Number(raw));
    }
  }
  return { parts };
}

/** Duplicate of compareVersions for parsed partials padded with zeros. */
function compareParts(left: number[], right: number[]): number {
  const a = [left[0] ?? 0, left[1] ?? 0, left[2] ?? 0];
  const b = [right[0] ?? 0, right[1] ?? 0, right[2] ?? 0];
  return a[0] - b[0] || a[1] - b[1] || a[2] - b[2];
}

/**
 * Build the predicate for one comparator. The semantics follow
 * docs/RANGES.md: every comparator desugars to a conjunction over the
 * version's numeric parts.
 */
function buildComparatorPredicate(op: ComparatorOp | "", partial: PartialVersion): Predicate {
  const parts = partial.parts;
  const n = parts.length;

  // "*"/"x" alone (no numeric parts): any version for most operators,
  // nothing for strict inequalities.
  if (n === 0) {
    if (op === ">" || op === "<") {
      return () => false;
    }
    return () => true;
  }

  // "1.2.3"-style exact equality (with "=" or no operator).
  if ((op === "" || op === "=") && n === 3) {
    return (v) => v.major === parts[0] && v.minor === parts[1] && v.patch === parts[2];
  }
  // "1.2" / "1" bare or with "=": same as >=low <high of the covered span.
  if (op === "" || op === "=") {
    const low = parts;
    const high = [...parts.slice(0, n - 1), parts[n - 1] + 1];
    return (v) => compareParts(versionToParts(v), low) >= 0 && compareParts(versionToParts(v), high) < 0;
  }

  switch (op) {
    case ">": {
      // >1.2.3: strictly greater; >1.2 / >1: greater than everything covered.
      if (n === 3) {
        return (v) => compareParts(versionToParts(v), parts) > 0;
      }
      const bound = [...parts.slice(0, n - 1), parts[n - 1] + 1];
      return (v) => compareParts(versionToParts(v), bound) >= 0;
    }
    case ">=": {
      return (v) => compareParts(versionToParts(v), parts) >= 0;
    }
    case "<": {
      return (v) => compareParts(versionToParts(v), parts) < 0;
    }
    case "<=": {
      // <=1.2.3: up to and including; <=1.2 / <=1: everything covered.
      const bound = n === 3 ? parts : [...parts.slice(0, n - 1), parts[n - 1] + 1];
      return (v) => {
        const cmp = compareParts(versionToParts(v), bound);
        return n === 3 ? cmp <= 0 : cmp < 0;
      };
    }
    case "~": {
      const low = parts;
      // ~1.2.3 / ~1.2 -> <1.3.0; ~1 -> <2.0.0
      const high = n === 1 ? [parts[0] + 1] : [parts[0], parts[1] + 1];
      return (v) => compareParts(versionToParts(v), low) >= 0 && compareParts(versionToParts(v), high) < 0;
    }
    case "^": {
      const low = parts;
      // ^ allows changes that do not modify the left-most non-zero part.
      let high: number[];
      const firstNonZero = parts.findIndex((p) => p !== 0);
      if (firstNonZero === -1) {
        // ^0 / ^0.0 / ^0.0.0: bump the next part after the given zeros.
        if (n === 1) high = [1];
        else if (n === 2) high = [0, 1];
        else high = [0, 0, parts[2] + 1];
      } else if (firstNonZero === 0) {
        high = [parts[0] + 1];
      } else if (firstNonZero === 1) {
        high = [0, parts[1] + 1];
      } else {
        high = [0, 0, parts[2] + 1];
      }
      return (v) => compareParts(versionToParts(v), low) >= 0 && compareParts(versionToParts(v), high) < 0;
    }
    default:
      return () => false;
  }
}

function versionToParts(v: Version): number[] {
  return [v.major, v.minor, v.patch];
}

/**
 * Parse one comparator token, e.g. ">=1.2.3", "^0.2", "~", "v1.2.3".
 * Returns a predicate. Throws TypeError for malformed tokens.
 */
function parseComparatorToken(token: string, range: string): Predicate {
  let op: ComparatorOp | "" = "";
  let rest = token;
  for (const candidate of OPERATORS) {
    if (candidate !== "=" && rest.startsWith(candidate)) {
      op = candidate;
      rest = rest.slice(candidate.length);
      break;
    }
  }
  if (op === "" && rest.startsWith("=")) {
    op = "=";
    rest = rest.slice(1);
  }
  if (rest === "") {
    throw invalidRange(range);
  }
  // "~" or "^" alone is invalid; "=" alone is invalid too.
  if ((op === "~" || op === "^" || op === "=") && rest === "") {
    throw invalidRange(range);
  }
  const partial = parsePartialVersion(rest, range);
  return buildComparatorPredicate(op, partial);
}

/** Split "A - B" hyphen ranges (whitespace required around the dash). */
const HYPHEN_SPLIT = /\s+-\s+/;

function parseAlternative(alternative: string, range: string): Predicate {
  const trimmed = alternative.trim();
  if (trimmed === "") {
    // Empty alternative matches every version.
    return () => true;
  }

  const hyphenParts = trimmed.split(HYPHEN_SPLIT);
  if (hyphenParts.length > 1) {
    if (hyphenParts.length !== 2 || hyphenParts.some((p) => p.trim() === "")) {
      throw invalidRange(range);
    }
    const [lowText, highText] = hyphenParts.map((p) => p.trim());
    // Operators are not allowed inside a hyphen range.
    if (OPERATORS.some((o) => lowText.startsWith(o)) || OPERATORS.some((o) => highText.startsWith(o))) {
      throw invalidRange(range);
    }
    const low = parsePartialVersion(lowText, range);
    const high = parsePartialVersion(highText, range);
    const lowParts = low.parts; // missing parts filled with zeros by compareParts
    const highBound =
      high.parts.length === 0
        ? null // upper bound of "*" means no upper bound
        : high.parts.length === 3
          ? high.parts
          : [...high.parts.slice(0, high.parts.length - 1), high.parts[high.parts.length - 1] + 1];
    const highInclusive = high.parts.length === 3;
    return (v) => {
      if (low.parts.length > 0 && compareParts(versionToParts(v), lowParts) < 0) {
        return false;
      }
      if (highBound !== null) {
        const cmp = compareParts(versionToParts(v), highBound);
        if (highInclusive ? cmp > 0 : cmp >= 0) {
          return false;
        }
      }
      return true;
    };
  }

  // Comparator set: whitespace-separated tokens, all must hold. An operator
  // may be separated from its version by whitespace (">= 1.2.3"), so merge
  // operator-only tokens with the token that follows them.
  const tokens = trimmed.split(/\s+/);
  const merged: string[] = [];
  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i];
    if (OPERATORS.includes(token as ComparatorOp)) {
      if (i + 1 >= tokens.length) {
        throw invalidRange(range);
      }
      merged.push(token + tokens[++i]);
    } else {
      merged.push(token);
    }
  }

  if (merged.length === 0) {
    return () => true;
  }

  const fns = merged.map((token) => parseComparatorToken(token, range));
  return (v) => fns.every((fn) => fn(v));
}

/**
 * Parse a range string into a predicate. Throws a TypeError when the range
 * does not fit the grammar in docs/RANGES.md.
 */
function parseRange(range: string): Predicate {
  if (typeof range !== "string") {
    throw invalidRange(String(range));
  }
  const alternatives = range.split("||");
  const fns = alternatives.map((alt) => parseAlternative(alt, range));
  return (v) => fns.some((fn) => fn(v));
}

/**
 * Check whether a release version satisfies a range. The version is validated
 * with parseVersion (release versions only, no prerelease handling). The range
 * grammar is defined in docs/RANGES.md: exact versions, =, <, <=, >, >=, ^,
 * ~, hyphen ranges, x-ranges/partial versions, space-separated comparator
 * sets and "||" alternatives.
 *
 * Throws a TypeError when the version is invalid or the range is malformed.
 */
export function satisfies(version: string, range: string): boolean {
  const v = parseVersion(version);
  const predicate = parseRange(range);
  return predicate(v);
}
