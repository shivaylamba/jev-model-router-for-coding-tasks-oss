import unittest

from notes import add_tag, create_note, remove_tag
from search import notes_with_tag, tag_counts


class NotesTest(unittest.TestCase):
    def test_create_with_tags(self):
        note = create_note("  Groceries ", "milk", ["Home", " errands "])
        self.assertEqual(note["title"], "Groceries")
        self.assertEqual(note["tags"], ["home", "errands"])

    def test_add_and_remove_tag(self):
        note = create_note("Plan", tags=["work"])
        add_tag(note, "Urgent")
        self.assertEqual(note["tags"], ["work", "urgent"])
        remove_tag(note, "WORK")
        self.assertEqual(note["tags"], ["urgent"])

    def test_search(self):
        a = create_note("a", tags=["x"])
        b = create_note("b", tags=["y"])
        self.assertEqual(notes_with_tag([a, b], "Y"), [b])

    def test_untagged_notes_do_not_share_tags(self):
        pinned = create_note("Standup", pinned=True)
        plain = create_note("Groceries")
        self.assertEqual(pinned["tags"], ["pinned"])
        self.assertEqual(plain["tags"], [])

    def test_add_tag_does_not_leak_to_other_notes(self):
        a = create_note("a")
        b = create_note("b")
        add_tag(a, "work")
        self.assertEqual(b["tags"], [])
        self.assertEqual(tag_counts([a, b]), {"work": 1})

    def test_tags_argument_is_not_modified(self):
        shared = ["Home", "Errands"]
        first = create_note("n1", tags=shared, pinned=True)
        second = create_note("n2", tags=shared)
        self.assertEqual(shared, ["Home", "Errands"])
        self.assertEqual(first["tags"], ["home", "errands", "pinned"])
        self.assertEqual(second["tags"], ["home", "errands"])
        self.assertIsNot(first["tags"], second["tags"])

    def test_tags_accepts_tuple(self):
        note = create_note("t", tags=("X",))
        self.assertEqual(note["tags"], ["x"])

    def test_pinned_tag_not_duplicated(self):
        note = create_note("p", tags=["Pinned"], pinned=True)
        self.assertEqual(note["tags"], ["pinned"])


if __name__ == "__main__":
    unittest.main()
