// Plain-text table rendering. The rules are in SPEC.md.

export type Align = "left" | "right" | "center";

export interface TableOptions {
  maxWidth?: number;
  align?: Align[];
  header?: boolean;
}

// Wide code point ranges from SPEC.md, in display columns.
const WIDE_RANGES: ReadonlyArray<readonly [number, number]> = [
  [0x1100, 0x115f],
  [0x2e80, 0x303e],
  [0x3041, 0x33ff],
  [0x3400, 0x4dbf],
  [0x4e00, 0x9fff],
  [0xa000, 0xa4cf],
  [0xac00, 0xd7a3],
  [0xf900, 0xfaff],
  [0xfe30, 0xfe4f],
  [0xff00, 0xff60],
  [0xffe0, 0xffe6],
  [0x1f300, 0x1f64f],
  [0x1f900, 0x1f9ff],
  [0x20000, 0x3fffd],
];

function isWide(cp: number): boolean {
  let lo = 0;
  let hi = WIDE_RANGES.length - 1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    const [start, end] = WIDE_RANGES[mid];
    if (cp < start) hi = mid - 1;
    else if (cp > end) lo = mid + 1;
    else return true;
  }
  return false;
}

/** Display width of a string in terminal columns, per code point. */
function displayWidth(s: string): number {
  let width = 0;
  for (const ch of s) width += isWide(ch.codePointAt(0)!) ? 2 : 1;
  return width;
}

/** Split a string into code points (not UTF-16 code units). */
function codePoints(s: string): string[] {
  return Array.from(s);
}

/** Split a cell into paragraphs, wrap each one greedily to `w` columns. */
function wrapCell(text: string, w: number): string[] {
  const lines: string[] = [];
  for (const paragraph of text.split("\n")) {
    const words = paragraph.split(" ").filter((word) => word.length > 0);
    if (words.length === 0) {
      lines.push("");
      continue;
    }
    let line = "";
    let lineWidth = 0;
    for (const word of words) {
      const wordWidth = displayWidth(word);
      const lineLen = lineWidth + (line === "" ? 0 : 1) + wordWidth;
      if (lineLen <= w) {
        line = line === "" ? word : `${line} ${word}`;
        lineWidth = lineLen;
        continue;
      }
      if (wordWidth <= w) {
        if (line !== "") lines.push(line);
        line = word;
        lineWidth = wordWidth;
        continue;
      }
      // Word is wider than the column: finish the line, then cut the word
      // into the longest prefixes that fit.
      if (line !== "") {
        lines.push(line);
        line = "";
        lineWidth = 0;
      }
      let pieces = codePoints(word);
      while (true) {
        let take = 0;
        let width = 0;
        while (take < pieces.length) {
          const cw = isWide(pieces[take].codePointAt(0)!) ? 2 : 1;
          if (width + cw > w) break;
          width += cw;
          take += 1;
        }
        if (take === pieces.length) {
          line = pieces.join("");
          lineWidth = width;
          break;
        }
        lines.push(pieces.slice(0, take).join(""));
        pieces = pieces.slice(take);
      }
      lineWidth = displayWidth(line);
    }
    lines.push(line);
    lineWidth = displayWidth(line);
  }
  return lines;
}

function pad(text: string, width: number, align: Align): string {
  const extra = width - displayWidth(text);
  if (align === "left") return text + " ".repeat(extra);
  if (align === "right") return " ".repeat(extra) + text;
  const left = Math.floor(extra / 2);
  return " ".repeat(left) + text + " ".repeat(extra - left);
}

export function renderTable(rows: string[][], options: TableOptions = {}): string {
  const { maxWidth, align, header = false } = options;

  if (maxWidth !== undefined && (!Number.isInteger(maxWidth) || maxWidth <= 0)) {
    throw new RangeError(`maxWidth must be a positive integer, got ${maxWidth}`);
  }
  if (align !== undefined) {
    for (const a of align) {
      if (a !== "left" && a !== "right" && a !== "center") {
        throw new RangeError(`invalid align entry ${JSON.stringify(a)}`);
      }
    }
  }

  const columns = rows.reduce((max, row) => Math.max(max, row.length), 0);
  if (columns === 0) return "";

  const alignment: Align[] = [];
  for (let i = 0; i < columns; i++) alignment.push(align?.[i] ?? "left");

  // Cells split into paragraphs, words re-joined with single spaces.
  const paragraphs: string[][][] = rows.map((row) =>
    Array.from({ length: columns }, (_, c) => {
      const text = row[c] ?? "";
      return text.split("\n").map((p) => p.split(" ").filter((word) => word.length > 0).join(" "));
    }),
  );

  const minWidths: number[] = [];
  const widths: number[] = [];
  for (let c = 0; c < columns; c++) {
    let natural = 0;
    let hasWide = false;
    for (const row of paragraphs) {
      for (const p of row[c]) {
        natural = Math.max(natural, displayWidth(p));
        if (!hasWide) {
          for (const ch of p) {
            if (isWide(ch.codePointAt(0)!)) {
              hasWide = true;
              break;
            }
          }
        }
      }
    }
    minWidths.push(hasWide ? 2 : 1);
    widths.push(Math.max(natural, minWidths[c]));
  }

  const tableWidth = (ws: number[]) => ws.reduce((sum, w) => sum + w, 0) + 3 * (columns - 1);
  if (maxWidth !== undefined) {
    if (tableWidth(widths) > maxWidth) {
      // Shrink the widest column that is above its minimum, rightmost on ties.
      let ws = [...widths];
      while (tableWidth(ws) > maxWidth) {
        let best = -1;
        for (let c = 0; c < columns; c++) {
          if (ws[c] <= minWidths[c]) continue;
          if (best === -1 || ws[c] >= ws[best]) best = c;
        }
        if (best === -1) throw new RangeError("table cannot be fitted to maxWidth");
        ws[best] -= 1;
      }
      for (let c = 0; c < columns; c++) widths[c] = ws[c];
    }
  }

  // Wrap each cell to its (possibly shrunk) column width.
  const wrapped: WrappedCell[][] = rows.map((row) =>
    Array.from({ length: columns }, (_, c) => wrapCell(row[c] ?? "", widths[c])),
  );

  const lines: string[] = [];
  for (let r = 0; r < rows.length; r++) {
    const height = Math.max(...wrapped[r].map((cellLines) => cellLines.length));
    for (let line = 0; line < height; line++) {
      lines.push(
        wrapped[r]
          .map((cellLines, c) => pad(cellLines[line] ?? "", widths[c], alignment[c]))
          .join(" | "),
      );
    }
    if (header && r === 0) {
      lines.push(widths.map((w) => "-".repeat(w)).join("-+-"));
    }
  }
  return lines.join("\n");
}
