import { test } from "node:test";
import assert from "node:assert/strict";
import { renderTable } from "../src/table.ts";

test("empty table", () => {
  assert.equal(renderTable([]), "");
  assert.equal(renderTable([[]]), "");
  assert.equal(renderTable([[], []]), "");
});

test("basic columns and padding", () => {
  assert.equal(
    renderTable([
      ["a", "b"],
      ["ccc", "d"],
    ]),
    ["a   | b", "ccc | d"].join("\n"),
  );
});

test("short rows padded with empty cells", () => {
  // single-char columns have their natural width from the header row
  assert.equal(renderTable([["a", "b", "c"], ["x"]]), "a | b | c\nx |   |  ");
});

test("header separator", () => {
  // "ab" gives column 0 width 2; column 1 is 1 wide
  assert.equal(
    renderTable([["ab", "c"], ["x", "y"]], { header: true }),
    "ab | c\n---+--\nx  | y",
  );
});

test("align right and center", () => {
  // col widths 3 and 1: right-align pads "a" two left; center with extra 0 changes nothing
  const out = renderTable([["a", "b"], ["xxx", "y"]], { align: ["right", "center"] });
  assert.equal(out, "  a | b\nxxx | y");
  // center, column width 3 from row 2, cell "b" in row 1: extra 2 -> 1 left, 1 right
  const out2 = renderTable([["a", "b"], ["xxx", "yyy"]], { align: ["left", "center"] });
  assert.equal(out2.split("\n")[0], "a   |  b ");
});

test("widths measured per code point", () => {
  // "é" is one code point (BMP); "🇺🇸" flags are 2 code points of width... flags are not in the wide ranges.
  assert.equal(renderTable([["aé", "b"], ["x", "y"]]), "aé | b\nx  | y");
});

test("wide characters count double", () => {
  // 你 (U+4F60) is wide: natural width 2, min width 2
  assert.equal(renderTable([["你", "b"]]), "你 | b");
  // widest paragraph decides the column: 你你 (4) over 你 (2); short cell padded right
  assert.equal(renderTable([["你"], ["你你"]]), "你  \n你你");
});

test("min width 2 for columns containing wide code points", () => {
  // "你" alone: natural 2, min 2. A narrow column next to a wide cell gets min 2? No—
  // min width applies per column only if that column has a wide code point.
  assert.equal(renderTable([["你", "a"], ["b", "b"]]), "你 | a\nb  | b");
});

test("paragraphs and word wrapping", () => {
  // no maxWidth: paragraphs re-joined with single spaces, column keeps natural width
  assert.equal(renderTable([["a  b\nc"]]), "a b\nc  ");
  // with maxWidth forcing width 1, each word wraps to its own line
  assert.equal(renderTable([["a b\nc"]], { maxWidth: 1 }), "a\nb\nc");
});

test("all-space paragraph produces one empty line", () => {
  // no words: min width 1, one empty line padded to width 1
  assert.equal(renderTable([["   "]]), " ");
});

test("word too long for column is cut", () => {
  // natural 6 + 1 + 3 = 10; maxWidth 8 shrinks col0 to 4, then "abcdef" is cut into 4-wide pieces
  const out = renderTable([["abcdef", "x"]], { maxWidth: 8 });
  assert.equal(out, "abcd | x\nef   |  ");
});

test("greedy wrap packs words two per line", () => {
  // col0 shrinks to 5: "aa bb" (5) fits, "cc" starts a new line; row height 2
  const out = renderTable([["aa bb cc", "x"]], { maxWidth: 9 });
  assert.equal(out, "aa bb | x\ncc    |  ");
});

test("narrowing picks the widest column, rightmost on ties", () => {
  // 3 and 3, table 9 -> maxWidth 8 shrinks the rightmost of the tied columns to 2;
  // its word "bbb" is wider than the column and wraps
  const out = renderTable([["aaa", "bbb"]], { maxWidth: 8 });
  assert.equal(out, "aaa | bb\n    | b ");
});

test("narrowing stops at minimum width", () => {
  // Column "ab" min 2; column "c" min 1. natural widths 2 and 1; table 2+1+3=6.
  // maxWidth 5 -> shrink widest (col 0) to 1? min is 2 (no wide chars, min 1!). natural 2, min 1 -> can shrink to 1.
  assert.equal(renderTable([["ab", "c"]], { maxWidth: 5 }), "a | c\nb |  ");
});

test("cannot fit throws", () => {
  // Two columns each with wide chars: min 2 each, table 2+2+3=7. maxWidth 6 impossible.
  assert.throws(() => renderTable([["你", "你"]], { maxWidth: 6 }), RangeError);
});

test("invalid maxWidth throws", () => {
  assert.throws(() => renderTable([["a"]], { maxWidth: 0 }), RangeError);
  assert.throws(() => renderTable([["a"]], { maxWidth: -1 }), RangeError);
  assert.throws(() => renderTable([["a"]], { maxWidth: 1.5 }), RangeError);
});

test("invalid align throws", () => {
  assert.throws(() => renderTable([["a"]], { align: ["top" as never] }), RangeError);
});

test("extra align entries ignored, missing default left", () => {
  assert.equal(renderTable([["a", "b"]], { align: ["right", "right", "left"] }), "a | b");
});

test("wide char inside long word is cut on wide boundary", () => {
  // natural 8 for col0; table 8+1+3 = 12 -> maxWidth 9 shrinks col0 to 5.
  // Each wide char is 2 columns; pieces at width 5 take two chars (4 columns), padded to 5.
  const out = renderTable([["你好世界", "x"]], { maxWidth: 9 });
  assert.equal(out, "你好  | x\n世界  |  ");
});
