/**
 * INI reading and writing. See docs/INI_FORMAT.md for the dialect.
 */

function quote(value) {
  const escaped = value
    .replace(/\\/g, "\\\\")
    .replace(/"/g, '\\"')
    .replace(/\n/g, "\\n")
    .replace(/\t/g, "\\t");
  return `"${escaped}"`;
}

function needsQuotes(value) {
  return value !== value.trim() || /["\\\n\t]/.test(value) || value.startsWith('"');
}

/**
 * Serialize { section: { key: value } } to INI text. Keys of the "" section
 * are written first, without a header. Values are converted with String().
 */
export function stringifyIni(data) {
  const lines = [];
  const sections = Object.keys(data);
  const ordered = sections.includes("") ? ["", ...sections.filter((s) => s !== "")] : sections;
  for (const section of ordered) {
    if (section !== "") {
      if (lines.length > 0) lines.push("");
      lines.push(`[${section}]`);
    }
    for (const [key, raw] of Object.entries(data[section])) {
      const value = String(raw);
      lines.push(`${key} = ${needsQuotes(value) ? quote(value) : value}`);
    }
  }
  return lines.join("\n") + "\n";
}

function fail(line, message) {
  const error = new SyntaxError(`line ${line}: ${message}`);
  error.line = line;
  throw error;
}

// The escapes a quoted value supports: \" \\ \n \t
function unescapeChar(ch) {
  switch (ch) {
    case '"':
      return '"';
    case "\\":
      return "\\";
    case "n":
      return "\n";
    case "t":
      return "\t";
    default:
      return undefined;
  }
}

// Assignment that keeps "__proto__" an own entry instead of tripping over
// Object.prototype's setter.
function setKey(object, key, value) {
  Object.defineProperty(object, key, {
    value,
    enumerable: true,
    writable: true,
    configurable: true,
  });
}

// Decode a value that starts with a quote; anything else it may not contain
// is a syntax error on `line`.
function parseQuotedValue(value, line) {
  let out = "";
  for (let i = 1; i < value.length; i++) {
    const ch = value[i];
    if (ch === '"') {
      if (value.slice(i + 1).trim() !== "") fail(line, "unexpected text after the closing quote");
      return out;
    }
    if (ch === "\\") {
      const unescaped = unescapeChar(value[i + 1]);
      if (unescaped === undefined) fail(line, "invalid escape in a quoted value");
      out += unescaped;
      i++;
    } else {
      out += ch;
    }
  }
  fail(line, "missing closing quote");
}

/**
 * Parse INI text into { section: { key: value } }. Keys that appear before
 * the first section header belong to the "" section. Malformed input throws
 * a SyntaxError with a 1-based numeric `line` property.
 */
export function parseIni(text) {
  // Split into physical lines and drop the empty entry after a final newline.
  const lines = text.split("\n");
  if (lines[lines.length - 1] === "") lines.pop();

  const sections = new Map();
  let current = null;
  let index = 0;

  while (index < lines.length) {
    const line = lines[index].trim();
    const number = index + 1;
    index += 1;

    if (line === "" || line[0] === ";" || line[0] === "#") continue;

    if (line[0] === "[") {
      if (!line.endsWith("]")) fail(number, "section header is missing ']'");
      const name = line.slice(1, -1).trim();
      if (name === "") fail(number, "section header has an empty name");
      let section = sections.get(name);
      if (section === undefined) {
        section = new Map();
        sections.set(name, section);
      }
      current = section;
      continue;
    }

    const eq = line.indexOf("=");
    if (eq === -1) fail(number, "expected 'key = value', a section header, or a comment");

    const key = line.slice(0, eq).trim();
    if (key === "") fail(number, "empty key");

    let value = line.slice(eq + 1).trim();
    if (value.startsWith('"')) {
      value = parseQuotedValue(value, number);
    } else {
      // An unquoted value ending in a backslash continues on the next line,
      // which counts as plain text even when it looks like a header or comment.
      let atLine = number;
      while (value.endsWith("\\")) {
        value = value.slice(0, -1).trimEnd();
        if (index >= lines.length) fail(atLine, "line continuation is missing a following line");
        value += " " + lines[index].trim();
        atLine = index + 1;
        index += 1;
      }
    }

    if (current === null) {
      current = new Map();
      sections.set("", current);
    }
    current.set(key, value);
  }

  const result = {};
  for (const [name, keys] of sections) {
    const section = {};
    for (const [key, value] of keys) setKey(section, key, value);
    setKey(result, name, section);
  }
  return result;
}
