"""Function decorators."""

import collections
import functools


def once(func):
    """Call `func` the first time only; later calls return the first result."""
    result = []

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        if not result:
            result.append(func(*args, **kwargs))
        return result[0]

    return wrapper


CacheInfo = collections.namedtuple("CacheInfo", ["hits", "misses", "size"])


def memoize(func):
    """Cache `func`'s result per distinct arguments; later calls with
    the same arguments return the cached result."""
    cache = {}
    hits = misses = 0

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        nonlocal hits, misses
        key = (args, tuple(sorted(kwargs.items())))
        if key in cache:
            hits += 1
            return cache[key]
        misses += 1
        result = func(*args, **kwargs)
        cache[key] = result
        return result

    def cache_info():
        """Return a CacheInfo(hits, misses, size) snapshot of this cache."""
        return CacheInfo(hits, misses, len(cache))

    def cache_clear():
        """Empty the cache and reset the hit and miss counts."""
        nonlocal hits, misses
        cache.clear()
        hits = misses = 0

    wrapper.cache_info = cache_info
    wrapper.cache_clear = cache_clear
    return wrapper
