import { test } from "node:test";
import assert from "node:assert/strict";
import { orderTotal } from "../src/pricing.ts";
import { createPricer, defaultRules } from "../src/rules.ts";

test("spec example: one desk-setup and one lighting form", () => {
  const t = orderTotal({ lines: [
    { sku: "DESK", unitPrice: 2000, quantity: 1 },
    { sku: "CHAIR", unitPrice: 3000, quantity: 1 },
    { sku: "LAMP", unitPrice: 500, quantity: 2 },
    { sku: "BULB", unitPrice: 200, quantity: 1 },
  ]});
  assert.deepEqual(t.discounts, [
    { rule: "bundle:desk-setup", amount: 825 },
    { rule: "bundle:lighting", amount: 70 },
  ]);
});

test("LAMP x1: only the desk-setup forms", () => {
  const t = orderTotal({ lines: [
    { sku: "DESK", unitPrice: 2000, quantity: 1 },
    { sku: "CHAIR", unitPrice: 3000, quantity: 1 },
    { sku: "LAMP", unitPrice: 500, quantity: 1 },
  ]});
  assert.deepEqual(t.discounts, [{ rule: "bundle:desk-setup", amount: 825 }]);
});

test("volume eligible on full quantity but only discounts unbundled units", () => {
  const t = orderTotal({ lines: [
    { sku: "LAMP", unitPrice: 500, quantity: 10 },
    { sku: "BULB", unitPrice: 200, quantity: 1 },
  ]});
  assert.deepEqual(t.discounts, [
    { rule: "bundle:lighting", amount: 70 },
    { rule: "volume", amount: 450 },
  ]);
});

test("exclusive coupon with bundles -> excluded, nothing off", () => {
  const t = orderTotal({ lines: [
    { sku: "DESK", unitPrice: 2000, quantity: 1 },
    { sku: "CHAIR", unitPrice: 3000, quantity: 1 },
    { sku: "LAMP", unitPrice: 500, quantity: 1 },
  ]}, { code: "SOLO", kind: "percent", value: 10, exclusive: true });
  assert.equal(t.coupon, "excluded");
  assert.deepEqual(t.discounts, [{ rule: "bundle:desk-setup", amount: 825 }]);
});

test("exclusive coupon without bundles applies normally", () => {
  const t = orderTotal({ lines: [{ sku: "PEN", unitPrice: 250, quantity: 4 }] },
    { code: "SOLO", kind: "percent", value: 10, exclusive: true });
  assert.equal(t.coupon, "applied");
  assert.deepEqual(t.discounts, [{ rule: "coupon:SOLO", amount: 100 }]);
});

test("non-exclusive coupon computes percent from merchandise after bundles", () => {
  const t = orderTotal({ lines: [
    { sku: "DESK", unitPrice: 2000, quantity: 2 },
    { sku: "CHAIR", unitPrice: 3000, quantity: 2 },
    { sku: "LAMP", unitPrice: 500, quantity: 2 },
  ]}, { code: "SPRING10", kind: "percent", value: 10 });
  assert.deepEqual(t.discounts, [
    { rule: "bundle:desk-setup", amount: 1650 },
    { rule: "coupon:SPRING10", amount: 935 },
  ]);
  assert.equal(t.merchandise, 8415);
});

test("third-party rule plugs into createPricer and runs in its slot", () => {
  const spy = {
    name: "spy",
    apply(ctx) { ctx.discounts.push({ rule: "spy", amount: 100 }); },
  };
  const price = createPricer([defaultRules[0], defaultRules[1], spy, defaultRules[2], defaultRules[3], defaultRules[4]]);
  const t = price({ lines: [{ sku: "PEN", unitPrice: 250, quantity: 4 }] });
  assert.deepEqual(t.discounts[0], { rule: "spy", amount: 100 });
  assert.equal(t.merchandise, 900);
});

test("empty order: no shipping, no tax, zeroes", () => {
  const t = orderTotal({ lines: [] });
  assert.deepEqual(t, {
    subtotal: 0, discounts: [], merchandise: 0, shipping: 0, tax: 0, total: 0, coupon: "none",
  });
});

test("baseline numbers from the old function still hold", () => {
  const t = orderTotal({ lines: [{ sku: "INK", unitPrice: 2600, quantity: 2 }] }, { code: "FIVE", kind: "fixed", value: 500 });
  assert.equal(t.tax, 376);
  assert.equal(t.total, 5575);
});
