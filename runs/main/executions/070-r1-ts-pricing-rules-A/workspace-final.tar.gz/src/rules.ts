import { percentOf } from "./money.ts";
import { BUNDLES } from "./bundles.ts";
import type { Bundle, Coupon, CouponStatus, Discount, Order, Totals } from "./types.ts";

export type PricedLine = {
  sku: string;
  unitPrice: number;
  quantity: number;
  gross: number;   // unitPrice * quantity
  bundled: number; // units of this line used in bundles; starts at 0
};

export type PricingContext = {
  order: Order;
  coupon: Coupon | undefined;
  lines: PricedLine[];        // one per order line, in order
  subtotal: number;           // sum of gross
  discounts: Discount[];      // starts empty; rules push onto it
  couponStatus: CouponStatus; // starts "none"; only the coupon rule changes it
  shipping: number;           // starts 0
  tax: number;                // starts 0
};

export type PricingRule = {
  name: string;
  apply(ctx: PricingContext): void;
};

/* Rule constants — the same numbers orderTotal used. */
const VOLUME_MIN_QUANTITY = 10;
const VOLUME_PERCENT = 10;
const FREE_SHIPPING_THRESHOLD = 5000;
const SHIPPING_FEE = 499;
const TAX_PERCENT = 8;

/** Subtotal minus the discount amounts, as they stand right now. */
export function merchandiseTotal(ctx: PricingContext): number {
  let off = 0;
  for (const discount of ctx.discounts) {
    off += discount.amount;
  }
  return ctx.subtotal - off;
}

/**
 * Returns (order, coupon?) => Totals. Validates the order before any rule
 * runs, then calls each rule's apply exactly once in array order.
 */
export function createPricer(rules: PricingRule[]): (order: Order, coupon?: Coupon) => Totals {
  return (order: Order, coupon?: Coupon): Totals => {
    for (const line of order.lines) {
      if (!Number.isInteger(line.quantity) || line.quantity < 1) {
        throw new RangeError(`bad quantity for ${line.sku}: ${line.quantity}`);
      }
      if (!Number.isInteger(line.unitPrice) || line.unitPrice < 0) {
        throw new RangeError(`bad unit price for ${line.sku}: ${line.unitPrice}`);
      }
    }

    const ctx: PricingContext = {
      order,
      coupon,
      lines: order.lines.map((line) => ({
        sku: line.sku,
        unitPrice: line.unitPrice,
        quantity: line.quantity,
        gross: line.unitPrice * line.quantity,
        bundled: 0,
      })),
      subtotal: 0,
      discounts: [],
      couponStatus: "none",
      shipping: 0,
      tax: 0,
    };
    for (const priced of ctx.lines) {
      ctx.subtotal += priced.gross;
    }

    for (const rule of rules) {
      rule.apply(ctx);
    }

    const merchandise = merchandiseTotal(ctx);
    return {
      subtotal: ctx.subtotal,
      discounts: ctx.discounts,
      merchandise,
      shipping: ctx.shipping,
      tax: ctx.tax,
      total: merchandise + ctx.shipping + ctx.tax,
      coupon: ctx.couponStatus,
    };
  };
}

/**
 * "bundle": forms bundles in array order, each as many times as free units
 * allow. Units come from the earliest line of a SKU first; the discount is
 * rounded per line and summed into one record per bundle id.
 */
export function bundleRule(bundles: Bundle[]): PricingRule {
  return {
    name: "bundle",
    apply(ctx: PricingContext): void {
      for (const bundle of bundles) {
        let amount = 0;
        for (;;) {
          let forms = true;
          for (const sku of bundle.skus) {
            let free = 0;
            for (const line of ctx.lines) {
              if (line.sku === sku) {
                free += line.quantity - line.bundled;
              }
            }
            if (free < 1) {
              forms = false;
              break;
            }
          }
          if (!forms) {
            break;
          }
          for (const sku of bundle.skus) {
            for (const line of ctx.lines) {
              if (line.sku === sku && line.quantity - line.bundled > 0) {
                line.bundled += 1;
                amount += percentOf(line.unitPrice, bundle.percent);
                break;
              }
            }
          }
        }
        if (amount > 0) {
          ctx.discounts.push({ rule: `bundle:${bundle.id}`, amount });
        }
      }
    },
  };
}

/**
 * "volume": a line with quantity >= 10 gets 10% off — per line, rounded,
 * and only on its unbundled units.
 */
export const volumeRule: PricingRule = {
  name: "volume",
  apply(ctx: PricingContext): void {
    let amount = 0;
    for (const line of ctx.lines) {
      if (line.quantity >= VOLUME_MIN_QUANTITY) {
        amount += percentOf(line.unitPrice * (line.quantity - line.bundled), VOLUME_PERCENT);
      }
    }
    if (amount > 0) {
      ctx.discounts.push({ rule: "volume", amount });
    }
  },
};

/**
 * "coupon": at most one coupon. Exclusive coupons are blocked by any bundle
 * discount ("excluded"); then the minimum check; then percent or fixed, from
 * the merchandise total at the moment the rule runs.
 */
export const couponRule: PricingRule = {
  name: "coupon",
  apply(ctx: PricingContext): void {
    const coupon = ctx.coupon;
    if (!coupon) {
      return;
    }
    if (coupon.exclusive && ctx.discounts.some((d) => d.rule.startsWith("bundle:"))) {
      ctx.couponStatus = "excluded";
      return;
    }
    const merchandise = merchandiseTotal(ctx);
    if (merchandise < (coupon.minSubtotal ?? 0)) {
      ctx.couponStatus = "below-minimum";
      return;
    }
    const off = coupon.kind === "percent"
      ? percentOf(merchandise, coupon.value)
      : Math.min(coupon.value, merchandise);
    ctx.couponStatus = "applied";
    if (off > 0) {
      ctx.discounts.push({ rule: `coupon:${coupon.code}`, amount: off });
    }
  },
};

/** "shipping": 499, free from 5000 of merchandise; no lines — no shipping. */
export const shippingRule: PricingRule = {
  name: "shipping",
  apply(ctx: PricingContext): void {
    if (ctx.order.lines.length > 0 && merchandiseTotal(ctx) < FREE_SHIPPING_THRESHOLD) {
      ctx.shipping = SHIPPING_FEE;
    }
  },
};

/** "tax": 8% of merchandise after everything. Shipping is not taxed. */
export const taxRule: PricingRule = {
  name: "tax",
  apply(ctx: PricingContext): void {
    ctx.tax = percentOf(merchandiseTotal(ctx), TAX_PERCENT);
  },
};

export const defaultRules: PricingRule[] = [bundleRule(BUNDLES), volumeRule, couponRule, shippingRule, taxRule];
