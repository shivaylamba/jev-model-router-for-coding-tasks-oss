import type { Bundle } from "./types.ts";

/** The store's bundles, in the order they are processed (see docs/PRICING.md). */
export const BUNDLES: Bundle[] = [
  { id: "desk-setup", skus: ["DESK", "CHAIR", "LAMP"], percent: 15 },
  { id: "lighting", skus: ["LAMP", "BULB"], percent: 10 },
];
