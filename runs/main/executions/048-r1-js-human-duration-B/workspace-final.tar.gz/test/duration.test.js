import { test } from "node:test";
import assert from "node:assert/strict";
import { formatDuration } from "../src/duration.js";

const SECOND = 1000;
const MINUTE = 60 * SECOND;
const HOUR = 60 * MINUTE;
const DAY = 24 * HOUR;

test("shows the largest non-zero units, skipping zeros", () => {
  assert.equal(formatDuration(SECOND + 500), "1 second");
  assert.equal(formatDuration(SECOND + 500, { smallest: "ms" }), "1 second, 500 milliseconds");
  assert.equal(formatDuration(DAY + 5 * MINUTE), "1 day, 5 minutes");
  assert.equal(formatDuration(HOUR + 30 * SECOND), "1 hour, 30 seconds");
  assert.equal(formatDuration(DAY + 5 * MINUTE, { units: 1 }), "1 day");
});

test("floors ms first and never rounds the remainder", () => {
  assert.equal(formatDuration(59 * MINUTE + 59 * SECOND + 999), "59 minutes, 59 seconds");
  assert.equal(formatDuration(3599999.999), "59 minutes, 59 seconds");
  assert.equal(formatDuration(5999.9, { smallest: "ms" }), "5 seconds, 999 milliseconds");
});

test("compact style", () => {
  assert.equal(formatDuration(HOUR + 5 * MINUTE, { style: "compact" }), "1h 5m");
  assert.equal(formatDuration(DAY + HOUR + MINUTE + SECOND, { style: "compact", units: 3 }), "1d 1h 1m");
  assert.equal(formatDuration(DAY + HOUR + MINUTE + SECOND, { style: "compact", units: 4 }), "1d 1h 1m 1s");
});

test("smallest hides smaller units", () => {
  assert.equal(formatDuration(MINUTE + 30 * SECOND, { smallest: "m" }), "1 minute");
  assert.equal(formatDuration(2 * DAY, { smallest: "d" }), "2 days");
  assert.equal(formatDuration(HOUR - 1, { smallest: "h" }), "0 hours");
  assert.equal(formatDuration(MINUTE / 2, { smallest: "m" }), "0 minutes");
});

test("values below the smallest unit render as zero", () => {
  assert.equal(formatDuration(0), "0 seconds");
  assert.equal(formatDuration(0, { style: "compact" }), "0s");
  assert.equal(formatDuration(-0), "0 seconds");
  assert.equal(formatDuration(SECOND - 1), "0 seconds");
});

test("singular only for 1", () => {
  assert.equal(formatDuration(DAY), "1 day");
  assert.equal(formatDuration(2 * HOUR), "2 hours");
  assert.equal(formatDuration(1, { smallest: "ms" }), "1 millisecond");
});

test("rejects invalid input", () => {
  assert.throws(() => formatDuration("1000"), TypeError);
  assert.throws(() => formatDuration(null), TypeError);
  assert.throws(() => formatDuration(-1), RangeError);
  assert.throws(() => formatDuration(NaN), RangeError);
  assert.throws(() => formatDuration(Infinity), RangeError);
  assert.throws(() => formatDuration(1000, { units: 0 }), RangeError);
  assert.throws(() => formatDuration(1000, { units: 1.5 }), RangeError);
  assert.throws(() => formatDuration(1000, { style: "short" }), RangeError);
  assert.throws(() => formatDuration(1000, { smallest: "min" }), RangeError);
});
