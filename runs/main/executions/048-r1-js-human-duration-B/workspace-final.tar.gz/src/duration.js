/**
 * @typedef {"d" | "h" | "m" | "s" | "ms"} UnitAbbr
 */

/**
 * @typedef {object} FormatOptions
 * @property {number} [units] Show at most this many of the largest non-zero units.
 * @property {"long" | "compact"} [style] "long" gives "1 hour, 5 minutes"; "compact" gives "1h 5m".
 * @property {UnitAbbr} [smallest] The smallest unit that may appear; anything smaller is ignored.
 */

/**
 * Time units from largest to smallest; sizes are in milliseconds.
 */
const UNITS = [
  { abbr: "d", name: "day", ms: 24 * 60 * 60 * 1000 },
  { abbr: "h", name: "hour", ms: 60 * 60 * 1000 },
  { abbr: "m", name: "minute", ms: 60 * 1000 },
  { abbr: "s", name: "second", ms: 1000 },
  { abbr: "ms", name: "millisecond", ms: 1 },
];

/**
 * A duration in milliseconds as a readable string, e.g. "1 hour, 5 minutes"
 * or "1h 5m". `ms` is floored to a whole number, then split into units from
 * largest to smallest. Zero units are skipped and don't count against
 * `units`; whatever falls below the last shown unit is dropped, never
 * rounded. A value below one `smallest` unit (including 0) renders as zero
 * in that unit: "0 seconds" / "0s" by default.
 *
 * @param {number} ms
 * @param {FormatOptions} [options]
 * @returns {string}
 * @throws {TypeError} If `ms` is not a number.
 * @throws {RangeError} If `ms` is negative, NaN or Infinity, or `units`,
 *   `style` or `smallest` is invalid.
 */
export function formatDuration(ms, options = {}) {
  const { units = 2, style = "long", smallest = "s" } = options;

  if (typeof ms !== "number") {
    throw new TypeError(`ms must be a number, got ${typeof ms}`);
  }
  if (!Number.isFinite(ms) || ms < 0) {
    throw new RangeError(`ms must be a non-negative finite number, got ${ms}`);
  }
  if (!Number.isInteger(units) || units < 1) {
    throw new RangeError(`units must be a positive integer, got ${units}`);
  }
  if (style !== "long" && style !== "compact") {
    throw new RangeError(`style must be "long" or "compact", got ${style}`);
  }
  const smallestIndex = UNITS.findIndex((u) => u.abbr === smallest);
  if (smallestIndex === -1) {
    throw new RangeError(`smallest must be one of "d", "h", "m", "s", "ms", got ${smallest}`);
  }

  let remaining = Math.floor(ms);
  const parts = [];
  for (const unit of UNITS.slice(0, smallestIndex + 1)) {
    const value = Math.floor(remaining / unit.ms);
    remaining %= unit.ms;
    if (value === 0) continue;
    parts.push({ value, unit });
    if (parts.length === units) break;
  }

  const shown = parts.length > 0 ? parts : [{ value: 0, unit: UNITS[smallestIndex] }];
  if (style === "compact") {
    return shown.map(({ value, unit }) => `${value}${unit.abbr}`).join(" ");
  }
  return shown
    .map(({ value, unit }) => `${value} ${unit.name}${value === 1 ? "" : "s"}`)
    .join(", ");
}
