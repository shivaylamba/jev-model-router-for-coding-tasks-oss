import { appendPointer } from "./pointer.ts";
import { SchemaError } from "./types.ts";
import type { Json, Schema, SchemaObject, ValidationError } from "./types.ts";

// Full implementation of the tinyschema spec (see SPEC.md).

function isPlainObject(value: unknown): value is { [key: string]: Json } {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function matchesType(value: Json, type: string): boolean {
  switch (type) {
    case "null":
      return value === null;
    case "boolean":
      return typeof value === "boolean";
    case "object":
      return isPlainObject(value);
    case "array":
      return Array.isArray(value);
    case "number":
      return typeof value === "number";
    case "integer":
      return typeof value === "number" && Number.isInteger(value);
    case "string":
      return typeof value === "string";
    default:
      return false;
  }
}

/** Deep JSON equality: type, array order and length, object key sets and values. */
function jsonEquals(a: Json, b: Json): boolean {
  if (a === b) return true;
  if (Array.isArray(a) && Array.isArray(b)) {
    return a.length === b.length && a.every((v, i) => jsonEquals(v, b[i]));
  }
  if (isPlainObject(a) && isPlainObject(b)) {
    const keysA = Object.keys(a);
    const keysB = Object.keys(b);
    return (
      keysA.length === keysB.length &&
      keysA.every((k) => Object.hasOwn(b, k) && jsonEquals(a[k], b[k]))
    );
  }
  return false;
}

/** Decode one JSON Pointer reference token (~1 -> /, ~0 -> ~, in that order). */
function decodeToken(token: string): string {
  return token.replace(/~1/g, "/").replace(/~0/g, "~");
}

/** Resolve a local $ref ("#" or "#/...") against the root schema. */
function resolveRef(ref: string, rootSchema: Schema): Schema {
  if (!ref.startsWith("#")) {
    throw new SchemaError(`Unsupported $ref "${ref}": only local refs starting with '#' are allowed`);
  }
  const pointer = ref.slice(1);
  if (pointer === "") return rootSchema;
  if (!pointer.startsWith("/")) {
    throw new SchemaError(`Invalid $ref "${ref}"`);
  }
  let current: unknown = rootSchema;
  for (const rawToken of pointer.slice(1).split("/")) {
    const token = decodeToken(rawToken);
    if (Array.isArray(current)) {
      const index = Number(token);
      if (!Number.isInteger(index) || index < 0 || index >= current.length) {
        throw new SchemaError(`Unresolvable $ref "${ref}"`);
      }
      current = current[index];
    } else if (isPlainObject(current) && Object.hasOwn(current, token)) {
      current = current[token];
    } else {
      throw new SchemaError(`Unresolvable $ref "${ref}"`);
    }
  }
  if (typeof current !== "boolean" && !isPlainObject(current)) {
    throw new SchemaError(`$ref "${ref}" does not point to a schema`);
  }
  return current as Schema;
}

function schemaList(value: unknown): Schema[] | null {
  return Array.isArray(value) ? (value as Schema[]) : null;
}

function check(
  schema: Schema,
  value: Json,
  path: string,
  errors: ValidationError[],
  rootSchema: Schema,
): void {
  if (schema === true) return;
  if (schema === false) {
    errors.push({ path, keyword: "false" });
    return;
  }
  const s = schema as SchemaObject;

  // $ref: resolve against the root schema; other keywords alongside still apply.
  if (typeof s.$ref === "string") {
    check(resolveRef(s.$ref, rootSchema), value, path, errors, rootSchema);
  }

  // Any type
  if (s.type !== undefined) {
    const types = Array.isArray(s.type) ? (s.type as string[]) : [s.type as string];
    if (!types.some((t) => matchesType(value, t))) errors.push({ path, keyword: "type" });
  }

  if (Array.isArray(s.enum)) {
    if (!(s.enum as Json[]).some((option) => jsonEquals(option, value))) {
      errors.push({ path, keyword: "enum" });
    }
  }

  if (s.const !== undefined) {
    if (!jsonEquals(s.const as Json, value)) errors.push({ path, keyword: "const" });
  }

  // Numbers
  if (typeof value === "number") {
    if (typeof s.minimum === "number" && value < s.minimum) {
      errors.push({ path, keyword: "minimum" });
    }
    if (typeof s.maximum === "number" && value > s.maximum) {
      errors.push({ path, keyword: "maximum" });
    }
    if (typeof s.exclusiveMinimum === "number" && value <= s.exclusiveMinimum) {
      errors.push({ path, keyword: "exclusiveMinimum" });
    }
    if (typeof s.exclusiveMaximum === "number" && value >= s.exclusiveMaximum) {
      errors.push({ path, keyword: "exclusiveMaximum" });
    }
  }

  // Strings
  if (typeof value === "string") {
    const length = [...value].length;
    if (typeof s.minLength === "number" && length < s.minLength) {
      errors.push({ path, keyword: "minLength" });
    }
    if (typeof s.maxLength === "number" && length > s.maxLength) {
      errors.push({ path, keyword: "maxLength" });
    }
    if (typeof s.pattern === "string") {
      if (!new RegExp(s.pattern, "u").test(value)) {
        errors.push({ path, keyword: "pattern" });
      }
    }
  }

  // Objects
  if (isPlainObject(value)) {
    if (Array.isArray(s.required)) {
      for (const name of s.required as string[]) {
        if (!Object.hasOwn(value, name)) {
          errors.push({ path: appendPointer(path, name), keyword: "required" });
        }
      }
    }
    const properties = isPlainObject(s.properties)
      ? (s.properties as { [key: string]: Schema })
      : null;
    if (properties) {
      for (const [name, sub] of Object.entries(properties)) {
        if (Object.hasOwn(value, name)) {
          check(sub, value[name], appendPointer(path, name), errors, rootSchema);
        }
      }
    }
    if (s.additionalProperties !== undefined && s.additionalProperties !== true) {
      const additional = Object.keys(value).filter(
        (name) => !properties || !Object.hasOwn(properties, name),
      );
      if (s.additionalProperties === false) {
        for (const name of additional) {
          errors.push({ path: appendPointer(path, name), keyword: "additionalProperties" });
        }
      } else if (isPlainObject(s.additionalProperties)) {
        for (const name of additional) {
          check(
            s.additionalProperties as Schema,
            value[name],
            appendPointer(path, name),
            errors,
            rootSchema,
          );
        }
      }
    }
  }

  // Arrays
  if (Array.isArray(value)) {
    if (typeof s.minItems === "number" && value.length < s.minItems) {
      errors.push({ path, keyword: "minItems" });
    }
    if (typeof s.maxItems === "number" && value.length > s.maxItems) {
      errors.push({ path, keyword: "maxItems" });
    }
    if (s.items !== undefined && (typeof s.items === "boolean" || isPlainObject(s.items))) {
      const itemSchema = s.items as Schema;
      value.forEach((item, i) => check(itemSchema, item, appendPointer(path, i), errors, rootSchema));
    }
    if (s.uniqueItems === true) {
      let duplicate = false;
      for (let i = 0; i < value.length && !duplicate; i++) {
        for (let j = i + 1; j < value.length; j++) {
          if (jsonEquals(value[i], value[j])) {
            duplicate = true;
            break;
          }
        }
      }
      if (duplicate) errors.push({ path, keyword: "uniqueItems" });
    }
  }

  // Combining schemas
  const allOf = schemaList(s.allOf);
  if (allOf) {
    for (const sub of allOf) check(sub, value, path, errors, rootSchema);
  }

  const anyOf = schemaList(s.anyOf);
  if (anyOf) {
    const anyValid = anyOf.some((sub) => {
      const subErrors: ValidationError[] = [];
      check(sub, value, path, subErrors, rootSchema);
      return subErrors.length === 0;
    });
    if (!anyValid) errors.push({ path, keyword: "anyOf" });
  }

  const oneOf = schemaList(s.oneOf);
  if (oneOf) {
    let matches = 0;
    for (const sub of oneOf) {
      const subErrors: ValidationError[] = [];
      check(sub, value, path, subErrors, rootSchema);
      if (subErrors.length === 0) matches++;
    }
    if (matches !== 1) errors.push({ path, keyword: "oneOf" });
  }
}

export function validate(schema: Schema, data: Json): ValidationError[] {
  const errors: ValidationError[] = [];
  check(schema, data, "", errors, schema);
  return errors;
}
