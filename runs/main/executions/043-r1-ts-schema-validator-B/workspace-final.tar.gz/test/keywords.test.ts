import { test } from "node:test";
import assert from "node:assert/strict";
import { validate } from "../src/validate.ts";
import { SchemaError } from "../src/types.ts";

// enum / const
test("enum requires deep equality with one element", () => {
  assert.deepEqual(validate({ enum: [1, "x", [1, 2]] }, [1, 2]), []);
  assert.deepEqual(validate({ enum: [1, "x"] }, { a: 1 }), [{ path: "", keyword: "enum" }]);
  assert.deepEqual(validate({ enum: [{ a: 1, b: 2 }] }, { b: 2, a: 1 }), []); // key order irrelevant
});

test("const requires deep equality", () => {
  assert.deepEqual(validate({ const: "par" }, "par"), []);
  assert.deepEqual(validate({ const: { a: [1] } }, { a: [2] }), [{ path: "", keyword: "const" }]);
  assert.deepEqual(validate({ const: 1 }, true), [{ path: "", keyword: "const" }]); // different JSON types
});

// Numeric bounds
test("numeric bounds ignored for non-numbers", () => {
  assert.deepEqual(validate({ minimum: 5, maximum: 1, exclusiveMinimum: 0 }, "abc"), []);
  assert.deepEqual(validate({ minimum: 3, maximum: 10 }, 5), []);
  assert.deepEqual(validate({ minimum: 5 }, 4), [{ path: "", keyword: "minimum" }]);
  assert.deepEqual(validate({ maximum: 5 }, 6), [{ path: "", keyword: "maximum" }]);
  assert.deepEqual(validate({ exclusiveMinimum: 5 }, 5), [{ path: "", keyword: "exclusiveMinimum" }]);
  assert.deepEqual(validate({ exclusiveMaximum: 5 }, 5), [{ path: "", keyword: "exclusiveMaximum" }]);
  assert.deepEqual(validate({ exclusiveMinimum: 5, exclusiveMaximum: 10 }, 7), []);
});

// Strings
test("minLength/maxLength count code points, not UTF-16 units", () => {
  assert.deepEqual(validate({ minLength: 2 }, "😀"), [{ path: "", keyword: "minLength" }]);
  assert.deepEqual(validate({ maxLength: 1 }, "😀"), []);
  assert.deepEqual(validate({ minLength: 1, maxLength: 3 }, "ab"), []);
  assert.deepEqual(validate({ maxLength: 2 }, "abc"), [{ path: "", keyword: "maxLength" }]);
  assert.deepEqual(validate({ minLength: 5 }, 42), []); // ignored for non-strings
});

test("pattern compiles with u flag and is not anchored", () => {
  assert.deepEqual(validate({ pattern: "b" }, "abc"), []);
  assert.deepEqual(validate({ pattern: "^a" }, "abc"), []);
  assert.deepEqual(validate({ pattern: "^b" }, "abc"), [{ path: "", keyword: "pattern" }]);
  assert.deepEqual(validate({ pattern: "\\p{Lu}" }, "abC"), []); // unicode property escape via u flag
  assert.deepEqual(validate({ pattern: "x" }, 42), []); // ignored for non-strings
});

// additionalProperties
test("additionalProperties false reports one error per extra member", () => {
  const schema = { properties: { a: true }, additionalProperties: false };
  assert.deepEqual(validate(schema, { a: 1, b: 2, c: 3 }), [
    { path: "/b", keyword: "additionalProperties" },
    { path: "/c", keyword: "additionalProperties" },
  ]);
});

test("additionalProperties applies to every member when properties absent", () => {
  assert.deepEqual(validate({ additionalProperties: false }, { x: 1 }), [
    { path: "/x", keyword: "additionalProperties" },
  ]);
});

test("additionalProperties true does nothing", () => {
  assert.deepEqual(validate({ additionalProperties: true }, { x: 1 }), []);
});

test("additionalProperties as schema validates extra members", () => {
  const schema = { properties: { a: true }, additionalProperties: { type: "integer" } };
  assert.deepEqual(validate(schema, { a: 1, b: 2.5 }), [{ path: "/b", keyword: "type" }]);
  assert.deepEqual(validate(schema, { a: 1, b: 2 }), []);
});

test("additionalProperties false paths escape special characters", () => {
  assert.deepEqual(validate({ additionalProperties: false }, { "a/b": 1 }), [
    { path: "/a~1b", keyword: "additionalProperties" },
  ]);
});

test("object keywords ignored for non-objects", () => {
  assert.deepEqual(validate({ required: ["a"], additionalProperties: false }, [1, 2]), []);
});

// Arrays
test("items validates each element at its index path", () => {
  assert.deepEqual(validate({ items: { type: "string" } }, ["a", 1, "b"]), [
    { path: "/1", keyword: "type" },
  ]);
});

test("minItems/maxItems and ignored for non-arrays", () => {
  assert.deepEqual(validate({ minItems: 2 }, [1]), [{ path: "", keyword: "minItems" }]);
  assert.deepEqual(validate({ maxItems: 1 }, [1, 2]), [{ path: "", keyword: "maxItems" }]);
  assert.deepEqual(validate({ minItems: 1, maxItems: 3 }, [1, 2]), []);
  assert.deepEqual(validate({ minItems: 5, maxItems: 1 }, "abc"), []);
});

test("uniqueItems reports a single error regardless of duplicate count", () => {
  assert.deepEqual(validate({ uniqueItems: true }, [1, 1, 2, 2]), [{ path: "", keyword: "uniqueItems" }]);
  assert.deepEqual(validate({ uniqueItems: true }, [{ a: 1 }, { a: 1 }]), [
    { path: "", keyword: "uniqueItems" },
  ]);
  assert.deepEqual(validate({ uniqueItems: true }, [1, 2, "1"]), []); // type matters
  assert.deepEqual(validate({ uniqueItems: false }, [1, 1]), []);
});

// Combining
test("allOf reports subschema errors as its own", () => {
  const schema = { allOf: [{ type: "string" }, { minLength: 3 }] };
  assert.deepEqual(validate(schema, "ab"), [{ path: "", keyword: "minLength" }]);
  const errors = validate(schema, 5);
  assert.deepEqual(errors.filter((e) => e.keyword === "allOf"), []);
  assert.deepEqual(errors, [{ path: "", keyword: "type" }]);
});

test("anyOf reports a single error when all branches fail", () => {
  const schema = { anyOf: [{ type: "string" }, { const: 5 }] };
  assert.deepEqual(validate(schema, 5), []);
  assert.deepEqual(validate(schema, "hi"), []);
  assert.deepEqual(validate(schema, 6), [{ path: "", keyword: "anyOf" }]);
});

test("oneOf requires exactly one matching branch", () => {
  const schema = { oneOf: [{ type: "number" }, { minimum: 5 }] };
  assert.deepEqual(validate(schema, 10), [{ path: "", keyword: "oneOf" }]); // both match
  assert.deepEqual(validate(schema, 3), []); // exactly one matches
  // "x": minimum is ignored for non-numbers, so only that branch matches
  assert.deepEqual(validate(schema, "x"), []);
  // none match when both branches produce errors
  assert.deepEqual(validate({ oneOf: [{ type: "string" }, { const: "y" }] }, 6), [
    { path: "", keyword: "oneOf" },
  ]);
});

// $ref
test("$ref resolves against the root schema", () => {
  const schema = {
    $defs: { name: { type: "string" } },
    properties: { user: { $ref: "#/$defs/name" } },
  };
  assert.deepEqual(validate(schema, { user: 42 }), [{ path: "/user", keyword: "type" }]);
  assert.deepEqual(validate(schema, { user: "ok" }), []);
});

test("$ref '#' refers to the whole root schema", () => {
  const schema = { properties: { self: { $ref: "#" } }, type: "object" };
  assert.deepEqual(validate(schema, { self: { self: 5 } }), [
    { path: "/self/self", keyword: "type" },
  ]);
});

test("$ref decodes ~0 and ~1 escape sequences", () => {
  const schema = {
    "a/b": { type: "string" },
    "m~n": { type: "number" },
    properties: { x: { $ref: "#/a~1b" }, y: { $ref: "#/m~0n" } },
  };
  assert.deepEqual(validate(schema, { x: 1, y: "s" }), [
    { path: "/x", keyword: "type" },
    { path: "/y", keyword: "type" },
  ]);
});

test("recursive $ref supports self-referencing tree schemas", () => {
  const schema = {
    type: "object",
    properties: { value: { type: "integer" }, child: { $ref: "#" } },
  };
  const data = { value: 1, child: { value: 2.5, child: { value: 3 } } };
  assert.deepEqual(validate(schema, data), [{ path: "/child/value", keyword: "type" }]);
});

test("bad $refs throw SchemaError", () => {
  assert.throws(() => validate({ $ref: "http://x/y" }, 1), SchemaError);
  assert.throws(() => validate({ $ref: "#/missing" }, 1), SchemaError);
  assert.throws(() => validate({ $ref: "#/props/0" }, 1), SchemaError);
});

test("keywords alongside $ref still apply", () => {
  const schema = {
    $defs: { s: { type: "string" } },
    $ref: "#/$defs/s",
    minLength: 2,
  };
  const errors = validate(schema, "a");
  assert.deepEqual(errors, [{ path: "", keyword: "minLength" }]);
  assert.deepEqual(validate(schema, 5), [{ path: "", keyword: "type" }]);
});
