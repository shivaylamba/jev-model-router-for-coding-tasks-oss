import { test } from "node:test";
import assert from "node:assert/strict";
import { formatDuration } from "../src/duration.js";

test("defaults: long style, 2 units, smallest second", () => {
  assert.equal(formatDuration(1500), "1 second");
  assert.equal(formatDuration(3661000), "1 hour, 1 minute");
  assert.equal(formatDuration(0), "0 seconds");
  assert.equal(formatDuration(999), "0 seconds");
});

test("floors ms before splitting", () => {
  assert.equal(formatDuration(1500.7), "1 second");
  assert.equal(formatDuration(59_999.999, { smallest: "ms" }), "59 seconds, 999 milliseconds");
});

test("skips zero units without counting them", () => {
  // 1 day + 5 minutes
  assert.equal(formatDuration(86_700_000), "1 day, 5 minutes");
  // 2 hours + 3 seconds, hours/minutes/seconds skipped where zero
  assert.equal(formatDuration(7_203_000), "2 hours, 3 seconds");
});

test("drops remainder below last shown unit, never rounds", () => {
  // 59m 59.999s
  assert.equal(formatDuration(3_599_999), "59 minutes, 59 seconds");
  assert.equal(formatDuration(3_599_999, { units: 1 }), "59 minutes");
});

test("singular only when the number is 1", () => {
  assert.equal(formatDuration(1000), "1 second");
  assert.equal(formatDuration(2000), "2 seconds");
  assert.equal(formatDuration(60_000), "1 minute");
});

test("compact style", () => {
  assert.equal(formatDuration(3900000, { style: "compact" }), "1h 5m");
  assert.equal(formatDuration(0, { style: "compact" }), "0s");
  assert.equal(formatDuration(1500, { style: "compact", smallest: "ms" }), "1s 500ms");
});

test("smallest unit option", () => {
  assert.equal(formatDuration(1500, { smallest: "ms" }), "1 second, 500 milliseconds");
  assert.equal(formatDuration(500, { smallest: "m" }), "0 minutes");
  assert.equal(formatDuration(500, { smallest: "ms" }), "500 milliseconds");
  assert.equal(formatDuration(86_400_000, { smallest: "d" }), "1 day");
  assert.equal(formatDuration(86_399_999, { smallest: "d" }), "0 days");
});

test("errors", () => {
  assert.throws(() => formatDuration("1500"), TypeError);
  assert.throws(() => formatDuration(null), TypeError);
  assert.throws(() => formatDuration(-1), RangeError);
  assert.throws(() => formatDuration(NaN), RangeError);
  assert.throws(() => formatDuration(Infinity), RangeError);
  assert.throws(() => formatDuration(1000, { units: 0 }), RangeError);
  assert.throws(() => formatDuration(1000, { units: 2.5 }), RangeError);
  assert.throws(() => formatDuration(1000, { style: "short" }), RangeError);
  assert.throws(() => formatDuration(1000, { smallest: "x" }), RangeError);
});
