/**
 * Time units from largest to smallest. `size` is the unit's length in
 * milliseconds, `abbr` the compact suffix, `name` the long singular name.
 */
const UNITS = [
  { abbr: "d", size: 86_400_000, name: "day" },
  { abbr: "h", size: 3_600_000, name: "hour" },
  { abbr: "m", size: 60_000, name: "minute" },
  { abbr: "s", size: 1_000, name: "second" },
  { abbr: "ms", size: 1, name: "millisecond" },
];

const STYLES = new Set(["long", "compact"]);

/**
 * Format a duration in milliseconds as a readable string, e.g.
 * "1 hour, 5 minutes" (long) or "1h 5m" (compact).
 *
 * The value is floored to whole milliseconds, split into units from largest
 * to smallest, and at most `units` non-zero units are shown; anything below
 * the last shown unit is dropped, never rounded. Units smaller than
 * `smallest` never appear. If nothing would be shown, zero in the `smallest`
 * unit is returned (e.g. "0 seconds").
 *
 * @param {number} ms Non-negative finite duration in milliseconds.
 * @param {object} [options]
 * @param {number} [options.units=2] Maximum number of non-zero units to show.
 * @param {"long"|"compact"} [options.style="long"] Output style.
 * @param {"d"|"h"|"m"|"s"|"ms"} [options.smallest="s"] Smallest unit allowed.
 * @returns {string}
 */
export function formatDuration(ms, options = {}) {
  if (typeof ms !== "number") {
    throw new TypeError(`ms must be a number, got ${typeof ms}`);
  }
  if (!Number.isFinite(ms) || ms < 0) {
    throw new RangeError(`ms must be a non-negative finite number, got ${ms}`);
  }

  const { units = 2, style = "long", smallest = "s" } = options;

  if (!Number.isInteger(units) || units < 1) {
    throw new RangeError(`units must be a positive integer, got ${units}`);
  }
  if (!STYLES.has(style)) {
    throw new RangeError(`style must be "long" or "compact", got ${style}`);
  }
  const smallestIndex = UNITS.findIndex((u) => u.abbr === smallest);
  if (smallestIndex === -1) {
    throw new RangeError(
      `smallest must be one of "d", "h", "m", "s", "ms", got ${smallest}`,
    );
  }

  let remainder = Math.floor(ms);
  const parts = [];
  for (let i = 0; i <= smallestIndex && parts.length < units; i++) {
    const unit = UNITS[i];
    const count = Math.floor(remainder / unit.size);
    remainder -= count * unit.size;
    if (count === 0) continue;
    parts.push(style === "compact"
      ? `${count}${unit.abbr}`
      : `${count} ${unit.name}${count === 1 ? "" : "s"}`);
  }

  if (parts.length === 0) {
    const unit = UNITS[smallestIndex];
    return style === "compact" ? `0${unit.abbr}` : `0 ${unit.name}s`;
  }
  return parts.join(style === "compact" ? " " : ", ");
}
