import { test } from "node:test";
import assert from "node:assert/strict";
import { deepMerge, deepMergeWith } from "../src/merge.ts";

test("merges nested objects instead of replacing them", () => {
  const target = { db: { host: "a", port: 1 }, other: true };
  const result = deepMerge(target, { db: { pool: 20 } }) as any;
  assert.equal(result.db.host, "a");
  assert.equal(result.db.pool, 20);
  assert.equal(result.other, true);
});

test("applies sources left to right", () => {
  assert.deepEqual(deepMerge({ x: 1 }, { x: 2 }, { x: 3 }), { x: 3 });
});

test("plain objects in the result are fresh, even untouched ones", () => {
  const target = { a: { b: 1 } };
  const result = deepMerge(target, { c: 2 }) as any;
  assert.notEqual(result, target);
  assert.notEqual(result.a, target.a);
  assert.deepEqual(result.a, { b: 1 });
  result.a.b = 99;
  assert.equal(target.a.b, 1);
});

test("inputs are never mutated", () => {
  const target = { a: { b: 1 } };
  const source = { a: { c: 2 } };
  deepMerge(target, source);
  assert.deepEqual(target, { a: { b: 1 } });
  assert.deepEqual(source, { a: { c: 2 } });
});

test("arrays replace by default, with fresh arrays", () => {
  const target = { list: [1, 2] };
  const source = { list: [3] };
  const result = deepMerge(target, source) as any;
  assert.deepEqual(result.list, [3]);
  assert.notEqual(result.list, source.list);
  result.list.push(4);
  assert.deepEqual(target.list, [1, 2]);
});

test("concat option joins arrays", () => {
  const result = deepMergeWith({ arrays: "concat" }, { list: [1] }, { list: [2, 3] });
  assert.deepEqual(result, { list: [1, 2, 3] });
  const replaced = deepMergeWith({ arrays: "replace" }, { list: [1] }, { list: [2] });
  assert.deepEqual(replaced, { list: [2] });
});

test("non-plain objects are used as-is by reference", () => {
  const when = new Date();
  const map = new Map();
  class Thing {}
  const thing = new Thing();
  const fn = () => {};
  const result = deepMerge({}, { when, map, thing, fn }) as any;
  assert.equal(result.when, when);
  assert.equal(result.map, map);
  assert.equal(result.thing, thing);
  assert.equal(result.fn, fn);
});

test("undefined source values are ignored; null is a normal value", () => {
  assert.deepEqual(deepMerge({ a: 1, b: 2 }, { a: undefined, b: null }), { a: 1, b: null });
  assert.deepEqual(deepMerge({ a: 1 }, { extra: undefined }), { a: 1 });
});

test("reads only own enumerable string keys; skips unsafe keys", () => {
  const inheritedOnly = Object.create({ inherited: 1 });
  assert.throws(() => deepMerge({}, inheritedOnly), TypeError); // not a plain object

  const source = Object.create(null) as any;
  source.own = 2;
  const result = deepMerge({}, source) as any;
  assert.deepEqual(result, { own: 2 });

  const unsafe = deepMerge({}, JSON.parse('{"__proto__": {"x": 1}, "constructor": 2}')) as any;
  assert.equal(Object.keys(unsafe).length, 0);
  assert.deepEqual(deepMerge({ a: {} }, { a: { __proto__: 1, b: 2 } }), { a: { b: 2 } });
});

test("key order: target keys first, then new source keys", () => {
  const result = deepMerge({ a: 1, b: 2 }, { c: 3, a: 4 }, { d: 5, b: 6 }) as any;
  assert.deepEqual(Object.keys(result), ["a", "b", "c", "d"]);
});

test("null and undefined sources are skipped", () => {
  const target = { a: 1 };
  assert.deepEqual(deepMerge(target, null, undefined, { b: 2 }), { a: 1, b: 2 });
});

test("throws TypeError for bad target or source", () => {
  assert.throws(() => deepMerge(null as any, {}), TypeError);
  assert.throws(() => deepMerge(undefined as any, {}), TypeError);
  assert.throws(() => deepMerge([], {}), TypeError);
  assert.throws(() => deepMerge("x" as any, {}), TypeError);
  assert.throws(() => deepMerge({}, 5), TypeError);
  assert.throws(() => deepMerge({}, [1]), TypeError);
  const badSource = Object.create(null) as any;
  badSource.x = 1;
  assert.doesNotThrow(() => deepMerge({}, badSource)); // null-prototype source is fine
});

test("throws RangeError for a bad arrays option", () => {
  assert.throws(() => deepMergeWith({ arrays: "merge" as any }, {}, {}), RangeError);
});

test("deepMergeWith defaults to replace", () => {
  assert.deepEqual(deepMergeWith({}, { list: [1] }, { list: [2] }), { list: [2] });
});

test("prototype pollution via nested __proto__ keys is blocked", () => {
  const source = JSON.parse('{"nested": {"__proto__": {"polluted": true}}}');
  deepMerge({}, source);
  assert.equal(({} as any).polluted, undefined);
});
