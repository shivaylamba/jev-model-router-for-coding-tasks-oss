import { test } from "node:test";
import assert from "node:assert/strict";
import { DEFAULTS, loadConfig } from "../src/config.ts";

test("a db override keeps the other db settings", () => {
  const config = loadConfig({ db: { pool: 20 } });
  assert.deepEqual(config.db, { host: "localhost", port: 5432, pool: 20 });
});

test("a nested override keeps service and features defaults", () => {
  const config = loadConfig({ service: { port: 3000 } });
  assert.deepEqual(config.service, { name: "api", port: 3000 });
  assert.deepEqual(config.features, ["metrics"]);
});

test("later layers win for the same nested key", () => {
  const config = loadConfig({ db: { host: "a" } }, { db: { host: "b" } });
  assert.equal((config.db as any).host, "b");
});

test("loadConfig does not mutate DEFAULTS", () => {
  loadConfig({ db: { pool: 20 }, service: { name: "changed" }, features: ["x"] });
  assert.deepEqual(DEFAULTS, {
    service: { name: "api", port: 8080 },
    db: { host: "localhost", port: 5432, pool: 5 },
    features: ["metrics"],
  });
});

test("undefined layers are ignored", () => {
  assert.deepEqual(loadConfig(undefined), DEFAULTS);
  const config = loadConfig(undefined, { db: { pool: 1 } });
  assert.equal((config.db as any).pool, 1);
});
