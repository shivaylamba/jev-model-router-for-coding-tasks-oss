type PlainObject = Record<string, unknown>;

const UNSAFE_KEYS = new Set(["__proto__", "constructor", "prototype"]);

function isPlainObject(value: unknown): value is PlainObject {
  if (value === null || typeof value !== "object") return false;
  const proto: unknown = Object.getPrototypeOf(value);
  return proto === Object.prototype || proto === null;
}

/**
 * Merge sources over target, left to right, recursively merging plain
 * objects. Arrays replace by default; nothing is mutated and plain
 * objects in the result are always fresh.
 */
export function deepMerge(target: unknown, ...sources: Array<unknown>): unknown {
  return mergeAll(target, sources, "replace");
}

/** Same as deepMerge, with merge options. */
export function deepMergeWith(
  options: { arrays?: "replace" | "concat" },
  target: unknown,
  ...sources: Array<unknown>
): unknown {
  const arrays = options.arrays ?? "replace";
  if (arrays !== "replace" && arrays !== "concat") {
    throw new RangeError(`arrays must be "replace" or "concat", got ${String(arrays)}`);
  }
  return mergeAll(target, sources, arrays);
}

function mergeAll(target: unknown, sources: Array<unknown>, arrays: "replace" | "concat"): unknown {
  if (!isPlainObject(target)) {
    throw new TypeError(`target must be a plain object, got ${describe(target)}`);
  }
  for (const source of sources) {
    if (source === null || source === undefined) continue;
    if (!isPlainObject(source)) {
      throw new TypeError(`source must be a plain object, got ${describe(source)}`);
    }
  }
  let result = mergeInto({}, target, arrays);
  for (const source of sources) {
    if (source === null || source === undefined) continue;
    result = mergeInto(result as PlainObject, source, arrays);
  }
  return result;
}

function mergeInto(
  into: PlainObject,
  from: PlainObject,
  arrays: "replace" | "concat",
): PlainObject {
  const out = into;
  for (const key of Object.keys(from)) {
    if (UNSAFE_KEYS.has(key)) continue;
    const value: unknown = (from as PlainObject)[key];
    if (value === undefined) continue;
    const existing: unknown = (out as PlainObject)[key];
    if (isPlainObject(value) && isPlainObject(existing)) {
      out[key] = mergeInto(existing as PlainObject, value, arrays);
    } else if (arrays === "concat" && Array.isArray(value) && Array.isArray(existing)) {
      out[key] = [...existing, ...value];
    } else if (Array.isArray(value)) {
      out[key] = [...value];
    } else if (isPlainObject(value)) {
      out[key] = mergeInto({}, value, arrays);
    } else {
      out[key] = value;
    }
  }
  return out;
}

function describe(value: unknown): string {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  return typeof value;
}
