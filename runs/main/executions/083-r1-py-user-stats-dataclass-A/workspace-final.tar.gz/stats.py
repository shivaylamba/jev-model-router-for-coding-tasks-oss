"""Per-user activity statistics."""

from dataclasses import dataclass


@dataclass(frozen=True)
class UserStats:
    """Summary of one user's events.

    Behaves like the tuple (total_events, active_days, last_seen) it replaces:
    it unpacks into the three values in order, len() is 3, and integer
    indexing (including negative indexes) works as on the tuple.
    """

    total_events: int
    active_days: int
    last_seen: object  # datetime or None

    def __iter__(self):
        yield self.total_events
        yield self.active_days
        yield self.last_seen

    def __len__(self):
        return 3

    def __getitem__(self, index):
        return (self.total_events, self.active_days, self.last_seen)[index]

    @property
    def events_per_active_day(self):
        """Average events per active day; 0.0 when the user was never active."""
        if self.active_days == 0:
            return 0.0
        return self.total_events / self.active_days

    def as_dict(self):
        return {
            "total_events": self.total_events,
            "active_days": self.active_days,
            "last_seen": self.last_seen,
        }


def get_user_stats(events, user_id):
    """Summarise one user's events.

    Returns UserStats: total_events is the number of events for the user,
    active_days the number of distinct UTC calendar dates with at least one
    event, and last_seen the latest event time, or None when the user has no
    events.
    """
    mine = [event for event in events if event.user_id == user_id]
    if not mine:
        return UserStats(0, 0, None)
    days = {event.at.date() for event in mine}
    return UserStats(len(mine), len(days), max(event.at for event in mine))


def get_all_user_stats(events):
    """get_user_stats for every user that appears in `events`, keyed by user id."""
    user_ids = sorted({event.user_id for event in events})
    return {user_id: get_user_stats(events, user_id) for user_id in user_ids}
