/** Sum of a list of numbers; 0 for an empty list. */
export function sum(values: readonly number[]): number {
  let total = 0;
  for (const v of values) total += v;
  return total;
}

/** Arithmetic mean. Throws RangeError for an empty list. */
export function mean(values: readonly number[]): number {
  if (values.length === 0) throw new RangeError("mean of an empty list");
  return sum(values) / values.length;
}

/** Limit `value` to the closed interval [min, max]. Throws RangeError if min > max. */
export function clamp(value: number, min: number, max: number): number {
  if (min > max) throw new RangeError(`clamp: min ${min} is greater than max ${max}`);
  return Math.min(Math.max(value, min), max);
}

/**
 * Python-style range: integers from `start` (inclusive) toward `stop`
 * (exclusive) in `step` increments. `range(5)` counts 0..4; a single
 * argument is the stop. Throws RangeError if step is 0.
 */
export function range(start: number, stop?: number, step = 1): number[] {
  if (step === 0) throw new RangeError("range: step must not be 0");
  const begin = stop === undefined ? 0 : start;
  const end = stop === undefined ? start : stop;
  const result: number[] = [];
  if (step > 0) {
    for (let v = begin; v < end; v += step) result.push(v);
  } else {
    for (let v = begin; v > end; v += step) result.push(v);
  }
  return result;
}
