import unittest

from urlbits import build_query, parse_query


class ParseQueryTest(unittest.TestCase):
    def test_bare_key_and_repeats(self):
        self.assertEqual(parse_query("a=1&flag&a=2"), {"a": ["1", "2"], "flag": [None]})

    def test_leading_question_mark_ignored(self):
        self.assertEqual(parse_query("?a=1&b=2"), parse_query("a=1&b=2"))

    def test_empty_segments_skipped(self):
        self.assertEqual(parse_query("a=1&&b=2"), {"a": ["1"], "b": ["2"]})
        self.assertEqual(parse_query("&a=1"), {"a": ["1"]})
        self.assertEqual(parse_query("a=1&"), {"a": ["1"]})
        self.assertEqual(parse_query(""), {})
        self.assertEqual(parse_query("?"), {})
        self.assertEqual(parse_query("&"), {})

    def test_splits_on_first_equals(self):
        self.assertEqual(parse_query("a=b=c"), {"a": ["b=c"]})

    def test_empty_value(self):
        self.assertEqual(parse_query("x="), {"x": [""]})

    def test_plus_becomes_space(self):
        self.assertEqual(parse_query("a+b=c+d"), {"a b": ["c d"]})

    def test_percent_hex_either_case(self):
        self.assertEqual(parse_query("%41=%2F"), {"A": ["/"]})
        self.assertEqual(parse_query("%41=%2f"), {"A": ["/"]})

    def test_percent_without_two_hex_digits_kept(self):
        self.assertEqual(parse_query("100%25=50%"), {"100%": ["50%"]})
        self.assertEqual(parse_query("a=%1G"), {"a": ["%1G"]})
        self.assertEqual(parse_query("a=%2"), {"a": ["%2"]})

    def test_plus_and_percent2b(self):
        # "+" decodes to a space but "%2B" decodes to "+".
        self.assertEqual(parse_query("a=x+y&a=x%2B"), {"a": ["x y", "x+"]})

    def test_multibyte_utf8(self):
        self.assertEqual(parse_query("q=%C3%A9"), {"q": ["é"]})

    def test_invalid_utf8_replaced(self):
        self.assertEqual(parse_query("a=%FF"), {"a": ["�"]})
        self.assertEqual(parse_query("a=%C3"), {"a": ["�"]})

    def test_keys_in_first_appearance_order(self):
        self.assertEqual(list(parse_query("b=1&a=2&a=3")), ["b", "a"])


class BuildQueryTest(unittest.TestCase):
    def test_spec_example(self):
        self.assertEqual(build_query({"q": "a b&c"}), "q=a+b%26c")

    def test_order_and_forms(self):
        self.assertEqual(
            build_query({"a": ["1", ""], "flag": None, "skip": [], "c": "z"}),
            "a=1&a=&flag&c=z",
        )

    def test_empty_mapping(self):
        self.assertEqual(build_query({}), "")

    def test_unreserved_pass_through(self):
        self.assertEqual(build_query({"k": "AZaz09-._~"}), "k=AZaz09-._~")

    def test_percent_encoding(self):
        self.assertEqual(build_query({"k": " "}), "k=+")
        self.assertEqual(build_query({"k": "100%"}), "k=100%25")
        self.assertEqual(build_query({"k": "é"}), "k=%C3%A9")
        self.assertEqual(build_query({"k": "a+b"}), "k=a%2Bb")
        self.assertEqual(build_query({"a b": "c"}), "a+b=c")

    def test_type_error_for_bad_values(self):
        for bad in (1, b"x", 1.5, ("a",), {"a": 1}):
            with self.assertRaises(TypeError):
                build_query({"a": bad})
        with self.assertRaises(TypeError):
            build_query({"a": ["ok", 2]})
        with self.assertRaises(TypeError):
            build_query({1: "x"})


class RoundTripTest(unittest.TestCase):
    def test_params_round_trip(self):
        params = {
            "q": ["a b&c", "", "100%", "é+%", "%2B", None],
            "flag": [None],
            "": ["empty key"],
        }
        self.assertEqual(parse_query(build_query(params)), params)

    def test_string_round_trip(self):
        # Only strings already encoded the way build_query encodes can
        # round-trip (so "+" for spaces, %XX for everything else).
        for query in (
            "a=1&b=x+y&flag",
            "q=a+b%26c",
            "a=1&a=&a=flag",
            "=x",
            "%C3%A9=%EF%BF%BD",
        ):
            self.assertEqual(build_query(parse_query(query)), query)


if __name__ == "__main__":
    unittest.main()
