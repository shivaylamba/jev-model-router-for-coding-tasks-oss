"""URL helpers for the link checker."""

import string
from collections.abc import Mapping

_HEX_DIGITS = frozenset("0123456789abcdefABCDEF")
_UNRESERVED = frozenset(string.ascii_letters + string.digits + "-._~")


def split_url(url):
    """Split a URL into (base, query, fragment).

    The query is the text after the first "?" (without the "?") and the
    fragment is the text after the first "#". Missing parts are "".

    >>> split_url("https://x.test/a?b=1#top")
    ('https://x.test/a', 'b=1', 'top')
    """
    base, _, fragment = url.partition("#")
    base, _, query = base.partition("?")
    return base, query, fragment


def parse_query(query: str) -> dict[str, list[str | None]]:
    """Parse a query string into an ordered mapping of keys to value lists.

    A leading "?" is ignored, empty "&"-separated segments are skipped,
    and each segment splits on its first "=".  A segment with no "=" is
    a bare key whose value is None ("x=" gives the value "").  Keys and
    values are decoded ("+" to space, then %XX escapes as UTF-8 bytes),
    invalid UTF-8 becomes U+FFFD, and keys keep first-appearance order.

    >>> parse_query("a=1&flag&a=2")
    {'a': ['1', '2'], 'flag': [None]}
    """
    params: dict[str, list[str | None]] = {}
    for segment in query.removeprefix("?").split("&"):
        if not segment:
            continue
        key, sep, value = segment.partition("=")
        key = _decode_component(key)
        params.setdefault(key, []).append(
            _decode_component(value) if sep else None
        )
    return params


def build_query(params: Mapping[str, str | None | list[str | None]]) -> str:
    """Build a query string (no leading "?") from a mapping.

    Values may be a str, None (the bare key), or a list of str/None;
    an empty list writes nothing for that key.  Keys go in mapping
    order and list values in list order, each as its own pair.  Keys
    and values are UTF-8 percent-encoded with uppercase hex; only
    A-Z a-z 0-9 - . _ ~ pass through and a space becomes "+".

    >>> build_query({"q": "a b&c"})
    'q=a+b%26c'
    >>> build_query({"a": ["1", None, ""]})
    'a=1&a&a='
    """
    pairs = []
    for key, value in params.items():
        if not isinstance(key, str):
            raise TypeError(f"query keys must be str, not {type(key).__name__}")
        if value is None or isinstance(value, str):
            values: list[str | None] = [value]
        elif isinstance(value, list):
            values = value
        else:
            raise TypeError(
                "query values must be str, None, or a list of str/None,"
                f" not {type(value).__name__}"
            )
        for item in values:
            if item is None:
                pairs.append(_encode_component(key))
            elif isinstance(item, str):
                pairs.append(
                    _encode_component(key) + "=" + _encode_component(item)
                )
            else:
                raise TypeError(
                    f"query values must be str or None, not {type(item).__name__}"
                )
    return "&".join(pairs)


def _decode_component(text: str) -> str:
    """Decode one key or value: "+" becomes a space, then %XX escapes
    (either hex case) decode as UTF-8 bytes.  A "%" not followed by two
    hex digits is kept as-is, and invalid UTF-8 becomes U+FFFD.
    """
    text = text.replace("+", " ")
    raw = bytearray()
    i = 0
    while i < len(text):
        if (
            text[i] == "%"
            and i + 2 < len(text)
            and text[i + 1] in _HEX_DIGITS
            and text[i + 2] in _HEX_DIGITS
        ):
            raw.append(int(text[i + 1 : i + 3], 16))
            i += 3
        else:
            raw.extend(text[i].encode("utf-8"))
            i += 1
    return raw.decode("utf-8", errors="replace")


def _encode_component(text: str) -> str:
    """Percent-encode one key or value as UTF-8 with uppercase hex.
    Unreserved characters pass through and a space becomes "+".
    """
    parts = []
    for byte in text.encode("utf-8"):
        if byte == 0x20:
            parts.append("+")
        elif chr(byte) in _UNRESERVED:
            parts.append(chr(byte))
        else:
            parts.append(f"%{byte:02X}")
    return "".join(parts)
