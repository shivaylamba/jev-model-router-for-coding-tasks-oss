import { test } from "node:test";
import assert from "node:assert/strict";
import { TodoService, type TodoQuery } from "../src/todos.ts";
import { handleTodos } from "../src/http.ts";

function fixedClock(start: number) {
  let now = start;
  return () => now++;
}

function makeService(): TodoService {
  const service = new TodoService(fixedClock(0));
  service.add({ title: "Buy milk", tags: ["home", "urgent"], due: "2026-10-20" }); // id 1
  service.add({ title: "Write report", tags: ["work"], due: "2026-10-15" }); //       id 2
  service.add({ title: "Buy bread", tags: ["home"], due: null }); //                 id 3
  service.add({ title: "Call plumber", tags: ["home"], due: "2026-10-18" }); //       id 4
  service.complete(4);
  return service;
}

const ids = (todos: { id: number }[]) => todos.map((t) => t.id);

test("query with no argument returns all todos in id order", () => {
  assert.deepEqual(ids(makeService().query()), [1, 2, 3, 4]);
});

test("status filter", () => {
  const service = makeService();
  assert.deepEqual(ids(service.query({ status: "open" })), [1, 2, 3]);
  assert.deepEqual(ids(service.query({ status: "done" })), [4]);
  assert.deepEqual(ids(service.query({ status: "all" })), [1, 2, 3, 4]);
});

test("tags filter requires every tag, case-insensitive", () => {
  const service = makeService();
  assert.deepEqual(ids(service.query({ tags: ["HOME"] })), [1, 3, 4]);
  assert.deepEqual(ids(service.query({ tags: ["home", "URGENT"] })), [1]);
  assert.deepEqual(ids(service.query({ tags: [] })), [1, 2, 3, 4]);
});

test("text filter is trimmed, case-insensitive substring; blank means no filter", () => {
  const service = makeService();
  assert.deepEqual(ids(service.query({ text: " BUY " })), [1, 3]);
  assert.deepEqual(ids(service.query({ text: "   " })), [1, 2, 3, 4]);
});

test("dueBefore keeps todos due on or before the date; undated todos never match", () => {
  const service = makeService();
  assert.deepEqual(ids(service.query({ dueBefore: "2026-10-18" })), [2, 4]);
  assert.deepEqual(ids(service.query({ dueBefore: "2026-10-15" })), [2]);
});

test("sorting by due puts undated todos last in both orders", () => {
  const service = makeService();
  assert.deepEqual(ids(service.query({ sort: "due", order: "asc" })), [2, 4, 1, 3]);
  assert.deepEqual(ids(service.query({ sort: "due", order: "desc" })), [1, 4, 2, 3]);
});

test("sorting by title uses lowercased plain string comparison", () => {
  const service = makeService();
  assert.deepEqual(ids(service.query({ sort: "title", order: "asc" })), [1, 3, 4, 2]);
  assert.deepEqual(ids(service.query({ sort: "title", order: "desc" })), [2, 4, 3, 1]);
});

test("ties are broken by id ascending whatever the order", () => {
  const service = new TodoService(() => 5); // identical createdAt for all
  service.add({ title: "x" });
  service.add({ title: "y" });
  service.add({ title: "z" });
  assert.deepEqual(ids(service.query({ sort: "created", order: "asc" })), [1, 2, 3]);
  assert.deepEqual(ids(service.query({ sort: "created", order: "desc" })), [1, 2, 3]);
  assert.deepEqual(ids(service.query({ sort: "due", order: "desc" })), [1, 2, 3]); // all undated
});

test("query does not reorder the service's own list and returns a new array", () => {
  const service = makeService();
  const result = service.query({ sort: "title" });
  assert.deepEqual(ids(service.list()), [1, 2, 3, 4]);
  assert.notEqual(result, service.list());
});

test("query throws RangeError on invalid values", () => {
  const service = makeService();
  assert.throws(() => service.query({ status: "nope" as TodoQuery["status"] }), RangeError);
  assert.throws(() => service.query({ sort: "nope" as TodoQuery["sort"] }), RangeError);
  assert.throws(() => service.query({ order: "nope" as TodoQuery["order"] }), RangeError);
  assert.throws(() => service.query({ dueBefore: "2026-02-30" }), RangeError);
  assert.throws(() => service.query({ dueBefore: "2026-2-3" }), RangeError);
  assert.doesNotThrow(() => service.query({ dueBefore: "2026-10-18" }));
});

test("GET /todos applies filters and sorting from the query string", () => {
  const service = makeService();
  const res = handleTodos(service, "/todos?status=open&sort=due&order=desc");
  assert.equal(res.status, 200);
  const body = res.body as { items: { id: number }[]; count: number };
  assert.deepEqual(ids(body.items), [1, 2, 3]);
  assert.equal(body.count, body.items.length);
});

test("GET /todos reads tag (repeated), q, dueBefore and ignores unknown params", () => {
  const service = makeService();
  const byTags = handleTodos(service, "/todos?tag=home&tag=Urgent").body as { items: { id: number }[] };
  assert.deepEqual(ids(byTags.items), [1]);
  const emptyTags = handleTodos(service, "/todos?tag=").body as { items: { id: number }[] };
  assert.deepEqual(ids(emptyTags.items), [1, 2, 3, 4]);
  const byText = handleTodos(service, "/todos?q=buy").body as { items: { id: number }[] };
  assert.deepEqual(ids(byText.items), [1, 3]);
  const byDue = handleTodos(service, "/todos?dueBefore=2026-10-18").body as { items: { id: number }[] };
  assert.deepEqual(ids(byDue.items), [2, 4]);
  const unknown = handleTodos(service, "/todos?whatever=1").body as { items: { id: number }[] };
  assert.deepEqual(ids(unknown.items), [1, 2, 3, 4]);
});

test("GET /todos answers 400 with an error string on invalid values", () => {
  const service = makeService();
  for (const url of ["/todos?status=nope", "/todos?sort=nope", "/todos?order=nope", "/todos?dueBefore=2026-02-30"]) {
    const res = handleTodos(service, url);
    assert.equal(res.status, 400, url);
    assert.equal(typeof (res.body as { error: unknown }).error, "string", url);
  }
});
