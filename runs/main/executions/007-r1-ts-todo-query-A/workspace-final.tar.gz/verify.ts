import assert from "node:assert/strict";
import { TodoService } from "./src/todos.ts";
import { handleTodos } from "./src/http.ts";

const s = new TodoService((() => { let i = 0; return () => i++; })());
s.add({ title: "Buy milk", tags: ["Home", "urgent"], due: "2026-03-01" }); // 1
s.add({ title: "File taxes", tags: ["home"], due: "2026-04-15" });         // 2
s.add({ title: "call mum", tags: ["home", "URGENT"], due: null });         // 3
s.add({ title: "Zoo trip", due: "2026-01-01" });                           // 4
s.complete(2);

const ids = (q?: Parameters<TodoService["query"]>[0]) => s.query(q).map(t => t.id);
const httpIds = (u: string) => (handleTodos(s, u).body as { items: { id: number }[] }).items.map(t => t.id);

// filters
assert.deepEqual(ids(), [1, 2, 3, 4]);
assert.deepEqual(ids({ status: "open" }), [1, 3, 4]);
assert.deepEqual(ids({ status: "done" }), [2]);
assert.deepEqual(ids({ status: "all" }), [1, 2, 3, 4]);
assert.deepEqual(ids({ tags: ["HOME", "Urgent"] }), [1, 3]); // every tag, case-insensitive
assert.deepEqual(ids({ tags: [] }), [1, 2, 3, 4]);
assert.deepEqual(ids({ text: "  MUM " }), [3]);
assert.deepEqual(ids({ text: "  " }), [1, 2, 3, 4]);
assert.deepEqual(ids({ dueBefore: "2026-03-01" }), [1, 4]); // on-or-before, null excluded

// sorting
assert.deepEqual(ids({ sort: "due" }), [4, 1, 2, 3]); // null last asc
assert.deepEqual(ids({ sort: "due", order: "desc" }), [2, 1, 4, 3]); // null last desc
assert.deepEqual(ids({ sort: "title" }), [1, 3, 2, 4]);
assert.deepEqual(ids({ sort: "title", order: "desc" }), [4, 2, 3, 1]);
assert.deepEqual(ids({ sort: "created", order: "desc" }), [4, 3, 2, 1]);

// ties broken by id ascending regardless of order
const s2 = new TodoService(() => 42);
s2.add({ title: "b", due: null }); s2.add({ title: "a", due: null }); s2.add({ title: "c", due: "2026-01-01" });
assert.deepEqual(s2.query({ sort: "created", order: "desc" }).map(t => t.id), [1, 2, 3]);
assert.deepEqual(s2.query({ sort: "due", order: "desc" }).map(t => t.id), [3, 1, 2]); // null dues last, id-asc among themselves

// internal list never reordered; new array returned
const before = s2.list().map(t => t.id).join(",");
assert.notEqual(s2.query({ sort: "title" }), s2.list());
assert.equal(s2.list().map(t => t.id).join(","), before);

// RangeError validation
for (const q of [
  { status: "later" }, { sort: "size" }, { order: "up" },
  { dueBefore: "2026-02-30" }, { dueBefore: "2026-2-3" }, { dueBefore: "not-a-date" },
] as const) {
  assert.throws(() => s.query(q as never), RangeError);
}
assert.doesNotThrow(() => s.query({ dueBefore: "2026-02-28" }));

// HTTP
assert.equal(handleTodos(s, "/todos").status, 200);
assert.deepEqual(httpIds("/todos"), [1, 2, 3, 4]);
assert.deepEqual(httpIds("/todos?status=done"), [2]);
assert.deepEqual(httpIds("/todos?tag=home&tag=Urgent"), [1, 3]);
assert.deepEqual(httpIds("/todos?tag="), [1, 2, 3, 4]);
assert.deepEqual(httpIds("/todos?q=milk"), [1]);
assert.deepEqual(httpIds("/todos?dueBefore=2026-03-01"), [1, 4]);
assert.deepEqual(httpIds("/todos?sort=title&order=desc"), [4, 2, 3, 1]);
assert.deepEqual(httpIds("/todos?bogus=1"), [1, 2, 3, 4]);
const bad = handleTodos(s, "/todos?sort=nope");
assert.equal(bad.status, 400);
assert.equal(typeof (bad.body as { error: unknown }).error, "string");
assert.equal(handleTodos(s, "/todos?dueBefore=2026-13-01").status, 400);
assert.equal(handleTodos(s, "/nope").status, 404);

console.log("all checks passed");
