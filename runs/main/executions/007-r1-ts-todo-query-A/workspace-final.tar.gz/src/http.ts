import type { TodoService } from "./todos.ts";
import type { TodoQuery } from "./todos.ts";

export interface Response {
  status: number;
  body: unknown;
}

/** Handle GET /todos. `url` is the request path plus query string, e.g. "/todos?status=open". */
export function handleTodos(service: TodoService, url: string): Response {
  const parsed = new URL(url, "http://localhost");
  if (parsed.pathname !== "/todos") {
    return { status: 404, body: { error: "not found" } };
  }

  const params = parsed.searchParams;

  // Build a TodoQuery only from parameters that are present; unknown
  // parameters are ignored and an absent parameter means "use the default".
  const query: TodoQuery = {};
  if (params.has("status")) query.status = params.get("status") as TodoQuery["status"];
  const tags = params.getAll("tag").filter((t) => t.trim() !== "");
  if (tags.length > 0) query.tags = tags;
  if (params.has("q")) query.text = params.get("q")!;
  if (params.has("dueBefore")) query.dueBefore = params.get("dueBefore")!;
  if (params.has("sort")) query.sort = params.get("sort") as TodoQuery["sort"];
  if (params.has("order")) query.order = params.get("order") as TodoQuery["order"];

  try {
    const items = service.query(query);
    return { status: 200, body: { items, count: items.length } };
  } catch (err) {
    if (err instanceof RangeError) {
      return { status: 400, body: { error: err.message } };
    }
    throw err;
  }
}
