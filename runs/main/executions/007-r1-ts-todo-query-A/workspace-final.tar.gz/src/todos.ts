export type Status = "open" | "done";

export interface Todo {
  id: number;
  title: string;
  status: Status;
  tags: string[];
  /** Due date as "YYYY-MM-DD", or null when there is none. */
  due: string | null;
  /** Milliseconds since the epoch, from the injected clock. */
  createdAt: number;
}

export interface NewTodo {
  title: string;
  tags?: string[];
  due?: string | null;
}

export interface TodoQuery {
  status?: "open" | "done" | "all";      // default "all"
  tags?: string[];                       // default: no tag filter
  text?: string;                         // default: no text filter
  dueBefore?: string;                    // "YYYY-MM-DD"
  sort?: "id" | "created" | "due" | "title"; // default "id"
  order?: "asc" | "desc";                // default "asc"
}

export class TodoService {
  private todos: Todo[] = [];
  private nextId = 1;
  private clock: () => number;

  constructor(clock: () => number = Date.now) {
    this.clock = clock;
  }

  add(input: NewTodo): Todo {
    const title = input.title.trim();
    if (title === "") throw new TypeError("title must not be empty");
    const todo: Todo = {
      id: this.nextId++,
      title,
      status: "open",
      tags: [...(input.tags ?? [])],
      due: input.due ?? null,
      createdAt: this.clock(),
    };
    this.todos.push(todo);
    return todo;
  }

  complete(id: number): Todo {
    const todo = this.todos.find((t) => t.id === id);
    if (!todo) throw new Error(`no todo with id ${id}`);
    todo.status = "done";
    return todo;
  }

  /** All todos in id order. */
  list(): Todo[] {
    return [...this.todos];
  }

  /**
   * Filter and sort todos per the agreed design in docs/query.md.
   *
   * Throws RangeError for:
   *  - a status, sort, or order value not in the allowed list
   *  - a dueBefore that is not a real calendar date in "YYYY-MM-DD" form
   */
  query(q?: TodoQuery): Todo[] {
    const status = q?.status ?? "all";
    const tags = q?.tags ?? [];
    const text = q?.text ?? "";
    const dueBefore = q?.dueBefore;
    const sort = q?.sort ?? "id";
    const order = q?.order ?? "asc";

    // ---- validation ----
    if (!["open", "done", "all"].includes(status)) {
      throw new RangeError(`invalid status: ${status}`);
    }
    if (!["id", "created", "due", "title"].includes(sort)) {
      throw new RangeError(`invalid sort: ${sort}`);
    }
    if (!["asc", "desc"].includes(order)) {
      throw new RangeError(`invalid order: ${order}`);
    }
    if (dueBefore !== undefined) {
      const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dueBefore);
      if (!m) throw new RangeError(`invalid dueBefore date: ${dueBefore}`);
      const [, y, mo, d] = m;
      const date = new Date(`${y}-${mo}-${d}T00:00:00Z`);
      // round-trip check: catches Feb 30, month 13, etc.
      if (
        date.getUTCFullYear() !== Number(y) ||
        date.getUTCMonth() + 1 !== Number(mo) ||
        date.getUTCDate() !== Number(d)
      ) {
        throw new RangeError(`invalid dueBefore date: ${dueBefore}`);
      }
    }

    // ---- filtering ----
    let result = [...this.todos];

    if (status !== "all") {
      result = result.filter((t) => t.status === status);
    }

    if (tags.length > 0) {
      const wanted = tags.map((t) => t.toLowerCase());
      result = result.filter((todo) => {
        const have = todo.tags.map((t) => t.toLowerCase());
        return wanted.every((w) => have.includes(w));
      });
    }

    const trimmedText = text.trim();
    if (trimmedText !== "") {
      const needle = trimmedText.toLowerCase();
      result = result.filter((t) => t.title.toLowerCase().includes(needle));
    }

    if (dueBefore !== undefined) {
      // keeps todos due on or before that date; nulls never match
      result = result.filter((t) => t.due !== null && t.due <= dueBefore);
    }

    // ---- sorting ----
    // todos without a due date always go last when sorting by due, both orders
    const compare = (a: Todo, b: Todo): number => {
      let cmp = 0;
      switch (sort) {
        case "id":
          cmp = a.id - b.id;
          break;
        case "created":
          cmp = a.createdAt - b.createdAt;
          break;
        case "title":
          const at = a.title.toLowerCase();
          const bt = b.title.toLowerCase();
          cmp = at < bt ? -1 : at > bt ? 1 : 0;
          break;
        case "due":
          if (a.due === null && b.due === null) cmp = 0;
          else if (a.due === null) cmp = 1;  // null due always last
          else if (b.due === null) cmp = -1;
          else cmp = a.due < b.due ? -1 : a.due > b.due ? 1 : 0;
          break;
      }
      // apply order to the primary key only; ties break by id ascending regardless
      if (cmp !== 0) {
        return order === "desc" ? -cmp : cmp;
      }
      // tie-break: id ascending, whatever the order
      // (covers equal keys and due=null pairs, where cmp stays 0)
      if (sort === "id") return 0; // id is unique; ties impossible
      return a.id - b.id;
    };

    result.sort(compare);
    return result;
  }
}
