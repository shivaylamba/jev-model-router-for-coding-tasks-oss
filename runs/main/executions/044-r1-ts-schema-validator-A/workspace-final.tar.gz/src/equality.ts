import type { Json } from "./types.ts";

/**
 * Deep JSON equality (SPEC.md "Equality"): different JSON types are never
 * equal; arrays compare element-wise in order; objects compare by member set,
 * ignoring member order.
 */
export function jsonEquals(a: Json, b: Json): boolean {
  if (a === b) return true;
  if (typeof a !== typeof b) return false;
  if (a === null || b === null) return false;

  if (Array.isArray(a)) {
    if (!Array.isArray(b) || a.length !== b.length) return false;
    for (let i = 0; i < a.length; i++) {
      if (!jsonEquals(a[i], b[i])) return false;
    }
    return true;
  }

  if (typeof b !== "object" || Array.isArray(b)) return false;

  const keysA = Object.keys(a);
  const keysB = Object.keys(b);
  if (keysA.length !== keysB.length) return false;
  for (const key of keysA) {
    if (!Object.hasOwn(b, key)) return false;
    if (!jsonEquals(a[key], b[key])) return false;
  }
  return true;
}
