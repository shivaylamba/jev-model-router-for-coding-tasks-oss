import { appendPointer } from "./pointer.ts";
import { jsonEquals } from "./equality.ts";
import { resolveRef } from "./ref.ts";
import type { Json, Schema, SchemaObject, ValidationError } from "./types.ts";

// Validators for the tinyschema keyword subset — see SPEC.md for the
// reporting rules each keyword follows.

function isPlainObject(value: unknown): value is { [key: string]: Json } {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function matchesType(value: Json, type: string): boolean {
  switch (type) {
    case "null":
      return value === null;
    case "boolean":
      return typeof value === "boolean";
    case "object":
      return isPlainObject(value);
    case "array":
      return Array.isArray(value);
    case "number":
      return typeof value === "number";
    case "integer":
      return typeof value === "number" && Number.isInteger(value);
    case "string":
      return typeof value === "string";
    default:
      return false;
  }
}

/** Length in Unicode code points, not UTF-16 code units. */
function codePointLength(value: string): number {
  return [...value].length;
}

function compilePattern(source: unknown): RegExp | undefined {
  if (typeof source !== "string") return undefined;
  try {
    return new RegExp(source, "u");
  } catch {
    return undefined;
  }
}

interface Context {
  rootSchema: Schema;
  /** (ref, path) pairs currently being resolved, to break $ref cycles. */
  resolving: Set<string>;
}

function checkAny(schema: Schema, value: Json, path: string, ctx: Context, errors: ValidationError[]): void {
  check(schema, value, path, ctx, errors);
}

function countErrors(schema: Schema, value: Json, path: string, ctx: Context): number {
  const sub: ValidationError[] = [];
  check(schema, value, path, ctx, sub);
  return sub.length;
}

function check(schema: Schema, value: Json, path: string, ctx: Context, errors: ValidationError[]): void {
  if (schema === true) return;
  if (schema === false) {
    errors.push({ path, keyword: "false" });
    return;
  }
  const s = schema as SchemaObject;

  if (typeof s.$ref === "string") {
    const key = `${s.$ref}@${path}`;
    if (!ctx.resolving.has(key)) {
      ctx.resolving.add(key);
      try {
        check(resolveRef(s.$ref, ctx.rootSchema), value, path, ctx, errors);
      } finally {
        ctx.resolving.delete(key);
      }
    }
    // Other keywords next to $ref still apply — fall through.
  }

  if (s.type !== undefined) {
    const types = Array.isArray(s.type) ? (s.type as string[]) : [s.type as string];
    if (!types.some((t) => matchesType(value, t))) errors.push({ path, keyword: "type" });
  }

  if (Array.isArray(s.enum)) {
    if (!(s.enum as Json[]).some((candidate) => jsonEquals(candidate, value))) {
      errors.push({ path, keyword: "enum" });
    }
  }

  if (s.const !== undefined) {
    if (!jsonEquals(s.const as Json, value)) errors.push({ path, keyword: "const" });
  }

  // Numbers — ignored for non-numbers.
  if (typeof value === "number") {
    if (typeof s.minimum === "number" && value < s.minimum) errors.push({ path, keyword: "minimum" });
    if (typeof s.maximum === "number" && value > s.maximum) errors.push({ path, keyword: "maximum" });
    if (typeof s.exclusiveMinimum === "number" && value <= s.exclusiveMinimum) {
      errors.push({ path, keyword: "exclusiveMinimum" });
    }
    if (typeof s.exclusiveMaximum === "number" && value >= s.exclusiveMaximum) {
      errors.push({ path, keyword: "exclusiveMaximum" });
    }
  }

  // Strings — ignored for non-strings.
  if (typeof value === "string") {
    if (typeof s.minLength === "number" && codePointLength(value) < s.minLength) {
      errors.push({ path, keyword: "minLength" });
    }
    if (typeof s.maxLength === "number" && codePointLength(value) > s.maxLength) {
      errors.push({ path, keyword: "maxLength" });
    }
    const pattern = compilePattern(s.pattern);
    if (pattern && !pattern.test(value)) errors.push({ path, keyword: "pattern" });
  }

  // Objects — ignored for non-objects.
  if (isPlainObject(value)) {
    if (Array.isArray(s.required)) {
      for (const name of s.required as string[]) {
        if (!Object.hasOwn(value, name)) errors.push({ path: appendPointer(path, name), keyword: "required" });
      }
    }
    const properties = isPlainObject(s.properties) ? (s.properties as { [key: string]: Schema }) : undefined;
    if (properties) {
      for (const [name, sub] of Object.entries(properties)) {
        if (Object.hasOwn(value, name)) checkAny(sub, value[name], appendPointer(path, name), ctx, errors);
      }
    }
    if (s.additionalProperties !== undefined && s.additionalProperties !== true) {
      const extras = Object.keys(value).filter((name) => !properties || !Object.hasOwn(properties, name));
      for (const name of extras) {
        const memberPath = appendPointer(path, name);
        if (s.additionalProperties === false) {
          errors.push({ path: memberPath, keyword: "additionalProperties" });
        } else if (isPlainObject(s.additionalProperties)) {
          checkAny(s.additionalProperties as Schema, value[name], memberPath, ctx, errors);
        }
      }
    }
  }

  // Arrays — ignored for non-arrays.
  if (Array.isArray(value)) {
    if (typeof s.minItems === "number" && value.length < s.minItems) errors.push({ path, keyword: "minItems" });
    if (typeof s.maxItems === "number" && value.length > s.maxItems) errors.push({ path, keyword: "maxItems" });
    if (s.items !== undefined && (typeof s.items === "boolean" || isPlainObject(s.items))) {
      const itemSchema = s.items as Schema;
      value.forEach((element, index) => checkAny(itemSchema, element, appendPointer(path, index), ctx, errors));
    }
    if (s.uniqueItems === true) {
      const seen: Json[] = [];
      let duplicate = false;
      for (const element of value) {
        if (seen.some((prev) => jsonEquals(prev, element))) {
          duplicate = true;
          break;
        }
        seen.push(element);
      }
      if (duplicate) errors.push({ path, keyword: "uniqueItems" });
    }
  }

  // Combining schemas.
  if (Array.isArray(s.allOf)) {
    for (const sub of s.allOf as Schema[]) checkAny(sub, value, path, ctx, errors);
  }
  if (Array.isArray(s.anyOf)) {
    const matches = (s.anyOf as Schema[]).filter((sub) => countErrors(sub, value, path, ctx) === 0).length;
    if (matches === 0) errors.push({ path, keyword: "anyOf" });
  }
  if (Array.isArray(s.oneOf)) {
    const matches = (s.oneOf as Schema[]).filter((sub) => countErrors(sub, value, path, ctx) === 0).length;
    if (matches !== 1) errors.push({ path, keyword: "oneOf" });
  }
}

export function validate(schema: Schema, data: Json): ValidationError[] {
  const errors: ValidationError[] = [];
  check(schema, data, "", { rootSchema: schema, resolving: new Set() }, errors);
  // SPEC: the list contains no duplicates — the same {path, keyword} pair at
  // most once (a repeated subschema via allOf/$ref must not double-report).
  const seen = new Set<string>();
  return errors.filter((e) => {
    const key = `${e.keyword}${e.path}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}
