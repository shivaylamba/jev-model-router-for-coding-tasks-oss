import type { Schema } from "./types.ts";
import { SchemaError } from "./types.ts";

/** Decode one JSON Pointer reference token (~1 → /, ~0 → ~; decode ~1 first). */
export function decodeToken(token: string): string {
  return token.replace(/~1/g, "/").replace(/~0/g, "~");
}

/**
 * Resolve a local $ref ("#" or "#/...") against the root schema.
 * Throws SchemaError for non-local refs or refs that point to nothing.
 */
export function resolveRef(ref: string, rootSchema: Schema): Schema {
  if (typeof ref !== "string" || !ref.startsWith("#")) {
    throw new SchemaError(`Unsupported $ref "${ref}": only local refs starting with "#" are supported`);
  }
  const pointer = ref.slice(1);
  if (pointer === "") return rootSchema;
  if (!pointer.startsWith("/")) {
    throw new SchemaError(`Unsupported $ref "${ref}": not a JSON Pointer`);
  }

  let current: unknown = rootSchema;
  for (const rawToken of pointer.slice(1).split("/")) {
    const token = decodeToken(rawToken);
    if (Array.isArray(current)) {
      const index = Number(token);
      if (!Number.isInteger(index) || index < 0 || index >= current.length) {
        throw new SchemaError(`Unresolvable $ref "${ref}": no element at "${token}"`);
      }
      current = current[index];
    } else if (typeof current === "object" && current !== null) {
      if (!Object.hasOwn(current, token)) {
        throw new SchemaError(`Unresolvable $ref "${ref}": no member "${token}"`);
      }
      current = (current as Record<string, unknown>)[token];
    } else {
      throw new SchemaError(`Unresolvable $ref "${ref}": cannot descend into "${token}"`);
    }
  }

  const isSchema =
    typeof current === "boolean" ||
    (typeof current === "object" && current !== null && !Array.isArray(current));
  if (!isSchema) {
    throw new SchemaError(`Unresolvable $ref "${ref}": target is not a schema`);
  }
  return current as Schema;
}
