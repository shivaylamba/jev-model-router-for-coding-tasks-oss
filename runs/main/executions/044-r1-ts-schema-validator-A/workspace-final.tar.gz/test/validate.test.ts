import { test } from "node:test";
import assert from "node:assert/strict";
import { SchemaError } from "../src/types.ts";
import { validate } from "../src/validate.ts";

test("type", () => {
  assert.deepEqual(validate({ type: "string" }, "x"), []);
  assert.deepEqual(validate({ type: "string" }, 1), [{ path: "", keyword: "type" }]);
  assert.deepEqual(validate({ type: ["string", "null"] }, null), []);
});

test("required points at the missing member", () => {
  assert.deepEqual(validate({ type: "object", required: ["id"] }, {}), [{ path: "/id", keyword: "required" }]);
});

test("properties validate nested members", () => {
  const schema = { properties: { user: { properties: { age: { type: "integer" } } } } };
  assert.deepEqual(validate(schema, { user: { age: 1.5 } }), [{ path: "/user/age", keyword: "type" }]);
});

test("boolean schemas", () => {
  assert.deepEqual(validate(true, { anything: 1 }), []);
  assert.deepEqual(validate(false, 1), [{ path: "", keyword: "false" }]);
});

test("enum with deep equality", () => {
  assert.deepEqual(validate({ enum: [1, "two"] }, 2), [{ path: "", keyword: "enum" }]);
  assert.deepEqual(validate({ enum: [1, "two"] }, "two"), []);
  // members in different order are still equal
  assert.deepEqual(validate({ enum: [{ a: 1, b: [2] }] }, { b: [2], a: 1 }), []);
  assert.deepEqual(validate({ enum: [{ a: 1 }] }, { a: 1, b: 2 }), [{ path: "", keyword: "enum" }]);
  // different JSON types are never equal
  assert.deepEqual(validate({ enum: ["1"] }, 1), [{ path: "", keyword: "enum" }]);
  assert.deepEqual(validate({ enum: [null] }, false), [{ path: "", keyword: "enum" }]);
});

test("const with deep equality", () => {
  assert.deepEqual(validate({ const: { a: [1, 2] } }, { a: [1, 2] }), []);
  assert.deepEqual(validate({ const: { a: [1, 2] } }, { a: [2, 1] }), [{ path: "", keyword: "const" }]);
});

test("keywords are independent — all failures reported", () => {
  const errors = validate({ type: "integer", minimum: 5 }, 1.5);
  assert.deepEqual(errors, [
    { path: "", keyword: "type" },
    { path: "", keyword: "minimum" },
  ]);
});

test("numeric bounds ignored for non-numbers", () => {
  assert.deepEqual(validate({ minimum: 5, maximum: 1 }, "x"), []);
  assert.deepEqual(validate({ exclusiveMinimum: 5 }, null), []);
});

test("numeric bounds are inclusive / exclusive", () => {
  assert.deepEqual(validate({ minimum: 5 }, 5), []);
  assert.deepEqual(validate({ maximum: 5 }, 5), []);
  assert.deepEqual(validate({ exclusiveMinimum: 5 }, 5), [{ path: "", keyword: "exclusiveMinimum" }]);
  assert.deepEqual(validate({ exclusiveMaximum: 5 }, 5), [{ path: "", keyword: "exclusiveMaximum" }]);
  assert.deepEqual(validate({ exclusiveMinimum: 5, exclusiveMaximum: 10 }, 7), []);
});

test("minLength / maxLength count code points", () => {
  assert.deepEqual(validate({ minLength: 2 }, "😀"), [{ path: "", keyword: "minLength" }]);
  assert.deepEqual(validate({ maxLength: 1 }, "😀"), []);
  assert.deepEqual(validate({ maxLength: 1 }, "ab"), [{ path: "", keyword: "maxLength" }]);
  // ignored for non-strings
  assert.deepEqual(validate({ minLength: 5 }, 1), []);
});

test("pattern with u flag, unanchored", () => {
  assert.deepEqual(validate({ pattern: "^ä+$" }, "ää"), []);
  assert.deepEqual(validate({ pattern: "bc" }, "abcd"), []);
  assert.deepEqual(validate({ pattern: "\\p{Emoji}" }, "hi 😀"), []);
  assert.deepEqual(validate({ pattern: "bc" }, "ad"), [{ path: "", keyword: "pattern" }]);
  // ignored for non-strings
  assert.deepEqual(validate({ pattern: "x" }, 7), []);
});

test("additionalProperties false reports each extra member", () => {
  const schema = { properties: { a: true }, additionalProperties: false };
  assert.deepEqual(validate(schema, { a: 1, b: 2, c: 3 }), [
    { path: "/b", keyword: "additionalProperties" },
    { path: "/c", keyword: "additionalProperties" },
  ]);
  assert.deepEqual(validate(schema, { a: 1 }), []);
  // without properties, every member is additional
  assert.deepEqual(validate({ additionalProperties: false }, { x: 1 }), [
    { path: "/x", keyword: "additionalProperties" },
  ]);
  // ignored for non-objects
  assert.deepEqual(validate({ additionalProperties: false }, [1]), []);
});

test("additionalProperties as schema validates extra members", () => {
  const schema = { properties: { a: true }, additionalProperties: { type: "string" } };
  assert.deepEqual(validate(schema, { a: 1, b: 2 }), [{ path: "/b", keyword: "type" }]);
  assert.deepEqual(validate(schema, { a: 1, b: "ok" }), []);
  assert.deepEqual(validate({ additionalProperties: true }, { x: 1 }), []);
});

test("minItems / maxItems", () => {
  assert.deepEqual(validate({ minItems: 2 }, [1]), [{ path: "", keyword: "minItems" }]);
  assert.deepEqual(validate({ maxItems: 1 }, [1, 2]), [{ path: "", keyword: "maxItems" }]);
  assert.deepEqual(validate({ minItems: 1, maxItems: 2 }, [1, 2]), []);
  // ignored for non-arrays
  assert.deepEqual(validate({ minItems: 5 }, "x"), []);
});

test("items validates every element at its index path", () => {
  const errors = validate({ items: { type: "integer" } }, [1, "x", 2.5]);
  assert.deepEqual(errors, [
    { path: "/1", keyword: "type" },
    { path: "/2", keyword: "type" },
  ]);
  assert.deepEqual(validate({ items: false }, [1]), [{ path: "/0", keyword: "false" }]);
});

test("uniqueItems reports a single error", () => {
  assert.deepEqual(validate({ uniqueItems: true }, [1, 2, 1, 2]), [
    { path: "", keyword: "uniqueItems" },
  ]);
  assert.deepEqual(validate({ uniqueItems: true }, [{ a: 1 }, { a: 1 }]), [
    { path: "", keyword: "uniqueItems" },
  ]);
  assert.deepEqual(validate({ uniqueItems: true }, [1, "1", { a: 1 }]), []);
  assert.deepEqual(validate({ uniqueItems: false }, [1, 1]), []);
  // ignored for non-arrays
  assert.deepEqual(validate({ uniqueItems: true }, "x"), []);
});

test("allOf reports subschema errors as-is", () => {
  const errors = validate({ allOf: [{ type: "integer" }, { minimum: 10 }] }, 2.5);
  assert.deepEqual(errors, [
    { path: "", keyword: "type" },
    { path: "", keyword: "minimum" },
  ]);
  assert.deepEqual(validate({ allOf: [{ type: "integer" }] }, 2), []);
});

test("anyOf reports one error only when nothing matches", () => {
  assert.deepEqual(validate({ anyOf: [{ type: "string" }, { type: "integer" }] }, 1.5), [
    { path: "", keyword: "anyOf" },
  ]);
  assert.deepEqual(validate({ anyOf: [{ type: "string" }, { type: "integer" }] }, 2), []);
  assert.deepEqual(validate({ anyOf: [{ type: "string" }, { minimum: 10 }] }, 20), []);
});

test("oneOf requires exactly one match", () => {
  const schema = { oneOf: [{ type: "number" }, { minimum: 0 }] };
  assert.deepEqual(validate(schema, 5), [{ path: "", keyword: "oneOf" }]); // both match
  assert.deepEqual(validate({ oneOf: [{ type: "string" }, { minimum: 0 }] }, -1), [
    { path: "", keyword: "oneOf" },
  ]); // none match
  assert.deepEqual(validate({ oneOf: [{ type: "string" }, { minimum: 0 }] }, 5), []);
});

test("oneOf does not leak subschema errors", () => {
  const errors = validate({ oneOf: [{ required: ["a"] }, { required: ["b"] }] }, {});
  // neither matches (each is missing its key) → single oneOf error at root
  assert.deepEqual(errors, [{ path: "", keyword: "oneOf" }]);
});

test("$ref resolves pointers in the root schema", () => {
  const schema = {
    definitions: { positive: { minimum: 1 } },
    properties: { count: { $ref: "#/definitions/positive" } },
  };
  assert.deepEqual(validate(schema, { count: 0 }), [{ path: "/count", keyword: "minimum" }]);
  assert.deepEqual(validate(schema, { count: 3 }), []);
});

test("$ref decodes escaped tokens", () => {
  const schema = {
    "a/b": { type: "string" },
    properties: { x: { $ref: "#/a~1b" } },
  };
  assert.deepEqual(validate(schema, { x: 1 }), [{ path: "/x", keyword: "type" }]);
});

test("$ref to array element", () => {
  const schema = { allOf: [{ type: "integer" }, { $ref: "#/allOf/0" }] };
  assert.deepEqual(validate(schema, "x"), [{ path: "", keyword: "type" }]);
});

test("$ref to root (#)", () => {
  const schema = { type: "object", properties: { child: { $ref: "#" } } };
  assert.deepEqual(validate(schema, { child: { child: {} } }), []);
  assert.deepEqual(validate(schema, { child: 1 }), [{ path: "/child", keyword: "type" }]);
});

test("recursive $ref (tree schema)", () => {
  const schema = {
    type: "object",
    required: ["name"],
    properties: {
      name: { type: "string" },
      children: { type: "array", items: { $ref: "#" } },
    },
  };
  const bad = { name: "a", children: [{ name: "b", children: [{ children: [] }] }] };
  assert.deepEqual(validate(schema, bad), [{ path: "/children/0/children/0/name", keyword: "required" }]);
  const good = { name: "a", children: [{ name: "b", children: [] }] };
  assert.deepEqual(validate(schema, good), []);
});

test("self-referencing $ref cycle does not hang", () => {
  const schema = { allOf: [{ $ref: "#" }], type: "string" };
  assert.deepEqual(validate(schema, 1), [{ path: "", keyword: "type" }]);
});

test("bad $ref throws SchemaError when reached", () => {
  assert.throws(() => validate({ $ref: "https://x.com/s.json" }, 1), SchemaError);
  assert.throws(() => validate({ $ref: "#/nope" }, 1), SchemaError);
  assert.throws(() => validate({ $ref: "#/definitions/9" }, 1), SchemaError);
  assert.throws(() => validate({ $ref: "#nope" }, 1), SchemaError);
  // not reached → no throw
  assert.deepEqual(validate({ properties: { a: { $ref: "#/missing" } } }, { b: 1 }), []);
  // keywords next to $ref are not evaluated when the throw happens
  assert.throws(() => validate({ $ref: "#/missing", type: "string" }, "ok"), SchemaError);
});

test("error list contains no duplicates", () => {
  // same subschema applied twice via allOf + $ref would report twice
  const schema = { allOf: [{ minimum: 5 }, { $ref: "#/allOf/0" }] };
  const errors = validate(schema, 1);
  const keys = errors.map((e) => `${e.path} ${e.keyword}`);
  assert.equal(new Set(keys).size, keys.length);
});
