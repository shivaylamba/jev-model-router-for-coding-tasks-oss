"""Function decorators."""

import functools
from collections import namedtuple


CacheInfo = namedtuple("CacheInfo", ["hits", "misses", "size"])


def once(func):
    """Call `func` the first time only; later calls return the first result."""
    result = []

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        if not result:
            result.append(func(*args, **kwargs))
        return result[0]

    return wrapper


def memoize(func):
    """Cache `func`'s return value per distinct set of arguments.

    Keyword arguments are matched by name, so call order doesn't matter,
    but positional and keyword spellings of the same call are cached as
    separate entries. Results that are None are cached like any other
    value; exceptions are never cached.
    """
    cache = {}
    hits = [0]
    misses = [0]

    # Positional and keyword forms of the same call get distinct keys: the
    # marker inside each keyword tuple separates (1, 2) from (1, ("b", 2)).
    def make_key(args, kwargs):
        return args, tuple((name, value) for name, value in sorted(kwargs.items()))

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        key = make_key(args, kwargs)
        try:
            hash(key)
        except TypeError:
            raise TypeError(
                f"unhashable arguments to memoized {func.__name__}"
            ) from None
        if key in cache:
            hits[0] += 1
            return cache[key][0]
        misses[0] += 1
        result = func(*args, **kwargs)
        cache[key] = [result]
        return result

    def cache_info():
        return CacheInfo(hits=hits[0], misses=misses[0], size=len(cache))

    def cache_clear():
        cache.clear()
        hits[0] = 0
        misses[0] = 0

    wrapper.cache_info = cache_info
    wrapper.cache_clear = cache_clear
    return wrapper
