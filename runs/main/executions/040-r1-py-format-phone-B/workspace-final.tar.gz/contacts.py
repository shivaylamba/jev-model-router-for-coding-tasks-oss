"""Formatting helpers for contact records."""


def format_name(first, last):
    """'ada', 'LOVELACE' -> 'Ada Lovelace'. Blank parts are skipped."""
    parts = [p.strip().capitalize() for p in (first, last) if p and p.strip()]
    return " ".join(parts)


def normalize_email(email):
    """Trim and lowercase an e-mail address."""
    return email.strip().lower()


_DIGITS = set("0123456789")
_IGNORED = set(" ()-.+")  # separators users type but we don't care about


def format_us_phone(raw):
    """'415-555-0123' -> '(415) 555-0123'. A leading country-code '1' is
    dropped; anything that isn't a valid US number raises ValueError."""
    digits = "".join(c for c in raw if c not in _IGNORED)
    if not all(c in _DIGITS for c in digits):
        raise ValueError(f"invalid characters in phone number: {raw!r}")
    if len(digits) == 11 and digits[0] == "1":
        digits = digits[1:]
    if len(digits) != 10:
        raise ValueError(f"phone number needs 10 digits (or 11 with a leading 1): {raw!r}")
    if digits[0] in "01" or digits[3] in "01":
        raise ValueError(f"area code and exchange must start with 2-9: {raw!r}")
    return f"({digits[:3]}) {digits[3:6]}-{digits[6:]}"
