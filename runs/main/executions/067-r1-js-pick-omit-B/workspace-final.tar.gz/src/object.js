/**
 * True for objects created by `{}`, `Object.create(null)` or `new Object()`.
 * @param {unknown} value
 * @returns {boolean}
 */
export function isPlainObject(value) {
  if (value === null || typeof value !== "object") return false;
  const proto = Object.getPrototypeOf(value);
  return proto === null || proto === Object.prototype;
}

/**
 * A new object with the same own enumerable keys, each value passed through `fn(value, key)`.
 * @param {Record<string, unknown>} obj
 * @param {(value: unknown, key: string) => unknown} fn
 */
export function mapValues(obj, fn) {
  const out = {};
  for (const key of Object.keys(obj)) out[key] = fn(obj[key], key);
  return out;
}

/**
 * A new object with only the listed `keys` that `obj` has as own enumerable
 * properties, in the order they appear in `keys`. Missing, inherited and
 * non-enumerable keys are skipped; a key whose value is `undefined` is kept.
 * @param {Record<string, unknown>} obj
 * @param {string[]} keys
 */
export function pick(obj, keys) {
  const out = {};
  for (const key of keys) {
    if (Object.prototype.propertyIsEnumerable.call(obj, key)) out[key] = obj[key];
  }
  return out;
}

/**
 * A new object with every own enumerable key of `obj` except the listed ones,
 * in the original key order. Keys `obj` does not have are ignored.
 * @param {Record<string, unknown>} obj
 * @param {string[]} keys
 */
export function omit(obj, keys) {
  const excluded = new Set(keys);
  const out = {};
  for (const key of Object.keys(obj)) {
    if (!excluded.has(key)) out[key] = obj[key];
  }
  return out;
}
