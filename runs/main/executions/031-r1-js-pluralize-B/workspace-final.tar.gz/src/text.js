/**
 * Upper-case the first character.
 * @param {string} s
 */
export function capitalize(s) {
  return s.length === 0 ? s : s[0].toUpperCase() + s.slice(1);
}

/**
 * Shorten to at most `max` characters, ending with "…" when cut.
 * @param {string} s
 * @param {number} max
 */
export function truncate(s, max) {
  return s.length <= max ? s : s.slice(0, Math.max(0, max - 1)) + "…";
}

/**
 * A count with the matching word form: `pluralize(1, "file")` is
 * `"1 file"`, `pluralize(0, "file")` is `"0 files"`.
 * @param {number} count
 * @param {string} singular
 * @param {string} [plural]
 */
export function pluralize(count, singular, plural) {
  if (typeof count !== "number" || !Number.isFinite(count)) {
    throw new TypeError("count must be a finite number");
  }
  const word = count === 1 ? singular : plural ?? pluralOf(singular);
  return String(count) + " " + word;
}

/**
 * Build the plural form of `singular`: buses, boxes, cities, days, files.
 * @param {string} singular
 */
function pluralOf(singular) {
  if (["s", "x", "z", "ch", "sh"].some((end) => singular.endsWith(end))) {
    return singular + "es";
  }
  const before = singular.at(-2);
  if (singular.endsWith("y") && before !== undefined && !"aeiou".includes(before)) {
    return singular.slice(0, -1) + "ies";
  }
  return singular + "s";
}
