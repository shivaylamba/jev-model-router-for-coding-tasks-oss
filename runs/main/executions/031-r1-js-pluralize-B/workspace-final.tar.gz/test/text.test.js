import { test } from "node:test";
import assert from "node:assert/strict";
import { capitalize, pluralize, truncate } from "../src/text.js";

test("capitalize", () => {
  assert.equal(capitalize("hello"), "Hello");
  assert.equal(capitalize(""), "");
});

test("truncate", () => {
  assert.equal(truncate("abcdef", 10), "abcdef");
  assert.equal(truncate("abcdef", 4), "abc…");
});

test("pluralize", () => {
  assert.equal(pluralize(1, "file"), "1 file");
  assert.equal(pluralize(0, "file"), "0 files");
  assert.equal(pluralize(2, "file"), "2 files");
  assert.equal(pluralize(-3, "city"), "-3 cities");
  assert.equal(pluralize(1.5, "day"), "1.5 days");
  assert.equal(pluralize(2, "child", "children"), "2 children");
  assert.equal(pluralize(2, "bus"), "2 buses");
  assert.equal(pluralize(2, "box"), "2 boxes");
  assert.equal(pluralize(2, "quiz"), "2 quizes");
  assert.equal(pluralize(2, "match"), "2 matches");
  assert.throws(() => pluralize(NaN, "file"), TypeError);
  assert.throws(() => pluralize(Infinity, "file"), TypeError);
  assert.throws(() => pluralize("2", "file"), TypeError);
});
