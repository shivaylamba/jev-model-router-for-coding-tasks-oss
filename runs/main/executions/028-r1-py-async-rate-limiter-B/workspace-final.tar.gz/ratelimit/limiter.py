"""Asyncio rate limiter: per-key token buckets plus a global concurrency cap.

See SPEC.md for the full behaviour.
"""

import asyncio
from collections import deque

from .bucket import TokenBucket


class _KeyState:
    """A key's bucket plus its FIFO queue of pending requests."""

    __slots__ = ("bucket", "queue")

    def __init__(self, rate, burst, clock):
        self.bucket = TokenBucket(rate, burst, clock)
        self.queue = deque()


class _Request:
    """One pending acquire: FIFO position, grant state, and its wakeup event."""

    __slots__ = ("seq", "key", "state", "granted", "event")

    def __init__(self, seq, key, state):
        self.seq = seq
        self.key = key
        self.state = state
        self.granted = False
        self.event = asyncio.Event()

    @property
    def is_head(self):
        return bool(self.state.queue) and self.state.queue[0] is self


class _Grant:
    """Returned by acquire(); consumed by release()."""

    __slots__ = ("_limiter", "_released")

    def __init__(self, limiter):
        self._limiter = limiter
        self._released = False

    def release(self):
        if self._released:
            raise RuntimeError("release() called twice on the same grant")
        self._released = True
        self._limiter._release()


class _LimiterContext:
    """Async context manager returned by limit(key)."""

    __slots__ = ("_limiter", "_key", "_grant")

    def __init__(self, limiter, key):
        self._limiter = limiter
        self._key = key
        self._grant = None

    async def __aenter__(self):
        self._grant = await self._limiter.acquire(self._key)
        return self

    async def __aexit__(self, exc_type, exc, tb):
        self._grant.release()
        return False


class RateLimiter:
    def __init__(self, rate, burst, max_concurrent, *, clock, sleep):
        if not isinstance(rate, (int, float)) or isinstance(rate, bool) or rate <= 0:
            raise ValueError("rate must be a number > 0")
        if isinstance(burst, bool) or not isinstance(burst, int) or burst < 1:
            raise ValueError("burst must be an int >= 1")
        if (
            isinstance(max_concurrent, bool)
            or not isinstance(max_concurrent, int)
            or max_concurrent < 1
        ):
            raise ValueError("max_concurrent must be an int >= 1")
        self._rate = rate
        self._burst = burst
        self._max_concurrent = max_concurrent
        self._clock = clock
        self._sleep = sleep
        self._keys = {}
        self._seq = 0
        self._in_use = 0
        # A single sleeper task (started lazily in an async context) performs
        # every sleep() on behalf of the limiter; waiting tasks never sleep
        # themselves, so cancelling one cannot cancel a scheduled wait.
        self._sleeper = None
        self._wake = None

    # -- introspection -----------------------------------------------------

    @property
    def in_use(self):
        return self._in_use

    def tokens(self, key):
        state = self._keys.get(key)
        if state is None:
            return float(self._burst)
        return state.bucket.available()

    def waiting(self, key=None):
        if key is None:
            return sum(len(s.queue) for s in self._keys.values())
        state = self._keys.get(key)
        return len(state.queue) if state is not None else 0

    # -- public operations -------------------------------------------------

    async def acquire(self, key):
        """Wait until a request for `key` is granted (one token and one slot)."""
        self._ensure_sleeper()
        state = self._keys.get(key)
        if state is None:
            state = self._keys[key] = _KeyState(self._rate, self._burst, self._clock)
        self._seq += 1
        request = _Request(self._seq, key, state)
        state.queue.append(request)
        self._grant_pass()
        if request.granted:
            return _Grant(self)
        try:
            await request.event.wait()
        except BaseException:
            # Cancelled (or otherwise unwound) before acquire returned.
            if request.granted:
                # Granted but never resumed: undo the grant.
                request.granted = False
                self._in_use -= 1
                state.bucket.put_back()
            else:
                try:
                    state.queue.remove(request)
                except ValueError:
                    pass
            self._grant_pass()
            raise
        return _Grant(self)

    def release(self):
        """Free one slot."""
        if self._in_use <= 0:
            raise RuntimeError("release() with no slot held")
        self._in_use -= 1
        self._grant_pass()

    def limit(self, key):
        """Async context manager: acquire on entry, release on exit."""
        return _LimiterContext(self, key)

    # -- internals ---------------------------------------------------------

    def _release(self):
        self._in_use -= 1
        self._grant_pass()

    def _ensure_sleeper(self):
        if self._sleeper is None:
            self._wake = asyncio.Event()
            self._sleeper = asyncio.create_task(self._sleeper_loop())

    def _grant_pass(self):
        """Grant the eligible head whose acquire came first; repeat.

        A head is eligible when its bucket has a token and a slot is free.
        Heads that lack only a slot never sleep; heads that lack a token are
        served by the sleeper task.
        """
        while self._in_use < self._max_concurrent:
            best = None
            for state in self._keys.values():
                if not state.queue:
                    continue
                head = state.queue[0]
                if state.bucket.available() < 1:
                    continue
                if best is None or head.seq < best.seq:
                    best = head
            if best is None:
                break
            best.state.queue.popleft()
            best.state.bucket.try_take()
            best.granted = True
            self._in_use += 1
            best.event.set()
        if self._wake is not None:
            # (Re)schedule the token wait; the sleeper recomputes the delay.
            self._wake.set()

    async def _sleeper_loop(self):
        """Performs every sleep() for the limiter, exactly one sleep per wait.

        Sleeps precisely the time until the earliest head's bucket reaches one
        token (computed from clock() at that moment), then runs a grant pass.
        Heads that only lack a slot are not waited on here.
        """
        wake = self._wake
        while True:
            await wake.wait()
            wake.clear()
            deadline = None
            for state in self._keys.values():
                if not state.queue:
                    continue
                wait = state.bucket.time_until_available()
                if wait <= 0:
                    # Head already has a token; only a slot could be missing,
                    # and slot waits are resolved by release/cancellation.
                    continue
                need_at = self._clock() + wait
                if deadline is None or need_at < deadline:
                    deadline = need_at
            if deadline is None:
                continue  # nothing to wait for; park until the next grant pass
            delay = deadline - self._clock()
            if delay > 0:
                # Re-check for new state before committing to the sleep;
                # _grant_pass() pokes `wake` again if anything changed.
                await asyncio.sleep(0)
                if wake.is_set():
                    continue
                await self._sleep(delay)
            self._grant_pass()
