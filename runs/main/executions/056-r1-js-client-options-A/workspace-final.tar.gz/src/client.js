import { deprecate } from "./deprecate.js";

const KNOWN_OPTIONS = new Set(["baseUrl", "token", "timeoutMs", "retries", "headers"]);

/**
 * Create an API client.
 *
 * Preferred form — options object:
 *   createClient({ baseUrl, token, timeoutMs = 5000, retries = 0, headers = {} })
 *
 * @param {string}   options.baseUrl     e.g. "https://api.internal.example"; trailing slashes are removed
 * @param {string}   [options.token]     bearer token; no Authorization header when omitted
 * @param {number}   [options.timeoutMs=5000]
 * @param {number}   [options.retries=0]
 * @param {object}   [options.headers]   extra headers added to every request
 *
 * Deprecated positional form (kept for external callers):
 *   createClient(baseUrl, token, timeoutMs, retries)
 */
export function createClient(baseUrl, token, timeoutMs, retries) {
  const raw = typeof baseUrl === "string" ? fromPositional(baseUrl, token, timeoutMs, retries) : baseUrl;
  const options = Object.freeze(normalize(raw));

  return {
    options,
    /**
     * Describe a request and pass it to `transport`, returning whatever the transport returns.
     */
    request(transport, method, path, body) {
      const headers = { accept: "application/json", ...options.headers };
      if (options.token) headers.authorization = `Bearer ${options.token}`;
      if (body !== undefined) headers["content-type"] = "application/json";
      return transport({
        method,
        url: options.baseUrl + (path.startsWith("/") ? path : `/${path}`),
        headers,
        body: body === undefined ? undefined : JSON.stringify(body),
        timeoutMs: options.timeoutMs,
        retries: options.retries,
      });
    },
  };
}

function fromPositional(baseUrl, token, timeoutMs, retries) {
  deprecate(
    "CLIENT_POSITIONAL_ARGS",
    "createClient(baseUrl, token, timeoutMs, retries) is deprecated; use createClient({ baseUrl, token, timeoutMs, retries, headers }) instead."
  );
  return { baseUrl, token, timeoutMs, retries };
}

function normalize(options) {
  if (options === null || typeof options !== "object" || Array.isArray(options)) {
    throw new TypeError("createClient expects an options object: createClient({ baseUrl, token, timeoutMs, retries, headers })");
  }

  for (const name of Object.keys(options)) {
    if (!KNOWN_OPTIONS.has(name)) {
      throw new TypeError(`Unknown option "${name}"; expected one of: ${[...KNOWN_OPTIONS].join(", ")}`);
    }
  }

  const { baseUrl, token, timeoutMs = 5000, retries = 0, headers = {} } = options;

  if (typeof baseUrl !== "string" || baseUrl === "") {
    throw new TypeError("baseUrl must be a non-empty string");
  }
  if (typeof timeoutMs !== "number" || !Number.isFinite(timeoutMs) || timeoutMs <= 0) {
    throw new RangeError("timeoutMs must be a finite number greater than 0");
  }
  if (typeof retries !== "number" || !Number.isInteger(retries) || retries < 0) {
    throw new RangeError("retries must be an integer >= 0");
  }

  return {
    baseUrl: baseUrl.replace(/\/+$/, ""),
    token,
    timeoutMs,
    retries,
    headers,
  };
}
