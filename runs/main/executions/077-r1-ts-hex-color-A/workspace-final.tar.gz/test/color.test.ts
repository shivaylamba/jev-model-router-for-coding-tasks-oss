import { test } from "node:test";
import assert from "node:assert/strict";
import { normalizeHexColor, rgbToHex } from "../src/color.ts";

test("rgbToHex", () => {
  assert.equal(rgbToHex(255, 136, 0), "#ff8800");
  assert.throws(() => rgbToHex(256, 0, 0), RangeError);
});

test("normalizeHexColor lowercases 6- and 8-digit forms", () => {
  assert.equal(normalizeHexColor("#FF8800"), "#ff8800");
  assert.equal(normalizeHexColor("#11223344"), "#11223344");
  assert.equal(normalizeHexColor("#AABBCCDD"), "#aabbccdd");
});

test("normalizeHexColor expands 3- and 4-digit forms", () => {
  assert.equal(normalizeHexColor("#AbC"), "#aabbcc");
  assert.equal(normalizeHexColor("#abcd"), "#aabbccdd");
  assert.equal(normalizeHexColor("#FFFF"), "#ffffffff");
});

test("normalizeHexColor keeps the alpha channel, even when ff", () => {
  assert.equal(normalizeHexColor("#ff8800ff"), "#ff8800ff");
  assert.equal(normalizeHexColor("#f80f"), "#ff8800ff");
});

test("normalizeHexColor ignores surrounding whitespace", () => {
  assert.equal(normalizeHexColor("  #ff8800  "), "#ff8800");
  assert.equal(normalizeHexColor("\t#abc\n"), "#aabbcc");
});

test("normalizeHexColor rejects invalid input", () => {
  for (const bad of [
    "ff8800", // missing "#"
    "##ff8800", // more than one "#"
    "#1", // wrong digit counts
    "#12",
    "#12345",
    "#1234567",
    "#123456789",
    "#gggggg", // non-hex characters
    "#ff 8800", // whitespace inside the value
    "# ff8800",
    "red", // named colours
    "",
    "   ",
    "#",
  ]) {
    assert.equal(normalizeHexColor(bad), null, JSON.stringify(bad));
  }
});
