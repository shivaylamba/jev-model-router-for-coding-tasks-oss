function channel(value: number): string {
  if (!Number.isInteger(value) || value < 0 || value > 255) {
    throw new RangeError(`colour channel out of range: ${value}`);
  }
  return value.toString(16).padStart(2, "0");
}

/** Format RGB channels (0-255) as a lowercase "#rrggbb" string. */
export function rgbToHex(r: number, g: number, b: number): string {
  return `#${channel(r)}${channel(g)}${channel(b)}`;
}

/**
 * Normalize a hex colour string to its canonical lowercase form.
 *
 * Accepts "#rgb", "#rgba", "#rrggbb" and "#rrggbbaa" (any letter case,
 * optional surrounding whitespace). Short forms are expanded by doubling
 * each digit. Returns null for anything else.
 */
export function normalizeHexColor(input: string): string | null {
  const match = /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.exec(
    input.trim(),
  );
  if (!match) return null;

  const digits = match[1].toLowerCase();
  if (digits.length <= 4) {
    return `#${[...digits].map((d) => d + d).join("")}`;
  }
  return `#${digits}`;
}
