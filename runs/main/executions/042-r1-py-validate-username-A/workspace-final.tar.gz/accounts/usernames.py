"""Username helpers."""

RESERVED = frozenset({"admin", "root", "support", "moderator"})


def normalize_username(raw):
    """Trim surrounding whitespace and lowercase a username as typed at signup."""
    return raw.strip().lower()


def is_reserved(name):
    """Whether a (normalized) username is reserved for staff accounts."""
    return name in RESERVED


SEPARATORS = "._-"


def is_valid_username(name):
    """Whether a normalized username is well-formed enough to sign up with.

    Expects output of normalize_username: 3-20 chars starting with a
    lowercase ASCII letter, made of lowercase ASCII letters, digits, and
    single separators, never two separators in a row, never ending on one.
    Reserved names are a separate concern; see is_reserved.
    """
    if not isinstance(name, str):
        return False
    if not 3 <= len(name) <= 20:
        return False
    if not "a" <= name[0] <= "z":
        return False
    if name[-1] in SEPARATORS:
        return False
    prev_was_separator = False
    for ch in name:
        if ch in SEPARATORS:
            if prev_was_separator:
                return False
            prev_was_separator = True
        elif "a" <= ch <= "z" or "0" <= ch <= "9":
            prev_was_separator = False
        else:
            return False
    return True
