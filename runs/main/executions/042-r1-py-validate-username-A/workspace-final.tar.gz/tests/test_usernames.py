import unittest

from accounts.usernames import is_reserved, is_valid_username, normalize_username


class NormalizeTest(unittest.TestCase):
    def test_normalize(self):
        self.assertEqual(normalize_username("  Ada.L "), "ada.l")

    def test_reserved(self):
        self.assertTrue(is_reserved("admin"))
        self.assertFalse(is_reserved("ada"))


class IsValidUsernameTest(unittest.TestCase):
    def test_valid_names(self):
        for name in ("ada", "ada.l", "ada_lovelace", "a-b-c", "a1b2c3", "x" * 20):
            with self.subTest(name=name):
                self.assertTrue(is_valid_username(name))

    def test_non_str(self):
        for value in (None, 123, b"ada", ["a", "d", "a"]):
            with self.subTest(value=value):
                self.assertFalse(is_valid_username(value))

    def test_length_bounds(self):
        self.assertFalse(is_valid_username("ab"))
        self.assertTrue(is_valid_username("abc"))
        self.assertTrue(is_valid_username("a" * 20))
        self.assertFalse(is_valid_username("a" * 21))

    def test_must_start_with_lowercase_letter(self):
        self.assertFalse(is_valid_username("1abc"))
        self.assertFalse(is_valid_username(".abc"))
        self.assertFalse(is_valid_username("_abc"))
        self.assertFalse(is_valid_username("Zbc"))

    def test_allowed_characters(self):
        self.assertFalse(is_valid_username("adA"))
        self.assertFalse(is_valid_username("ad "))
        self.assertFalse(is_valid_username("ad!"))
        self.assertFalse(is_valid_username("adé"))

    def test_no_adjacent_separators(self):
        self.assertFalse(is_valid_username("a..b"))
        self.assertFalse(is_valid_username("a._b"))
        self.assertFalse(is_valid_username("a-.b"))
        self.assertTrue(is_valid_username("a.b_c-d"))

    def test_no_trailing_separator(self):
        self.assertFalse(is_valid_username("ada."))
        self.assertFalse(is_valid_username("ada_"))
        self.assertFalse(is_valid_username("ada-"))

    def test_reserved_is_separate(self):
        self.assertTrue(is_valid_username("admin"))


if __name__ == "__main__":
    unittest.main()
