import { readFile } from "node:fs";

export type Config = {
  host: string;
  port: number;
  debug: boolean;
};

export type ConfigCallback = (err: Error | null, config?: Config) => void;

/** Thrown (or passed to the callback) when the file parses but holds bad values. */
export class ConfigError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ConfigError";
  }
}

export const DEFAULTS: Config = { host: "localhost", port: 8080, debug: false };

/** Merge parsed JSON over the defaults and check the values. */
export function applyDefaults(raw: unknown): Config {
  if (raw === null || typeof raw !== "object" || Array.isArray(raw)) {
    throw new ConfigError("config must be a JSON object");
  }
  const config = { ...DEFAULTS, ...(raw as Partial<Config>) };
  if (!Number.isInteger(config.port) || config.port < 1 || config.port > 65535) {
    throw new ConfigError(`invalid port: ${config.port}`);
  }
  if (typeof config.host !== "string" || config.host === "") {
    throw new ConfigError("host must be a non-empty string");
  }
  if (typeof config.debug !== "boolean") {
    throw new ConfigError("debug must be a boolean");
  }
  return config;
}

/**
 * Read and validate a JSON config file.
 *
 * Called with a callback, it behaves as a classic Node-style async function:
 * the callback fires exactly once with (err) on failure or (null, config) on
 * success, and readConfig returns undefined. Called without a callback, it
 * returns a Promise that resolves with the same merged, validated config and
 * rejects with the same errors — the file-system error as-is (for example
 * ENOENT), a SyntaxError for malformed JSON, or a ConfigError for bad values.
 */
export function readConfig(path: string): Promise<Config>;
export function readConfig(path: string, callback: ConfigCallback): void;
export function readConfig(
  path: string,
  callback?: ConfigCallback,
): Promise<Config> | void {
  const promise = new Promise<Config>((resolve, reject) => {
    readFile(path, "utf8", (err, text) => {
      if (err) {
        reject(err);
        return;
      }
      try {
        resolve(applyDefaults(JSON.parse(text)));
      } catch (parseErr) {
        reject(parseErr as Error);
      }
    });
  });

  if (callback === undefined) {
    return promise;
  }

  // Callback form: deliver the outcome and keep the promise settled so a
  // failure cannot also surface as an unhandled rejection.
  promise.then(
    (config) => callback(null, config),
    (err) => callback(err as Error),
  );
}
