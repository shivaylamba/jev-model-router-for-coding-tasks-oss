export const MINUTES_PER_DAY = 24 * 60;

/** Format minutes after midnight as zero-padded 24-hour "HH:MM". */
export function formatClock(minutes: number): string {
  if (!Number.isInteger(minutes) || minutes < 0 || minutes >= MINUTES_PER_DAY) {
    throw new RangeError(`minutes out of range: ${minutes}`);
  }
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return `${String(hours).padStart(2, "0")}:${String(mins).padStart(2, "0")}`;
}

// 24-hour "H:MM" or "HH:MM".
const CLOCK_24 = /^(\d{1,2}):(\d{2})$/;
// 12-hour "H[:MM]" followed by am/pm, any letter case, optional space before it.
const CLOCK_12 = /^(\d{1,2})(?::(\d{2}))?\s*(am|pm)$/i;

/** Parse a 24-hour or 12-hour clock string into minutes after midnight. */
export function parseClock(input: string): number {
  const text = input.trim();

  const match24 = CLOCK_24.exec(text);
  if (match24) {
    const hours = Number(match24[1]);
    const minutes = Number(match24[2]);
    if (hours > 23 || minutes > 59) {
      throw new RangeError(`time out of range: ${text}`);
    }
    return hours * 60 + minutes;
  }

  const match12 = CLOCK_12.exec(text);
  if (match12) {
    const hours = Number(match12[1]);
    const minutes = match12[2] === undefined ? 0 : Number(match12[2]);
    if (hours < 1 || hours > 12 || minutes > 59) {
      throw new RangeError(`time out of range: ${text}`);
    }
    const pm = match12[3].toLowerCase() === "pm";
    const clockHours = (hours % 12) + (pm ? 12 : 0);
    return clockHours * 60 + minutes;
  }

  throw new SyntaxError(`not a clock time: ${text}`);
}
