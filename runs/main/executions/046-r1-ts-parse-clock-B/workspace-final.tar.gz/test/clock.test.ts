import { test } from "node:test";
import assert from "node:assert/strict";
import { formatClock, parseClock } from "../src/clock.ts";

test("formatClock pads hours and minutes", () => {
  assert.equal(formatClock(0), "00:00");
  assert.equal(formatClock(19 * 60 + 5), "19:05");
});

test("formatClock rejects out-of-range minutes", () => {
  assert.throws(() => formatClock(1440), RangeError);
});

test("parseClock accepts 24-hour times", () => {
  assert.equal(parseClock("19:30"), 19 * 60 + 30);
  assert.equal(parseClock("7:05"), 7 * 60 + 5);
  assert.equal(parseClock("0:00"), 0);
  assert.equal(parseClock("  23:59  "), 23 * 60 + 59);
});

test("parseClock accepts 12-hour times", () => {
  assert.equal(parseClock("7:30 pm"), 19 * 60 + 30);
  assert.equal(parseClock("7pm"), 19 * 60);
  assert.equal(parseClock("9 Am"), 9 * 60);
  assert.equal(parseClock("12:15 am"), 15);
  assert.equal(parseClock("12pm"), 12 * 60);
  assert.equal(parseClock("7:30PM"), 19 * 60 + 30);
});

test("parseClock throws RangeError for out-of-range numbers", () => {
  assert.throws(() => parseClock("24:00"), RangeError);
  assert.throws(() => parseClock("7:60"), RangeError);
  assert.throws(() => parseClock("13pm"), RangeError);
  assert.throws(() => parseClock("0am"), RangeError);
});

test("parseClock throws SyntaxError for other junk", () => {
  for (const bad of ["", "7", "7:5", "noon", "7:30 p.m."]) {
    assert.throws(() => parseClock(bad), SyntaxError);
  }
});
