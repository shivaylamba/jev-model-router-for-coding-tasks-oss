import { test } from "node:test";
import assert from "node:assert/strict";
import { WeightedLRU } from "../src/weightedLru.ts";

test("rejects a bad maxWeight", () => {
  for (const bad of [0, -1, NaN, Infinity, -Infinity]) {
    assert.throws(() => new WeightedLRU({ maxWeight: bad }), RangeError);
  }
});

test("defaults to counting entries", () => {
  const cache = new WeightedLRU<string, number>({ maxWeight: 2 });
  cache.set("a", 1);
  cache.set("b", 2);
  cache.set("c", 3);
  assert.equal(cache.has("a"), false);
  assert.equal(cache.size, 2);
  assert.equal(cache.totalWeight, 2);
});

test("evicts least recently used by weight until it fits", () => {
  const evicted: string[] = [];
  const cache = new WeightedLRU<string, number>({
    maxWeight: 5,
    weigh: (v) => v,
    onEvict: (k) => evicted.push(k),
  });
  cache.set("a", 2);
  cache.set("b", 2);
  cache.set("c", 2); // evicts a (oldest first)
  assert.deepEqual(evicted, ["a"]);
  assert.equal(cache.totalWeight, 4);
  assert.deepEqual(cache.keys(), ["b", "c"]);
});

test("a hit makes the entry most recently used", () => {
  const cache = new WeightedLRU<string, number>({ maxWeight: 5, weigh: (v) => v });
  cache.set("a", 2);
  cache.set("b", 2);
  cache.get("a");
  cache.set("c", 2);
  assert.equal(cache.has("b"), false);
  assert.equal(cache.get("a"), 2);
});

test("peek and has do not touch recency or stats", () => {
  const cache = new WeightedLRU<string, number>({ maxWeight: 5, weigh: (v) => v });
  cache.set("a", 2);
  cache.set("b", 2);
  assert.equal(cache.peek("a"), 2);
  assert.equal(cache.has("a"), true);
  cache.set("c", 2);
  assert.equal(cache.has("a"), false); // a untouched, still oldest
  assert.deepEqual(cache.stats(), { hits: 0, misses: 0, evictions: 1 });
});

test("zero and fractional weights work", () => {
  const cache = new WeightedLRU<string, number>({ maxWeight: 1, weigh: (v) => v });
  assert.equal(cache.set("free", 0), true);
  assert.equal(cache.set("half", 0.5), true);
  assert.equal(cache.totalWeight, 0.5);
  assert.equal(cache.size, 2);
});

test("rejects negative, NaN or infinite weights without storing", () => {
  const cache = new WeightedLRU<string, number>({ maxWeight: 5, weigh: (v) => v });
  for (const bad of [-1, NaN, Infinity]) {
    assert.throws(() => cache.set("x", bad), RangeError);
  }
  assert.equal(cache.size, 0);
  assert.equal(cache.has("x"), false);
});

test("an entry heavier than maxWeight is refused, keeping any old value", () => {
  const cache = new WeightedLRU<string, number>({ maxWeight: 5, weigh: (v) => v });
  cache.set("k", 3);
  assert.equal(cache.set("k", 6), false);
  assert.equal(cache.get("k"), 3);
  assert.equal(cache.totalWeight, 3);
  assert.deepEqual(cache.stats().evictions, 0);
});

test("replacing a key updates weight and recency and is not an eviction", () => {
  const evicted: string[] = [];
  const cache = new WeightedLRU<string, number>({
    maxWeight: 5,
    weigh: (v) => v,
    onEvict: (k) => evicted.push(k),
  });
  cache.set("k", 3);
  cache.set("k", 5);
  assert.equal(cache.totalWeight, 5);
  assert.deepEqual(evicted, []);
  assert.deepEqual(cache.keys(), ["k"]);
});

test("delete and clear do not call onEvict; clear keeps stats", () => {
  const evicted: string[] = [];
  const cache = new WeightedLRU<string, number>({
    maxWeight: 2,
    weigh: (v) => v,
    onEvict: (k) => evicted.push(k),
  });
  cache.set("a", 1);
  cache.get("a");
  cache.get("missing");
  assert.equal(cache.delete("a"), true);
  assert.equal(cache.delete("a"), false);
  cache.set("b", 1);
  cache.clear();
  assert.equal(cache.size, 0);
  assert.equal(cache.totalWeight, 0);
  assert.deepEqual(evicted, []);
  assert.deepEqual(cache.stats(), { hits: 1, misses: 1, evictions: 0 });
});
