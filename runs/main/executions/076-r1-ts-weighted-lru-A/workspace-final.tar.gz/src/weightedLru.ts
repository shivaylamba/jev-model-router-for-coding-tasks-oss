/**
 * A least-recently-used cache bounded by total entry weight instead of entry
 * count (e.g. bytes for cached thumbnails). A Map keeps insertion order, so
 * re-inserting a key moves it to the end (most recently used) and the first
 * key is always the oldest.
 */

export interface WeightedLRUOptions<K, V> {
  /** Upper bound on the sum of entry weights; must be positive and finite. */
  maxWeight: number;
  /** Weight of an entry; defaults to 1 per entry. */
  weigh?: (value: V, key: K) => number;
  /** Called with each entry evicted to make room, after its removal. */
  onEvict?: (key: K, value: V) => void;
}

interface Entry<V> {
  value: V;
  weight: number;
}

export interface Stats {
  hits: number;
  misses: number;
  evictions: number;
}

export class WeightedLRU<K, V> {
  readonly maxWeight: number;
  readonly #weigh: (value: V, key: K) => number;
  readonly #onEvict?: (key: K, value: V) => void;
  #entries = new Map<K, Entry<V>>();
  #totalWeight = 0;
  #stats: Stats = { hits: 0, misses: 0, evictions: 0 };

  constructor({ maxWeight, weigh = () => 1, onEvict }: WeightedLRUOptions<K, V>) {
    if (typeof maxWeight !== "number" || !(maxWeight > 0) || !Number.isFinite(maxWeight)) {
      throw new RangeError(`maxWeight must be a positive finite number, got ${maxWeight}`);
    }
    this.maxWeight = maxWeight;
    this.#weigh = weigh;
    this.#onEvict = onEvict;
  }

  get size(): number {
    return this.#entries.size;
  }

  get totalWeight(): number {
    return this.#totalWeight;
  }

  /**
   * Stores the entry as most recently used, then evicts least recently used
   * entries until the total weight fits. Returns false and leaves the cache
   * untouched if the entry alone exceeds maxWeight. Throws RangeError on an
   * invalid weight without storing anything.
   */
  set(key: K, value: V): boolean {
    const weight = this.#weigh(value, key);
    if (typeof weight !== "number" || !(weight >= 0) || !Number.isFinite(weight)) {
      throw new RangeError(`weight must be a non-negative finite number, got ${weight}`);
    }
    if (weight > this.maxWeight) {
      return false;
    }
    const existing = this.#entries.get(key);
    if (existing !== undefined) {
      this.#totalWeight -= existing.weight;
      this.#entries.delete(key);
    }
    this.#entries.set(key, { value, weight });
    this.#totalWeight += weight;
    while (this.#totalWeight > this.maxWeight) {
      // The first key is the oldest, and never the one just set: its weight
      // fits on its own, so eviction stops before reaching it.
      const oldest = this.#entries.keys().next().value as K;
      const evicted = this.#entries.get(oldest) as Entry<V>;
      this.#entries.delete(oldest);
      this.#totalWeight -= evicted.weight;
      this.#stats.evictions += 1;
      this.#onEvict?.(oldest, evicted.value);
    }
    return true;
  }

  get(key: K): V | undefined {
    const entry = this.#entries.get(key);
    if (entry === undefined) {
      this.#stats.misses += 1;
      return undefined;
    }
    this.#stats.hits += 1;
    this.#entries.delete(key);
    this.#entries.set(key, entry);
    return entry.value;
  }

  peek(key: K): V | undefined {
    return this.#entries.get(key)?.value;
  }

  has(key: K): boolean {
    return this.#entries.has(key);
  }

  delete(key: K): boolean {
    const entry = this.#entries.get(key);
    if (entry === undefined) {
      return false;
    }
    this.#entries.delete(key);
    this.#totalWeight -= entry.weight;
    return true;
  }

  /** Removes every entry; stats are kept. */
  clear(): void {
    this.#entries.clear();
    this.#totalWeight = 0;
  }

  /** Keys from least to most recently used. */
  keys(): K[] {
    return [...this.#entries.keys()];
  }

  stats(): Stats {
    return { ...this.#stats };
  }
}
