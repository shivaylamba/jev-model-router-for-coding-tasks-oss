# tally

A small `wc`-style command-line tool: counts lines, words and characters in
text files.

```
node bin/tally.js notes.txt todo.txt
```

prints one row per file and, when more than one file is given, a `total` row:

```
      3      12      80 notes.txt
      1       4      19 todo.txt
      4      16      99 total
```

Each number is right-aligned in a 7-character column followed by a space.

With `--json` (which may appear anywhere among the arguments) the table is
replaced by exactly one JSON document on stdout, followed by a newline:

```
{"files":[{"path":"notes.txt","lines":3,"words":12,"chars":80},{"path":"todo.txt","lines":1,"words":4,"chars":19}],"total":{"lines":4,"words":16,"chars":99}}
```

`files` has one entry per file that was read, in command-line order, and
`total` is always included, even for a single file; with no files at all the
output is `{"files":[],"total":{"lines":0,"words":0,"chars":0}}`.

A file that cannot be read is reported on stderr as `tally: cannot read <path>`,
the other files are still counted (and, in JSON mode, are still listed in
`files`), and the exit code is 1. An unknown option
prints a usage line on stderr and exits with code 2. Otherwise the exit code is 0.

Code layout: `src/count.js` does the counting, `src/cli.js` parses arguments and
prints (`run(argv, io)` takes the IO functions as parameters so it can be
tested without touching the real terminal or disk), `bin/tally.js` wires it to
the process.

Node 24, no dependencies. Run the tests with `node --test`.
