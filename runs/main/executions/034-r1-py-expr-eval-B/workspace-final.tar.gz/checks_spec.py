"""Spec conformance checks for calc.evaluate. Run with: python3 -I checks_spec.py"""
import math

import calc
from calc import ExprError

failures = []


def ok(expr, expected, variables=None):
    try:
        got = calc.evaluate(expr, variables)
    except ExprError as e:
        failures.append(f"{expr!r}: expected {expected}, got error {e}")
        return
    if not isinstance(got, float):
        failures.append(f"{expr!r}: result {got!r} is not a float")
    if not math.isclose(got, expected, rel_tol=1e-12):
        failures.append(f"{expr!r}: expected {expected}, got {got}")


def err(expr, position, variables=None):
    try:
        got = calc.evaluate(expr, variables)
    except ExprError as e:
        if e.position != position:
            failures.append(f"{expr!r}: expected position {position}, got {e.position} ({e})")
        return
    failures.append(f"{expr!r}: expected ExprError at {position}, got {got!r}")


# --- precedence and semantics ---
ok("2+3*4", 14)
ok("(2+3)*4", 20)
ok("2^3^2", 512)          # ^ right-associative
ok("-2^2", -4)            # unary minus looser than ^
ok("2^-1", 0.5)           # exponent is a unary expression
ok("-2^-2", -0.25)
ok("--2", 2)
ok("-+2", -2)
ok("10-4-3", 3)           # left-associative
ok("100/10/5", 2)
ok("10 % 3", 1)
ok("-7 % 3", 2)           # floored modulo
ok("7 % -3", -2)
ok("1e3 + 2.5E-2", 1000.025)
ok(".5", 0.5)
ok("pi", math.pi)
ok("e", math.e)
ok(" 1 +\t2 ", 3)

# variables, constants, functions
ok("x*2", 10, {"x": 5})
ok("x", 3.0, {"x": 3})            # int variable returned as float
ok("pi", 99.0, {"pi": 99})        # variables win over constants
ok("min(3,1,2)", 1)
ok("max(1+2, 2*3)", 6)
ok("hypot(3,4)", 5)
ok("round(2.5)", 2)
ok("abs(-3)", 3)
ok("sqrt(9)", 3)
ok("min(2)", 2)
ok("price * (1 + rate) ^ years", 100 * 1.05 ** 3, {"price": 100, "rate": 0.05, "years": 3})

# --- syntax error positions (table from SPEC.md) ---
err("", 0)
err("   ", 3)
err("1 +", 3)
err("(1 + 2", 6)
err("1 + 2)", 5)
err("2 3", 2)
err("2x", 1)
err("1 * * 2", 4)
err("min(1,)", 6)
err("1, 2", 1)
err("3 $ 4", 2)
err("-", 1)          # unary sign, then end of input
err("min(1", 5)
err("min(", 4)
err("5.", 1)         # number is 5, '.' unexpected
err("(1)(2)", 3)     # no implicit multiplication
err("2(3)", 1)
err("2e", 1)         # number 2, then name e: two operands in a row
ok("2e1", 20)

# --- evaluation errors and positions ---
err("x", 0)                       # unknown name
err("  y + 1", 2)
err("foo(1)", 0)                  # unknown function (variables can't be called)
err("foo(1)", 0, {"foo": 3})
err("sqrt(1, 2)", 0)              # arity
err("hypot(1)", 0)
err("sqrt()", 0)
err("min()", 0)
err("sqrt(-1)", 0)                # domain error at function name
err("1 / 0", 2)                   # at operator
err("1 % 0", 2)
err("0 ^ -1", 2)                  # at the ^
err("(-8) ^ (1/3)", 5)
err("10 ^ 400", 3)
ok("(-2)^2", 4)

# evaluation order: name error before arity error later
err("x + sqrt(1, 2)", 0)
# arity checked before arguments are evaluated
err("sqrt(1/0, 2)", 0)
err("sqrt(1/0)", 6)               # single arg: args evaluated, error inside
err("min(1/0, nope)", 5)          # left-to-right arg evaluation
# parse-first: syntax error at end beats eval error at start
err("nope + 1 )", 9)
err("1/0 +", 5)

if failures:
    print("FAILURES:")
    for f in failures:
        print(" ", f)
    raise SystemExit(1)
print("all checks passed")
