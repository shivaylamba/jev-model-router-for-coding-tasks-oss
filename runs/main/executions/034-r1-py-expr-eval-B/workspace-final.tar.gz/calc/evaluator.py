"""Evaluator for parsed formulas (see SPEC.md, "Evaluation").

Nodes are evaluated left to right, so the first error met in that order is
the one raised.
"""

import math

from calc.errors import ExprError
from calc.functions import CONSTANTS, FUNCTIONS
from calc.parser import Binary, Call, Name, Num, Unary


def evaluate_node(node, variables):
    if isinstance(node, Num):
        return node.value
    if isinstance(node, Name):
        return _eval_name(node, variables)
    if isinstance(node, Unary):
        return -evaluate_node(node.operand, variables)
    if isinstance(node, Binary):
        return _eval_binary(node, variables)
    if isinstance(node, Call):
        return _eval_call(node, variables)
    raise AssertionError(f"unknown node {node!r}")


def _eval_name(node, variables):
    if variables is not None and node.text in variables:
        return float(variables[node.text])
    if node.text in CONSTANTS:
        return float(CONSTANTS[node.text])
    raise ExprError(f"unknown name {node.text!r}", node.position)


def _eval_binary(node, variables):
    left = evaluate_node(node.left, variables)
    right = evaluate_node(node.right, variables)
    op = node.op
    if op == "+":
        return left + right
    if op == "-":
        return left - right
    if op == "*":
        return left * right
    if op == "/":
        if right == 0:
            raise ExprError("division by zero", node.op_position)
        return left / right
    if op == "%":
        if right == 0:
            raise ExprError("modulo by zero", node.op_position)
        return left % right  # floored modulo, like Python's %
    if op == "^":
        return _power(left, right, node.op_position)
    raise AssertionError(f"unknown operator {op!r}")


def _power(base, exponent, position):
    try:
        result = math.pow(base, exponent)
    except (ValueError, OverflowError):
        # e.g. 0 ^ -1, (-8) ^ (1/3), or a result too large for a float.
        raise ExprError("power is not a finite real number", position)
    if not math.isfinite(result):
        raise ExprError("power is not a finite real number", position)
    return result


def _eval_call(node, variables):
    spec = FUNCTIONS.get(node.name)
    if spec is None:
        raise ExprError(f"unknown function {node.name!r}", node.name_position)
    low, high, impl = spec
    count = len(node.args)
    if count < low or (high is not None and count > high):
        if high is None:
            range_label = f"{low}+"
        elif high == low:
            range_label = str(low)
        else:
            range_label = f"{low} to {high}"
        raise ExprError(
            f"{node.name!r} expects {range_label} argument(s), got {count}",
            node.name_position,
        )
    args = [evaluate_node(arg, variables) for arg in node.args]
    try:
        # min/max take variadic arguments; with a single argument Python's
        # built-ins would try to iterate it, so pass the list for those.
        if impl is min or impl is max:
            result = impl(args)
        else:
            result = impl(*args)
        return float(result)
    except (ValueError, OverflowError, ZeroDivisionError, TypeError):
        # e.g. sqrt(-1); the error points at the function name, not the argument.
        raise ExprError(
            f"{node.name!r} failed for these arguments", node.name_position
        )
