"""Tokenizer for the formula language (see SPEC.md, "Tokens")."""

from calc.errors import ExprError

# Token kinds
NUMBER = "number"
NAME = "name"
OP = "op"
LPAREN = "lparen"
RPAREN = "rparen"
COMMA = "comma"
END = "end"

_OPERATORS = "+-*/%^"


class Token:
    __slots__ = ("kind", "value", "position")

    def __init__(self, kind, value, position):
        self.kind = kind
        self.value = value
        self.position = position

    def __repr__(self):
        return f"Token({self.kind}, {self.value!r}, {self.position})"


def tokenize(expr):
    """Split `expr` into a list of tokens ending with an END token.

    The END token's position is len(expr). Raises ExprError at the position
    of any character that cannot start a token.
    """
    tokens = []
    i = 0
    n = len(expr)
    while i < n:
        ch = expr[i]
        if ch in " \t":
            i += 1
        elif ch.isdigit() or ch == ".":
            token, i = _read_number(expr, i)
            tokens.append(token)
        elif ch.isalpha() or ch == "_":
            start = i
            i += 1
            while i < n and (expr[i].isalnum() or expr[i] == "_"):
                i += 1
            tokens.append(Token(NAME, expr[start:i], start))
        elif ch in _OPERATORS:
            tokens.append(Token(OP, ch, i))
            i += 1
        elif ch == "(":
            tokens.append(Token(LPAREN, ch, i))
            i += 1
        elif ch == ")":
            tokens.append(Token(RPAREN, ch, i))
            i += 1
        elif ch == ",":
            tokens.append(Token(COMMA, ch, i))
            i += 1
        else:
            raise ExprError(f"unexpected character {ch!r}", i)
    tokens.append(Token(END, None, n))
    return tokens


def _read_number(expr, start):
    """Read a number token starting at index `start`.

    A number is `digits`, `digits.digits` or `.digits`, optionally followed
    by an exponent `e`/`E`, an optional sign, and digits. A trailing `.`
    without digits and an `e` not followed by digits are not part of the
    number.
    """
    n = len(expr)
    i = start
    while i < n and expr[i].isdigit():
        i += 1
    if i < n and expr[i] == ".":
        if i + 1 < n and expr[i + 1].isdigit():
            i += 2
            while i < n and expr[i].isdigit():
                i += 1
        elif i == start:
            # `.digits`: the leading dot case; must have a digit after.
            raise ExprError("unexpected character '.'", start)
        # Otherwise a trailing `.` is left for the next token, where it is
        # an unexpected character.
    if i < n and expr[i] in "eE":
        j = i + 1
        if j < n and expr[j] in "+-":
            j += 1
        if j < n and expr[j].isdigit():
            j += 1
            while j < n and expr[j].isdigit():
                j += 1
            i = j
        # Otherwise the `e` starts a name token, not an exponent.
    if i == start:
        # Only possible for a bare `.` at the end of the input.
        raise ExprError("unexpected character '.'", start)
    return Token(NUMBER, float(expr[start:i]), start), i
