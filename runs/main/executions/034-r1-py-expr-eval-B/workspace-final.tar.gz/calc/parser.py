"""Recursive-descent parser for the formula language (see SPEC.md).

Grammar, lowest to highest precedence:

    expr    := term  (('+' | '-') term)*     # left-associative
    term    := unary (('*' | '/' | '%') unary)*   # left-associative
    unary   := ('-' | '+') unary | power
    power   := primary ('^' unary)?          # right-exponent is a unary
    primary := NUMBER
             | NAME                          # variable or constant
             | NAME '(' expr (',' expr)* ')' # function call
             | '(' expr ')'

Unary minus binds less tightly than `^`: `-2^2` is `-(2^2)`, and the
right operand of `^` may itself carry unary signs: `2^-1` is 0.5.
"""

from calc.errors import ExprError
from calc import lexer
from calc.lexer import NAME, NUMBER, END, tokenize

# ----------------------------- AST nodes -----------------------------------
# Each node stores the position that an evaluation error should point at.


class Num:
    def __init__(self, value):
        self.value = value


class Name:
    def __init__(self, text, position):
        self.text = text
        self.position = position


class Unary:
    def __init__(self, op, operand):
        self.op = op
        self.operand = operand


class Binary:
    def __init__(self, op, left, right, op_position):
        self.op = op
        self.left = left
        self.right = right
        self.op_position = op_position


class Call:
    def __init__(self, name, name_position, args):
        self.name = name
        self.name_position = name_position
        self.args = args


# ----------------------------- parser --------------------------------------


class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.i = 0

    @property
    def tok(self):
        return self.tokens[self.i]

    def _advance(self):
        token = self.tok
        self.i += 1
        return token

    def _expect_operand(self):
        """Raise the standard 'expected an operand' error at the current token."""
        found = "end of input" if self.tok.kind == END else repr(self.tok.value)
        raise ExprError(f"expected an operand, found {found}", self.tok.position)

    def parse(self):
        """Parse a whole formula: an expression followed by end of input."""
        node = self.parse_expr()
        if self.tok.kind != END:
            found = "end of input" if self.tok.kind == END else repr(self.tok.value)
            raise ExprError(f"expected an operator, found {found}", self.tok.position)
        return node

    def parse_expr(self):
        node = self.parse_term()
        while self.tok.kind == lexer.OP and self.tok.value in "+-":
            op = self._advance()
            node = Binary(op.value, node, self.parse_term(), op.position)
        return node

    def parse_term(self):
        node = self.parse_unary()
        while self.tok.kind == lexer.OP and self.tok.value in "*/%":
            op = self._advance()
            node = Binary(op.value, node, self.parse_unary(), op.position)
        return node

    def parse_unary(self):
        if self.tok.kind == lexer.OP and self.tok.value in "+-":
            sign = self._advance()
            operand = self.parse_unary()  # signs may repeat: --2
            if sign.value == "+":
                return operand  # unary plus is a no-op
            return Unary("-", operand)
        return self.parse_power()

    def parse_power(self):
        base = self.parse_primary()
        if self.tok.kind == lexer.OP and self.tok.value == "^":
            op = self._advance()
            # Exponent is a unary expression, making ^ right-associative
            # (2^3^2 = 2^(3^2)) while still allowing 2^-1.
            exponent = self.parse_unary()
            return Binary("^", base, exponent, op.position)
        return base

    def parse_primary(self):
        token = self.tok
        if token.kind == NUMBER:
            self._advance()
            return Num(token.value)
        if token.kind == NAME:
            self._advance()
            if self.tok.kind == lexer.LPAREN:
                return self._parse_call(token)
            return Name(token.value, token.position)
        if token.kind == lexer.LPAREN:
            self._advance()
            node = self.parse_expr()
            if self.tok.kind != lexer.RPAREN:
                found = "end of input" if self.tok.kind == END else repr(self.tok.value)
                raise ExprError(f"expected ')', found {found}", self.tok.position)
            self._advance()  # consume ')'
            return node
        self._expect_operand()

    def _parse_call(self, name_token):
        self._advance()  # consume '('
        args = []
        if self.tok.kind != lexer.RPAREN:
            while True:
                args.append(self.parse_expr())
                if self.tok.kind == lexer.COMMA:
                    self._advance()
                    continue
                break
        if self.tok.kind != lexer.RPAREN:
            found = "end of input" if self.tok.kind == END else repr(self.tok.value)
            raise ExprError(f"expected ')', found {found}", self.tok.position)
        self._advance()  # consume ')'
        return Call(name_token.value, name_token.position, args)


def parse(expr):
    """Parse the whole formula into an AST. Raises ExprError on syntax errors."""
    return Parser(tokenize(expr)).parse()
