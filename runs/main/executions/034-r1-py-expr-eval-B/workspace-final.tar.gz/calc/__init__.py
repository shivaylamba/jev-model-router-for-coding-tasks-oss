"""Formula engine for computed columns. See SPEC.md."""

from calc.errors import ExprError
from calc.evaluator import evaluate_node
from calc.parser import parse

__all__ = ["ExprError", "evaluate"]


def evaluate(expr, variables=None):
    """Evaluate the formula `expr` and return a float (see SPEC.md).

    `variables` maps names to int or float values. Raises ExprError, with a
    `position`, for any syntax or evaluation error.
    """
    # The whole formula is parsed before anything is evaluated, so a syntax
    # error anywhere beats an evaluation error earlier in the string.
    tree = parse(expr)
    return float(evaluate_node(tree, variables))
