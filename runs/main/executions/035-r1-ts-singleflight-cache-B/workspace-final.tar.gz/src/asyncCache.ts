export type AsyncCacheOptions<V> = {
  load: (key: string) => Promise<V>;
  ttlMs: number; // finite, > 0
  staleMs: number; // finite, >= 0
  maxEntries: number; // integer, >= 1
  now?: () => number; // current time in ms; defaults to Date.now
  onRefreshError?: (key: string, error: unknown) => void;
};

type Entry<V> = {
  value: V;
  storedAt: number;
};

// One load in flight for a key. `isRefresh` records whether the load was
// started by a background refresh, which decides how rejection is handled.
type Flight<V> = {
  promise: Promise<V>;
  isRefresh: boolean;
};

export class AsyncCache<V> {
  #load: (key: string) => Promise<V>;
  #ttlMs: number;
  #staleMs: number;
  #maxEntries: number;
  #now: () => number;
  #onRefreshError?: (key: string, error: unknown) => void;

  // Stored values, in least-recently-used first order (Map preserves
  // insertion order; using an entry moves it to the end).
  #entries = new Map<string, Entry<V>>();

  // At most one *active* load per key. Invalidation/clear removes a flight
  // so it will neither store its result nor be joined by later gets.
  #flights = new Map<string, Flight<V>>();

  constructor(options: AsyncCacheOptions<V>) {
    this.#load = options.load;
    this.#now = options.now ?? Date.now;

    if (!Number.isFinite(options.ttlMs) || options.ttlMs <= 0) {
      throw new RangeError("ttlMs must be a finite number > 0");
    }
    if (!Number.isFinite(options.staleMs) || options.staleMs < 0) {
      throw new RangeError("staleMs must be a finite number >= 0");
    }
    if (!Number.isInteger(options.maxEntries) || options.maxEntries < 1) {
      throw new RangeError("maxEntries must be an integer >= 1");
    }

    this.#ttlMs = options.ttlMs;
    this.#staleMs = options.staleMs;
    this.#maxEntries = options.maxEntries;
    this.#onRefreshError = options.onRefreshError;
  }

  // Expired entries are still stored physically, but never served.
  #isExpired(entry: Entry<V>, now: number): boolean {
    return now - entry.storedAt >= this.#ttlMs + this.#staleMs;
  }

  get(key: string): Promise<V> {
    const now = this.#now();
    const entry = this.#entries.get(key);

    if (entry !== undefined && !this.#isExpired(entry, now)) {
      // Fresh or stale: serve the stored value and become most recently used.
      this.#entries.delete(key);
      this.#entries.set(key, entry);

      if (now - entry.storedAt < this.#ttlMs) {
        return Promise.resolve(entry.value); // fresh: no load
      }
      // stale: serve it right away, refresh in the background if none is running
      if (!this.#flights.has(key)) {
        this.#startLoad(key, true);
      }
      return Promise.resolve(entry.value);
    }

    // No value, or an expired one: the expired value is dropped.
    if (entry !== undefined) {
      this.#entries.delete(key);
    }
    const flight = this.#flights.get(key);
    if (flight) {
      return flight.promise; // join an earlier get or a refresh
    }
    return this.#startLoad(key, false).promise;
  }

  peek(key: string): V | undefined {
    const now = this.#now();
    const entry = this.#entries.get(key);
    if (entry === undefined || this.#isExpired(entry, now)) {
      return undefined;
    }
    return entry.value;
  }

  invalidate(key: string): boolean {
    const hadEntry = this.#entries.delete(key);
    // A load already in flight must not store its result, and the next
    // get starts a new load instead of waiting on it.
    this.#flights.delete(key);
    return hadEntry;
  }

  clear(): void {
    this.#entries.clear();
    this.#flights.clear();
  }

  get size(): number {
    const now = this.#now();
    let count = 0;
    for (const entry of this.#entries.values()) {
      if (!this.#isExpired(entry, now)) count += 1;
    }
    return count;
  }

  // Loads in flight do not count towards the size limit, and evicting a key
  // does not stop its in-flight load from storing its result later.
  #startLoad(key: string, isRefresh: boolean): Flight<V> {
    let promise: Promise<V>;
    try {
      promise = Promise.resolve(this.#load(key));
    } catch (error) {
      promise = Promise.reject(error); // sync throw behaves like a rejection
    }

    const flight: Flight<V> = { promise, isRefresh };
    this.#flights.set(key, flight);

    promise.then(
      (value) => this.#onLoadSettled(key, flight, value),
      (error) => this.#onLoadRejected(key, flight, error),
    );
    return flight;
  }

  #onLoadSettled(key: string, flight: Flight<V>, value: V): void {
    if (this.#flights.get(key) !== flight) {
      // The key was invalidated (or cleared) after this load started, or a
      // newer load has been started since: do not store.
      return;
    }
    this.#flights.delete(key);
    this.#entries.delete(key); // re-insert as most recently used
    this.#entries.set(key, { value, storedAt: this.#now() });
    this.#enforceLimit();
  }

  #onLoadRejected(key: string, flight: Flight<V>, error: unknown): void {
    if (this.#flights.get(key) === flight) {
      this.#flights.delete(key);
    }
    if (flight.isRefresh) {
      // Never surfaces as an unhandled rejection.
      this.#onRefreshError?.(key, error);
    }
    // Nothing is stored; any stored value is left as it is.
  }

  // Only runs when more than maxEntries values are stored: drop every
  // expired value, then evict least-recently-used values while still over.
  #enforceLimit(): void {
    if (this.#entries.size <= this.#maxEntries) return;

    const now = this.#now();
    for (const [key, entry] of this.#entries) {
      if (this.#isExpired(entry, now)) this.#entries.delete(key);
    }
    while (this.#entries.size > this.#maxEntries) {
      const lru = this.#entries.keys().next().value;
      if (lru === undefined) break;
      this.#entries.delete(lru);
    }
  }
}
