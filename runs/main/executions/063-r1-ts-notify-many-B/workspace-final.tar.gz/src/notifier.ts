export interface Transport {
  send(recipient: string, message: string): void;
}

/** Records every send in memory. Handy in tests and dry runs. */
export class MemoryTransport implements Transport {
  sent: Array<{ recipient: string; message: string }> = [];

  send(recipient: string, message: string): void {
    this.sent.push({ recipient, message });
  }
}

export class Notifier {
  private transport: Transport;

  constructor(transport: Transport) {
    this.transport = transport;
  }

  /**
   * Send `message` to one recipient or a list of recipients, in the order given.
   * Each recipient is trimmed before sending. Duplicates are sent only once:
   * recipients match case-insensitively after trimming, and the first spelling
   * is the one that gets sent. Returns how many messages were actually sent
   * (1 for a single string, 0 for an empty list).
   * Throws TypeError if any recipient is empty or only whitespace, and does so
   * before sending anything — a bad list never results in a partial send.
   */
  notify(recipients: string | readonly string[], message: string): number {
    const list = typeof recipients === "string" ? [recipients] : recipients;
    const trimmed = list.map((recipient) => recipient.trim());
    for (const to of trimmed) {
      if (to === "") {
        throw new TypeError("recipient must be a non-empty string");
      }
    }
    const seen = new Set<string>();
    let sent = 0;
    for (const to of trimmed) {
      const key = to.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      this.transport.send(to, message);
      sent++;
    }
    return sent;
  }
}
