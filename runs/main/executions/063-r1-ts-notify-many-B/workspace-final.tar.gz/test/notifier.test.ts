import { test } from "node:test";
import assert from "node:assert/strict";
import { MemoryTransport, Notifier } from "../src/notifier.ts";
import { dispatchAlert } from "../src/alerts.ts";
import { sendDigest } from "../src/digest.ts";

test("notify trims and sends", () => {
  const transport = new MemoryTransport();
  new Notifier(transport).notify("  ops@example.com ", "hi");
  assert.deepEqual(transport.sent, [{ recipient: "ops@example.com", message: "hi" }]);
});

test("blank recipient is rejected", () => {
  const notifier = new Notifier(new MemoryTransport());
  assert.throws(() => notifier.notify("  ", "hi"), TypeError);
});

test("notify sends to each recipient in order", () => {
  const transport = new MemoryTransport();
  const sent = new Notifier(transport).notify(["  a@example.com ", "b@example.com"], "hi");
  assert.equal(sent, 2);
  assert.deepEqual(transport.sent, [
    { recipient: "a@example.com", message: "hi" },
    { recipient: "b@example.com", message: "hi" },
  ]);
});

test("notify returns 1 for a single string recipient", () => {
  const transport = new MemoryTransport();
  assert.equal(new Notifier(transport).notify("a@example.com", "hi"), 1);
});

test("notify sends an empty list nowhere", () => {
  const transport = new MemoryTransport();
  assert.equal(new Notifier(transport).notify([], "hi"), 0);
  assert.deepEqual(transport.sent, []);
});

test("notify skips duplicates case-insensitively, keeping the first spelling", () => {
  const transport = new MemoryTransport();
  const sent = new Notifier(transport).notify(["Ops@Example.com", "  ops@example.com", "OPS@EXAMPLE.COM"], "hi");
  assert.equal(sent, 1);
  assert.deepEqual(transport.sent, [{ recipient: "Ops@Example.com", message: "hi" }]);
});

test("blank recipient in a list is rejected before anything is sent", () => {
  const transport = new MemoryTransport();
  assert.throws(() => new Notifier(transport).notify(["a@example.com", "  "], "hi"), TypeError);
  assert.deepEqual(transport.sent, []);
});

test("alerts page only on critical", () => {
  const transport = new MemoryTransport();
  const notifier = new Notifier(transport);
  assert.equal(dispatchAlert(notifier, "oncall@example.com", { service: "db", level: "warning", text: "slow" }), false);
  assert.equal(dispatchAlert(notifier, "oncall@example.com", { service: "db", level: "critical", text: "down" }), true);
  assert.deepEqual(transport.sent, [{ recipient: "oncall@example.com", message: "[db] down" }]);
});

test("digest goes to every subscriber", () => {
  const transport = new MemoryTransport();
  sendDigest(new Notifier(transport), ["a@example.com", "b@example.com"], ["one"]);
  assert.equal(transport.sent.length, 2);
  assert.equal(transport.sent[1].message, "- one");
});
