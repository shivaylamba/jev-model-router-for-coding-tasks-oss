# eventdump

Exports audit events from our API (JSON documents) for people who want to open
them in a spreadsheet.

- `loader.py` - reads newline-delimited JSON files into a list of dicts
- `csvexport.py` - CSV output; `records_to_csv(records)` flattens parsed records
  (nested dicts become dot-separated columns) into spreadsheet-ready CSV

Standard library only (Python 3.11). Run the tests with
`python3 -m unittest discover -s tests -t .`
