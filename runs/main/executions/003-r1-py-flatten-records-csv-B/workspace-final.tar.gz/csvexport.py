"""CSV output for exported events."""

import csv
import io


def rows_to_csv(header, rows):
    """Render a header and rows (lists of strings) with the csv module's default dialect."""
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(header)
    writer.writerows(rows)
    return buffer.getvalue()


def records_to_csv(records):
    """Flatten records (dicts, as from loader.parse_ndjson) and render them as CSV text.

    Nested dicts become dot-separated columns, named in first-seen order;
    lists and tuples become ';'-joined cells. An empty list of records yields "".
    """
    columns = []
    seen = set()
    flat_records = []
    for position, record in enumerate(records):
        if not isinstance(record, dict):
            raise TypeError(
                f"record {position} is a {type(record).__name__}, expected a dict"
            )
        values = {}
        for name, value in _flatten(record):
            if name in values:
                raise ValueError(
                    f"record {position}: multiple keys flatten to column {name!r}"
                )
            values[name] = value
            if name not in seen:
                seen.add(name)
                columns.append(name)
        flat_records.append(values)
    if not flat_records:
        return ""
    rows = [[_cell(values.get(name)) for name in columns] for values in flat_records]
    return rows_to_csv(columns, rows)


def _flatten(mapping, prefix=""):
    """Return (column, value) pairs for a mapping, descending into nested dicts.

    Names are joined with '.'; an empty nested dict contributes nothing.
    """
    pairs = []
    for key, value in mapping.items():
        name = f"{prefix}{key}"
        if isinstance(value, dict):
            if value:
                pairs.extend(_flatten(value, f"{name}."))
        else:
            pairs.append((name, value))
    return pairs


def _cell(value):
    """Render one flattened value: lists and tuples as ';'-joined items, else a scalar."""
    if isinstance(value, (list, tuple)):
        return ";".join(_scalar(item) for item in value)
    return _scalar(value)


def _scalar(value):
    """Render None as an empty cell, booleans as true/false, anything else with str()."""
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)
