import copy
import unittest

from csvexport import records_to_csv, rows_to_csv
from loader import parse_ndjson


class LoaderTest(unittest.TestCase):
    def test_parse_ndjson(self):
        self.assertEqual(parse_ndjson('{"a": 1}\n\n{"a": 2}\n'), [{"a": 1}, {"a": 2}])

    def test_bad_line(self):
        with self.assertRaises(ValueError):
            parse_ndjson('{"a": 1}\nnope\n')


class RowsToCsvTest(unittest.TestCase):
    def test_rows_to_csv(self):
        self.assertEqual(rows_to_csv(["a", "b"], [["1", "x,y"]]), 'a,b\r\n1,"x,y"\r\n')


class RecordsToCsvTest(unittest.TestCase):
    def test_flattens_nested_dicts_at_any_depth(self):
        records = [{"event": {"user": {"name": "ada"}}, "action": "login"}]
        self.assertEqual(
            records_to_csv(records),
            "event.user.name,action\r\nada,login\r\n",
        )

    def test_column_order_is_first_seen_and_missing_columns_are_empty(self):
        records = [{"b": 1}, {"a": {"x": 1}, "b": 2}]
        self.assertEqual(records_to_csv(records), "b,a.x\r\n1,\r\n2,1\r\n")

    def test_columns_follow_key_order_descending_where_dicts_appear(self):
        records = [{"x": 5, "user": {"name": "ada", "roles": ["admin"]}, "y": 6}]
        self.assertEqual(
            records_to_csv(records),
            "x,user.name,user.roles,y\r\n5,ada,admin,6\r\n",
        )

    def test_plain_value_and_dict_for_same_key_coexist(self):
        records = [{"a": 5}, {"a": {"b": 7}}]
        self.assertEqual(records_to_csv(records), "a,a.b\r\n5,\r\n,7\r\n")

    def test_empty_nested_dict_contributes_no_column(self):
        records = [{"a": {}}, {"a": 1}]
        # the empty record renders as '""': the csv module quotes a row whose
        # single field is empty so it is not read back as a blank line
        self.assertEqual(records_to_csv(records), 'a\r\n""\r\n1\r\n')

    def test_cell_conversions(self):
        records = [{
            "n": None, "t": True, "f": False, "i": 2, "s": "x",
            "l": [True, None, 2], "e": [], "tup": (1, 2),
        }]
        self.assertEqual(
            records_to_csv(records),
            "n,t,f,i,s,l,e,tup\r\n,true,false,2,x,true;;2,,1;2\r\n",
        )

    def test_csv_quoting(self):
        records = [{"a": "x,y"}, {"b": 'say "hi"'}]
        self.assertEqual(
            records_to_csv(records),
            'a,b\r\n"x,y",\r\n,"say ""hi"""\r\n',
        )

    def test_empty_record_list_returns_empty_string(self):
        self.assertEqual(records_to_csv([]), "")

    def test_colliding_keys_in_one_record_raise_value_error(self):
        with self.assertRaises(ValueError):
            records_to_csv([{"a.b": 1, "a": {"b": 2}}])

    def test_non_dict_record_raises_type_error(self):
        with self.assertRaises(TypeError):
            records_to_csv([{"a": 1}, "nope"])

    def test_input_not_modified(self):
        records = [{"user": {"name": "ada"}, "tags": [1, 2]}, {"user": {"name": "ben"}}]
        before = copy.deepcopy(records)
        records_to_csv(records)
        self.assertEqual(records, before)


if __name__ == "__main__":
    unittest.main()
