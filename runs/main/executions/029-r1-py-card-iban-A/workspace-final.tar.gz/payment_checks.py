"""Card and bank-account helpers for the checkout service."""

from iban_countries import IBAN_LENGTHS  # noqa: F401  (used by the IBAN check)


def strip_separators(text, separators=" -"):
    """Return text with every character in `separators` removed."""
    return "".join(ch for ch in text if ch not in separators)


def mask_card(number):
    """Mask all but the last four digits: '4111 1111 1111 1111' -> '************1111'.

    Spaces and hyphens are ignored. Raises ValueError if fewer than four digits remain.
    """
    digits = strip_separators(number)
    if len(digits) < 4 or not digits.isdigit():
        raise ValueError("not a card number")
    return "*" * (len(digits) - 4) + digits[-4:]


def luhn_ok(digits):
    """Return True if the digit string passes the Luhn checksum."""
    total = 0
    for position, ch in enumerate(reversed(digits)):
        n = int(ch)
        if position % 2 == 1:
            n *= 2
            if n > 9:
                n -= 9
        total += n
    return total % 10 == 0


def card_brand(number):
    """Return 'visa', 'mastercard', 'amex' or 'discover' for a valid card number.

    Spaces and hyphens are separators and are ignored; any other non-digit
    character, a failed Luhn checksum, or an unknown prefix/length returns None.
    """
    if not isinstance(number, str):
        raise TypeError("card number must be a string")
    digits = strip_separators(number)
    if not digits or not digits.isdigit() or not luhn_ok(digits):
        return None

    two = int(digits[:2]) if len(digits) >= 2 else None
    three = int(digits[:3]) if len(digits) >= 3 else None
    four = int(digits[:4]) if len(digits) >= 4 else None

    if two in (34, 37) and len(digits) == 15:
        return "amex"
    if digits.startswith("4") and len(digits) in (13, 16, 19):
        return "visa"
    if (
        (two is not None and 51 <= two <= 55)
        or (four is not None and 2221 <= four <= 2720)
    ) and len(digits) == 16:
        return "mastercard"
    if (
        digits.startswith("6011")
        or digits.startswith("65")
        or (three is not None and 644 <= three <= 649)
    ) and len(digits) in (16, 19):
        return "discover"
    return None


def is_valid_iban(iban):
    """Return True if the IBAN is structurally valid and passes mod-97.

    Spaces are ignored; letters may be in either case. The country must appear
    in IBAN_LENGTHS with a matching total length, the layout must be two
    letters, two digits, then letters/digits, and the standard mod-97 check
    must return 1.
    """
    if not isinstance(iban, str):
        raise TypeError("IBAN must be a string")
    compact = iban.replace(" ", "").upper()
    if (
        len(compact) < 4
        or not compact[:2].isalpha()
        or not compact[2:4].isdigit()
        or not compact.isalnum()
    ):
        return False
    country = compact[:2]
    if IBAN_LENGTHS.get(country) != len(compact):
        return False

    rearranged = compact[4:] + compact[:4]
    numeric = "".join(str(int(ch, 36)) for ch in rearranged)
    return int(numeric) % 97 == 1
