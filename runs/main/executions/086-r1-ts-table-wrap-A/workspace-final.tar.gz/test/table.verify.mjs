import { renderTable } from '../src/table.ts';

let pass = 0, fail = 0;
function eq(actual, expected, name) {
  if (actual === expected) { pass++; }
  else { fail++; console.log(`FAIL ${name}\n  expected: ${JSON.stringify(expected)}\n  actual:   ${JSON.stringify(actual)}`); }
}
function throws(fn, name) {
  try { fn(); fail++; console.log(`FAIL ${name}: no throw`); }
  catch (e) { if (e instanceof RangeError) pass++; else { fail++; console.log(`FAIL ${name}: threw ${e.constructor.name}: ${e.message}`); } }
}

// 1. Basic table, no options
eq(renderTable([["a", "b"], ["ccc", "d"]]),
   "a   | b\nccc | d", "basic");

// 2. No columns -> ""
eq(renderTable([]), "", "empty rows");
eq(renderTable([[], []]), "", "only empty rows");

// 3. Header separator
eq(renderTable([["Name", "Size"], ["a", "22"]], { header: true }),
   "Name | Size\n-----+-----\na    | 22  ", "header");

// 4. Alignment
eq(renderTable([["x", "y", "z"]], { align: ["right", "center", "left"] }),
   "x | y | z", "align no padding needed");
eq(renderTable([["x", "y", "z"], ["www", "www", "www"]], { align: ["right", "center", "left"] }),
   "  x |  y  | z  \nwww | www | www", "align padding");

// 5. Extra align entries ignored, missing default left
eq(renderTable([["ab", "cd"]], { align: ["right", "left", "right"] }),
   "ab | cd", "extra align ignored");

// 6. Ragged rows
eq(renderTable([["long", "x"], ["y"]]),
   "long | x\ny    |  ", "ragged rows");

// 7. Wide characters count 2
eq(renderTable([["ab", "你在"], ["cd", "xy"]]),
   "ab | 你在\ncd | xy  ", "wide chars");

// 8. Shrinking: widest column shrinks first
eq(renderTable([["aaaaaaaaaa", "bbbbbb"]], { maxWidth: 12 }),
   "aaaa | bbbbb\naaaa | b    \naa   |      ",
   "shrink widest");

// 9. Rightmost on tie
eq(renderTable([["aaaaa", "bbbbb"]], { maxWidth: 12 }),
   "aaaaa | bbbb\n      | b   ",
   "tie shrinks rightmost");

// 10. Wrapping behavior (lines are padded to column width, never trimmed)
eq(renderTable([["  aa   bb  "]], { maxWidth: 3 }),
   "aa \nbb ", "space normalization + wrap");
eq(renderTable([["aa bb cc"]], { maxWidth: 3 }),
   "aa \nbb \ncc ", "greedy wrap");
eq(renderTable([["aaaa b"]], { maxWidth: 4 }),
   "aaaa\nb   ", "word starts new line");
eq(renderTable([["abcdef"]], { maxWidth: 4 }),
   "abcd\nef  ", "word cut");
eq(renderTable([["abcdef g"]], { maxWidth: 4 }),
   "abcd\nef g", "append after cut");
eq(renderTable([["你你你"]], { maxWidth: 3 }),
   "你 \n你 \n你 ", "wide word cut, min width 2 kept");;
eq(renderTable([["你你你"]], { maxWidth: 4 }),
   "你你\n你  ", "wide word cut width 4");

// 11. Multi-line cell (paragraphs)
eq(renderTable([["a\nb", "x"]]),
   "a | x\nb |  ", "paragraphs");

// 12. Empty paragraph produces one empty line
eq(renderTable([["", "q"]]),
   "  | q", "empty paragraph");

// 13. Row height padded at bottom
eq(renderTable([["one two", "x"]], { maxWidth: 7 }),
   "one | x\ntwo |  ",
   "row height padding");

// 14. RangeErrors
throws(() => renderTable([["你"]], { maxWidth: 1 }), "cannot fit min width 2");
throws(() => renderTable([["ab"]], { maxWidth: 0 }), "maxWidth 0");
throws(() => renderTable([["ab"]], { maxWidth: -5 }), "maxWidth negative");
throws(() => renderTable([["ab"]], { maxWidth: 2.5 }), "maxWidth non-integer");
throws(() => renderTable([["ab"]], { maxWidth: NaN }), "maxWidth NaN");
throws(() => renderTable([["ab"]], { align: ["middle"] }), "bad align");
throws(() => renderTable([["ab", "cd", "ef"]], { maxWidth: 3 }), "gaps alone exceed maxWidth");

// 15. Every line exactly table width
const out = renderTable([["hdr1", "hdr2"], ["a b c", "你你"]], { maxWidth: 11, header: true, align: ["left", "right"] });
console.log("sample output:");
console.log(out);
eq(out.endsWith("\n"), false, "no trailing newline");

// 16. header separator uses '-+-'
eq(renderTable([["h1", "h2"]], { header: true }).split("\n")[1], "--+--", "separator -+-");

// 17. exact fit at maxWidth
eq(renderTable([["abc"]], { maxWidth: 3 }), "abc", "exact fit");

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
