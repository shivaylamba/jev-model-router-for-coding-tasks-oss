import { createPricer, defaultRules } from "./rules.ts";
import type { Coupon, Order, Totals } from "./types.ts";

export {
  FREE_SHIPPING_THRESHOLD,
  SHIPPING_FEE,
  TAX_PERCENT,
  VOLUME_MIN_QUANTITY,
  VOLUME_PERCENT,
} from "./rules.ts";

const priceWithDefaults = createPricer(defaultRules);

/** Price an order with the default rules. See docs/PRICING.md for the rules. */
export function orderTotal(order: Order, coupon?: Coupon): Totals {
  return priceWithDefaults(order, coupon);
}
