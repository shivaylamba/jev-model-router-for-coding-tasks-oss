import type { Bundle } from "./types.ts";

/** The store's bundles. See docs/PRICING.md, "Bundle discount". */
export const BUNDLES: Bundle[] = [
  { id: "desk-setup", skus: ["DESK", "CHAIR", "LAMP"], percent: 15 },
  { id: "lighting", skus: ["LAMP", "BULB"], percent: 10 },
];
