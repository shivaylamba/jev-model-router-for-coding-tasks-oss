import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { ConfigError, readConfig } from "../src/config.ts";

function tempPath(): string {
  const dir = mkdtempSync(join(tmpdir(), "cfg-"));
  return join(dir, "devserver.json");
}

function fileWith(text: string): string {
  const path = tempPath();
  writeFileSync(path, text);
  return path;
}

test("callback receives the merged config", (_t, done) => {
  readConfig(fileWith('{"port": 3000}'), (err, config) => {
    assert.equal(err, null);
    assert.deepEqual(config, { host: "localhost", port: 3000, debug: false });
    done();
  });
});

test("callback receives a ConfigError for a bad port", (_t, done) => {
  readConfig(fileWith('{"port": 0}'), (err) => {
    assert.ok(err instanceof ConfigError);
    done();
  });
});

test("with a callback, readConfig returns undefined", (_t, done) => {
  const result = readConfig(fileWith("{}"), (err) => {
    assert.equal(err, null);
    done();
  });
  assert.equal(result, undefined);
});

test("without a callback, resolves with the merged config", async () => {
  const config = await readConfig(fileWith('{"port": 3000}'));
  assert.deepEqual(config, { host: "localhost", port: 3000, debug: false });
});

test("without a callback, rejects with the file-system error for a missing file", async () => {
  await assert.rejects(readConfig(tempPath()), { code: "ENOENT" });
});

test("without a callback, rejects with a SyntaxError for malformed JSON", async () => {
  await assert.rejects(readConfig(fileWith("{")), SyntaxError);
});

test("with a callback, failures reach the callback instead of an unhandled rejection", (_t, done) => {
  let callbackErr = null;
  const onUnhandled = () => {
    process.off("unhandledRejection", onUnhandled);
    done(new Error("callback-form failure surfaced as an unhandled rejection"));
  };
  process.on("unhandledRejection", onUnhandled);
  // Missing file: ENOENT, a guaranteed rejection if the promise had no handler.
  readConfig(tempPath(), (err) => {
    callbackErr = err;
  });
  // Let several macrotasks pass so any stray rejection would have fired.
  setTimeout(() => {
    process.off("unhandledRejection", onUnhandled);
    assert.ok(callbackErr !== null);
    assert.equal(callbackErr.code, "ENOENT");
    done();
  }, 50);
});

test("without a callback, rejects with a ConfigError for a bad port", async () => {
  await assert.rejects(readConfig(fileWith('{"port": 0}')), ConfigError);
});
