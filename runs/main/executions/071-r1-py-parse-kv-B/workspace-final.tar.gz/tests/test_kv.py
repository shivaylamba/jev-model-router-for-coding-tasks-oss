import unittest

from kv import format_kv, parse_kv


class FormatKvTest(unittest.TestCase):
    def test_format(self):
        self.assertEqual(format_kv({"a": 1, "b": "two"}), "a=1; b=two")

    def test_empty(self):
        self.assertEqual(format_kv({}), "")


class ParseKvTest(unittest.TestCase):
    def test_basic(self):
        self.assertEqual(parse_kv("a=1; b = two"), {"a": "1", "b": "two"})

    def test_empty_string_and_blank_segments(self):
        self.assertEqual(parse_kv(""), {})
        self.assertEqual(parse_kv("  ; ; "), {})

    def test_splits_on_first_equals_only(self):
        self.assertEqual(parse_kv("query=x=1"), {"query": "x=1"})

    def test_empty_value(self):
        self.assertEqual(parse_kv("a="), {"a": ""})

    def test_last_value_wins(self):
        self.assertEqual(parse_kv("a=1; a=2"), {"a": "2"})

    def test_missing_equals_raises(self):
        with self.assertRaises(ValueError):
            parse_kv("a=1; bogus; b=2")

    def test_empty_key_raises(self):
        with self.assertRaises(ValueError):
            parse_kv(" = 2")

    def test_round_trips_through_format_kv(self):
        pairs = {"region": "eu-west", "replicas": "3"}
        self.assertEqual(parse_kv(format_kv(pairs)), pairs)


if __name__ == "__main__":
    unittest.main()
