"""Helpers for `key=value; key=value` strings."""


def format_kv(pairs):
    """Format a mapping as `key=value; key=value`, in the mapping's order.

    >>> format_kv({"region": "eu-west", "replicas": 3})
    'region=eu-west; replicas=3'
    """
    return "; ".join(f"{key}={value}" for key, value in pairs.items())


def parse_kv(text):
    """Parse a `key=value; key=value` string into a dict, the inverse of `format_kv`.

    Values stay strings, segments are split on their first `=`, and a
    repeated key keeps its last value.

    >>> parse_kv("a=1; b = two")
    {'a': '1', 'b': 'two'}
    >>> parse_kv("query=x=1")
    {'query': 'x=1'}
    >>> parse_kv("")
    {}
    """
    pairs = {}
    for segment in text.split(";"):
        key, sep, value = segment.partition("=")
        if not sep:
            if not key.strip():
                continue  # Empty or whitespace-only segment: skip it.
            raise ValueError(f"segment has no '=': {segment.strip()!r}")
        key = key.strip()
        if not key:
            raise ValueError(f"empty key in segment: {segment.strip()!r}")
        pairs[key] = value.strip()
    return pairs
