import { test } from "node:test";
import assert from "node:assert/strict";
import { Editor } from "../src/editor.ts";

/** Mutable fake clock so grouping behaviour is deterministic. */
function fakeClock(start = 0) {
  let now = start;
  return {
    clock: () => now,
    advance(ms: number) {
      now += ms;
    },
  };
}

// --- basic undo/redo -------------------------------------------------------

test("undo restores text and selection", () => {
  const editor = new Editor("hello world");
  editor.select(6, 11);
  editor.insert("there");
  assert.equal(editor.text, "hello there");
  assert.deepEqual(editor.selection, { start: 11, end: 11 });

  assert.equal(editor.undo(), true);
  assert.equal(editor.text, "hello world");
  assert.deepEqual(editor.selection, { start: 6, end: 11 });
});

test("redo re-applies text and selection", () => {
  const editor = new Editor("abc");
  editor.select(1);
  editor.deleteBackward();
  editor.undo();
  assert.equal(editor.text, "abc");
  assert.deepEqual(editor.selection, { start: 1, end: 1 });

  assert.equal(editor.redo(), true);
  assert.equal(editor.text, "bc");
  assert.deepEqual(editor.selection, { start: 0, end: 0 });
});

test("undo/redo return false and do nothing when stacks are empty", () => {
  const editor = new Editor("abc");
  assert.equal(editor.canUndo(), false);
  assert.equal(editor.canRedo(), false);
  assert.equal(editor.undo(), false);
  assert.equal(editor.redo(), false);
  assert.equal(editor.text, "abc");
});

test("initial text is not undoable", () => {
  const editor = new Editor("hello");
  assert.equal(editor.canUndo(), false);
});

test("deleteForward creates an undoable step", () => {
  const editor = new Editor("abc");
  editor.select(1);
  editor.deleteForward();
  assert.equal(editor.text, "ac");
  editor.undo();
  assert.equal(editor.text, "abc");
  assert.deepEqual(editor.selection, { start: 1, end: 1 });
});

// --- no-op edits & selection changes ----------------------------------------

test("no-op deleteBackward creates no step and keeps the redo stack", () => {
  const editor = new Editor("ab");
  editor.insert("c"); // "abc", cursor at 3
  editor.undo(); // "ab"
  assert.equal(editor.canRedo(), true);

  editor.select(0);
  editor.deleteBackward(); // no-op at offset 0
  assert.equal(editor.text, "ab");
  assert.equal(editor.canRedo(), true);
  assert.equal(editor.redo(), true);
  assert.equal(editor.text, "abc");
});

test("insert(\"\") with empty selection creates no step and keeps the redo stack", () => {
  const editor = new Editor("ab");
  editor.insert("c");
  editor.undo();
  editor.insert("");
  assert.equal(editor.canRedo(), true);
  assert.equal(editor.canUndo(), false);
});

test("select never creates a step and never clears the redo stack", () => {
  const editor = new Editor("ab");
  editor.insert("c");
  editor.undo();
  editor.select(0, 2);
  editor.select(1);
  assert.equal(editor.canRedo(), true);
  assert.equal(editor.canUndo(), false);
  assert.equal(editor.redo(), true);
  assert.equal(editor.text, "abc");
});

test("a new change clears the redo stack", () => {
  const editor = new Editor("ab");
  editor.insert("c");
  editor.undo();
  editor.insert("d");
  assert.equal(editor.canRedo(), false);
  assert.equal(editor.redo(), false);
});

// --- typing groups -----------------------------------------------------------

test("consecutive keystrokes within 1000 ms group into one step", () => {
  const { clock, advance } = fakeClock();
  const editor = new Editor("", { clock });
  editor.insert("h");
  advance(999);
  editor.insert("i");
  advance(500);
  editor.insert("!");
  assert.equal(editor.text, "hi!");
  assert.equal(editor.undo(), true);
  assert.equal(editor.text, "");
  assert.equal(editor.canUndo(), false);
});

test("a gap of exactly 1000 ms starts a new step", () => {
  const { clock, advance } = fakeClock();
  const editor = new Editor("", { clock });
  editor.insert("a");
  advance(1000);
  editor.insert("b");
  assert.equal(editor.undo(), true);
  assert.equal(editor.text, "a");
  assert.equal(editor.undo(), true);
  assert.equal(editor.text, "");
});

test("time is measured from the previous keystroke, not the group start", () => {
  const { clock, advance } = fakeClock();
  const editor = new Editor("", { clock });
  editor.insert("a");
  for (let i = 0; i < 10; i++) {
    advance(900); // well under 1000 ms each time
    editor.insert("x");
  }
  assert.equal(editor.text, "axxxxxxxxxx");
  editor.undo();
  assert.equal(editor.text, ""); // all one group despite 9000 ms total span
});

test("newline insert is not typing and starts its own step", () => {
  const { clock, advance } = fakeClock();
  const editor = new Editor("", { clock });
  editor.insert("a");
  advance(100);
  editor.insert("\n");
  editor.insert("b");
  assert.equal(editor.undo(), true); // removes "b"
  assert.equal(editor.text, "a\n");
  assert.equal(editor.undo(), true); // removes "\n"
  assert.equal(editor.text, "a");
  assert.equal(editor.undo(), true); // removes "a"
  assert.equal(editor.text, "");
});

test("pasting multiple characters is not typing", () => {
  const { clock, advance } = fakeClock();
  const editor = new Editor("", { clock });
  editor.insert("a");
  advance(100);
  editor.insert("bc");
  advance(100);
  editor.insert("d");
  // "d" does not extend the "bc" step (bc was not typing), so: [a][bc][d]
  assert.equal(editor.undo(), true);
  assert.equal(editor.text, "abc");
  assert.equal(editor.undo(), true);
  assert.equal(editor.text, "a");
  assert.equal(editor.undo(), true);
  assert.equal(editor.text, "");
});

test("insert replacing a non-empty selection is not typing", () => {
  const { clock, advance } = fakeClock();
  const editor = new Editor("xy", { clock });
  editor.select(0, 2);
  editor.insert("a"); // replaces selection -> own step, not typing
  advance(100);
  editor.insert("b"); // typing, but previous step was not a typing group
  assert.equal(editor.text, "ab");
  assert.equal(editor.undo(), true);
  assert.equal(editor.text, "a");
  assert.equal(editor.undo(), true);
  assert.equal(editor.text, "xy");
  assert.deepEqual(editor.selection, { start: 0, end: 2 });
});

test("select closes the open typing group", () => {
  const { clock, advance } = fakeClock();
  const editor = new Editor("", { clock });
  editor.insert("a");
  editor.select(1); // same spot, still closes the group
  advance(100);
  editor.insert("b");
  assert.equal(editor.undo(), true);
  assert.equal(editor.text, "a");
});

test("deletes close the open typing group", () => {
  const { clock, advance } = fakeClock();
  const editor = new Editor("", { clock });
  editor.insert("a");
  editor.deleteBackward();
  advance(100);
  editor.insert("b");
  assert.equal(editor.text, "b");
  assert.equal(editor.undo(), true);
  assert.equal(editor.text, "");
  assert.equal(editor.undo(), true);
  assert.equal(editor.text, "a");
  assert.equal(editor.undo(), true);
  assert.equal(editor.text, "");
});

test("a non-typing no-op insert closes the group", () => {
  const { clock, advance } = fakeClock();
  const editor = new Editor("", { clock });
  editor.insert("a");
  editor.insert(""); // no-op, but still closes the group
  advance(100);
  editor.insert("b");
  assert.equal(editor.undo(), true);
  assert.equal(editor.text, "a");
});

test("undo closes the typing group", () => {
  const { clock, advance } = fakeClock();
  const editor = new Editor("", { clock });
  editor.insert("a");
  advance(100);
  editor.insert("b"); // group: "ab"
  editor.undo(); // back to ""
  editor.redo(); // "ab" again
  advance(100);
  editor.insert("c"); // group was closed by undo/redo -> new step
  assert.equal(editor.text, "abc");
  editor.undo();
  assert.equal(editor.text, "ab");
});

// --- transactions ------------------------------------------------------------

test("transact makes everything inside one undo step", () => {
  const editor = new Editor("ab");
  const result = editor.transact(() => {
    editor.select(2);
    editor.insert("c");
    editor.insert("d");
    editor.deleteBackward();
    return 42;
  });
  assert.equal(result, 42);
  assert.equal(editor.text, "abc");
  assert.equal(editor.undo(), true);
  assert.equal(editor.text, "ab");
  assert.deepEqual(editor.selection, { start: 2, end: 2 });
  assert.equal(editor.canUndo(), false);
});

test("transact restores text and selection when the callback throws", () => {
  const editor = new Editor("ab");
  const boom = new Error("boom");
  assert.throws(
    () =>
      editor.transact(() => {
        editor.select(0, 2);
        editor.insert("zz");
        throw boom;
      }),
    (error) => error === boom,
  );
  assert.equal(editor.text, "ab");
  assert.deepEqual(editor.selection, { start: 2, end: 2 });
  assert.equal(editor.canUndo(), false);
});

test("failed transaction leaves the redo stack alone", () => {
  const editor = new Editor("ab");
  editor.insert("c");
  editor.undo();
  assert.equal(editor.canRedo(), true);
  assert.throws(() =>
    editor.transact(() => {
      editor.insert("x");
      throw new Error("nope");
    }),
  );
  assert.equal(editor.canRedo(), true);
});

test("no-change transact creates no step and leaves the redo stack alone", () => {
  const editor = new Editor("ab");
  editor.insert("c"); // "abc"
  editor.undo();
  editor.transact(() => {
    editor.select(0); // selection-only transaction
  });
  assert.equal(editor.canRedo(), true);
  assert.equal(editor.canUndo(), false);
});

test("text that ends up equal creates no step even if it changed midway", () => {
  const editor = new Editor("ab");
  editor.transact(() => {
    editor.select(2);
    editor.insert("x");
    editor.deleteBackward();
  });
  assert.equal(editor.text, "ab");
  assert.equal(editor.canUndo(), false);
});

test("nested transact joins the outermost step", () => {
  const editor = new Editor();
  editor.transact(() => {
    editor.insert("a");
    editor.transact(() => {
      editor.transact(() => {
        editor.insert("b");
      });
      editor.insert("c");
    });
  });
  assert.equal(editor.text, "abc");
  assert.equal(editor.undo(), true);
  assert.equal(editor.text, "");
  assert.equal(editor.canUndo(), false);
});

test("a throwing inner transaction restores the outer transaction's start state", () => {
  const editor = new Editor("ab");
  assert.throws(() =>
    editor.transact(() => {
      editor.insert("x"); // "abx"
      editor.transact(() => {
        editor.insert("y"); // "abxy"
        throw new Error("inner fail");
      });
    }),
  );
  assert.equal(editor.text, "ab");
  assert.equal(editor.canUndo(), false);
});

test("undo and redo inside a transaction throw", () => {
  const editor = new Editor("ab");
  editor.insert("c"); // something to undo
  assert.throws(
    () => editor.transact(() => editor.undo()),
    /transaction/,
  );
  assert.throws(
    () => editor.transact(() => editor.redo()),
    /transaction/,
  );
  // the failed transactions changed nothing
  assert.equal(editor.text, "abc");
  assert.equal(editor.canUndo(), true);
});

test("typing inside a transaction does not extend a step from before it", () => {
  const { clock, advance } = fakeClock();
  const editor = new Editor("", { clock });
  editor.insert("a"); // typing group
  advance(100);
  editor.transact(() => {
    editor.insert("b"); // typed within 1000 ms, but inside a transaction
  });
  assert.equal(editor.text, "ab");
  assert.equal(editor.undo(), true); // undoes just the transaction
  assert.equal(editor.text, "a");
});

test("typing after a transaction does not extend the transaction's step", () => {
  const { clock, advance } = fakeClock();
  const editor = new Editor("", { clock });
  editor.transact(() => {
    editor.insert("a");
  });
  advance(100);
  editor.insert("b"); // within 1000 ms, but the transaction step is not a group
  assert.equal(editor.text, "ab");
  assert.equal(editor.undo(), true);
  assert.equal(editor.text, "a");
  assert.equal(editor.undo(), true);
  assert.equal(editor.text, "");
});

// --- history limit -----------------------------------------------------------

test("history limit discards the oldest steps", () => {
  const editor = new Editor("", { historyLimit: 2 });
  editor.insert("a");
  editor.select(1);
  editor.insert("b");
  editor.select(2);
  editor.insert("c");
  assert.equal(editor.text, "abc");
  assert.equal(editor.undo(), true); // remove c
  assert.equal(editor.undo(), true); // remove b
  assert.equal(editor.undo(), false); // "a" was discarded
  assert.equal(editor.text, "a");
});

test("extending a typing group does not count towards the limit", () => {
  const { clock, advance } = fakeClock();
  const editor = new Editor("", { historyLimit: 1, clock });
  editor.insert("a");
  advance(100);
  editor.insert("b");
  advance(100);
  editor.insert("c");
  // still a single step despite limit 1
  assert.equal(editor.undo(), true);
  assert.equal(editor.text, "");
});

test("historyLimit: 0 means nothing is undoable", () => {
  const limited = new Editor("ab", { historyLimit: 0 });
  limited.insert("x");
  limited.deleteBackward();
  assert.equal(limited.canUndo(), false);
  assert.equal(limited.undo(), false);
  limited.transact(() => limited.insert("y"));
  assert.equal(limited.canUndo(), false);
  assert.equal(limited.text, "aby");
});

test("invalid historyLimit throws RangeError", () => {
  assert.throws(() => new Editor("", { historyLimit: -1 }), RangeError);
  assert.throws(() => new Editor("", { historyLimit: 1.5 }), RangeError);
  assert.throws(() => new Editor("", { historyLimit: NaN }), RangeError);
  // valid values don't throw
  new Editor("", { historyLimit: 0 });
  new Editor("", { historyLimit: 100 });
});

// --- original editing behaviour is unchanged --------------------------------

test("default constructor options work (real clock, default limit)", () => {
  const editor = new Editor("hello");
  editor.insert("!");
  assert.equal(editor.text, "hello!");
  editor.undo();
  assert.equal(editor.text, "hello");
});
