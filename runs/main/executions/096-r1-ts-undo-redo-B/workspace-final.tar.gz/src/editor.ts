import { History, normalizeHistoryLimit, type State } from "./history.ts";
import { isEmpty, normalizeSelection, replaceRange, type Selection } from "./text.ts";

export interface EditorOptions {
  /** Milliseconds clock used by undo grouping. Defaults to Date.now. */
  clock?: () => number;
  /** Maximum number of undo steps kept. Defaults to 100. */
  historyLimit?: number;
}

export class Editor {
  private content: string;
  private sel: Selection;
  private readonly history: History;

  constructor(text: string = "", options: EditorOptions = {}) {
    this.content = text;
    this.sel = { start: text.length, end: text.length };
    this.history = new History(normalizeHistoryLimit(options.historyLimit), options.clock ?? Date.now);
  }

  get text(): string {
    return this.content;
  }

  /** A copy of the current selection. */
  get selection(): Selection {
    return { ...this.sel };
  }

  /** Set the selection; offsets are clamped to the text and ordered. `end` defaults to `start`. */
  select(start: number, end: number = start): void {
    this.history.closeTypingGroup();
    this.sel = normalizeSelection(this.content.length, start, end);
  }

  /** Replace the selection with `str` and put the cursor right after it. */
  insert(str: string): void {
    const { start, end } = this.sel;
    const typing = this.isTypingInsert(str);
    const before = this.snapshot();
    const newText = replaceRange(this.content, start, end, str);
    const cursor = start + str.length;
    if (newText === this.content) {
      // No-op edits create no step and leave the redo stack alone. A no-op
      // typing insert is impossible (one char always changes the text), so
      // any no-op here is a non-typing insert and closes the typing group.
      this.sel = { start: cursor, end: cursor };
      this.history.closeTypingGroup();
      return;
    }
    this.content = newText;
    this.sel = { start: cursor, end: cursor };
    // record() extends the open typing group for typing inserts; for anything
    // else it creates a fresh step (closing the group in the process).
    this.history.record(before, this.snapshot(), typing);
  }

  /** Delete the selection, or the character before the cursor when the selection is empty. */
  deleteBackward(): void {
    this.history.closeTypingGroup();
    const { start, end } = this.sel;
    if (!isEmpty(this.sel)) {
      const before = this.snapshot();
      this.content = replaceRange(this.content, start, end, "");
      this.sel = { start, end: start };
      this.finishRecord(before);
    } else if (start > 0) {
      const before = this.snapshot();
      this.content = replaceRange(this.content, start - 1, start, "");
      this.sel = { start: start - 1, end: start - 1 };
      this.finishRecord(before);
    }
    // No-op deleteBackward (cursor at 0 with empty selection) creates no step.
  }

  /** Delete the selection, or the character after the cursor when the selection is empty. */
  deleteForward(): void {
    this.history.closeTypingGroup();
    const { start, end } = this.sel;
    if (!isEmpty(this.sel)) {
      const before = this.snapshot();
      this.content = replaceRange(this.content, start, end, "");
      this.sel = { start, end: start };
      this.finishRecord(before);
    } else if (start < this.content.length) {
      const before = this.snapshot();
      this.content = replaceRange(this.content, start, start + 1, "");
      this.finishRecord(before);
    }
    // No-op deleteForward (cursor at end with empty selection) creates no step.
  }

  /**
   * Run `fn` as a single undo step. Nested calls join the outermost one.
   * If `fn` throws, the text and selection are restored to their state when
   * `transact` was called, no step is created, and the error is rethrown.
   */
  transact<T>(fn: () => T): T {
    this.history.closeTypingGroup();
    this.history.beginTransaction(this.snapshot());
    try {
      const result = fn();
      this.history.endTransaction(this.snapshot());
      return result;
    } catch (error) {
      const restored = this.history.abortTransaction();
      this.apply(restored);
      throw error;
    }
  }

  undo(): boolean {
    const step = this.history.takeUndo();
    if (step === null) {
      return false;
    }
    this.apply(step.before);
    this.history.passToRedo(step);
    return true;
  }

  redo(): boolean {
    const step = this.history.takeRedo();
    if (step === null) {
      return false;
    }
    this.apply(step.after);
    this.history.passToUndo(step);
    return true;
  }

  canUndo(): boolean {
    return this.history.canUndo();
  }

  canRedo(): boolean {
    return this.history.canRedo();
  }

  private snapshot(): State {
    return { text: this.content, selection: { ...this.sel } };
  }

  private apply(state: State): void {
    this.content = state.text;
    this.sel = { ...state.selection };
  }

  private finishRecord(before: State): void {
    if (this.content === before.text) {
      // No-op edit: no step and the redo stack stays as it was.
      return;
    }
    this.history.record(before, this.snapshot(), false);
  }

  /** Typing = empty selection and exactly one character that isn't a newline. */
  private isTypingInsert(str: string): boolean {
    return isEmpty(this.sel) && str.length === 1 && str !== "\n";
  }
}
