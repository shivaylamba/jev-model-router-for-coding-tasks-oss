import type { Selection } from "./text.ts";

/** A snapshot of the text and the selection at one moment. */
export interface State {
  text: string;
  selection: Selection;
}

/** One undo step: the "before" and "after" states of a change. */
export interface Step {
  before: State;
  after: State;
}

/** Internal step with typing-group bookkeeping. */
interface TrackedStep extends Step {
  /** Clock time of the latest typing insert in this group. */
  lastKeystroke?: number;
}

/** Time span within which consecutive typing inserts extend one group (ms). */
export const TYPING_GROUP_INTERVAL = 1000;

function copyState(state: State): State {
  return { text: state.text, selection: { ...state.selection } };
}

/**
 * Undo/redo bookkeeping: the undo and redo stacks, typing-group tracking and
 * transaction nesting. The History only records states; the Editor performs
 * the actual edits and feeds snapshots in.
 */
export class History {
  private readonly limit: number;
  private readonly clock: () => number;
  private undoStack: TrackedStep[] = [];
  private redoStack: Step[] = [];
  private openTypingGroup: TrackedStep | null = null;
  /** "Before" snapshots of the currently running transactions, outermost first. */
  private transactionStack: State[] = [];

  constructor(limit: number, clock: () => number) {
    this.limit = limit;
    this.clock = clock;
  }

  get inTransaction(): boolean {
    return this.transactionStack.length > 0;
  }

  canUndo(): boolean {
    return this.undoStack.length > 0;
  }

  canRedo(): boolean {
    return this.redoStack.length > 0;
  }

  /**
   * Record a change from `before` to `after`. A typing insert extends the most
   * recent step instead of creating a new one when that step is an open typing
   * group and less than TYPING_GROUP_INTERVAL has passed since that group's
   * previous keystroke (measured by clock). An extended step keeps its
   * original "before" state, and extending does not count as a new step for
   * the history limit. Any step creation or extension clears the redo stack.
   *
   * While a transaction is running, individual edits are not recorded — the
   * outermost transaction's endTransaction records a single step covering
   * everything the callback did.
   */
  record(before: State, after: State, typing: boolean): void {
    if (this.inTransaction) {
      this.closeTypingGroup();
      return;
    }
    const now = this.clock();
    const group = this.openTypingGroup;
    if (
      typing &&
      group !== null &&
      now - group.lastKeystroke! < TYPING_GROUP_INTERVAL
    ) {
      group.after = copyState(after);
      group.lastKeystroke = now;
      this.redoStack = [];
      return;
    }
    const step: TrackedStep = {
      before: copyState(before),
      after: copyState(after),
    };
    if (typing) {
      step.lastKeystroke = now;
    }
    this.undoStack.push(step);
    while (this.undoStack.length > this.limit) {
      this.undoStack.shift();
    }
    this.redoStack = [];
    this.openTypingGroup = typing ? step : null;
  }

  /** Close the open typing group, if any. */
  closeTypingGroup(): void {
    this.openTypingGroup = null;
  }

  /** Start a transaction, remembering the state at its start. */
  beginTransaction(state: State): void {
    this.transactionStack.push(copyState(state));
    this.closeTypingGroup();
  }

  /**
   * End the innermost transaction. `final` is the state when its callback
   * returned. Nested transactions join the outermost one: only the outermost
   * end records a step, with "before" taken from when the outermost
   * transaction started. If the text is unchanged, no step is created and the
   * redo stack is left alone.
   */
  endTransaction(final: State): void {
    const before = this.transactionStack.pop()!;
    this.closeTypingGroup();
    if (this.transactionStack.length > 0) {
      return; // Nested transaction: the outermost one records the step.
    }
    if (final.text === before.text) {
      return;
    }
    this.record(before, final, false);
  }

  /**
   * Roll back a transaction whose callback threw: return the recorded
   * "before" state so the editor can restore it. No step is created and the
   * redo stack is left alone; the error is rethrown by the caller.
   */
  abortTransaction(): State {
    const before = this.transactionStack.pop()!;
    this.closeTypingGroup();
    return copyState(before);
  }

  /**
   * Pop the most recent undo step and close the open typing group. Returns
   * null when there is nothing to undo. The caller applies step.before and
   * then moves the step to the redo stack with passToRedo(step).
   */
  takeUndo(): Step | null {
    if (this.inTransaction) {
      throw new Error("undo() is not allowed while a transaction is running");
    }
    this.closeTypingGroup();
    return this.undoStack.pop() ?? null;
  }

  /**
   * Pop the most recent redo step and close the open typing group. Returns
   * null when there is nothing to redo. The caller applies step.after and
   * then moves the step back to the undo stack with passToUndo(step).
   */
  takeRedo(): Step | null {
    if (this.inTransaction) {
      throw new Error("redo() is not allowed while a transaction is running");
    }
    this.closeTypingGroup();
    return this.redoStack.pop() ?? null;
  }

  /** Move an undone step onto the redo stack. */
  passToRedo(step: Step): void {
    this.redoStack.push(step);
  }

  /** Move a redone step back onto the undo stack. */
  passToUndo(step: Step): void {
    this.undoStack.push(step);
  }
}

/** Validate the historyLimit option: it must be an integer >= 0. */
export function normalizeHistoryLimit(value: number | undefined): number {
  if (value === undefined) {
    return 100;
  }
  if (!Number.isInteger(value) || value < 0) {
    throw new RangeError("historyLimit must be an integer >= 0");
  }
  return value;
}
