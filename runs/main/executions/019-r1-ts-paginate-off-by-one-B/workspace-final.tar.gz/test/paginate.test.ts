import { test } from "node:test";
import assert from "node:assert/strict";
import { paginate } from "../src/paginate.ts";

test("rejects invalid arguments", () => {
  assert.throws(() => paginate([1, 2, 3], 0, 10), RangeError);
  assert.throws(() => paginate([1, 2, 3], 1, 0), RangeError);
  assert.throws(() => paginate([1, 2, 3], 1.5, 10), RangeError);
});

test("pages are 1-based and the last page may be shorter", () => {
  const items = Array.from({ length: 25 }, (_, i) => i + 1);

  assert.deepEqual(paginate(items, 1, 10), {
    items: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    page: 1,
    pageSize: 10,
    totalItems: 25,
    totalPages: 3,
    hasNext: true,
    hasPrev: false,
  });

  const last = paginate(items, 3, 10);
  assert.deepEqual(last.items, [21, 22, 23, 24, 25]);
  assert.equal(last.hasNext, false);
  assert.equal(last.hasPrev, true);
});

test("a page past the end has no items", () => {
  const page = paginate([1, 2, 3], 4, 10);
  assert.deepEqual(page.items, []);
  assert.equal(page.totalPages, 1);
  assert.equal(page.hasNext, false);
});

test("totalPages is 0 for an empty list", () => {
  const page = paginate([], 1, 10);
  assert.deepEqual(page, {
    items: [],
    page: 1,
    pageSize: 10,
    totalItems: 0,
    totalPages: 0,
    hasNext: false,
    hasPrev: false,
  });
});

test("an exact multiple of pageSize has no empty trailing page", () => {
  const page = paginate([1, 2, 3, 4], 2, 2);
  assert.deepEqual(page.items, [3, 4]);
  assert.equal(page.totalPages, 2);
  assert.equal(page.hasNext, false);
});
