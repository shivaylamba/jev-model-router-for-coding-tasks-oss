import { isEmpty, normalizeSelection, replaceRange, type Selection } from "./text.ts";
import { HistoryManager } from "./history.ts";

export interface EditorOptions {
  /** Milliseconds clock used by undo grouping. Defaults to Date.now. */
  clock?: () => number;
  /** Maximum number of undo steps kept. Defaults to 100. */
  historyLimit?: number;
}

export class Editor {
  private content: string;
  private sel: Selection;
  private history: HistoryManager;

  constructor(text: string = "", options: EditorOptions = {}) {
    this.content = text;
    this.sel = { start: text.length, end: text.length };
    this.history = new HistoryManager({
      clock: options.clock ?? Date.now,
      historyLimit: options.historyLimit ?? 100,
    });
  }

  get text(): string {
    return this.content;
  }

  /** A copy of the current selection. */
  get selection(): Selection {
    return { ...this.sel };
  }

  /** Set the selection; offsets are clamped to the text and ordered. `end` defaults to `start`. */
  select(start: number, end: number = start): void {
    this.sel = normalizeSelection(this.content.length, start, end);
    this.history.closeGroup(); // select never creates a step and never clears redo
  }

  /** Replace the selection with `str` and put the cursor right after it. */
  insert(str: string): void {
    const { start, end } = this.sel;
    const typing = start === end && str.length === 1 && str !== "\n";
    if (!typing) this.history.closeGroup(); // any non-typing insert closes the group
    const before = this.history.captureBefore(this.capture());
    this.content = replaceRange(this.content, start, end, str);
    const cursor = start + str.length;
    this.sel = { start: cursor, end: cursor };
    this.record(before, typing ? "typing" : "edit");
  }

  /** Delete the selection, or the character before the cursor when the selection is empty. */
  deleteBackward(): void {
    this.history.closeGroup();
    const before = this.history.captureBefore(this.capture());
    const { start, end } = this.sel;
    if (!isEmpty(this.sel)) {
      this.content = replaceRange(this.content, start, end, "");
      this.sel = { start, end: start };
    } else if (start > 0) {
      this.content = replaceRange(this.content, start - 1, start, "");
      this.sel = { start: start - 1, end: start - 1 };
    }
    this.record(before, "edit");
  }

  /** Delete the selection, or the character after the cursor when the selection is empty. */
  deleteForward(): void {
    this.history.closeGroup();
    const before = this.history.captureBefore(this.capture());
    const { start, end } = this.sel;
    if (!isEmpty(this.sel)) {
      this.content = replaceRange(this.content, start, end, "");
      this.sel = { start, end: start };
    } else if (start < this.content.length) {
      this.content = replaceRange(this.content, start, start + 1, "");
    }
    this.record(before, "edit");
  }

  canUndo(): boolean {
    return this.history.canUndo();
  }

  canRedo(): boolean {
    return this.history.canRedo();
  }

  /** Revert the most recent step, restoring text and selection. */
  undo(): boolean {
    const target = this.history.undo();
    if (!target) return false;
    this.restore(target);
    return true;
  }

  /** Re-apply the most recently undone step, restoring text and selection. */
  redo(): boolean {
    const target = this.history.redo();
    if (!target) return false;
    this.restore(target);
    return true;
  }

  /** Run fn as a single undo step; returns fn's result. Throws roll back text and selection. */
  transact<T>(fn: () => T): T {
    return this.history.transact(fn, {
      capture: () => this.capture(),
      restore: (snapshot) => this.restore(snapshot),
    });
  }

  private capture() {
    return { text: this.content, selection: { ...this.sel } };
  }

  private restore(snapshot: { text: string; selection: Selection }) {
    this.content = snapshot.text;
    this.sel = { ...snapshot.selection };
  }

  /** Record a step only when the text actually changed; no-ops leave the redo stack alone. */
  private record(before: { text: string; selection: Selection } | null, kind: "typing" | "edit") {
    if (before === null) {
      // Inside a transaction: always report, the transaction decides at the end.
      this.history.captureAfter(null, kind, this.capture());
      return;
    }
    if (this.content === before.text) return;
    this.history.captureAfter(before, kind, this.capture());
  }
}
