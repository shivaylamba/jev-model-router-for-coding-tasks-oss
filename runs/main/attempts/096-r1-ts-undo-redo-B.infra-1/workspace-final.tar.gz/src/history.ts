/**
 * Undo/redo bookkeeping for the editor.
 *
 * A "snapshot" is a frozen copy of the editor's text + selection.
 * A "step" pairs the snapshot before a change with the one after.
 * Undo sets the editor to a step's `before` and moves it to the redo stack;
 * redo restores the `after` and moves it back.
 *
 * Only this module decides whether a change becomes a new step, extends the
 * open typing group, or is dropped (no-op). The editor just reports edits.
 */

/** @typedef {{ text: string, selection: { start: number, end: number } }} Snapshot */
/** @typedef {{ before: Snapshot, after: Snapshot, typing: boolean, lastTypingAt: number }} Step */

const TYPING_WINDOW_MS = 1000;

export class HistoryManager {
  #undoStack = [];   /** @type {Step[]} */
  #redoStack = [];   /** @type {Step[]} */
  #openGroup = null; /** @type {Step|null} — a typing step that can still be extended */

  #clock;
  #limit;

  // Transaction state (depth > 0 means a transaction is running)
  #depth = 0;
  #txBefore = null;      /** @type {Snapshot|null} */
  #txAfter = null;       /** @type {Snapshot|null} */
  #txHadOpenGroup = false;

  constructor({ clock = Date.now, historyLimit = 100 } = {}) {
    if (!Number.isInteger(historyLimit) || historyLimit < 0) {
      throw new RangeError("historyLimit must be an integer >= 0");
    }
    this.#clock = clock;
    this.#limit = historyLimit;
  }

  get inTransaction() {
    return this.#depth > 0;
  }

  canUndo() {
    return !this.inTransaction && this.#undoStack.length > 0;
  }

  canRedo() {
    return !this.inTransaction && this.#redoStack.length > 0;
  }

  /**
   * Runs fn as one undo step. Returns fn's result.
   * Nested calls join the outermost transaction. If fn throws, the state
   * recorded at entry is passed to `rollback` and the error is rethrown.
   */
  transact(fn, rollback) {
    this.#depth++;
    if (this.#depth === 1) {
      // Outermost: close any open typing group and snapshot the entry state.
      this.#txHadOpenGroup = this.#openGroup !== null;
      this.#openGroup = null;
      this.#txBefore = rollback.capture();
      this.#txAfter = null;
    }
    try {
      const result = fn();
      this.#depth--;
      this.#finishTransaction(rollback);
      return result;
    } catch (err) {
      this.#depth--;
      if (this.#depth === 0) {
        // Outermost failed: restore text/selection, drop any buffered after-state,
        // leave the redo stack alone, rethrow.
        rollback.restore(this.#txBefore);
        // A group that was open at entry was closed by entering the transaction.
        this.#txBefore = null;
        this.#txAfter = null;
        this.#txHadOpenGroup = false;
      }
      throw err;
    }
  }

  #finishTransaction(rollback) {
    if (this.#depth > 0) return; // nested call: the outermost will finish
    const before = this.#txBefore;
    const after = rollback.capture();
    this.#txBefore = null;
    this.#txAfter = null;
    this.#txHadOpenGroup = false;
    if (after.text !== before.text) {
      this.#pushStep({ before, after, typing: false, lastTypingAt: 0 });
    }
    // No text change → no step, redo stack untouched.
  }

  /**
   * Called by the editor immediately before a text edit. Returns a snapshot
   * to pass back into `captureAfter`, or null inside a transaction (the
   * transaction owns the snapshots instead).
   */
  captureBefore(currentSnapshot) {
    if (this.inTransaction) return null;
    return currentSnapshot;
  }

  /**
   * Called by the editor after a text edit.
   * @param {Snapshot|null} before - from captureBefore (null in a transaction)
   * @param {"typing"|"edit"} kind - typing = single non-newline char into empty selection
   * @param {Snapshot} after - the state after the edit
   */
  captureAfter(before, kind, after) {
    if (this.inTransaction) {
      this.#txAfter = after; // last edit wins; outermost finishTransaction reads capture() anyway
      return;
    }

    const now = this.#clock();

    if (kind === "typing") {
      const g = this.#openGroup;
      if (g && now - g.lastTypingAt < TYPING_WINDOW_MS) {
        // Extend the open group: keep its `before`, advance `after`.
        g.after = after;
        g.lastTypingAt = now;
        this.#redoStack = []; // extending a step still counts as a new change
        return;
      }
      // Not extendable → start a new typing group.
      const step = { before, after, typing: true, lastTypingAt: now };
      this.#openGroup = step;
      this.#pushStep(step);
      return;
    }

    // Non-typing edit: closes any open group, always its own step.
    this.#openGroup = null;
    this.#pushStep({ before, after, typing: false, lastTypingAt: 0 });
  }

  /** A selection change or a no-op edit: closes the open group, touches nothing else. */
  closeGroup() {
    this.#openGroup = null;
  }

  #pushStep(step) {
    if (this.#limit === 0) {
      // Nothing is ever undoable, but a new change still clears the redo stack.
      this.#redoStack = [];
      this.#openGroup = null;
      return;
    }
    this.#undoStack.push(step);
    if (this.#undoStack.length > this.#limit) {
      this.#undoStack.shift(); // discard the oldest step
    }
    this.#redoStack = []; // any new/extended change clears redo
  }

  /** Returns the snapshot to restore, or null if there is nothing to undo. */
  undo() {
    if (this.inTransaction) throw new Error("Cannot undo while a transaction is running");
    const step = this.#undoStack.pop();
    if (!step) return null;
    this.#openGroup = null; // undo closes the open group
    this.#redoStack.push(step);
    return step.before;
  }

  /** Returns the snapshot to restore, or null if there is nothing to redo. */
  redo() {
    if (this.inTransaction) throw new Error("Cannot redo while a transaction is running");
    const step = this.#redoStack.pop();
    if (!step) return null;
    this.#undoStack.push(step);
    return step.after;
  }
}
