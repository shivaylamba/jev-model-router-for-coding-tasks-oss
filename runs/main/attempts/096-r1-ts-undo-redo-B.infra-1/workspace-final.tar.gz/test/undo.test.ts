import { test } from "node:test";
import assert from "node:assert/strict";
import { Editor } from "../src/editor.ts";

/** A controllable clock so grouping tests are deterministic. */
function makeClock(start = 0) {
  let now = start;
  return {
    clock: () => now,
    advance: (ms) => { now += ms; },
    set: (t) => { now = t; },
  };
}

test("undo/redo are no-ops when history is empty", () => {
  const e = new Editor("hello");
  assert.equal(e.canUndo(), false);
  assert.equal(e.canRedo(), false);
  assert.equal(e.undo(), false);
  assert.equal(e.redo(), false);
});

test("the constructor text is not undoable", () => {
  const e = new Editor("hello");
  e.undo();
  assert.equal(e.text, "hello");
});

test("undo restores text and selection", () => {
  const e = new Editor("hello world");
  e.select(6, 11);
  e.insert("there"); // "hello there", cursor at 11
  assert.equal(e.undo(), true);
  assert.equal(e.text, "hello world");
  assert.deepEqual(e.selection, { start: 6, end: 11 }); // selection before the insert
});

test("redo restores text and selection", () => {
  const e = new Editor("hello world");
  e.select(6, 11);
  e.insert("there");
  e.undo();
  assert.equal(e.redo(), true);
  assert.equal(e.text, "hello there");
  assert.deepEqual(e.selection, { start: 11, end: 11 }); // cursor right after the insert
});

test("canUndo / canRedo track the stacks", () => {
  const e = new Editor("");
  e.insert("abc"); // non-typing paste: one step
  assert.equal(e.canUndo(), true);
  assert.equal(e.canRedo(), false);
  e.undo();
  assert.equal(e.canUndo(), false);
  assert.equal(e.canRedo(), true);
});

test("a new change clears the redo stack", () => {
  const e = new Editor("ab");
  e.select(2);
  e.deleteBackward();
  e.undo(); // text back to "ab", redo available
  assert.equal(e.canRedo(), true);
  e.insert("XYZ"); // new change
  assert.equal(e.canRedo(), false);
  assert.equal(e.redo(), false);
});

test("no-op edits create no step and leave the redo stack alone", () => {
  const e = new Editor("ab");
  e.select(2);
  e.deleteBackward(); // "b" removed
  e.undo();           // back to "ab", redo available

  e.select(0);
  e.deleteBackward(); // no-op: cursor already at 0
  e.insert("");       // insert("") with empty selection can no-op (text unchanged? no — insert always places cursor)
  assert.equal(e.text, "ab");
  assert.equal(e.canRedo(), true, "redo survived the no-op edits");

  e.redo();
  assert.equal(e.text, "a");
});

test("selection changes create no step and leave the redo stack alone", () => {
  const e = new Editor("ab");
  e.select(2);
  e.deleteBackward();
  e.undo();
  e.select(1); // just moving the cursor
  assert.equal(e.canRedo(), true);
  e.redo();
  assert.equal(e.text, "a");
});

// ---- typing groups ----

test("consecutive typing within 1s is one undo step", () => {
  const { clock, advance } = makeClock(1_000_000);
  const e = new Editor("", { clock });
  e.insert("h");
  advance(500);
  e.insert("i");
  assert.equal(e.text, "hi");
  e.undo(); // single step undoes both characters
  assert.equal(e.text, "");
  assert.equal(e.canUndo(), false);
});

test("typing pauses of >= 1000ms start a new step", () => {
  const { clock, advance } = makeClock(1_000_000);
  const e = new Editor("", { clock });
  e.insert("h");
  advance(999);
  e.insert("i");   // still within the window → same group
  advance(1000);   // exactly 1000ms → new step
  e.insert("!");
  assert.equal(e.text, "hi!");
  e.undo();
  assert.equal(e.text, "hi");  // "!" undone alone
  e.undo();
  assert.equal(e.text, "");    // "hi" undone together
  assert.equal(e.canUndo(), false);
});

test("a multi-char paste is not typing and breaks the group", () => {
  const { clock, advance } = makeClock(0);
  const e = new Editor("", { clock });
  e.insert("h");
  advance(100);
  e.insert("i");
  advance(100);
  e.insert("paste"); // non-typing: closes the group, own step
  advance(100);
  e.insert("!");     // typing, but previous step is not an open group → new step
  e.undo();
  assert.equal(e.text, "hipaste");
  e.undo();
  assert.equal(e.text, "hi");
  e.undo();
  assert.equal(e.text, "");
});

test("a newline insert is not typing", () => {
  const { clock, advance } = makeClock(0);
  const e = new Editor("", { clock });
  e.insert("a");
  advance(100);
  e.insert("\n");
  advance(100);
  e.insert("b");
  // 3 separate steps: "a", "\n", "b"
  e.undo(); assert.equal(e.text, "a\n");
  e.undo(); assert.equal(e.text, "a");
  e.undo(); assert.equal(e.text, "");
});

test("replacing a non-empty selection with one char is not typing", () => {
  const { clock, advance } = makeClock(0);
  const e = new Editor("ab", { clock });
  e.select(0, 2);
  e.insert("x"); // one char but selection was non-empty → plain edit
  advance(100);
  e.insert("y"); // typing, but group was closed by the replace → new step
  e.undo(); assert.equal(e.text, "x");
  e.undo(); assert.equal(e.text, "ab");
});

test("select closes the typing group", () => {
  const { clock, advance } = makeClock(0);
  const e = new Editor("", { clock });
  e.insert("a");
  advance(100);
  e.select(1); // closes the group without changing anything
  advance(100);
  e.insert("b");
  e.undo();
  assert.equal(e.text, "a"); // "b" alone, not "ab"
});

test("undo closes the typing group", () => {
  const { clock, advance } = makeClock(0);
  const e = new Editor("", { clock });
  e.insert("a");
  advance(100);
  e.undo();       // undoes "a", closes group
  e.redo();       // text: "a" again
  advance(100);
  e.insert("b");  // typing — but the group was closed by undo, so new step
  e.undo();
  assert.equal(e.text, "a");
  e.undo();
  assert.equal(e.text, "");
});

test("deleteBackward closes the typing group", () => {
  const { clock, advance } = makeClock(0);
  const e = new Editor("", { clock });
  e.insert("a");
  advance(100);
  e.deleteBackward();  // own step, closes group
  advance(100);
  e.insert("b");
  e.undo(); assert.equal(e.text, "");
  e.undo(); assert.equal(e.text, "a");
  e.undo(); assert.equal(e.text, "");
});

test("extended typing group keeps the original before state", () => {
  const { clock, advance } = makeClock(0);
  const e = new Editor("X", { clock });
  e.select(1);
  e.insert("a");
  advance(100);
  e.insert("b");
  assert.equal(e.text, "Xab");
  e.undo();
  assert.equal(e.text, "X");
  assert.deepEqual(e.selection, { start: 1, end: 1 }); // before the first keystroke
  e.redo();
  assert.equal(e.text, "Xab");
  assert.deepEqual(e.selection, { start: 3, end: 3 }); // after the latest keystroke
});

// ---- transactions ----

test("transact bundles several edits into one step and returns fn's result", () => {
  const e = new Editor("hello");
  const result = e.transact(() => {
    e.select(5);
    e.insert(" ");
    e.insert("world");
    e.select(0, 5);
    e.insert("goodbye");
    return 42;
  });
  assert.equal(result, 42);
  assert.equal(e.text, "goodbye world");
  e.undo();
  assert.equal(e.text, "hello");
  assert.deepEqual(e.selection, { start: 5, end: 5 }); // state when transact was called
  e.redo();
  assert.equal(e.text, "goodbye world");
});

test("transact with no net text change creates no step and keeps redo", () => {
  const e = new Editor("ab");
  e.select(2);
  e.deleteBackward(); // step 1
  e.undo();
  assert.equal(e.canRedo(), true);

  e.transact(() => {
    e.insert("x");
    e.deleteBackward(); // net text unchanged
    e.select(0);        // selection changed, but that alone makes no step
  });
  assert.equal(e.canRedo(), true, "redo still available");
  assert.equal(e.canUndo(), false, "no new step");
});

test("nested transacts join the outermost one", () => {
  const e = new Editor("");
  e.transact(() => {
    e.insert("a");
    e.transact(() => {
      e.insert("b");
      e.transact(() => {
        e.insert("c");
      });
    });
  });
  assert.equal(e.text, "abc");
  e.undo();
  assert.equal(e.text, "");
  assert.equal(e.canUndo(), false, "only one step total");
});

test("a throwing transact rolls back, creates no step, keeps redo, and rethrows", () => {
  const e = new Editor("ab");
  e.select(2);
  e.deleteBackward();
  e.undo();
  assert.equal(e.canRedo(), true);

  assert.throws(
    () => e.transact(() => {
      e.insert("XYZ");
      e.select(0);
      throw new Error("boom");
    }),
    /boom/,
  );
  assert.equal(e.text, "ab", "text rolled back");
  assert.deepEqual(e.selection, { start: 2, end: 2 }, "selection rolled back");
  assert.equal(e.canUndo(), false, "no step created");
  assert.equal(e.canRedo(), true, "redo stack untouched");
  e.redo();
  assert.equal(e.text, "a"); // redo still refers to the earlier delete
});

test("undo/redo inside a transaction throw", () => {
  const e = new Editor("ab");
  e.select(2);
  e.deleteBackward();
  assert.throws(
    () => e.transact(() => { e.undo(); }),
    /transaction/,
  );
});

test("typing inside a transaction does not extend a step from before it", () => {
  const { clock, advance } = makeClock(0);
  const e = new Editor("", { clock });
  e.insert("a");
  advance(100);
  e.transact(() => {
    e.insert("b"); // typing keystroke inside a transaction
  });
  assert.equal(e.text, "ab");
  e.undo();
  assert.equal(e.text, "a", "transaction step undoes only b");
  e.undo();
  assert.equal(e.text, "", "'a' is its own step");
});

test("typing after a transaction does not extend the transaction's step", () => {
  const { clock, advance } = makeClock(0);
  const e = new Editor("", { clock });
  e.transact(() => { e.insert("ab"); });
  advance(100);
  e.insert("c"); // typing keystroke: must not merge into the transaction step
  assert.equal(e.text, "abc");
  e.undo();
  assert.equal(e.text, "ab", "'c' is its own step");
  e.undo();
  assert.equal(e.text, "");
});

// ---- history limit ----

test("historyLimit discards the oldest steps", () => {
  const e = new Editor("", { historyLimit: 2 });
  e.insert("A");
  e.insert("BB");  // non-typing pastes: three distinct steps
  e.insert("CCC");
  assert.equal(e.text, "ABBCCC");
  e.undo(); assert.equal(e.text, "ABB");
  e.undo(); assert.equal(e.text, "A");
  assert.equal(e.canUndo(), false, "the first step was discarded");
});

test("extending a typing group does not count against the limit", () => {
  const { clock, advance } = makeClock(0);
  const e = new Editor("", { historyLimit: 2, clock });
  e.insert("h");
  advance(10);
  e.insert("e");
  advance(10);
  e.insert("l");
  advance(10);
  e.insert("l");
  advance(10);
  e.insert("o"); // all one extended step
  assert.equal(e.text, "hello");
  e.undo();
  assert.equal(e.text, "");
  assert.equal(e.canUndo(), false, "one step used, limit never hit");
});

test("historyLimit: 0 means nothing is undoable", () => {
  const e = new Editor("", { historyLimit: 0 });
  e.insert("abc");
  assert.equal(e.canUndo(), false);
  assert.equal(e.undo(), false);
});

test("historyLimit must be an integer >= 0", () => {
  assert.throws(() => new Editor("", { historyLimit: -1 }), RangeError);
  assert.throws(() => new Editor("", { historyLimit: 1.5 }), RangeError);
  assert.throws(() => new Editor("", { historyLimit: NaN }), RangeError);
  assert.throws(() => new Editor("", { historyLimit: "10" }), RangeError);
  new Editor("", { historyLimit: 0 });   // valid
  new Editor("", { historyLimit: 100 }); // valid
});

// ---- existing behaviour must not change ----

test("existing editing behaviour is unchanged", () => {
  const e = new Editor("abcd");
  e.select(2);
  e.deleteBackward();
  assert.equal(e.text, "acd");
  e.deleteForward();
  assert.equal(e.text, "ad");
  assert.deepEqual(e.selection, { start: 1, end: 1 });

  e.insert("XY");
  assert.equal(e.text, "aXYd");
  assert.deepEqual(e.selection, { start: 3, end: 3 });

  e.select(100, -5);
  assert.deepEqual(e.selection, { start: 0, end: 4 });
});
