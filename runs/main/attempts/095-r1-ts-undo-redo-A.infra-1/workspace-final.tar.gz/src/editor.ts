import { isEmpty, normalizeSelection, replaceRange, type Selection } from "./text.ts";
import { History, type Snapshot } from "./history.ts";

export interface EditorOptions {
  /** Milliseconds clock used by undo grouping. Defaults to Date.now. */
  clock?: () => number;
  /** Maximum number of undo steps kept. Defaults to 100. */
  historyLimit?: number;
}

export class Editor {
  private content: string;
  private sel: Selection;
  private clock: () => number;
  private history: History;
  private txBefore: Snapshot[] = [];

  constructor(text: string = "", options: EditorOptions = {}) {
    this.content = text;
    this.sel = { start: text.length, end: text.length };
    this.clock = options.clock ?? Date.now;
    this.history = new History(options.historyLimit ?? 100);
  }

  get text(): string {
    return this.content;
  }

  /** A copy of the current selection. */
  get selection(): Selection {
    return { ...this.sel };
  }

  /** Set the selection; offsets are clamped to the text and ordered. `end` defaults to `start`. */
  select(start: number, end: number = start): void {
    this.history.closeGroup();
    this.sel = normalizeSelection(this.content.length, start, end);
  }

  /** Replace the selection with `str` and put the cursor right after it. */
  insert(str: string): void {
    const before = this.snapshot();
    const typing = isEmpty(this.sel) && str.length === 1 && str !== "\n" && this.txBefore.length === 0;
    const { start, end } = this.sel;
    this.content = replaceRange(this.content, start, end, str);
    const cursor = start + str.length;
    this.sel = { start: cursor, end: cursor };
    this.history.record(before, this.snapshot(), typing, this.clock);
  }

  /** Delete the selection, or the character before the cursor when the selection is empty. */
  deleteBackward(): void {
    const before = this.snapshot();
    const { start, end } = this.sel;
    if (!isEmpty(this.sel)) {
      this.content = replaceRange(this.content, start, end, "");
      this.sel = { start, end: start };
    } else if (start > 0) {
      this.content = replaceRange(this.content, start - 1, start, "");
      this.sel = { start: start - 1, end: start - 1 };
    }
    this.history.record(before, this.snapshot(), false, this.clock);
  }

  /** Delete the selection, or the character after the cursor when the selection is empty. */
  deleteForward(): void {
    const before = this.snapshot();
    const { start, end } = this.sel;
    if (!isEmpty(this.sel)) {
      this.content = replaceRange(this.content, start, end, "");
      this.sel = { start, end: start };
    } else if (start < this.content.length) {
      this.content = replaceRange(this.content, start, start + 1, "");
    }
    this.history.record(before, this.snapshot(), false, this.clock);
  }

  /** Revert the most recent step, restoring text and selection. False when nothing to undo. */
  undo(): boolean {
    this.checkTransaction("undo");
    const snapshot = this.history.undo();
    this.history.closeGroup();
    if (!snapshot) return false;
    this.restore(snapshot);
    return true;
  }

  /** Re-apply the most recently undone step. False when nothing to redo. */
  redo(): boolean {
    this.checkTransaction("redo");
    const snapshot = this.history.redo();
    this.history.closeGroup();
    if (!snapshot) return false;
    this.restore(snapshot);
    return true;
  }

  canUndo(): boolean {
    return this.history.canUndo();
  }

  canRedo(): boolean {
    return this.history.canRedo();
  }

  /**
   * Run fn as one undo step: before = state at the call, after = state when fn
   * returns. Nested calls join the outermost one. If fn throws, text and
   * selection are restored, no step is created and the error is rethrown.
   */
  transact<T>(fn: () => T): T {
    const outermost = this.txBefore.length === 0;
    if (outermost) {
      this.history.closeGroup();
    }
    const before = this.snapshot();
    this.txBefore.push(before);
    let result: T;
    try {
      result = fn();
    } catch (error) {
      this.txBefore.pop();
      this.restore(before);
      throw error;
    }
    this.txBefore.pop();
    if (outermost) {
      this.history.record(before, this.snapshot(), false, this.clock);
      this.history.closeGroup();
    }
    return result;
  }

  private snapshot(): Snapshot {
    return { text: this.content, selection: { ...this.sel } };
  }

  private restore(snapshot: Snapshot): void {
    this.content = snapshot.text;
    this.sel = { ...snapshot.selection };
  }

  private checkTransaction(method: string): void {
    if (this.txBefore.length > 0) {
      throw new Error(`${method}() cannot be called while a transaction is running`);
    }
  }
}
