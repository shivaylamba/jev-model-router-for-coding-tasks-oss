import type { Selection } from "./text.ts";

/** The text and the selection at one point in time, the state an undo step restores. */
export interface Snapshot {
  text: string;
  selection: Selection;
}

/** A revertible change: the state before and after it. */
interface Step {
  before: Snapshot;
  after: Snapshot;
}

const DEFAULT_LIMIT = 100;

/**
 * Undo/redo bookkeeping for the Editor: sees every edit as the state before
 * and after it, groups single-character typing, and enforces the step limit.
 * Editing itself stays in editor.ts.
 */
export class History {
  private limit: number;
  private steps: Step[] = [];
  private next = 0; // steps[0:next] are undoable, steps[next:] are redoable
  private group: Step | null = null;
  private groupAt = 0;

  constructor(limit: number = DEFAULT_LIMIT) {
    if (!Number.isInteger(limit) || limit < 0) {
      throw new RangeError(`historyLimit must be an integer >= 0, got ${limit}`);
    }
    this.limit = limit;
  }

  canUndo(): boolean {
    return this.next > 0;
  }

  canRedo(): boolean {
    return this.next < this.steps.length;
  }

  /**
   * Record an edit. True typing inserts may extend the open typing group
   * (see docs/UNDO.md); anything else is its own step. No-op edits leave both
   * stacks alone. Returns the step the undo stack grew by (0 or 1).
   */
  record(before: Snapshot, after: Snapshot, isTyping: boolean, clock: () => number): void {
    if (before.text === after.text) return;
    if (isTyping) {
      const now = clock();
      if (this.group !== null && this.next === this.steps.length && now - this.groupAt < 1000) {
        // Chained onto a keystroke less than a second ago: same group, same
        // original "before", the latest state is the new "after". Not a new
        // step for the limit, but anything undone is obsolete either way.
        this.group.after = after;
        this.groupAt = now;
        this.steps.length = this.next;
        return;
      }
      this.group = null;
    } else {
      this.group = null;
    }
    const step: Step = { before, after };
    this.steps.length = this.next;
    if (this.limit !== 0) {
      this.steps.push(step);
      if (this.steps.length > this.limit) {
        this.steps.shift();
      }
      this.next = this.steps.length;
      if (isTyping) {
        this.group = step;
        this.groupAt = clock();
      }
    }
  }

  /** Undo the latest step; returns its "before" state, or null when empty. */
  undo(): Snapshot | null {
    if (!this.canUndo()) return null;
    this.next -= 1;
    return this.steps[this.next].before;
  }

  /** Redo the latest undone step; returns its "after" state, or null when empty. */
  redo(): Snapshot | null {
    if (!this.canRedo()) return null;
    const step = this.steps[this.next];
    this.next += 1;
    return step.after;
  }

  /** Close the open typing group without touching the stacks. */
  closeGroup(): void {
    this.group = null;
  }
}
