# tally

A small `wc`-style command-line tool: counts lines, words and characters in
text files.

```
node bin/tally.js notes.txt todo.txt
```

prints one row per file and, when more than one file is given, a `total` row:

```
      3      12      80 notes.txt
      1       4      19 todo.txt
      4      16      99 total
```

Each number is right-aligned in a 7-character column followed by a space.

With `--json` (which may appear anywhere among the arguments) the table is
replaced by a single JSON document — one line on stdout — with one entry per
file in command-line order and a `total` entry that is always present:

```
node bin/tally.js --json notes.txt todo.txt
{"files":[{"path":"notes.txt","lines":3,"words":12,"chars":80},{"path":"todo.txt","lines":1,"words":4,"chars":19}],"total":{"lines":4,"words":16,"chars":99}}
```

With no files at all the JSON output is
`{"files": [], "total": {"lines": 0, "words": 0, "chars": 0}}` (which prints
`{"files":[],"total":{"lines":0,"words":0,"chars":0}}` — JSON.stringify leaves
no spaces).

A file that cannot be read is reported on stderr as `tally: cannot read <path>`,
the other files are still counted, and the exit code is 1 (in JSON mode such a
file is simply left out of `files`). Any option other than `--json`
prints a usage line on stderr and exits with code 2. Otherwise the exit code is 0.

Code layout: `src/count.js` does the counting, `src/cli.js` parses arguments and
prints (`run(argv, io)` takes the IO functions as parameters so it can be
tested without touching the real terminal or disk), `bin/tally.js` wires it to
the process.

Node 24, no dependencies. Run the tests with `node --test`.
