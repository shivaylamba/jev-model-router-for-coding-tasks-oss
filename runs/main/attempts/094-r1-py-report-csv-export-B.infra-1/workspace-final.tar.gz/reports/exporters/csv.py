"""CSV for machines: a header line, then one line per report row."""

_QUOTE_TRIGGERS = (",", '"', "\n", "\r")


def _quote(text):
    """Standard CSV quoting: wrap in double quotes only if the text contains a comma, a double quote or a line break."""
    if any(trigger in text for trigger in _QUOTE_TRIGGERS):
        return '"' + text.replace('"', '""') + '"'
    return text


def _field(value):
    """Format a cell for machines: plain ints, two-decimal floats, true/false, empty for null."""
    if value is None:
        text = ""
    elif isinstance(value, bool):
        text = "true" if value else "false"
    elif isinstance(value, float):
        text = format(value, ".2f")
    else:
        text = str(value)
    return _quote(text)


class CsvExporter:
    name = "csv"
    extension = ".csv"

    def export(self, report):
        lines = [",".join(_field(column.label) for column in report.columns)]
        for row in report.rows:
            lines.append(",".join(_field(report.cell(row, column)) for column in report.columns))
        return "\n".join(lines) + "\n"
