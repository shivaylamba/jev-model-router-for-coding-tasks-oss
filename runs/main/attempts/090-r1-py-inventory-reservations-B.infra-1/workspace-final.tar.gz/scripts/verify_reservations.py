"""Adversarial checks: reproduce each support ticket against the documented contract."""

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from inventory.clock import ManualClock
from inventory.errors import (
    HoldExpiredError,
    HoldNotFoundError,
    HoldStateError,
    IdempotencyConflictError,
    InsufficientStockError,
)
from inventory.service import ReservationService
from inventory.stock import StockLedger


def make(units=10, ttl=600, start=1000):
    clock = ManualClock(start)
    ledger = StockLedger({"lamp": units})
    return ReservationService(ledger, clock, hold_ttl=ttl), ledger, clock


class Ticket1ExpiryFreesStockImmediately(unittest.TestCase):
    def test_expired_hold_stops_blocking_without_sweep(self):
        svc, _, clock = make()
        svc.reserve("lamp", 10, "r1")
        self.assertEqual(svc.available("lamp"), 0)
        clock.advance(600)  # exactly at expiry; no sweep run
        self.assertEqual(svc.available("lamp"), 10)
        # can reserve again right away
        svc.reserve("lamp", 10, "r2")
        self.assertEqual(svc.available("lamp"), 0)

    def test_get_hold_reports_expired_as_soon_as_time_is_up(self):
        svc, _, clock = make()
        hold = svc.reserve("lamp", 2, "r1")
        clock.advance(599)
        self.assertEqual(svc.get_hold(hold.id).status, "held")
        clock.advance(1)  # now == expires_at
        self.assertEqual(svc.get_hold(hold.id).status, "expired")

    def test_sweep_is_pure_housekeeping(self):
        svc, _, clock = make()
        hold = svc.reserve("lamp", 3, "r1")
        clock.advance(600)
        before = svc.available("lamp")
        self.assertEqual(svc.sweep_expired(), 1)
        self.assertEqual(svc.sweep_expired(), 0)  # idempotent
        self.assertEqual(svc.available("lamp"), before)
        self.assertEqual(svc.get_hold(hold.id).status, "expired")


class Ticket2Boundary(unittest.TestCase):
    def test_exact_expiry_instant_is_expired(self):
        svc, _, clock = make()
        hold = svc.reserve("lamp", 2, "r1")
        clock.advance(600)  # now == expires_at exactly
        self.assertEqual(svc.get_hold(hold.id).status, "expired")
        self.assertEqual(svc.available("lamp"), 10)
        with self.assertRaises(HoldExpiredError):
            svc.confirm(hold.id)


class Ticket3DoubleRelease(unittest.TestCase):
    def test_second_release_returns_false_and_restores_nothing_extra(self):
        svc, _, _ = make()
        hold = svc.reserve("lamp", 4, "r1")
        self.assertTrue(svc.release(hold.id))
        self.assertEqual(svc.available("lamp"), 10)
        self.assertFalse(svc.release(hold.id))
        self.assertFalse(svc.release(hold.id))
        self.assertEqual(svc.available("lamp"), 10)  # not 14

    def test_release_after_expiry_returns_false(self):
        svc, _, clock = make()
        hold = svc.reserve("lamp", 4, "r1")
        clock.advance(600)
        self.assertFalse(svc.release(hold.id))
        self.assertEqual(svc.get_hold(hold.id).status, "expired")


class Ticket4ReleaseAfterConfirm(unittest.TestCase):
    def test_release_of_confirmed_hold_raises_and_keeps_units_sold(self):
        svc, ledger, _ = make()
        hold = svc.reserve("lamp", 3, "r1")
        svc.confirm(hold.id)
        self.assertEqual(ledger.on_hand("lamp"), 7)
        with self.assertRaises(HoldStateError):
            svc.release(hold.id)
        self.assertEqual(ledger.on_hand("lamp"), 7)
        self.assertEqual(svc.available("lamp"), 7)
        self.assertEqual(svc.get_hold(hold.id).status, "confirmed")


class Ticket5ConfirmInvalidStates(unittest.TestCase):
    def test_confirm_expired_raises_and_preserves_ledger(self):
        svc, ledger, clock = make()
        hold = svc.reserve("lamp", 3, "r1")
        clock.advance(600)
        with self.assertRaises(HoldExpiredError):
            svc.confirm(hold.id)
        self.assertEqual(ledger.on_hand("lamp"), 10)
        self.assertEqual(svc.available("lamp"), 10)

    def test_double_confirm_takes_stock_once(self):
        svc, ledger, _ = make()
        hold = svc.reserve("lamp", 3, "r1")
        first = svc.confirm(hold.id)
        second = svc.confirm(hold.id)  # double click on Pay
        self.assertIs(first, second)
        self.assertEqual(ledger.on_hand("lamp"), 7)  # not 4
        with self.assertRaises(InsufficientStockError):
            svc.reserve("lamp", 8, "r2")

    def test_confirm_released_raises(self):
        svc, ledger, _ = make()
        hold = svc.reserve("lamp", 3, "r1")
        svc.release(hold.id)
        with self.assertRaises(HoldStateError):
            svc.confirm(hold.id)
        self.assertEqual(ledger.on_hand("lamp"), 10)


class Ticket6Idempotency(unittest.TestCase):
    def test_retry_same_request_id_returns_same_hold(self):
        svc, _, _ = make()
        h1 = svc.reserve("lamp", 2, "req-1")
        h2 = svc.reserve("lamp", 2, "req-1")
        self.assertEqual(h1.id, h2.id)
        self.assertEqual(len(svc._holds.all()), 1)
        self.assertEqual(svc.available("lamp"), 8)  # not double-reserved

    def test_retry_returns_current_status_of_hold(self):
        svc, _, _ = make()
        h1 = svc.reserve("lamp", 2, "req-1")
        svc.confirm(h1.id)
        again = svc.reserve("lamp", 2, "req-1")
        self.assertEqual(again.id, h1.id)
        self.assertEqual(again.status, "confirmed")

    def test_same_request_id_different_args_conflicts(self):
        svc, _, _ = make()
        svc.reserve("lamp", 2, "req-1")
        with self.assertRaises(IdempotencyConflictError):
            svc.reserve("lamp", 3, "req-1")
        with self.assertRaises(IdempotencyConflictError):
            svc.reserve("mug", 2, "req-1")

    def test_failed_reservation_leaves_request_id_reusable(self):
        svc, _, _ = make()
        with self.assertRaises(InsufficientStockError):
            svc.reserve("lamp", 50, "req-9")
        hold = svc.reserve("lamp", 2, "req-9")  # same id, now treated as new
        self.assertEqual(hold.status, "held")


class MiscContract(unittest.TestCase):
    def test_validation(self):
        svc, _, _ = make()
        for bad_qty in (0, -1, 1.5, "2", True):
            with self.assertRaises(ValueError, msg=repr(bad_qty)):
                svc.reserve("lamp", bad_qty, "r")
        for bad_req in ("", None, 123):
            with self.assertRaises(ValueError, msg=repr(bad_req)):
                svc.reserve("lamp", 1, bad_req)

    def test_unknown_ids(self):
        svc, _, _ = make()
        for op in (svc.get_hold, svc.release, svc.confirm):
            with self.assertRaises(HoldNotFoundError):
                op("nope")

    def test_hold_timestamps(self):
        svc, _, _ = make()
        hold = svc.reserve("lamp", 1, "r1")
        self.assertEqual(hold.created_at, 1000)
        self.assertEqual(hold.expires_at, 1600.0)


if __name__ == "__main__":
    unittest.main()
