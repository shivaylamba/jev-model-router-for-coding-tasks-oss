import { deprecate } from "./deprecate.js";

const DEFAULTS = Object.freeze({
  timeoutMs: 5000,
  retries: 0,
  headers: {},
});

const KNOWN_OPTIONS = new Set(["baseUrl", "token", "timeoutMs", "retries", "headers"]);

function isPlainObject(value) {
  if (typeof value !== "object" || value === null) return false;
  const proto = Object.getPrototypeOf(value);
  return proto === Object.prototype || proto === null;
}

/**
 * Validate a set of already-defaulted options and return the frozen,
 * normalized options object shared as `client.options`.
 */
function normalize(options) {
  for (const key of Object.keys(options)) {
    if (!KNOWN_OPTIONS.has(key)) {
      throw new TypeError(`unknown createClient option "${key}"`);
    }
  }

  const baseUrl = options.baseUrl;
  const token = options.token;
  const timeoutMs = options.timeoutMs === undefined ? DEFAULTS.timeoutMs : options.timeoutMs;
  const retries = options.retries === undefined ? DEFAULTS.retries : options.retries;
  const headers = options.headers === undefined ? DEFAULTS.headers : options.headers;

  if (typeof baseUrl !== "string" || baseUrl === "") {
    throw new TypeError("baseUrl must be a non-empty string");
  }
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0) {
    throw new RangeError("timeoutMs must be a finite number greater than 0");
  }
  if (!Number.isInteger(retries) || retries < 0) {
    throw new RangeError("retries must be an integer >= 0");
  }

  return Object.freeze({
    baseUrl: baseUrl.replace(/\/+$/, ""),
    token,
    timeoutMs,
    retries,
    headers: Object.freeze({ ...headers }),
  });
}

/**
 * Create an API client.
 *
 * Prefer the options form:
 * @param {{ baseUrl: string, token?: string, timeoutMs?: number, retries?: number, headers?: object }} arg
 *        e.g. { baseUrl: "https://api.internal.example/", timeoutMs: 5000 }. Any option whose value is
 *        undefined counts as not given and falls back to its default. Unknown option names are rejected.
 *
 * For backwards compatibility the legacy positional form `createClient(baseUrl, token, timeoutMs, retries)`
 * is still accepted (with the same defaults and validation) but reports a one-time deprecation warning.
 */
export function createClient(baseUrl, token, timeoutMs, retries) {
  if (typeof baseUrl === "string") {
    deprecate(
      "CLIENT_POSITIONAL_ARGS",
      "createClient(baseUrl, token, timeoutMs, retries) is deprecated; pass a single options object instead",
    );
    return makeClient({ baseUrl, token, timeoutMs, retries });
  }
  if (baseUrl === undefined || !isPlainObject(baseUrl)) {
    throw new TypeError("createClient() expects a string baseUrl or an options object");
  }
  return makeClient(baseUrl);
}

function makeClient(options) {
  const normalized = normalize(options);

  return {
    options: normalized,
    /**
     * Describe a request and pass it to `transport`, returning whatever the transport returns.
     */
    request(transport, method, path, body) {
      const headers = { ...normalized.headers };
      headers.accept = "application/json";
      if (normalized.token) headers.authorization = `Bearer ${normalized.token}`;
      if (body !== undefined) headers["content-type"] = "application/json";
      return transport({
        method,
        url: normalized.baseUrl + (path.startsWith("/") ? path : `/${path}`),
        headers,
        body: body === undefined ? undefined : JSON.stringify(body),
        timeoutMs: normalized.timeoutMs,
        retries: normalized.retries,
      });
    },
  };
}