import { test } from "node:test";
import assert from "node:assert/strict";
import { createClient } from "../src/client.js";
import { createUsersApi } from "../src/users.js";
import { createBillingApi } from "../src/billing.js";
import { createReportsApi } from "../src/reports.js";
import { resetDeprecations, setDeprecationHandler } from "../src/deprecate.js";

const echo = (req) => req;
setDeprecationHandler(() => {});

test("request description", () => {
  resetDeprecations();
  const client = createClient({
    baseUrl: "https://api.example/",
    token: "t0k",
    timeoutMs: 1000,
    retries: 1,
    headers: { "x-trace": "abc" },
  });
  assert.deepEqual(client.request(echo, "POST", "items", { a: 1 }), {
    method: "POST",
    url: "https://api.example/items",
    headers: {
      "x-trace": "abc",
      accept: "application/json",
      authorization: "Bearer t0k",
      "content-type": "application/json",
    },
    body: '{"a":1}',
    timeoutMs: 1000,
    retries: 1,
  });
});

test("defaults", () => {
  const client = createClient({ baseUrl: "https://api.example" });
  assert.equal(client.options.timeoutMs, 5000);
  assert.equal(client.options.retries, 0);
  assert.deepEqual(client.options.headers, {});
  assert.equal(client.request(echo, "GET", "/x").headers.authorization, undefined);
});

test("normalized options", () => {
  const client = createClient({ baseUrl: "https://api.example//", headers: { "x-a": "1" } });
  assert.equal(client.options.baseUrl, "https://api.example");
  assert.equal(client.options.token, undefined);
  assert.equal(Object.isFrozen(client.options), true);
  assert.equal(Object.isFrozen(client.options.headers), true);
});

test("unknown option is rejected", () => {
  assert.throws(() => createClient({ baseUrl: "https://x", bogus: 1 }), /bogus/);
});

test("invalid inputs are rejected", () => {
  assert.throws(() => createClient(), TypeError);
  assert.throws(() => createClient(42), TypeError);
  assert.throws(() => createClient(["https://x"]), TypeError);
  assert.throws(() => createClient({ baseUrl: "" }), TypeError);
  assert.throws(() => createClient({ baseUrl: 42 }), TypeError);
  assert.throws(() => createClient({ baseUrl: "https://x", timeoutMs: 0 }), RangeError);
  assert.throws(() => createClient({ baseUrl: "https://x", timeoutMs: NaN }), RangeError);
  assert.throws(() => createClient({ baseUrl: "https://x", timeoutMs: Infinity }), RangeError);
  assert.throws(() => createClient({ baseUrl: "https://x", retries: 1.5 }), RangeError);
  assert.throws(() => createClient({ baseUrl: "https://x", retries: -1 }), RangeError);
});

test("undefined options fall back to defaults", () => {
  const client = createClient({ baseUrl: "https://x", timeoutMs: undefined, retries: undefined, headers: undefined });
  assert.equal(client.options.timeoutMs, 5000);
  assert.equal(client.options.retries, 0);
  assert.deepEqual(client.options.headers, {});
});

test("positional call is deprecated once; options form never warns", () => {
  resetDeprecations();
  const codes = [];
  setDeprecationHandler((code) => codes.push(code));

  createClient("https://api.example", "t", 1000, 1);
  createClient("https://api.example/"); // same code, reported only once
  createClient({ baseUrl: "https://api.example" });
  createClient({ baseUrl: "https://api.example" });

  assert.deepEqual(codes, ["CLIENT_POSITIONAL_ARGS"]);
});

test("positional form keeps defaults and validation", () => {
  resetDeprecations();
  const client = createClient("https://api.example/");
  assert.equal(client.options.timeoutMs, 5000);
  assert.equal(client.options.retries, 0);
  assert.equal(client.options.baseUrl, "https://api.example");
  assert.throws(() => createClient("", "t"), TypeError);
  assert.throws(() => createClient("https://x", null, 0), RangeError);
});

test("services", () => {
  const config = { apiUrl: "https://u.example", billingUrl: "https://b.example", reportsUrl: "https://r.example", token: "s3cret" };
  assert.equal(createUsersApi(config).getUser(echo, "a b").url, "https://u.example/users/a%20b");
  const charge = createBillingApi(config).charge(echo, "c1", 500);
  assert.equal(charge.timeoutMs, 15000);
  assert.equal(charge.retries, 3);
  const report = createReportsApi(config).monthly(echo, "2026-01");
  assert.equal(report.timeoutMs, 60000);
  assert.equal(report.headers.authorization, undefined);
});