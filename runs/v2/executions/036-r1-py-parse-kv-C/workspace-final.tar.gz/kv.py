"""Helpers for `key=value; key=value` strings."""


def format_kv(pairs):
    """Format a mapping as `key=value; key=value`, in the mapping's order.

    >>> format_kv({"region": "eu-west", "replicas": 3})
    'region=eu-west; replicas=3'
    """
    return "; ".join(f"{key}={value}" for key, value in pairs.items())


def parse_kv(text):
    """Parse a `key=value; key=value` string into a dict.

    Segments separated by ";" (empty/whitespace-only segments are skipped),
    each split on its first "=" only, keys/values stripped. Values stay
    strings. Last occurrence of a key wins.

    >>> parse_kv("a=1; b = two")
    {'a': '1', 'b': 'two'}
    >>> parse_kv("")
    {}
    >>> parse_kv("query=x=1")
    {'query': 'x=1'}

    Raises ValueError for a non-empty segment with no "=", or with an empty
    key after stripping.
    """
    result = {}
    for segment in text.split(";"):
        if not segment.strip():
            continue
        if "=" not in segment:
            raise ValueError(f"segment has no '=': {segment!r}")
        key, value = segment.split("=", 1)
        key = key.strip()
        if not key:
            raise ValueError(f"segment has empty key: {segment!r}")
        result[key] = value.strip()
    return result
