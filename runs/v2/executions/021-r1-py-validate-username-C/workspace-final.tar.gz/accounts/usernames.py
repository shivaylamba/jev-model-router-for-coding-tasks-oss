"""Username helpers."""

import re

RESERVED = frozenset({"admin", "root", "support", "moderator"})

# Lowercase ASCII letter/digit/separator. A valid name must be built only from
# these classes and start with a letter.
_SEPARATORS = frozenset({".", "_", "-"})
_LEADING_RULE = re.compile(r"[a-z]")
_ALLOWED_RULE = re.compile(r"[a-z0-9._-]+\Z")
_ADJACENT_SEPARATORS = re.compile(r"[._-][._-]")


def normalize_username(raw):
    """Trim surrounding whitespace and lowercase a username as typed at signup."""
    return raw.strip().lower()


def is_reserved(name):
    """Whether a (normalized) username is reserved for staff accounts."""
    return name in RESERVED


def is_valid_username(name):
    """Whether a (normalized) username satisfies the signup character rules.

    Never raises: anything that isn't a str (including empty, oversized, or
    wrongly-typed inputs) yields False.
    """
    if not isinstance(name, str):
        return False
    if not 3 <= len(name) <= 20:
        return False
    if not _LEADING_RULE.fullmatch(name[0]):
        return False
    if _ALLOWED_RULE.fullmatch(name) is None:
        return False
    if _ADJACENT_SEPARATORS.search(name):
        return False
    if name[-1] in _SEPARATORS:
        return False
    return True
