"""Reservation service used by checkout."""

from collections import defaultdict

from .errors import (HoldExpiredError, HoldNotFoundError, HoldStateError,
                     IdempotencyConflictError, InsufficientStockError)
from .holds import HoldStore


class ReservationService:
    def __init__(self, ledger, clock, hold_ttl=900):
        self._ledger = ledger
        self._clock = clock
        self._ttl = hold_ttl
        self._holds = HoldStore()

    def _effective_status(self, hold):
        if hold.status != "held":
            return hold.status
        return "expired" if hold.is_expired(self._clock.now()) else "held"

    def _reserved(self):
        now = self._clock.now()
        res = defaultdict(int)
        for hold in self._holds.all():
            if hold.status == "held" and not hold.is_expired(now):
                res[hold.sku] += hold.quantity
        return res

    def available(self, sku):
        return self._ledger.on_hand(sku) - self._reserved()[sku]

    def reserve(self, sku, quantity, request_id):
        if not isinstance(quantity, int) or isinstance(quantity, bool) or quantity < 1:
            raise ValueError("quantity must be a positive integer")
        if not isinstance(request_id, str) or not request_id:
            raise ValueError("request_id must be a non-empty string")
        existing = self._holds.by_request(request_id)
        if existing is not None:
            if (existing.sku, existing.quantity) != (sku, quantity):
                raise IdempotencyConflictError(request_id)
            return existing
        if quantity > self.available(sku):
            raise InsufficientStockError(f"only {self.available(sku)} of {sku} available")
        now = self._clock.now()
        return self._holds.create(sku, quantity, request_id, now, now + self._ttl)

    def get_hold(self, hold_id):
        hold = self._holds.get(hold_id)
        if hold is None:
            raise HoldNotFoundError(hold_id)
        if self._effective_status(hold) == "expired":
            hold.status = "expired"
        return hold

    def release(self, hold_id):
        hold = self.get_hold(hold_id)
        status = self._effective_status(hold)
        if status == "confirmed":
            raise HoldStateError(f"hold {hold_id} is confirmed")
        if status in ("released", "expired"):
            return False
        hold.status = "released"
        return True

    def confirm(self, hold_id):
        hold = self.get_hold(hold_id)
        status = self._effective_status(hold)
        if status == "confirmed":
            return hold
        if status == "expired":
            raise HoldExpiredError(f"hold {hold_id} expired")
        if status == "released":
            raise HoldStateError(f"hold {hold_id} was released")
        self._ledger.remove(hold.sku, hold.quantity)
        hold.status = "confirmed"
        return hold

    def sweep_expired(self):
        """Mark expired holds for housekeeping. Makes no observable difference."""
        now = self._clock.now()
        marked = 0
        for hold in self._holds.all():
            if hold.status == "held" and hold.is_expired(now):
                hold.status = "expired"
                marked += 1
        return marked
