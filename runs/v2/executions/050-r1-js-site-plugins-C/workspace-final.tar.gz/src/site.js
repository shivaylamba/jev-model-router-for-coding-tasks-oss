import { defaultLayout } from "./layout.js";
import { renderMarkdown } from "./markdown.js";

/** "guide/intro.md" -> "guide/intro.html" */
export function outputPath(sourcePath) {
  return sourcePath.replace(/\.md$/, "") + ".html";
}

export class PluginError extends Error {
  constructor(plugin, hook, cause) {
    super(`Plugin "${plugin}" failed in ${hook} hook: ${cause.message}`);
    this.plugin = plugin;
    this.hook = hook;
    this.cause = cause;
  }
}

/**
 * Create a site builder that supports plugins.
 */
export function createSite({ layout = defaultLayout } = {}) {
  const plugins = [];

  return {
    use(plugin) {
      // Validate plugin is an object
      if (typeof plugin !== "object" || plugin === null) {
        throw new TypeError("Plugin must be an object");
      }
      // Validate name is a non-empty string
      if (typeof plugin.name !== "string" || plugin.name === "") {
        throw new TypeError("Plugin name must be a non-empty string");
      }
      // Check for duplicate names
      if (plugins.some((p) => p.name === plugin.name)) {
        throw new Error(`Plugin "${plugin.name}" is already registered`);
      }
      // Validate hooks are functions if present
      for (const hook of ["beforeRender", "afterRender", "onComplete"]) {
        if (hook in plugin && typeof plugin[hook] !== "function") {
          throw new TypeError(`Plugin "${plugin.name}" hook "${hook}" must be a function`);
        }
      }
      plugins.push(plugin);
      return this;
    },

    async build(pages) {
      const outputs = new Map();

      for (const page of pages) {
        // Shallow copy the caller's page for the first beforeRender
        let currentPage = { ...page };

        // Run beforeRender hooks in order
        for (const plugin of plugins) {
          if (plugin.beforeRender) {
            try {
              const result = await plugin.beforeRender(currentPage);
              if (result !== undefined) {
                if (typeof result !== "object" || result === null) {
                  throw new TypeError(
                    `beforeRender must return undefined or an object, got ${typeof result}`
                  );
                }
                currentPage = result;
              }
            } catch (cause) {
              throw new PluginError(plugin.name, "beforeRender", cause);
            }
          }
        }

        // Render the page with the final page state
        const content = renderMarkdown(currentPage.body);
        const html = layout({
          title: currentPage.title,
          content,
          path: currentPage.path,
        });

        // Run afterRender hooks in order
        let currentHtml = html;
        for (const plugin of plugins) {
          if (plugin.afterRender) {
            try {
              const result = await plugin.afterRender(currentHtml, currentPage);
              if (result !== undefined) {
                if (typeof result !== "string") {
                  throw new TypeError(
                    `afterRender must return undefined or a string, got ${typeof result}`
                  );
                }
                currentHtml = result;
              }
            } catch (cause) {
              throw new PluginError(plugin.name, "afterRender", cause);
            }
          }
        }

        outputs.set(outputPath(currentPage.path), currentHtml);
      }

      // Run onComplete hooks in order
      for (const plugin of plugins) {
        if (plugin.onComplete) {
          try {
            await plugin.onComplete(outputs);
          } catch (cause) {
            throw new PluginError(plugin.name, "onComplete", cause);
          }
        }
      }

      return outputs;
    },
  };
}

/**
 * Render every page. Pages are { path, title, body }; the result maps each
 * output path to its HTML, in page order.
 */
export async function buildSite(pages, options) {
  return createSite(options).build(pages);
}
