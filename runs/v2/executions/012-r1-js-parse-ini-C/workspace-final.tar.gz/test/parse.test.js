import { test } from "node:test";
import assert from "node:assert/strict";
import { parseIni, stringifyIni } from "../src/ini.js";

test("parses basic sections and global keys", () => {
  const out = parseIni('name = api\n\n[server]\nport = 8080\n');
  assert.deepEqual(out, { "": { name: "api" }, server: { port: "8080" } });
});

test("empty section appears as empty object", () => {
  assert.deepEqual(parseIni("[db]\n[server]\nport=1\n"), {
    db: {},
    server: { port: "1" },
  });
});

test("no global section when there are no global keys", () => {
  assert.deepEqual(parseIni("; comment\n# another\n\n[server]\nhost = x\n"), {
    server: { host: "x" },
  });
});

test("section names keep dots and spaces, trimmed", () => {
  assert.deepEqual(parseIni("[server.http]\n[ s ]\na=1\n"), {
    "server.http": {},
    s: { a: "1" },
  });
});

test("duplicate sections merge, last value wins", () => {
  assert.deepEqual(parseIni("[s]\na=1\nb=2\n[s]\na=3\n"), { s: { a: "3", b: "2" } });
});

test("duplicate key in same section: last wins", () => {
  assert.deepEqual(parseIni("[s]\na=1\na=2\n"), { s: { a: "2" } });
});

test("empty value is allowed", () => {
  assert.deepEqual(parseIni("[s]\na=\nb=   \n"), { s: { a: "", b: "" } });
});

test("quoted values with escapes, whitespace kept", () => {
  const out = parseIni('[s]\na = " hi \\"there\\" \\\\ \\n \\t "\n');
  assert.deepEqual(out, { s: { a: ' hi "there" \\ \n \t ' } });
});

test("no inline comments", () => {
  // `;` and `#` mid-line are ordinary text.
  assert.deepEqual(parseIni("[s]\na = x;y #z\n"), { s: { a: "x;y #z" } });
});

test("backslash line continuation", () => {
  assert.deepEqual(
    parseIni("[s]\nmsg = hello \\\nworld\n"),
    { s: { msg: "hello world" } }
  );
});

test("continuation chains and takes section/comment-text lines", () => {
  assert.deepEqual(
    parseIni("[s]\nmsg = a \\\n[b] \\\n; not a comment\n"),
    { s: { msg: "a [b] ; not a comment" } }
  );
});

test("both \\n and \\r\\n line endings", () => {
  assert.deepEqual(parseIni("[s]\r\na=1\r\n[b]\r\nc=2\r\n"), {
    s: { a: "1" },
    b: { c: "2" },
  });
});

test("stringify then parse round-trips", () => {
  const data = {
    "": { name: "api", desc: " has spaces\nand \"quotes\" \t here" },
    server: { port: "8080", motd: "" },
    db: {},
  };
  assert.deepEqual(parseIni(stringifyIni(data)), data);
});

function throwsAt(fn, line) {
  assert.throws(fn, (err) => {
    assert.ok(err instanceof SyntaxError, "expected SyntaxError");
    assert.equal(err.line, line, "line property");
    return true;
  });
}

test("syntax errors carry a 1-based line property", () => {
  throwsAt(() => parseIni("ok=1\n[bad\n"), 2); // header not closed
  throwsAt(() => parseIni("[]\n"), 1); // empty section name
  throwsAt(() => parseIni("[  ]\n"), 1); // blank section name
  throwsAt(() => parseIni("= no key\n"), 1); // empty key
  throwsAt(() => parseIni("[s]\nno equals here\n"), 2); // bare line
  throwsAt(() => parseIni('[s]\na="unclosed\n'), 2); // missing closing quote
  throwsAt(() => parseIni('[s]\na="x"y\n'), 2); // junk after closing quote
  throwsAt(() => parseIni('[s]\na="\\q"\n'), 2); // unknown escape
  throwsAt(() => parseIni("a = tail\\"), 1); // unterminated continuation
});