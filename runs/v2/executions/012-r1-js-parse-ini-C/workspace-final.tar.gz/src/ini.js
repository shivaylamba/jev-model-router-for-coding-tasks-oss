/**
 * INI reading and writing. See docs/INI_FORMAT.md for the dialect.
 */

function quote(value) {
  const escaped = value
    .replace(/\\/g, "\\\\")
    .replace(/"/g, '\\"')
    .replace(/\n/g, "\\n")
    .replace(/\t/g, "\\t");
  return `"${escaped}"`;
}

function needsQuotes(value) {
  return value !== value.trim() || /["\\\n\t]/.test(value) || value.startsWith('"');
}

/**
 * Serialize { section: { key: value } } to INI text. Keys of the "" section
 * are written first, without a header. Values are converted with String().
 */
export function stringifyIni(data) {
  const lines = [];
  const sections = Object.keys(data);
  const ordered = sections.includes("") ? ["", ...sections.filter((s) => s !== "")] : sections;
  for (const section of ordered) {
    if (section !== "") {
      if (lines.length > 0) lines.push("");
      lines.push(`[${section}]`);
    }
    for (const [key, raw] of Object.entries(data[section])) {
      const value = String(raw);
      lines.push(`${key} = ${needsQuotes(value) ? quote(value) : value}`);
    }
  }
  return lines.join("\n") + "\n";
}

function parseError(line) {
  const e = new SyntaxError(`INI syntax error on line ${line}`);
  e.line = line;
  return e;
}

// Parse a value that starts with a `"` (the caller has already trimmed the
// line). Returns the unescaped value, or throws on a bad escape, a missing
// closing quote, or trailing non-whitespace after the closing quote.
function parseQuoted(value, line) {
  let out = "";
  let i = 1;
  while (i < value.length) {
    const c = value[i];
    if (c === '"') {
      if (value.slice(i + 1).trim() !== "") throw parseError(line);
      return out;
    }
    if (c === "\\") {
      const es = { '"': '"', "\\": "\\", n: "\n", t: "\t" };
      const e = value[i + 1];
      if (!(e in es)) throw parseError(line);
      out += es[e];
      i += 2;
      continue;
    }
    out += c;
    i += 1;
  }
  throw parseError(line);
}

/**
 * Parse INI text into { section: { key: value } }. Section names are the keys,
 * in first-appear order; the global section (keys before any header) is `""`
 * and appears only when it has at least one key. Throws a SyntaxError with a
 * numeric `line` property (1-based) for malformed input.
 */
export function parseIni(text) {
  const lines = text.split("\n").map((line, idx) => ({
    text: line.trim(),
    n: idx + 1,
  }));

  const sections = {};
  const order = [];

  function ensure(name) {
    if (!(name in sections)) {
      sections[name] = {};
      order.push(name);
    }
    return sections[name];
  }

  let cur = null; // null until any header is seen; keys go to "" then.
  let i = 0;
  while (i < lines.length) {
    const { text, n } = lines[i];
    if (text === "" || text[0] === ";" || text[0] === "#") {
      i += 1;
      continue;
    }

    if (text[0] === "[") {
      if (!text.endsWith("]")) throw parseError(n);
      const name = text.slice(1, -1).trim();
      if (name === "") throw parseError(n);
      cur = ensure(name);
      i += 1;
      continue;
    }

    const eq = text.indexOf("=");
    if (eq === -1) throw parseError(n);
    const key = text.slice(0, eq).trim();
    if (key === "") throw parseError(n);
    const raw = text.slice(eq + 1).trim();

    if (raw.startsWith('"')) {
      // Quoted values never continue onto the next line.
      if (cur === null) cur = ensure("");
      cur[key] = parseQuoted(raw, n);
      i += 1;
      continue;
    }

    // Unquoted value; a trailing backslash continues onto the next line.
    let acc = raw;
    let j = i;
    while (acc.endsWith("\\")) {
      if (j + 1 >= lines.length) throw parseError(lines[j].n);
      acc = acc.slice(0, -1).trimEnd() + " " + lines[(j += 1)].text;
    }
    if (cur === null) cur = ensure("");
    cur[key] = acc.trim();
    i = j + 1;
  }

  return order.reduce((o, name) => ((o[name] = sections[name]), o), {});
}
