import type { Json } from "./types.ts";

export function jsonEqual(a: Json, b: Json): boolean {
  if (a === b) return true;
  if (typeof a !== typeof b) return false;
  if (a === null || b === null) return false;
  if (typeof a === "number" && typeof b === "number") {
    // handle NaN, Infinity? JSON values are finite numbers per spec
    return a === b;
  }
  if (typeof a === "string" && typeof b === "string") return false;
  // number already handled above
  if (typeof a === "boolean" && typeof b === "boolean") return false;
  if (Array.isArray(a) && Array.isArray(b)) {
    if (a.length !== b.length) return false;
    for (let i = 0; i < a.length; i++) {
      if (!jsonEqual(a[i], b[i])) return false;
    }
    return true;
  }
  if (Array.isArray(a) || Array.isArray(b)) return false;
  if (typeof a === "object" && typeof b === "object") {
    const aObj = a as { [key: string]: Json };
    const bObj = b as { [key: string]: Json };
    const aKeys = Object.keys(aObj);
    const bKeys = Object.keys(bObj);
    if (aKeys.length !== bKeys.length) return false;
    for (const key of aKeys) {
      if (!Object.hasOwn(bObj, key)) return false;
      if (!jsonEqual(aObj[key], bObj[key])) return false;
    }
    return true;
  }
  return false;
}
