import { appendPointer } from "./pointer.ts";
import type { Json, Schema, SchemaObject, ValidationError } from "./types.ts";
import { SchemaError } from "./types.ts";
import { jsonEqual } from "./json-equal.ts";

function isPlainObject(value: unknown): value is { [key: string]: Json } {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function matchesType(value: Json, type: string): boolean {
  switch (type) {
    case "null":
      return value === null;
    case "boolean":
      return typeof value === "boolean";
    case "object":
      return isPlainObject(value);
    case "array":
      return Array.isArray(value);
    case "number":
      return typeof value === "number";
    case "integer":
      return typeof value === "number" && Number.isInteger(value);
    case "string":
      return typeof value === "string";
    default:
      return false;
  }
}

/** Resolve a JSON Pointer (starting with #) against the root schema.
 *  Throws SchemaError for invalid or unresolvable references.
 */
function resolveRef(root: Schema, ref: string): Schema {
  if (!ref.startsWith("#")) {
    throw new SchemaError(`Invalid $ref: ${ref}`);
  }
  const pointer = ref.slice(1); // everything after #
  if (pointer === "") return root;
  if (!pointer.startsWith("/")) {
    throw new SchemaError(`Invalid $ref: ${ref}`);
  }
  let current: unknown = root;
  const tokens = pointer.slice(1).split("/");
  for (const rawToken of tokens) {
    if (current === null || typeof current !== "object") {
      throw new SchemaError(`Invalid $ref: ${ref}`);
    }
    const token = rawToken.replace(/~1/g, "/").replace(/~0/g, "~");
    if (Array.isArray(current)) {
      const idx = Number(token);
      if (!Number.isInteger(idx) || idx < 0 || idx >= current.length) {
        throw new SchemaError(`Invalid $ref: ${ref}`);
      }
      current = current[idx];
    } else {
      if (!Object.hasOwn(current, token)) {
        throw new SchemaError(`Invalid $ref: ${ref}`);
      }
      current = (current as Record<string, unknown>)[token];
    }
  }
  // Accept boolean and object schemas; reject other types
  if (current !== true && current !== false && (current === null || typeof current !== "object" || Array.isArray(current))) {
    throw new SchemaError(`Invalid $ref: ${ref}`);
  }
  return current as Schema;
}

function check(schema: Schema, value: Json, path: string, errors: ValidationError[], root: Schema, seen: Set<string>): void {
  if (schema === true) return;
  if (schema === false) {
    const key = `${path}\0false`;
    if (!seen.has(key)) {
      seen.add(key);
      errors.push({ path, keyword: "false" });
    }
    return;
  }
  const s = schema as SchemaObject;

  function addError(keyword: string): void {
    const key = `${path}\0${keyword}`;
    if (!seen.has(key)) {
      seen.add(key);
      errors.push({ path, keyword });
    }
  }

  if (s.type !== undefined) {
    const types = Array.isArray(s.type) ? (s.type as string[]) : [s.type as string];
    if (!types.some((t) => matchesType(value, t))) addError("type");
  }

  if (s.enum !== undefined && Array.isArray(s.enum)) {
    if (!s.enum.some((item) => jsonEqual(value, item as Json))) {
      addError("enum");
    }
  }

  if (s.const !== undefined) {
    if (!jsonEqual(value, s.const as Json)) {
      addError("const");
    }
  }

  // Number constraints — ignored for non-numbers
  if (typeof value === "number") {
    if (s.minimum !== undefined && typeof s.minimum === "number") {
      if (value < s.minimum) addError("minimum");
    }
    if (s.maximum !== undefined && typeof s.maximum === "number") {
      if (value > s.maximum) addError("maximum");
    }
    if (s.exclusiveMinimum !== undefined && typeof s.exclusiveMinimum === "number") {
      if (value <= s.exclusiveMinimum) addError("exclusiveMinimum");
    }
    if (s.exclusiveMaximum !== undefined && typeof s.exclusiveMaximum === "number") {
      if (value >= s.exclusiveMaximum) addError("exclusiveMaximum");
    }
  }

  // String constraints — ignored for non-strings
  if (typeof value === "string") {
    const codePoints = [...value].length;
    if (s.minLength !== undefined && typeof s.minLength === "number") {
      if (codePoints < s.minLength) addError("minLength");
    }
    if (s.maxLength !== undefined && typeof s.maxLength === "number") {
      if (codePoints > s.maxLength) addError("maxLength");
    }
    if (s.pattern !== undefined && typeof s.pattern === "string") {
      const re = new RegExp(s.pattern, "u");
      if (!re.test(value)) addError("pattern");
    }
  }

  // Object constraints — ignored for non-objects
  if (isPlainObject(value)) {
    const allowedProps = isPlainObject(s.properties) ? Object.keys(s.properties) : [];

    if (Array.isArray(s.required)) {
      for (const name of s.required as string[]) {
        const memberPath = appendPointer(path, name);
        const key = `${memberPath}\0required`;
        if (!Object.hasOwn(value, name) && !seen.has(key)) {
          seen.add(key);
          errors.push({ path: memberPath, keyword: "required" });
        }
      }
    }
    if (isPlainObject(s.properties)) {
      const properties = s.properties as { [key: string]: Schema };
      for (const [name, sub] of Object.entries(properties)) {
        if (Object.hasOwn(value, name)) check(sub, value[name], appendPointer(path, name), errors, root, seen);
      }
    }
    if (s.additionalProperties !== undefined) {
      for (const name of Object.keys(value)) {
        if (!allowedProps.includes(name)) {
          const memberPath = appendPointer(path, name);
          if (s.additionalProperties === false) {
            const key = `${memberPath}\0additionalProperties`;
            if (!seen.has(key)) {
              seen.add(key);
              errors.push({ path: memberPath, keyword: "additionalProperties" });
            }
          } else if (s.additionalProperties !== true) {
            check(s.additionalProperties as Schema, value[name], memberPath, errors, root, seen);
          }
        }
      }
    }
  }

  // Array constraints — ignored for non-arrays
  if (Array.isArray(value)) {
    if (s.minItems !== undefined && typeof s.minItems === "number") {
      if (value.length < s.minItems) addError("minItems");
    }
    if (s.maxItems !== undefined && typeof s.maxItems === "number") {
      if (value.length > s.maxItems) addError("maxItems");
    }
    if (s.items !== undefined) {
      const itemsSchema = s.items as Schema;
      for (let i = 0; i < value.length; i++) {
        check(itemsSchema, value[i], appendPointer(path, i), errors, root, seen);
      }
    }
    if (s.uniqueItems === true) {
      outer: for (let i = 0; i < value.length; i++) {
        for (let j = i + 1; j < value.length; j++) {
          if (jsonEqual(value[i], value[j])) {
            addError("uniqueItems");
            break outer;
          }
        }
      }
    }
  }

  // Combining schemas
  if (Array.isArray(s.allOf)) {
    for (const sub of s.allOf as Schema[]) {
      check(sub, value, path, errors, root, seen);
    }
  }
  if (Array.isArray(s.anyOf)) {
    let anyValid = false;
    for (const sub of s.anyOf as Schema[]) {
      const subErrors: ValidationError[] = [];
      check(sub, value, path, subErrors, root, new Set());
      if (subErrors.length === 0) {
        anyValid = true;
        break;
      }
    }
    if (!anyValid) {
      addError("anyOf");
    }
  }
  if (Array.isArray(s.oneOf)) {
    let matchCount = 0;
    for (const sub of s.oneOf as Schema[]) {
      const subErrors: ValidationError[] = [];
      check(sub, value, path, subErrors, root, new Set());
      if (subErrors.length === 0) {
        matchCount++;
        if (matchCount > 1) break;
      }
    }
    if (matchCount !== 1) {
      addError("oneOf");
    }
  }

  // $ref — other keywords in the same schema still apply (already done above)
  if (s.$ref !== undefined && typeof s.$ref === "string") {
    const resolved = resolveRef(root, s.$ref);
    check(resolved, value, path, errors, root, seen);
  }
}

export function validate(schema: Schema, data: Json): ValidationError[] {
  const errors: ValidationError[] = [];
  check(schema, data, "", errors, schema, new Set());
  return errors;
}
