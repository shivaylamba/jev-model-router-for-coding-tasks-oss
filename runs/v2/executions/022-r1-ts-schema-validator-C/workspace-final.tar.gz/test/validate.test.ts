import { test } from "node:test";
import assert from "node:assert/strict";
import { validate } from "../src/validate.ts";
import { SchemaError } from "../src/types.ts";

test("type", () => {
  assert.deepEqual(validate({ type: "string" }, "x"), []);
  assert.deepEqual(validate({ type: "string" }, 1), [{ path: "", keyword: "type" }]);
  assert.deepEqual(validate({ type: ["string", "null"] }, null), []);
  assert.deepEqual(validate({ type: "integer" }, 2), []);
  assert.deepEqual(validate({ type: "integer" }, 2.5), [{ path: "", keyword: "type" }]);
  assert.deepEqual(validate({ type: "integer" }, 2.0), []);
  assert.deepEqual(validate({ type: "number" }, 2), []);
  assert.deepEqual(validate({ type: "number" }, 2.5), []);
  assert.deepEqual(validate({ type: "object" }, { a: 1 }), []);
  assert.deepEqual(validate({ type: "object" }, null), [{ path: "", keyword: "type" }]);
  assert.deepEqual(validate({ type: "object" }, [1, 2]), [{ path: "", keyword: "type" }]);
});

test("required points at the missing member", () => {
  assert.deepEqual(validate({ type: "object", required: ["id"] }, {}), [{ path: "/id", keyword: "required" }]);
});

test("properties validate nested members", () => {
  const schema = { properties: { user: { properties: { age: { type: "integer" } } } } };
  assert.deepEqual(validate(schema, { user: { age: 1.5 } }), [{ path: "/user/age", keyword: "type" }]);
});

test("boolean schemas", () => {
  assert.deepEqual(validate(true, { anything: 1 }), []);
  assert.deepEqual(validate(false, 1), [{ path: "", keyword: "false" }]);
});

test("enum", () => {
  assert.deepEqual(validate({ enum: [1, "a", null] }, "a"), []);
  assert.deepEqual(validate({ enum: [1, "a", null] }, 2), [{ path: "", keyword: "enum" }]);
  assert.deepEqual(validate({ enum: [{ a: 1 }, { a: 2 }] }, { a: 1 }), []);
  assert.deepEqual(validate({ enum: [{ a: 1 }, { a: 2 }] }, { a: 3 }), [{ path: "", keyword: "enum" }]);
});

test("const", () => {
  assert.deepEqual(validate({ const: 42 }, 42), []);
  assert.deepEqual(validate({ const: 42 }, 43), [{ path: "", keyword: "const" }]);
  assert.deepEqual(validate({ const: { x: 1 } }, { x: 1 }), []);
  assert.deepEqual(validate({ const: { x: 1 } }, { x: 2 }), [{ path: "", keyword: "const" }]);
});

test("numeric bounds", () => {
  assert.deepEqual(validate({ minimum: 0 }, 0), []);
  assert.deepEqual(validate({ minimum: 0 }, -1), [{ path: "", keyword: "minimum" }]);
  assert.deepEqual(validate({ maximum: 10 }, 10), []);
  assert.deepEqual(validate({ maximum: 10 }, 11), [{ path: "", keyword: "maximum" }]);
  assert.deepEqual(validate({ exclusiveMinimum: 0 }, 0), [{ path: "", keyword: "exclusiveMinimum" }]);
  assert.deepEqual(validate({ exclusiveMinimum: 0 }, 1), []);
  assert.deepEqual(validate({ exclusiveMaximum: 10 }, 10), [{ path: "", keyword: "exclusiveMaximum" }]);
  assert.deepEqual(validate({ exclusiveMaximum: 10 }, 9), []);
  // ignored for non-numbers
  assert.deepEqual(validate({ minimum: 0 }, "hi"), []);
  assert.deepEqual(validate({ maximum: 10 }, null), []);
});

test("string length", () => {
  assert.deepEqual(validate({ minLength: 2 }, "ab"), []);
  assert.deepEqual(validate({ minLength: 2 }, "a"), [{ path: "", keyword: "minLength" }]);
  assert.deepEqual(validate({ maxLength: 2 }, "ab"), []);
  assert.deepEqual(validate({ maxLength: 2 }, "abc"), [{ path: "", keyword: "maxLength" }]);
  // code points
  assert.deepEqual(validate({ minLength: 1 }, "😀"), []);
  assert.deepEqual(validate({ maxLength: 1 }, "😀"), []);
  assert.deepEqual(validate({ minLength: 2 }, "😀"), [{ path: "", keyword: "minLength" }]);
  assert.deepEqual(validate({ maxLength: 0 }, "😀"), [{ path: "", keyword: "maxLength" }]);
  // ignored for non-strings
  assert.deepEqual(validate({ minLength: 1 }, 1), []);
});

test("pattern", () => {
  assert.deepEqual(validate({ pattern: "a" }, "abc"), []);
  assert.deepEqual(validate({ pattern: "^a$" }, "abc"), [{ path: "", keyword: "pattern" }]);
  assert.deepEqual(validate({ pattern: "[A-Z]+" }, "HELLO"), []);
  assert.deepEqual(validate({ pattern: "\\d+" }, "abc"), [{ path: "", keyword: "pattern" }]);
  // unicode flag
  assert.deepEqual(validate({ pattern: "\\p{Emoji}" }, "😀"), []);
  // ignored for non-strings
  assert.deepEqual(validate({ pattern: "a" }, 1), []);
});

test("additionalProperties boolean", () => {
  const schema = { properties: { a: { type: "string" } }, additionalProperties: false };
  assert.deepEqual(validate(schema, { a: "x" }), []);
  assert.deepEqual(validate(schema, { a: "x", b: 1 }), [{ path: "/b", keyword: "additionalProperties" }]);

  const schema2 = { additionalProperties: false };
  assert.deepEqual(validate(schema2, {}), []);
  assert.deepEqual(validate(schema2, { a: 1 }), [{ path: "/a", keyword: "additionalProperties" }]);

  const schema3 = { properties: { a: { type: "string" } }, additionalProperties: true };
  assert.deepEqual(validate(schema3, { a: "x", b: 1 }), []);
});

test("additionalProperties schema", () => {
  const schema = { properties: { a: { type: "string" } }, additionalProperties: { type: "number" } };
  assert.deepEqual(validate(schema, { a: "x", b: 1 }), []);
  assert.deepEqual(validate(schema, { a: "x", b: "y" }), [{ path: "/b", keyword: "type" }]);
  // additionalProperties does not apply to known properties
  assert.deepEqual(validate(schema, { a: 1 }), [{ path: "/a", keyword: "type" }]);
});

test("minItems/maxItems", () => {
  assert.deepEqual(validate({ minItems: 2 }, [1, 2]), []);
  assert.deepEqual(validate({ minItems: 2 }, [1]), [{ path: "", keyword: "minItems" }]);
  assert.deepEqual(validate({ maxItems: 2 }, [1, 2]), []);
  assert.deepEqual(validate({ maxItems: 2 }, [1, 2, 3]), [{ path: "", keyword: "maxItems" }]);
  // ignored for non-arrays
  assert.deepEqual(validate({ minItems: 1 }, "a"), []);
});

test("items", () => {
  const schema = { items: { type: "integer" } };
  assert.deepEqual(validate(schema, [1, 2]), []);
  assert.deepEqual(validate(schema, [1, "a"]), [{ path: "/1", keyword: "type" }]);
  // ignored for non-arrays
  assert.deepEqual(validate({ items: { type: "integer" } }, "a"), []);
});

test("uniqueItems", () => {
  assert.deepEqual(validate({ uniqueItems: true }, [1, 2, 3]), []);
  assert.deepEqual(validate({ uniqueItems: true }, [1, 1]), [{ path: "", keyword: "uniqueItems" }]);
  assert.deepEqual(validate({ uniqueItems: true }, [{ a: 1 }, { a: 1 }]), [{ path: "", keyword: "uniqueItems" }]);
  assert.deepEqual(validate({ uniqueItems: true }, [{ a: 1 }, { a: 2 }]), []);
  // ignored for non-arrays
  assert.deepEqual(validate({ uniqueItems: true }, "aa"), []);
});

test("allOf", () => {
  assert.deepEqual(validate({ allOf: [{ type: "string" }, { minLength: 2 }] }, "abc"), []);
  assert.deepEqual(validate({ allOf: [{ type: "string" }, { minLength: 2 }] }, 1), [
    { path: "", keyword: "type" },
  ]);
  assert.deepEqual(validate({ allOf: [{ type: "string" }, { minLength: 2 }] }, "a"), [
    { path: "", keyword: "minLength" },
  ]);
});

test("anyOf", () => {
  assert.deepEqual(validate({ anyOf: [{ type: "string" }, { type: "number" }] }, "x"), []);
  assert.deepEqual(validate({ anyOf: [{ type: "string" }, { type: "number" }] }, 1), []);
  assert.deepEqual(validate({ anyOf: [{ type: "string" }, { type: "number" }] }, null), [
    { path: "", keyword: "anyOf" },
  ]);
  // does not report subschema errors
  assert.deepEqual(validate({ anyOf: [{ type: "string", minLength: 5 }, { type: "string", maxLength: 1 }] }, "ab"), [
    { path: "", keyword: "anyOf" },
  ]);
});

test("oneOf", () => {
  assert.deepEqual(validate({ oneOf: [{ type: "string" }, { type: "number" }] }, "x"), []);
  assert.deepEqual(validate({ oneOf: [{ type: "string" }, { type: "number" }] }, 1), []);
  // none match
  assert.deepEqual(validate({ oneOf: [{ type: "string" }, { type: "number" }] }, null), [
    { path: "", keyword: "oneOf" },
  ]);
  // two match
  assert.deepEqual(validate({ oneOf: [{ type: "string" }, { minLength: 1 }] }, "x"), [
    { path: "", keyword: "oneOf" },
  ]);
  // does not report subschema errors
  assert.deepEqual(validate({ oneOf: [{ type: "string", minLength: 5 }, { type: "string", maxLength: 1 }] }, "ab"), [
    { path: "", keyword: "oneOf" },
  ]);
});

test("$ref simple", () => {
  const schema = {
    $ref: "#/definitions/stringType",
    definitions: {
      stringType: { type: "string" },
    },
  };
  assert.deepEqual(validate(schema, "x"), []);
  assert.deepEqual(validate(schema, 1), [{ path: "", keyword: "type" }]);
});

test("$ref nested property", () => {
  const schema = {
    properties: {
      name: { $ref: "#/definitions/nonEmpty" },
    },
    definitions: {
      nonEmpty: { minLength: 1 },
    },
  };
  assert.deepEqual(validate(schema, { name: "x" }), []);
  assert.deepEqual(validate(schema, { name: "" }), [{ path: "/name", keyword: "minLength" }]);
});

test("$ref into array element", () => {
  const schema = {
    $ref: "#/0/stringType",
    0: {
      stringType: { type: "string" },
    },
  };
  assert.deepEqual(validate(schema, "x"), []);
  assert.deepEqual(validate(schema, 1), [{ path: "", keyword: "type" }]);
});

test("$ref recursive", () => {
  const schema = {
    definitions: {
      node: {
        type: "object",
        properties: {
          left: { $ref: "#/definitions/node" },
          right: { $ref: "#/definitions/node" },
        },
      },
    },
    $ref: "#/definitions/node",
  };
  assert.deepEqual(validate(schema, { left: {}, right: { left: {} } }), []);
  assert.deepEqual(validate(schema, { left: "oops" }), [{ path: "/left", keyword: "type" }]);
});

test("$ref with other keywords", () => {
  const schema = { $ref: "#/definitions/s", minimum: 5, definitions: { s: { type: "number" } } };
  assert.deepEqual(validate(schema, 10), []);
  assert.deepEqual(validate(schema, 4), [{ path: "", keyword: "minimum" }]);
  assert.deepEqual(validate(schema, "x"), [{ path: "", keyword: "type" }]);
});

test("$ref invalid throws SchemaError", () => {
  assert.throws(() => validate({ $ref: "not_a_ref" }, 1), SchemaError);
  assert.throws(() => validate({ $ref: "#/definitions/missing" }, 1), SchemaError);
  assert.throws(() => validate({ $ref: "#/definitions/a/b" }, 1), SchemaError);
});

test("$ref with ~0 and ~1", () => {
  const schema = {
    definitions: {
      "a/b": { type: "string" },
      "c~d": { type: "number" },
    },
    properties: {
      a: { $ref: "#/definitions/a~1b" },
      b: { $ref: "#/definitions/c~0d" },
    },
  };
  assert.deepEqual(validate(schema, { a: "x", b: 1 }), []);
  assert.deepEqual(validate(schema, { a: 1, b: "x" }), [
    { path: "/a", keyword: "type" },
    { path: "/b", keyword: "type" },
  ]);
});

test("deduplication of identical errors", () => {
  // allOf with two subschemas that both report type error at same path -> one error
  assert.deepEqual(validate({ allOf: [{ type: "string" }, { type: "string" }] }, 1), [
    { path: "", keyword: "type" },
  ]);
  // $ref + sibling keyword both report same error -> one error
  const schema = { $ref: "#/definitions/s", type: "string", definitions: { s: { type: "string" } } };
  assert.deepEqual(validate(schema, 1), [{ path: "", keyword: "type" }]);
});

test("keywords ignored for wrong value types", () => {
  assert.deepEqual(validate({ required: ["a"] }, "x"), []);
  assert.deepEqual(validate({ properties: { a: { type: "string" } } }, "x"), []);
  assert.deepEqual(validate({ additionalProperties: false }, "x"), []);
  assert.deepEqual(validate({ items: { type: "integer" } }, { a: 1 }), []);
  assert.deepEqual(validate({ uniqueItems: true }, { a: 1 }), []);
  assert.deepEqual(validate({ minItems: 2 }, { a: 1 }), []);
  assert.deepEqual(validate({ maxItems: 1 }, { a: 1 }), []);
  assert.deepEqual(validate({ minLength: 2 }, [1, 2]), []);
  assert.deepEqual(validate({ maxLength: 1 }, [1, 2]), []);
  assert.deepEqual(validate({ pattern: "a" }, [1, 2]), []);
  assert.deepEqual(validate({ minimum: 0 }, "x"), []);
  assert.deepEqual(validate({ maximum: 0 }, "x"), []);
  assert.deepEqual(validate({ exclusiveMinimum: 0 }, "x"), []);
  assert.deepEqual(validate({ exclusiveMaximum: 0 }, "x"), []);
  assert.deepEqual(validate({ enum: [1, 2] }, "x"), [{ path: "", keyword: "enum" }]);
  assert.deepEqual(validate({ const: 1 }, "x"), [{ path: "", keyword: "const" }]);
});

test("properties and additionalProperties together", () => {
  const schema = {
    properties: {
      known: { type: "string" },
    },
    additionalProperties: { type: "number" },
  };
  assert.deepEqual(validate(schema, { known: "x", extra: 1 }), []);
  assert.deepEqual(validate(schema, { known: "x", extra: "y" }), [{ path: "/extra", keyword: "type" }]);
  assert.deepEqual(validate(schema, { known: 1, extra: 1 }), [{ path: "/known", keyword: "type" }]);
  assert.deepEqual(validate(schema, { known: 1, extra: "y" }), [
    { path: "/known", keyword: "type" },
    { path: "/extra", keyword: "type" },
  ]);
});
