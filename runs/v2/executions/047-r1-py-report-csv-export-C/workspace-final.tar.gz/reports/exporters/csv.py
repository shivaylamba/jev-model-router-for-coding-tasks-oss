"""Comma-separated values for spreadsheets.

Machine-readable, so it does not use the display formatting in formatting.py.
"""


def _cell(value):
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return format(value, ".2f")
    return value


def _quote(field):
    if "," in field or '"' in field or "\n" in field or "\r" in field:
        return '"' + field.replace('"', '""') + '"'
    return field


def _line(cells):
    return ",".join(_quote(cell) for cell in cells) + "\n"


class CsvExporter:
    name = "csv"
    extension = ".csv"

    def export(self, report):
        out = [_line([column.label for column in report.columns])]
        out += [_line([_cell(report.cell(row, c)) for c in report.columns]) for row in report.rows]
        return "".join(out)