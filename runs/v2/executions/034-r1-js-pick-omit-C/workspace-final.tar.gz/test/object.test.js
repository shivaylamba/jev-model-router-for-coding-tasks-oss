import { test } from "node:test";
import assert from "node:assert/strict";
import { isPlainObject, mapValues, pick, omit } from "../src/object.js";

test("isPlainObject", () => {
  assert.equal(isPlainObject({}), true);
  assert.equal(isPlainObject(Object.create(null)), true);
  assert.equal(isPlainObject([]), false);
  assert.equal(isPlainObject(new Date()), false);
});

test("mapValues", () => {
  assert.deepEqual(mapValues({ a: 1, b: 2 }, (v) => v * 10), { a: 10, b: 20 });
});

test("pick keeps listed keys in order, ignoring missing ones", () => {
  assert.deepEqual(pick({ a: 1, b: 2, c: 3 }, ["c", "a", "nope"]), { c: 3, a: 1 });
});

test("pick keeps a key whose value is undefined", () => {
  assert.deepEqual(pick({ a: undefined }, ["a"]), { a: undefined });
});

test("pick ignores inherited and non-enumerable properties", () => {
  const proto = { inherited: 1 };
  const obj = Object.create(proto);
  Object.defineProperty(obj, "hidden", { value: 2, enumerable: false });
  obj.own = 3;
  assert.deepEqual(pick(obj, ["inherited", "hidden", "own"]), { own: 3 });
});

test("pick returns a new empty object when nothing matches", () => {
  const empty = pick({ a: 1 }, ["z"]);
  assert.deepEqual(empty, {});
  assert.notEqual(empty, {});
});

test("pick does not mutate obj or keys", () => {
  const obj = { a: 1, b: 2 };
  const keys = ["b", "a"];
  pick(obj, keys);
  assert.deepEqual(obj, { a: 1, b: 2 });
  assert.deepEqual(keys, ["b", "a"]);
});

test("omit drops listed keys, keeping original order", () => {
  assert.deepEqual(omit({ a: 1, b: 2, c: 3 }, ["b", "nope"]), { a: 1, c: 3 });
});

test("omit ignores inherited and non-enumerable properties", () => {
  const proto = { inherited: 1 };
  const obj = Object.create(proto);
  Object.defineProperty(obj, "hidden", { value: 2, enumerable: false });
  obj.own = 3;
  assert.deepEqual(omit(obj, []), { own: 3 });
});

test("omit returns a new empty object when everything is omitted", () => {
  const empty = omit({ a: 1 }, ["a"]);
  assert.deepEqual(empty, {});
  assert.notEqual(empty, {});
});

test("omit does not mutate obj or keys", () => {
  const obj = { a: 1, b: 2 };
  const keys = ["b"];
  omit(obj, keys);
  assert.deepEqual(obj, { a: 1, b: 2 });
  assert.deepEqual(keys, ["b"]);
});
