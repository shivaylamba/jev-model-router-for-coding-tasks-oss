import { percentOf } from "./money.ts";
import { BUNDLES } from "./bundles.ts";
import type { Bundle, Coupon, CouponStatus, Discount, Order } from "./types.ts";

export type PricedLine = {
  sku: string;
  unitPrice: number;
  quantity: number;
  gross: number;
  bundled: number;
};

export type PricingContext = {
  order: Order;
  coupon: Coupon | undefined;
  lines: PricedLine[];
  subtotal: number;
  discounts: Discount[];
  couponStatus: CouponStatus;
  shipping: number;
  tax: number;
};

export type PricingRule = {
  name: string;
  apply(ctx: PricingContext): void;
};

export function merchandiseTotal(ctx: PricingContext): number {
  let sum = 0;
  for (const d of ctx.discounts) {
    sum += d.amount;
  }
  return ctx.subtotal - sum;
}

export function createPricer(rules: PricingRule[]) {
  return (order: Order, coupon?: Coupon) => {
    for (const line of order.lines) {
      if (!Number.isInteger(line.quantity) || line.quantity < 1) {
        throw new RangeError(`bad quantity for ${line.sku}: ${line.quantity}`);
      }
      if (!Number.isInteger(line.unitPrice) || line.unitPrice < 0) {
        throw new RangeError(`bad unit price for ${line.sku}: ${line.unitPrice}`);
      }
    }

    const lines: PricedLine[] = order.lines.map((line) => ({
      ...line,
      gross: line.unitPrice * line.quantity,
      bundled: 0,
    }));

    const ctx: PricingContext = {
      order,
      coupon,
      lines,
      subtotal: lines.reduce((sum, l) => sum + l.gross, 0),
      discounts: [],
      couponStatus: "none",
      shipping: 0,
      tax: 0,
    };

    for (const rule of rules) {
      rule.apply(ctx);
    }

    const merchandise = merchandiseTotal(ctx);
    return {
      subtotal: ctx.subtotal,
      discounts: ctx.discounts,
      merchandise,
      shipping: ctx.shipping,
      tax: ctx.tax,
      total: merchandise + ctx.shipping + ctx.tax,
      coupon: ctx.couponStatus,
    };
  };
}

export const VOLUME_MIN_QUANTITY = 10;
export const VOLUME_PERCENT = 10;
export const FREE_SHIPPING_THRESHOLD = 5000;
export const SHIPPING_FEE = 499;
export const TAX_PERCENT = 8;

export function bundleRule(bundles: Bundle[]): PricingRule {
  return {
    name: "bundle",
    apply(ctx) {
      for (const bundle of bundles) {
        // Map sku -> entries of remaining unbundled units, earliest lines first
        type LineSlot = { line: PricedLine; remaining: number };
        const skuLines = new Map<string, LineSlot[]>();
        for (let i = 0; i < ctx.lines.length; i++) {
          const line = ctx.lines[i];
          const remaining = line.quantity - line.bundled;
          if (remaining > 0) {
            const arr = skuLines.get(line.sku);
            if (arr) {
              arr.push({ line, remaining });
            } else {
              skuLines.set(line.sku, [{ line, remaining }]);
            }
          }
        }

        let bundleCount = Number.POSITIVE_INFINITY;
        for (const sku of bundle.skus) {
          const arr = skuLines.get(sku);
          const total = arr ? arr.reduce((s, slot) => s + slot.remaining, 0) : 0;
          bundleCount = Math.min(bundleCount, total);
        }

        if (bundleCount === 0 || bundleCount === Number.POSITIVE_INFINITY) {
          continue;
        }

        // Consume units for this bundle id, earliest lines first
        const takenPerLine = new Map<PricedLine, number>();
        for (let b = 0; b < bundleCount; b++) {
          for (const sku of bundle.skus) {
            const arr = skuLines.get(sku)!;
            for (const slot of arr) {
              if (slot.remaining > 0) {
                slot.remaining--;
                slot.line.bundled++;
                takenPerLine.set(slot.line, (takenPerLine.get(slot.line) || 0) + 1);
                break;
              }
            }
          }
        }

        let totalDiscount = 0;
        for (const [line, taken] of takenPerLine) {
          totalDiscount += percentOf(line.unitPrice * taken, bundle.percent);
        }

        if (totalDiscount > 0) {
          ctx.discounts.push({ rule: `bundle:${bundle.id}`, amount: totalDiscount });
        }
      }
    },
  };
}

export const volumeRule: PricingRule = {
  name: "volume",
  apply(ctx) {
    let total = 0;
    for (const line of ctx.lines) {
      if (line.quantity >= VOLUME_MIN_QUANTITY) {
        const unbundled = line.quantity - line.bundled;
        if (unbundled > 0) {
          total += percentOf(line.unitPrice * unbundled, VOLUME_PERCENT);
        }
      }
    }
    if (total > 0) {
      ctx.discounts.push({ rule: "volume", amount: total });
    }
  },
};

export const couponRule: PricingRule = {
  name: "coupon",
  apply(ctx) {
    const coupon = ctx.coupon;
    if (!coupon) {
      ctx.couponStatus = "none";
      return;
    }

    if (coupon.exclusive) {
      for (const d of ctx.discounts) {
        if (d.rule.startsWith("bundle:")) {
          ctx.couponStatus = "excluded";
          return;
        }
      }
    }

    const merchandise = merchandiseTotal(ctx);
    if (merchandise < (coupon.minSubtotal ?? 0)) {
      ctx.couponStatus = "below-minimum";
      return;
    }

    const off = coupon.kind === "percent"
      ? percentOf(merchandise, coupon.value)
      : Math.min(coupon.value, merchandise);

    ctx.couponStatus = "applied";
    if (off > 0) {
      ctx.discounts.push({ rule: `coupon:${coupon.code}`, amount: off });
    }
  },
};

export const shippingRule: PricingRule = {
  name: "shipping",
  apply(ctx) {
    if (ctx.order.lines.length === 0) {
      ctx.shipping = 0;
      return;
    }
    const merchandise = merchandiseTotal(ctx);
    ctx.shipping = merchandise >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_FEE;
  },
};

export const taxRule: PricingRule = {
  name: "tax",
  apply(ctx) {
    ctx.tax = percentOf(merchandiseTotal(ctx), TAX_PERCENT);
  },
};

export const defaultRules: PricingRule[] = [
  bundleRule(BUNDLES),
  volumeRule,
  couponRule,
  shippingRule,
  taxRule,
];
