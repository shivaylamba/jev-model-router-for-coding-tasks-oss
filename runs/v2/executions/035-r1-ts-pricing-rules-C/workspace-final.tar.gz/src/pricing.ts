import { createPricer, defaultRules } from "./rules.ts";
import type { Coupon, Order, Totals } from "./types.ts";

/** Price an order. See docs/PRICING.md for the rules. */
export function orderTotal(order: Order, coupon?: Coupon): Totals {
  return createPricer(defaultRules)(order, coupon);
}
