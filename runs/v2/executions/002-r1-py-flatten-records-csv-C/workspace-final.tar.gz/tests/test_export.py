import unittest

from csvexport import records_to_csv, rows_to_csv
from loader import parse_ndjson


class LoaderTest(unittest.TestCase):
    def test_parse_ndjson(self):
        self.assertEqual(parse_ndjson('{"a": 1}\n\n{"a": 2}\n'), [{"a": 1}, {"a": 2}])

    def test_bad_line(self):
        with self.assertRaises(ValueError):
            parse_ndjson('{"a": 1}\nnope\n')


class RowsToCsvTest(unittest.TestCase):
    def test_rows_to_csv(self):
        self.assertEqual(rows_to_csv(["a", "b"], [["1", "x,y"]]), 'a,b\r\n1,"x,y"\r\n')


class RecordsToCsvTest(unittest.TestCase):
    def test_empty_records(self):
        self.assertEqual(records_to_csv([]), "")

    def test_flatten_nested_dicts(self):
        records = [
            {"user": {"name": "ada", "id": 1}, "action": "login"},
            {"user": {"name": "bob"}},
        ]
        self.assertEqual(
            records_to_csv(records),
            'user.name,user.id,action\r\nada,1,login\r\nbob,,\r\n',
        )

    def test_scalar_cells(self):
        records = [{"flags": [True, None, 2], "empty": [], "n": None, "b": False}]
        self.assertEqual(
            records_to_csv(records),
            'flags,empty,n,b\r\ntrue;;2,,,false\r\n',
        )

    def test_value_and_dict_for_same_key(self):
        records = [{"a": 5}, {"a": {"b": 1}}]
        self.assertEqual(records_to_csv(records), 'a,a.b\r\n5,\r\n,1\r\n')

    def test_nested_empty_dict_contributes_no_column(self):
        records = [{"a": {"b": {}}, "c": 1}]
        self.assertEqual(records_to_csv(records), 'c\r\n1\r\n')

    def test_quoting(self):
        records = [{"a": "x,y"}, {"a": 'say "hi"'}]
        self.assertEqual(
            records_to_csv(records),
            'a\r\n"x,y"\r\n"say ""hi"""\r\n',
        )

    def test_same_record_collision(self):
        with self.assertRaises(ValueError):
            records_to_csv([{"a.b": 1, "a": {"b": 2}}])

    def test_cross_record_collision_merges(self):
        records = [{"a.b": 1}, {"a": {"b": 2}}]
        self.assertEqual(records_to_csv(records), 'a.b\r\n1\r\n2\r\n')

    def test_non_dict_record(self):
        with self.assertRaises(TypeError):
            records_to_csv([42])

    def test_input_not_modified(self):
        records = [{"user": {"name": "ada"}, "tags": [True, None]}]
        snapshot = [{"user": {"name": "ada"}, "tags": [True, None]}]
        records_to_csv(records)
        self.assertEqual(records, snapshot)


if __name__ == "__main__":
    unittest.main()
