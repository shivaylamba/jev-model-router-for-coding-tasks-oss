"""CSV output for exported events."""

import csv
import io


def rows_to_csv(header, rows):
    """Render a header and rows (lists of strings) with the csv module's default dialect."""
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(header)
    writer.writerows(rows)
    return buffer.getvalue()


def records_to_csv(records):
    """Render a list of dicts (as parsed by loader.parse_ndjson) as CSV text.

    Nested dicts are flattened into dot-separated column names at any depth; a
    nested empty dict contributes no column. Columns appear in first-seen order.
    Raises ValueError if two keys in the same record flatten to the same column
    name, and TypeError if a record is not a dict. The input is not modified.
    """
    if not records:
        return ""

    # Flatten each record once into a (column -> value) lookup; this also
    # raises on a same-record name collision.
    lookups = [dict(_flatten(record)) for record in records]

    # Gather columns in first-seen order across all records.
    columns = []
    seen = set()
    for lookup in lookups:
        for column in lookup:
            if column not in seen:
                seen.add(column)
                columns.append(column)

    rows = [[_cell(lookup.get(column)) for column in columns] for lookup in lookups]
    return rows_to_csv(columns, rows)


def _flatten(record):
    """Return the record's flattened leaves as a list of ``(column, value)`` pairs.

    A leaf is a non-dict value; a nested empty dict contributes nothing. Raises
    TypeError for non-dict records and ValueError if two keys in the same record
    flatten to the same column name.
    """
    if not isinstance(record, dict):
        raise TypeError(f"record must be a dict, got {type(record).__name__}")

    leaves = []
    _walk(record, "", leaves)

    columns = [column for column, _ in leaves]
    if len(columns) != len(set(columns)):
        duplicates = sorted({c for c in columns if columns.count(c) > 1})
        raise ValueError("duplicate column name(s): " + ", ".join(duplicates))
    return leaves


def _walk(value, prefix, leaves):
    for key, sub in value.items():
        column = f"{prefix}.{key}" if prefix else key
        if isinstance(sub, dict):
            if sub:
                _walk(sub, column, leaves)
        else:
            leaves.append((column, sub))


def _cell(value):
    """Render a leaf value as a CSV cell: None as empty, lists/tuples joined
    with ';' (each item using scalar rules), bools and other scalars as text."""
    if isinstance(value, (list, tuple)):
        return ";".join(_scalar(item) for item in value)
    return _scalar(value)


def _scalar(value):
    if value is None:
        return ""
    if value is True:
        return "true"
    if value is False:
        return "false"
    return str(value)
