export type AsyncCacheOptions<V> = {
  load: (key: string) => Promise<V>;
  ttlMs: number; // finite, > 0
  staleMs: number; // finite, >= 0
  maxEntries: number; // integer, >= 1
  now?: () => number; // current time in ms; defaults to Date.now
  onRefreshError?: (key: string, error: unknown) => void;
};

type Entry<V> = {
  value: V;
  storedAt: number;
};

type LoadState<V> = "pending" | "fulfilled" | "rejected";

type TrackedPromise<V> = Promise<V> & {
  // Internal bookkeeping attached to the tracked promise so later `get`s can
  // distinguish refresh loads from caller-visible loads and detect rejection.
  __asyncCacheRecord?: LoadRecord<V>;
};

/**
 * AsyncCache implements the contract described in docs/ASYNC_CACHE.md:
 *
 * - Values are classified by age = now() - storedAt:
 *   fresh while age < ttlMs, stale while ttlMs <= age < ttlMs + staleMs,
 *   expired once age >= ttlMs + staleMs.
 * - At most one load is in flight per key (single flight).
 * - Stale values are served immediately while a background refresh runs.
 * - Failed loads never overwrite a stored value; failed refreshes are
 *   reported via onRefreshError and swallowed.
 * - invalidate(key)/clear() prevent in-flight loads from storing results.
 * - Storing beyond maxEntries drops expired entries first, then evicts LRU.
 */
export class AsyncCache<V> {
  private readonly loadFn: (key: string) => Promise<V>;
  private readonly ttlMs: number;
  private readonly staleMs: number;
  private readonly maxEntries: number;
  private readonly now: () => number;
  private readonly onRefreshError?: (key: string, error: unknown) => void;

  private entries = new Map<string, Entry<V>>();
  private loads = new Map<string, LoadRecord<V>>();
  private invVersion = new Map<string, number>();

  constructor(options: AsyncCacheOptions<V>) {
    if (!Number.isFinite(options.ttlMs) || options.ttlMs <= 0) {
      throw new RangeError("ttlMs must be finite and > 0");
    }
    if (!Number.isFinite(options.staleMs) || options.staleMs < 0) {
      throw new RangeError("staleMs must be finite and >= 0");
    }
    if (!Number.isInteger(options.maxEntries) || options.maxEntries < 1) {
      throw new RangeError("maxEntries must be an integer >= 1");
    }

    this.#load = options.load;
    this.#ttlMs = options.ttlMs;
    this.#staleMs = options.staleMs;
    this.#maxEntries = options.maxEntries;
    this.#now = options.now ?? Date.now;
    this.#onRefreshError = options.onRefreshError;
  }

  get size(): number {
    const now = this.#now();
    const totalLifetime = this.#ttlMs + this.#staleMs;
    let count = 0;
    for (const [, entry] of this.#entries) {
      if (now - entry.storedAt < totalLifetime) count++;
    }
    return count;
  }

  get(key: string): Promise<V> {
    const now = this.#now();
    const entry = this.#entries.get(key);

    if (entry !== undefined) {
      const age = now - entry.storedAt;
      if (age < this.#ttlMs) {
        this.#touch(key);
        return Promise.resolve(entry.value);
      }
      if (age < this.#ttlMs + this.#staleMs) {
        this.#touch(key);
        if (!this.#loads.has(key)) {
          this.#startLoad(key, true);
        }
        return Promise.resolve(entry.value);
      }
    }

    this.#entries.delete(key);

    const inFlight = this.#loads.get(key);
    if (inFlight !== undefined) {
      return inFlight.promise;
    }
    return this.#startLoad(key, false);
  }

  peek(key: string): V | undefined {
    const entry = this.#entries.get(key);
    if (entry === undefined) return undefined;
    const age = this.#now() - entry.storedAt;
    if (age >= this.#ttlMs + this.#staleMs) return undefined;
    return entry.value;
  }

  invalidate(key: string): boolean {
    this.#invVersion.set(key, this.#versionOf(key) + 1);
    this.#loads.delete(key);
    return this.#entries.delete(key);
  }

  clear(): void {
    for (const key of this.#loads.keys()) {
      this.#invVersion.set(key, this.#versionOf(key) + 1);
    }
    this.#loads.clear();
    this.#entries.clear();
  }

  #touch(key: string): void {
    const entry = this.#entries.get(key);
    if (entry !== undefined) {
      this.#entries.delete(key);
      this.#entries.set(key, entry);
    }
  }

  #startLoad(key: string, isRefresh: boolean): Promise<V> {
    const versionAtStart = this.#versionOf(key);
    const record: LoadRecord<V> = {
      promise: undefined as unknown as Promise<V>,
      isRefresh,
    };

    const run = async (): Promise<V> => {
      try {
        const value = await this.#load(key);
        if (this.#loads.get(key) === record) this.#loads.delete(key);
        if (this.#versionOf(key) === versionAtStart) {
          this.#store(key, value);
        }
        return value;
      } catch (error) {
        if (this.#loads.get(key) === record) this.#loads.delete(key);
        if (isRefresh && this.#onRefreshError) {
          try {
            this.#onRefreshError(key, error);
          } catch {
            // onRefreshError must never throw; ignore.
          }
        }
        throw error;
      }
    };

    record.promise = judged;
    this.#loads.set(key, record);

    if (isRefresh) {
      judged.catch(() => {});
    }
    return judged;
  }
}
