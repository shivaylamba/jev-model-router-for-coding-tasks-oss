export type Status = "open" | "done";

export interface Todo {
  id: number;
  title: string;
  status: Status;
  tags: string[];
  /** Due date as "YYYY-MM-DD", or null when there is none. */
  due: string | null;
  /** Milliseconds since the epoch, from the injected clock. */
  createdAt: number;
}

export interface NewTodo {
  title: string;
  tags?: string[];
  due?: string | null;
}

export interface TodoQuery {
  status?: "open" | "done" | "all";
  tags?: string[];
  text?: string;
  dueBefore?: string;
  sort?: "id" | "created" | "due" | "title";
  order?: "asc" | "desc";
}

/** True when `s` is a real calendar date written as zero-padded `YYYY-MM-DD`. */
function isValidDateString(s: string): boolean {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  if (!m) return false;
  const year = Number(m[1]);
  const month = Number(m[2]);
  const day = Number(m[3]);
  if (month < 1 || month > 12) return false;
  const dt = new Date(0);
  dt.setUTCFullYear(year, month - 1, day);
  dt.setUTCHours(0, 0, 0, 0);
  return (
    dt.getUTCFullYear() === year &&
    dt.getUTCMonth() === month - 1 &&
    dt.getUTCDate() === day
  );
}

export class TodoService {
  private todos: Todo[] = [];
  private nextId = 1;
  private clock: () => number;

  constructor(clock: () => number = Date.now) {
    this.clock = clock;
  }

  add(input: NewTodo): Todo {
    const title = input.title.trim();
    if (title === "") throw new TypeError("title must not be empty");
    const todo: Todo = {
      id: this.nextId++,
      title,
      status: "open",
      tags: [...(input.tags ?? [])],
      due: input.due ?? null,
      createdAt: this.clock(),
    };
    this.todos.push(todo);
    return todo;
  }

  complete(id: number): Todo {
    const todo = this.todos.find((t) => t.id === id);
    if (!todo) throw new Error(`no todo with id ${id}`);
    todo.status = "done";
    return todo;
  }

  /** All todos in id order. */
  list(): Todo[] {
    return [...this.todos];
  }

  /** Filter and sort the todos. Returns a new array; the service is never reordered. */
  query(query?: TodoQuery): Todo[] {
    const status = query?.status ?? "all";
    const tags = query?.tags ?? [];
    const text = query?.text;
    const dueBefore = query?.dueBefore;
    const sort = query?.sort ?? "id";
    const order = query?.order ?? "asc";

    if (!["open", "done", "all"].includes(status)) {
      throw new RangeError(`invalid status: ${JSON.stringify(status)}`);
    }
    if (!["id", "created", "due", "title"].includes(sort)) {
      throw new RangeError(`invalid sort: ${JSON.stringify(sort)}`);
    }
    if (!["asc", "desc"].includes(order)) {
      throw new RangeError(`invalid order: ${JSON.stringify(order)}`);
    }
    if (dueBefore !== undefined && !isValidDateString(dueBefore)) {
      throw new RangeError(`invalid dueBefore: ${JSON.stringify(dueBefore)}`);
    }

    const trimmedText = text?.trim();
    const dir = order === "desc" ? -1 : 1;

    const result = this.todos.filter((t) => {
      if (status === "open" && t.status !== "open") return false;
      if (status === "done" && t.status !== "done") return false;
      if (tags.length > 0) {
        const wanted = tags.map((tag) => tag.toLowerCase());
        if (
          !wanted.every((want) => t.tags.some((tt) => tt.toLowerCase() === want))
        ) {
          return false;
        }
      }
      if (trimmedText && !t.title.toLowerCase().includes(trimmedText.toLowerCase())) {
        return false;
      }
      if (dueBefore !== undefined && (t.due === null || t.due > dueBefore)) {
        return false;
      }
      return true;
    });

    result.sort((a, b) => {
      let keyCmp: number;
      if (sort === "due") {
        // Todos without a due date always come last, in both orders.
        if (a.due === null && b.due === null) keyCmp = 0;
        else if (a.due === null) keyCmp = 1;
        else if (b.due === null) keyCmp = -1;
        else keyCmp = (a.due < b.due ? -1 : a.due > b.due ? 1 : 0) * dir;
      } else {
        let ka: number | string;
        let kb: number | string;
        if (sort === "id") {
          ka = a.id;
          kb = b.id;
        } else if (sort === "created") {
          ka = a.createdAt;
          kb = b.createdAt;
        } else {
          ka = a.title.toLowerCase();
          kb = b.title.toLowerCase();
        }
        keyCmp = ka < kb ? -1 : ka > kb ? 1 : 0;
        keyCmp *= dir;
      }
      if (keyCmp !== 0) return keyCmp;
      // Ties are always broken by id ascending, whatever the order.
      return a.id - b.id;
    });

    return result;
  }
}
