export interface Transport {
  send(recipient: string, message: string): void;
}

/** Records every send in memory. Handy in tests and dry runs. */
export class MemoryTransport implements Transport {
  sent: Array<{ recipient: string; message: string }> = [];

  send(recipient: string, message: string): void {
    this.sent.push({ recipient, message });
  }
}

export class Notifier {
  private transport: Transport;

  constructor(transport: Transport) {
    this.transport = transport;
  }

  /**
   * Send `message` to `recipients`. A single recipient is trimmed before
   * sending, as before. An array sends to each recipient in the order given,
   * returning how many messages were actually sent. Recipients are trimmed and
   * de-duplicated case-insensitively, keeping the first spelling. Throws
   * TypeError if any recipient is empty or only whitespace — before anything
   * is sent, so a bad list never results in a partial send.
   */
  notify(recipients: string | readonly string[], message: string): number {
    const list = typeof recipients === "string" ? [recipients] : [...recipients];

    const trimmed = list.map((recipient) => recipient.trim());
    for (const to of trimmed) {
      if (to === "") {
        throw new TypeError("recipient must be a non-empty string");
      }
    }

    const seen = new Set<string>();
    for (const to of trimmed) {
      const key = to.toLowerCase();
      if (!seen.has(key)) {
        seen.add(key);
        this.transport.send(to, message);
      }
    }
    return seen.size;
  }
}
