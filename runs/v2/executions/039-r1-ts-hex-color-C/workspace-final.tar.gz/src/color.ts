function channel(value: number): string {
  if (!Number.isInteger(value) || value < 0 || value > 255) {
    throw new RangeError(`colour channel out of range: ${value}`);
  }
  return value.toString(16).padStart(2, "0");
}

/** Format RGB channels (0-255) as a lowercase "#rrggbb" string. */
export function rgbToHex(r: number, g: number, b: number): string {
  return `#${channel(r)}${channel(g)}${channel(b)}`;
}

/**
 * Normalize a user-supplied hex colour into the canonical lowercase "#rrggbb"
 * (or "#rrggbbaa") form. Accepts "#" plus exactly 3, 4, 6 or 8 hex digits in
 * any case, ignoring surrounding whitespace; 3/4-digit forms are expanded by
 * doubling each digit. Returns null for any non-hex or malformed input.
 */
export function normalizeHexColor(input: string): string | null {
  const trimmed = input.trim();
  const matched = /^#([0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.exec(trimmed);
  if (!matched) {
    return null;
  }
  const digits = matched[1];
  return `#${digits.length < 6 ? doubleDigits(digits) : digits}`.toLowerCase();
}

function doubleDigits(digits: string): string {
  let out = "";
  for (const d of digits) {
    out += d + d;
  }
  return out;
}
