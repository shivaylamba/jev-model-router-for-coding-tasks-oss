import { test } from "node:test";
import assert from "node:assert/strict";
import { normalizeHexColor, rgbToHex } from "../src/color.ts";

test("rgbToHex", () => {
  assert.equal(rgbToHex(255, 136, 0), "#ff8800");
  assert.throws(() => rgbToHex(256, 0, 0), RangeError);
});

test("normalizeHexColor", () => {
  assert.equal(normalizeHexColor("#FF8800"), "#ff8800");
  assert.equal(normalizeHexColor("#11223344"), "#11223344");
  assert.equal(normalizeHexColor("#AbC"), "#aabbcc");
  assert.equal(normalizeHexColor("#abcd"), "#aabbccdd");
  assert.equal(normalizeHexColor("#ff8800ff"), "#ff8800ff");
  assert.equal(normalizeHexColor("  #AABBCC  "), "#aabbcc");

  assert.equal(normalizeHexColor("ff8800"), null);
  assert.equal(normalizeHexColor("#"), null);
  assert.equal(normalizeHexColor("##aabbcc"), null);
  assert.equal(normalizeHexColor("#aabbccc"), null);
  assert.equal(normalizeHexColor("#12"), null);
  assert.equal(normalizeHexColor("#gg"), null);
  assert.equal(normalizeHexColor("#aa bb cc"), null);
  assert.equal(normalizeHexColor("red"), null);
  assert.equal(normalizeHexColor(""), null);
});
