"""GET /articles."""

from .errors import InvalidCursorError, ValidationError


def serialize(article):
    return {
        "id": article.id,
        "title": article.title,
        "author": article.author,
        "status": article.status,
        "published_at": article.published_at,
    }


def _int_param(params, name, default):
    raw = params.get(name)
    if raw is None:
        return default
    if not raw.isdigit():
        raise ValidationError(f"{name} must be a positive integer")
    return int(raw)


def _has_any(d, *keys):
    return any(k in d for k in keys)


class ArticlesApi:
    def __init__(self, service):
        self._service = service

    def handle_list(self, params):
        """`params` maps query-string names to string values. Returns (status, body)."""
        legacy = _has_any(params, "page", "per_page")
        modern = _has_any(params, "cursor", "limit")
        if legacy and modern:
            return 400, {"error": "Cannot mix page/per_page with cursor/limit"}

        if legacy:
            try:
                result = self._service.list_page(
                    page=_int_param(params, "page", 1),
                    per_page=_int_param(params, "per_page", 20),
                    author=params.get("author"),
                    status=params.get("status"),
                )
            except ValidationError as err:
                return 400, {"error": str(err)}
            body = dict(result)
            body["items"] = [serialize(a) for a in result["items"]]
            return 200, body

        # cursor mode (default)
        limit_raw = params.get("limit")
        author = params.get("author")
        status = params.get("status") or None  # empty string treated as None
        cursor = params.get("cursor") or None  # empty string treated as None
        if limit_raw is None:
            limit = 20
        elif not limit_raw.isdigit():
            return 400, {"error": "limit must be a positive integer"}
        else:
            limit = int(limit_raw)
        try:
            page = self._service.list_articles(
                limit=limit,
                cursor=cursor,
                author=author or None,
                status=status,
            )
        except (ValidationError, InvalidCursorError) as err:
            return 400, {"error": str(err)}
        return 200, {
            "items": [serialize(a) for a in page.items],
            "next_cursor": page.next_cursor,
        }
