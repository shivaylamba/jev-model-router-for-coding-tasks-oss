"""Queries against the article store."""


class ArticleRepository:
    def __init__(self, store):
        self._store = store

    @staticmethod
    def _sort_key(a):
        return (a.published_at, a.id)

    def _filtered(self, author=None, status=None):
        rows = self._store.scan()
        if author is not None:
            rows = [a for a in rows if a.author == author]
        if status is not None:
            rows = [a for a in rows if a.status == status]
        return rows

    def count(self, author=None, status=None):
        return len(self._filtered(author, status))

    def list_offset(self, offset, limit, author=None, status=None):
        """Newest first (published_at desc, then id desc)."""
        rows = sorted(self._filtered(author, status), key=self._sort_key, reverse=True)
        return rows[offset:offset + limit]

    def list_cursor(self, limit, after_published_at, after_id, author=None, status=None):
        """Articles strictly after the given position, newest first.

        Returns a list of at most `limit` articles.
        """
        rows = self._filtered(author, status)
        if after_published_at is not None and after_id is not None:
            rows = [
                a for a in rows
                if (a.published_at, a.id) < (after_published_at, after_id)
            ]
        rows = sorted(rows, key=self._sort_key, reverse=True)
        return rows[:limit]
