"""Listing rules for articles."""

import base64
import json
import warnings
from dataclasses import dataclass

from .errors import InvalidCursorError, ValidationError
from .store import STATUSES

MAX_PER_PAGE = 100


@dataclass
class Page:
    items: list
    next_cursor: str | None


class ArticleService:
    def __init__(self, repository):
        self._repo = repository

    def _check_filters(self, author, status):
        if status is not None and status not in STATUSES:
            raise ValidationError(f"status must be one of {', '.join(STATUSES)}")

    def _encode_cursor(self, author, status, item):
        payload = {"author": author, "status": status, "p": item.published_at, "i": item.id}
        raw = base64.urlsafe_b64encode(json.dumps(payload, separators=(",", ":")).encode()).decode()
        # strip padding to keep cursors ASCII alphanumeric + "-" and "_" only
        return raw.rstrip("=")

    def _decode_cursor(self, author, status, cursor):
        # restore padding
        padded = cursor + "=" * ((4 - len(cursor) % 4) % 4)
        try:
            raw = base64.urlsafe_b64decode(padded)
            payload = json.loads(raw)
        except Exception:
            raise InvalidCursorError("Invalid cursor")
        if payload.get("author") != author or payload.get("status") != status:
            raise InvalidCursorError("Cursor was created with different filters")
        return payload["p"], payload["i"]

    def list_articles(self, limit=20, cursor=None, author=None, status=None):
        """One page of articles, newest first (published_at desc, then id desc).

        Returns a `Page` with `items` and `next_cursor`.
        """
        if not isinstance(limit, int) or isinstance(limit, bool) or not 1 <= limit <= MAX_PER_PAGE:
            raise ValidationError(f"limit must be an integer from 1 to {MAX_PER_PAGE}")
        self._check_filters(author, status)

        after_published_at = None
        after_id = None
        if cursor is not None:
            if not isinstance(cursor, str):
                raise InvalidCursorError("Invalid cursor")
            after_published_at, after_id = self._decode_cursor(author, status, cursor)

        items = self._repo.list_cursor(limit + 1, after_published_at, after_id, author, status)
        if len(items) > limit:
            next_cursor = self._encode_cursor(author, status, items[limit - 1])
            items = items[:limit]
        else:
            next_cursor = None
        return Page(items=items, next_cursor=next_cursor)

    def list_page(self, page=1, per_page=20, author=None, status=None):
        """One page of articles, newest first.

        Returns {"items": [Article, ...], "page": page, "per_page": per_page, "total": total}
        where total counts every article matching the filters.
        """
        warnings.warn(
            "list_page is deprecated; use list_articles instead",
            DeprecationWarning,
            stacklevel=2,
        )
        if not isinstance(page, int) or page < 1:
            raise ValidationError("page must be an integer >= 1")
        if not isinstance(per_page, int) or not 1 <= per_page <= MAX_PER_PAGE:
            raise ValidationError(f"per_page must be an integer from 1 to {MAX_PER_PAGE}")
        self._check_filters(author, status)
        items = self._repo.list_offset((page - 1) * per_page, per_page, author, status)
        return {"items": items, "page": page, "per_page": per_page, "total": self._repo.count(author, status)}
