"""Shared field validators."""

import re

from .errors import ValidationError

_USERNAME_RE = re.compile(r"[A-Za-z][A-Za-z0-9_]*")
RESERVED_USERNAMES = {"admin", "root", "support", "system"}


def validate_email(value):
    email = value.strip().lower()
    if email.count("@") != 1:
        raise ValidationError("email", "must contain exactly one @")
    local, _, domain = email.partition("@")
    if local == "" or domain == "":
        raise ValidationError("email", "missing local part or domain")
    if any(ch.isspace() for ch in email):
        raise ValidationError("email", "must not contain spaces")
    parts = domain.split(".")
    if len(parts) < 2 or any(part == "" for part in parts):
        raise ValidationError("email", "invalid domain")
    return email


def validate_username(value):
    username = value.strip()
    if len(username) < 3 or len(username) > 20:
        raise ValidationError("username", "must be 3 to 20 characters")
    if not _USERNAME_RE.fullmatch(username):
        raise ValidationError("username", "letters, digits and _ only, starting with a letter")
    username = username.lower()
    if username in RESERVED_USERNAMES:
        raise ValidationError("username", "is reserved")
    return username


def validate_phone(value):
    digits = value.strip()
    prefix = ""
    if digits[0:1] == "+":
        prefix, digits = "+", digits[1:]
    digits = "".join(ch for ch in digits if ch not in " -.()")
    if not (digits.isascii() and digits.isdigit()):
        raise ValidationError("phone", "digits only")
    if len(digits) < 7 or len(digits) > 15:
        raise ValidationError("phone", "must have 7 to 15 digits")
    return prefix + digits


def validate_display_name(value):
    name = " ".join(value.split())
    if not name:
        raise ValidationError("display_name", "is required")
    if len(name) > 50:
        raise ValidationError("display_name", "must be at most 50 characters")
    if any(not ch.isprintable() for ch in name):
        raise ValidationError("display_name", "contains control characters")
    return name
