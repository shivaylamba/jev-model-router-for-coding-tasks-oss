"""New account registration."""

from .errors import ValidationError
from .validators import (
    validate_email,
    validate_phone,
    validate_username,
)


def register(form):
    """Validate a sign-up form (a dict of strings) and return the normalised account.

    Required keys: username, email, password. Optional: phone.
    """
    for key in ("username", "email", "password"):
        if not form.get(key, "").strip():
            raise ValidationError(key, "is required")
    if len(form["password"]) < 10:
        raise ValidationError("password", "must be at least 10 characters")
    account = {
        "username": validate_username(form["username"]),
        "email": validate_email(form["email"]),
        "phone": None,
    }
    if form.get("phone", "").strip():
        account["phone"] = validate_phone(form["phone"])
    return account
