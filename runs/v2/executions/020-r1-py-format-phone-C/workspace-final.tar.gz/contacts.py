"""Formatting helpers for contact records."""


def format_name(first, last):
    """'ada', 'LOVELACE' -> 'Ada Lovelace'. Blank parts are skipped."""
    parts = [p.strip().capitalize() for p in (first, last) if p and p.strip()]
    return " ".join(parts)


def normalize_email(email):
    """Trim and lowercase an e-mail address."""
    return email.strip().lower()


_IGNORED = set("()-.+ ")


def format_us_phone(raw):
    """Format a US phone number as '(415) 555-0123'.

    Spaces, parentheses, hyphens, dots and '+' are ignored; any other
    non-digit character raises ValueError. Exactly 10 digits are required,
    or 11 where the first is the country code '1' (which is dropped). The
    area code and exchange may not start with 0 or 1.
    """
    chars = []
    for c in raw:
        if c in _IGNORED:
            continue
        if c.isdigit():
            chars.append(c)
        else:
            raise ValueError(f"invalid character {c!r} in US phone number: {raw!r}")
    digits = "".join(chars)
    if len(digits) == 11 and digits[0] == "1":
        digits = digits[1:]
    if len(digits) != 10:
        raise ValueError(f"invalid US phone number: {raw!r}")
    area, exchange, rest = digits[:3], digits[3:6], digits[6:]
    if area[0] in "01" or exchange[0] in "01":
        raise ValueError(f"invalid US phone number: {raw!r}")
    return f"({area}) {exchange}-{rest}"
