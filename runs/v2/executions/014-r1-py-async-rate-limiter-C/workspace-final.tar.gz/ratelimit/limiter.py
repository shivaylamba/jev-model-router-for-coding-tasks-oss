"""Asyncio rate limiter: per-key token buckets plus a global concurrency cap.

See SPEC.md for the full behaviour.
"""

import asyncio
from collections import deque
from contextlib import asynccontextmanager

from .bucket import TokenBucket


class _Request:
    """One acquire() call waiting in a key's queue.

    `future` is the handle a grant pass uses to wake the request's task.
    """

    def __init__(self, key, sequence):
        self.key = key
        self.sequence = sequence
        self.future = None
        self.granted = False


class RateLimiter:
    def __init__(self, rate, burst, max_concurrent, *, clock, sleep):
        if not isinstance(burst, int) or burst < 1:
            raise ValueError("burst must be an int >= 1")
        if not isinstance(max_concurrent, int) or max_concurrent < 1:
            raise ValueError("max_concurrent must be an int >= 1")
        if rate <= 0:
            raise ValueError("rate must be positive")
        self._rate = rate
        self._burst = burst
        self._max_concurrent = max_concurrent
        self._clock = clock
        self._sleep = sleep
        self._buckets = {}      # key -> TokenBucket, created full
        self._queues = {}       # key -> deque of ungranted requests, ordered
        self._sequence = 0      # global arrival order of acquire() calls
        self._in_use = 0        # slots currently held

    async def acquire(self, key):
        """Wait until a request for `key` is granted (one token and one slot)."""
        self._sequence += 1
        request = _Request(key, self._sequence)
        self._queues.setdefault(key, deque()).append(request)
        try:
            self._grant_pass()
            while not request.granted:
                # Futures wait only for a slot (no sleep): they are granted by
                # the grant pass of a later release or cancellation.
                request.future = asyncio.get_running_loop().create_future()
                head = self._queues[key][0]
                if head is request and self._eligible(key):
                    self._grant(request)
                    continue
                if head is request:
                    delay = self._bucket(key).time_until_available()
                    if delay > 0:
                        request.future = self._start_token_wait(key)
                await request.future
            return
        except asyncio.CancelledError:
            self._undo_if_granted(request)
            self._remove(request)
            self._grant_pass()
            raise
        finally:
            request.future = None

    def release(self):
        """Free one slot and run a grant pass before returning."""
        if self._in_use <= 0:
            raise RuntimeError("release() with no slot held")
        self._in_use -= 1
        self._grant_pass()

    def limit(self, key):
        """Async context manager: acquire on entry, release on exit."""
        @asynccontextmanager
        async def _manager():
            await self.acquire(key)
            try:
                yield self
            finally:
                self.release()

        return _manager()

    @property
    def in_use(self):
        return self._in_use

    def tokens(self, key):
        bucket = self._buckets.get(key)
        return float(self._burst) if bucket is None else bucket.available()

    def waiting(self, key=None):
        if key is not None:
            return len(self._queues.get(key, ()))
        return sum(len(queue) for queue in self._queues.values())

    # -- internals ---------------------------------------------------------

    def _bucket(self, key):
        bucket = self._buckets.get(key)
        if bucket is None:
            bucket = TokenBucket(self._rate, self._burst, self._clock)
            self._buckets[key] = bucket
        return bucket

    def _grant_pass(self):
        """Grant the eligible head whose acquire call came first, repeatedly."""
        heads = []
        for key, queue in self._queues.items():
            if queue:
                heads.append((queue[0].sequence, key))
        for _, key in sorted(heads):
            queue = self._queues[key]
            if queue and self._eligible(key):
                self._grant(queue[0])

    def _grant(self, request):
        self._bucket(request.key).try_take()
        self._in_use += 1
        request.granted = True
        queue = self._queues[request.key]
        queue.popleft()
        if not queue:
            del self._queues[request.key]
        else:
            # The new head must re-evaluate immediately: it may now start
            # waiting for a token ("a request that becomes the head ... starts
            # this wait right away").
            self._wake(queue[0])
        self._wake(request)

    @staticmethod
    def _wake(request):
        if request.future is not None and not request.future.done():
            request.future.set_result(None)

    def _eligible(self, key):
        return (
            self._in_use < self._max_concurrent
            and self._bucket(key).available() >= 1
        )

    def _start_token_wait(self, key):
        """The head of `key` waits exactly the time until its next token.

        The wait re-converges without polling when the sleep ends early: the
        grant pass ends it if the request got away otherwise, and if the clock
        has not advanced far enough acquire() sleeps again for the remaining
        time.
        """
        future = asyncio.get_running_loop().create_future()

        async def wait():
            try:
                await self._sleep(self._bucket(key).time_until_available())
                self._grant_pass()
            finally:
                if not future.done():
                    future.set_result(None)

        task = asyncio.get_running_loop().create_task(wait())
        future.add_done_callback(lambda _: task.cancel())
        return future

    def _undo_if_granted(self, request):
        if request.granted:
            self._in_use -= 1
            self._buckets[request.key]._refill()
            self._buckets[request.key]._tokens = min(
                float(self._burst), self._buckets[request.key]._tokens + 1
            )

    def _remove(self, request):
        queue = self._queues.get(request.key)
        if queue is None:
            return
        if request not in queue:
            return
        was_head = queue[0] is request
        queue.remove(request)
        if not queue:
            del self._queues[request.key]
        elif was_head:
            # The next request becomes the head and starts waiting for a
            # token if needed; wake it so it re-evaluates right away.
            self._wake(queue[0])
