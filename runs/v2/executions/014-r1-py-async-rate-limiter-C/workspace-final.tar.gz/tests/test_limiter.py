"""Async tests for ratelimit.RateLimiter, driven with FakeTime."""

import asyncio
import unittest

from ratelimit import RateLimiter
from tests.fake_time import FakeTime, settle


class RateLimiterTest(unittest.IsolatedAsyncioTestCase):
    def make(self, rate=2.0, burst=3, max_concurrent=10):
        ft = FakeTime()
        limiter = RateLimiter(
            rate, burst, max_concurrent, clock=ft.clock, sleep=ft.sleep
        )
        return ft, limiter

    # -- construction -------------------------------------------------------

    def test_bad_arguments_raise_value_error(self):
        ft, _ = self.make()
        for rate, burst, maxc in (
            (0, 3, 2), (-1, 3, 2), (2, 0, 2), (2, -1, 2),
            (2, 1.5, 2), (2, 3, 0), (2, 3, -2), (2, 3, 1.5),
        ):
            with self.assertRaises(ValueError):
                RateLimiter(rate, burst, maxc, clock=ft.clock, sleep=ft.sleep)

    def test_release_without_hold_raises(self):
        _, limiter = self.make()
        with self.assertRaises(RuntimeError):
            limiter.release()

    async def test_immediate_acquire_no_sleep(self):
        ft, limiter = self.make()
        await limiter.acquire("a")
        self.assertEqual(ft.sleep_calls, [])
        self.assertEqual(limiter.in_use, 1)
        self.assertEqual(limiter.tokens("a"), 2.0)

    async def test_limit_context_manager_releases_on_error(self):
        _, limiter = self.make()
        with self.assertRaises(ValueError):
            async with limiter.limit("a"):
                self.assertEqual(limiter.in_use, 1)
                raise ValueError("boom")
        self.assertEqual(limiter.in_use, 0)

    # -- token waiting ------------------------------------------------------

    async def test_waits_exact_time_until_token(self):
        ft, limiter = self.make(rate=2.0)
        # empty the bucket immediately
        for _ in range(3):
            await limiter.acquire("a")
        self.assertEqual(ft.sleep_calls, [])
        waiter = asyncio.ensure_future(limiter.acquire("a"))
        await settle()
        self.assertEqual(limiter.waiting("a"), 1)
        self.assertEqual(ft.sleep_calls, [0.5])
        await ft.advance(0.5)
        await waiter
        self.assertEqual(limiter.in_use, 4)

    async def test_resleeps_remaining_when_clock_short(self):
        ft, limiter = self.make(rate=2.0)
        for _ in range(3):
            await limiter.acquire("a")
        waiter = asyncio.ensure_future(limiter.acquire("a"))
        await settle()
        self.assertEqual(ft.sleep_calls, [0.5])
        # FakeTime.sleep returns only at its deadline, so to simulate a spurious
        # early return we complete the sleeper without advancing the clock.
        for deadline, future in list(ft._sleepers):
            if not future.done():
                future.set_result(None)
        await settle()
        # clock at 0.0: bucket still empty -> re-sleep the full 0.5
        self.assertEqual(ft.sleep_calls, [0.5, 0.5])
        self.assertFalse(waiter.done())
        await ft.advance(0.5)
        await waiter

    # -- FIFO per key -------------------------------------------------------

    async def test_fifo_within_a_key(self):
        ft, limiter = self.make(rate=1.0, burst=1, max_concurrent=3)
        order = []

        async def grab(tag):
            await limiter.acquire("a")
            order.append(tag)

        await limiter.acquire("a")  # uses the single token, t=0
        first = asyncio.ensure_future(grab("first"))
        await settle()
        second = asyncio.ensure_future(grab("second"))
        await settle()
        self.assertEqual(order, [])
        self.assertEqual(ft.sleep_calls, [1.0])
        await ft.advance(1.0)
        self.assertEqual(order, ["first"])
        await ft.advance(1.0)
        self.assertEqual(order, ["first", "second"])
        first.result()
        second.result()

    # -- slot cap and grant pass across keys --------------------------------

    async def test_out_of_token_key_does_not_block_other_keys(self):
        ft, limiter = self.make(rate=1.0, burst=2, max_concurrent=2)
        await limiter.acquire("a")
        await limiter.acquire("a")      # in_use=2, a's bucket empty
        blocked = asyncio.ensure_future(limiter.acquire("a"))
        await settle()                  # a is head: no token, no slot -> sleeps 1.0
        lucky = asyncio.ensure_future(limiter.acquire("b"))  # b has tokens
        await settle()
        self.assertEqual(ft.sleep_calls, [1.0])  # b never sleeps on a slot wait
        limiter.release()               # grant pass: a (no token) skipped; b granted
        await settle()
        self.assertTrue(lucky.done())
        self.assertFalse(blocked.done())
        self.assertEqual(limiter.in_use, 2)
        # let the blocked head through now that a has a token and a slot exists
        limiter.release()
        await ft.advance(1.0)
        await blocked

    async def test_earliest_eligible_caller_wins_slot(self):
        ft, limiter = self.make(rate=100.0, burst=5, max_concurrent=2)
        await limiter.acquire("x")
        await limiter.acquire("y")      # in_use=2, both have tokens left
        first = asyncio.ensure_future(limiter.acquire("c"))
        await settle()
        second = asyncio.ensure_future(limiter.acquire("d"))
        await settle()
        limiter.release()               # one slot: goes to c (earliest caller)
        await settle()
        self.assertTrue(first.done())
        self.assertFalse(second.done())
        limiter.release()               # now d
        await settle()
        self.assertTrue(second.done())
        self.assertEqual(limiter.in_use, 2)

    async def test_release_runs_grant_pass_so_in_use_does_not_drop(self):
        ft, limiter = self.make(rate=1000, burst=10, max_concurrent=1)
        await limiter.acquire("a")
        waiter = asyncio.ensure_future(limiter.acquire("b"))
        await settle()
        self.assertEqual(limiter.waiting(), 1)
        self.assertEqual(ft.sleep_calls, [])  # slot-only wait: no sleep
        limiter.release()
        await settle()
        self.assertEqual(limiter.in_use, 1)
        await waiter

    # -- cancellation -------------------------------------------------------

    async def test_cancel_ungranted_leaves_no_trace(self):
        ft, limiter = self.make(rate=1, burst=1, max_concurrent=2)
        await limiter.acquire("a")
        task = asyncio.ensure_future(limiter.acquire("a"))
        await settle()
        self.assertEqual(limiter.waiting("a"), 1)
        task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await task
        await settle()
        self.assertEqual(limiter.waiting(), 0)
        self.assertEqual(limiter.tokens("a"), 0.0)  # consumed nothing
        # token conservation: the next acquire still waits the full 1.0s
        again = asyncio.ensure_future(limiter.acquire("a"))
        await settle()
        self.assertEqual(ft.sleep_calls[-1], 1.0)
        again.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await again

    async def test_cancel_granted_undoes_slot_and_token(self):
        ft, limiter = self.make(rate=1000, burst=2, max_concurrent=1)
        await limiter.acquire("a")          # holds the only slot; in_use=1
        wait = asyncio.ensure_future(limiter.acquire("b"))
        await settle()
        self.assertEqual(limiter.waiting("b"), 1)
        limiter.release()                   # grant pass grants b synchronously
        wait.cancel()                       # b not yet resumed -> grant undone
        with self.assertRaises(asyncio.CancelledError):
            await wait
        await settle()
        self.assertEqual(limiter.in_use, 0)
        self.assertEqual(limiter.tokens("b"), 2.0)  # token returned to bucket

    async def test_cancel_head_promotes_next(self):
        ft, limiter = self.make(rate=1, burst=1, max_concurrent=1)
        await limiter.acquire("a")
        head = asyncio.ensure_future(limiter.acquire("a"))
        await settle()
        nxt = asyncio.ensure_future(limiter.acquire("a"))
        await settle()
        self.assertEqual(limiter.waiting("a"), 2)
        head.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await head
        await settle()
        self.assertEqual(limiter.waiting("a"), 1)
        # the promoted head starts its own token wait
        self.assertEqual(ft.sleep_calls[-1], 1.0)
        await ft.advance(1.0)
        # token is back but the sole slot is still held -> waits for a slot
        limiter.release()
        await settle()
        await nxt

    # -- introspection ------------------------------------------------------

    def test_tokens_fresh_key_is_burst(self):
        _, limiter = self.make(burst=4)
        self.assertEqual(limiter.tokens("zzz"), 4.0)

    async def test_waiting_key_and_total(self):
        ft, limiter = self.make(rate=0.5, burst=1, max_concurrent=5)
        await limiter.acquire("a")
        await limiter.acquire("b")          # both buckets now empty
        for key in ("a", "a", "b"):
            asyncio.ensure_future(limiter.acquire(key))
        await settle()
        self.assertEqual(limiter.waiting("a"), 2)
        self.assertEqual(limiter.waiting("b"), 1)
        self.assertEqual(limiter.waiting(), 3)


if __name__ == "__main__":
    unittest.main()