/**
 * Upper-case the first character.
 * @param {string} s
 */
export function capitalize(s) {
  return s.length === 0 ? s : s[0].toUpperCase() + s.slice(1);
}

/**
 * Shorten to at most `max` characters, ending with "…" when cut.
 * @param {string} s
 * @param {number} max
 */
export function truncate(s, max) {
  return s.length <= max ? s : s.slice(0, Math.max(0, max - 1)) + "…";
}

/**
 * Format a count with the correct plural form of its noun.
 * @param {number} count
 * @param {string} singular
 * @param {string} [plural]
 */
export function pluralize(count, singular, plural) {
  if (typeof count !== "number" || !Number.isFinite(count)) {
    throw new TypeError("count must be a finite number");
  }
  if (count === 1) {
    return String(count) + " " + singular;
  }
  if (plural !== undefined) {
    return String(count) + " " + plural;
  }
  return String(count) + " " + pluralOf(singular);
}

function pluralOf(singular) {
  if (/(s|x|z|ch|sh)$/.test(singular)) {
    return singular + "es";
  }
  if (/([bcdfghjklmnpqrstvwxyz])y$/.test(singular)) {
    return singular.slice(0, -1) + "ies";
  }
  return singular + "s";
}
