"""Helpers for taking the top or bottom of a ranking."""


def top_n(items, n, key=None, *, reverse=False):
    """Return the top ``n`` items from ``items``.

    ``items`` is any iterable. With ``reverse=False`` (the default) the
    ``n`` largest items are returned, largest first; with ``reverse=True``
    the ``n`` smallest items are returned, smallest first.

    ``key`` behaves like :func:`sorted`'s ``key``: it is a callable taking
    one item and returning a value used only for comparison.

    The sort is stable: items that compare equal keep their original
    relative order, in both directions.

    ``n`` larger than the number of items returns all of them, and ``n == 0``
    returns ``[]``. ``n`` must be non-negative; a negative ``n`` raises
    :exc:`ValueError`.

    ``items`` is never modified.

    ``reverse`` is keyword-only and must be passed by name.
    """
    if n < 0:
        raise ValueError("n must be non-negative")
    return sorted(items, key=key, reverse=not reverse)[:n]