"""Helpers for working with latency measurements."""

from ranking import top_n


def fastest(items, n):
    """Return the ``n`` fastest items from ``items``, fastest first.

    "Fastest" here means smallest value. ``items`` is any iterable of
    comparable values. ``n`` larger than the number of items returns all of
    them; ties keep their original relative order. ``items`` is never
    modified.
    """
    return top_n(items, n, reverse=True)