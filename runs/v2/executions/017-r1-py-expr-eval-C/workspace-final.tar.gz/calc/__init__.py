"""Formula engine for computed columns. See SPEC.md."""

from calc.errors import ExprError
from calc.evaluator import evaluate as _eval_ast
from calc.parser import Parser
from calc.tokenizer import Tokenizer

__all__ = ["ExprError", "evaluate"]


def evaluate(expr, variables=None):
    """Evaluate the formula `expr` and return a float (see SPEC.md).

    `variables` maps names to int or float values. Raises ExprError, with a
    `position`, for any syntax or evaluation error.
    """
    variables = variables or {}
    tokenizer = Tokenizer(expr)
    tokens = tokenizer.tokenize()
    parser = Parser(tokens)
    ast = parser.parse()
    return _eval_ast(ast, variables)
