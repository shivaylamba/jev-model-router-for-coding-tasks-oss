"""Recursive-descent parser for formula expressions."""

from calc.errors import ExprError


class ASTNode:
    pass


class NumberNode(ASTNode):
    def __init__(self, value: str, pos: int):
        self.value = float(value)
        self.pos = pos


class NameNode(ASTNode):
    def __init__(self, name: str, pos: int):
        self.name = name
        self.pos = pos


class BinaryOpNode(ASTNode):
    def __init__(self, op: str, pos: int, left: ASTNode, right: ASTNode):
        self.op = op
        self.pos = pos
        self.left = left
        self.right = right


class UnaryOpNode(ASTNode):
    def __init__(self, op: str, pos: int, operand: ASTNode):
        self.op = op
        self.pos = pos
        self.operand = operand


class CallNode(ASTNode):
    def __init__(self, name: str, name_pos: int, args: list):
        self.name = name
        self.name_pos = name_pos
        self.args = args


class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0
        self.current = tokens[0]

    def _advance(self):
        self.pos += 1
        self.current = self.tokens[self.pos]

    def parse(self):
        result = self._expr()
        if self.current.kind != 'EOF':
            self._unexpected(self.current)
        return result

    def _expect(self, kind, message=None):
        if self.current.kind != kind:
            self._unexpected(self.current, message)
        tok = self.current
        self._advance()
        return tok

    def _unexpected(self, token, message=None):
        if message is None:
            if token.kind == 'EOF':
                message = "expected an operand, found end of input"
            elif token.kind in ('PLUS', 'MINUS', 'STAR', 'SLASH', 'PERCENT', 'CARET'):
                message = f"expected an operand, found '{token.value}'"
            elif token.kind == 'RPAREN':
                message = "unexpected ')'"
            elif token.kind == 'COMMA':
                message = "a comma outside a call"
            elif token.kind in ('NUMBER', 'NAME', 'LPAREN') and self.pos > 0:
                # reach here only after a complete operand was parsed
                message = "two operands in a row"
            else:
                message = f"unexpected character '{token.value}'"
        raise ExprError(message, token.pos)

    def _expr(self):
        """Addition and subtraction (lowest precedence)."""
        left = self._term()
        while self.current.kind in ('PLUS', 'MINUS'):
            op = self.current.value
            pos = self.current.pos
            self._advance()
            right = self._term()
            left = BinaryOpNode(op, pos, left, right)
        return left

    def _term(self):
        """Multiplication, division, modulo."""
        left = self._unary()
        while self.current.kind in ('STAR', 'SLASH', 'PERCENT'):
            op = self.current.value
            pos = self.current.pos
            self._advance()
            right = self._unary()
            left = BinaryOpNode(op, pos, left, right)
        return left

    def _unary(self):
        """Unary + and - (prefix, may repeat)."""
        if self.current.kind in ('PLUS', 'MINUS'):
            op = self.current.value
            pos = self.current.pos
            self._advance()
            operand = self._unary()
            return UnaryOpNode(op, pos, operand)
        return self._power()

    def _power(self):
        """Power: right-associative, binds tighter than unary."""
        left = self._primary()
        if self.current.kind == 'CARET':
            pos = self.current.pos
            self._advance()
            right = self._unary()  # right side can have unary ops
            left = BinaryOpNode('^', pos, left, right)
        return left

    def _primary(self):
        """Numbers, names, function calls, parenthesized expressions."""
        if self.current.kind == 'NUMBER':
            node = NumberNode(self.current.value, self.current.pos)
            self._advance()
            return node

        if self.current.kind == 'NAME':
            name = self.current.value
            name_pos = self.current.pos
            self._advance()
            # Check for function call: name followed by LPAREN (whitespace allowed)
            if self.current.kind == 'LPAREN':
                self._advance()  # consume (
                args = self._arg_list()
                self._expect('RPAREN', "expected ')', found end of input")
                return CallNode(name, name_pos, args)
            else:
                return NameNode(name, name_pos)

        if self.current.kind == 'LPAREN':
            self._advance()  # consume (
            inner = self._expr()
            self._expect('RPAREN', "expected ')', found end of input")
            return inner

        # Anything else is an unexpected token where we need an operand
        self._unexpected(self.current)

    def _arg_list(self):
        """Parse arguments inside parentheses: zero or more comma-separated."""
        args = []
        if self.current.kind == 'RPAREN':
            return args
        while True:
            args.append(self._expr())
            if self.current.kind == 'COMMA':
                self._advance()  # consume ,
                # After a comma, we expect either another argument or RPAREN
                if self.current.kind == 'RPAREN':
                    # Trailing comma: expected an operand, found ')'
                    self._unexpected(self.current, "expected an operand, found ')'")
                continue
            break
        return args
