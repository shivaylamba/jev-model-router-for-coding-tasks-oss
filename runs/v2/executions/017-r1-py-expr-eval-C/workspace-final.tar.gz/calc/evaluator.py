"""Evaluator for parsed formula ASTs."""

import math

from calc.errors import ExprError
from calc.functions import CONSTANTS, FUNCTIONS, arity_ok
from calc.parser import (
    ASTNode,
    BinaryOpNode,
    CallNode,
    NameNode,
    NumberNode,
    UnaryOpNode,
)


def evaluate(node: ASTNode, variables: dict) -> float:
    """Evaluate an AST node and return a float."""
    if isinstance(node, NumberNode):
        return node.value

    if isinstance(node, NameNode):
        # Names are looked up: variables first, then constants
        if node.name in variables:
            val = variables[node.name]
            return float(val)
        if node.name in CONSTANTS:
            return float(CONSTANTS[node.name])
        raise ExprError(f"unknown name '{node.name}'", node.pos)

    if isinstance(node, UnaryOpNode):
        val = evaluate(node.operand, variables)
        if node.op == '+':
            return val
        elif node.op == '-':
            return -val

    if isinstance(node, BinaryOpNode):
        left = evaluate(node.left, variables)
        right = evaluate(node.right, variables)

        if node.op == '+':
            return left + right
        elif node.op == '-':
            return left - right
        elif node.op == '*':
            return left * right
        elif node.op == '/':
            if right == 0:
                raise ExprError("division by zero", node.pos)
            return left / right
        elif node.op == '%':
            if right == 0:
                raise ExprError("modulo by zero", node.pos)
            # Python's % already handles negative correctly for floored modulo
            return left % right
        elif node.op == '^':
            try:
                result = math.pow(left, right)
            except (ValueError, OverflowError):
                raise ExprError("bad power", node.pos)
            if not math.isfinite(result):
                raise ExprError("bad power", node.pos)
            return result

    if isinstance(node, CallNode):
        # Unknown function
        if node.name not in FUNCTIONS:
            raise ExprError(f"unknown function '{node.name}'", node.name_pos)

        # Check arity before evaluating arguments
        arg_count = len(node.args)
        if not arity_ok(node.name, arg_count):
            raise ExprError(
                f"wrong number of arguments for '{node.name}'", node.name_pos
            )

        # Evaluate arguments left to right
        evaluated_args = []
        for arg in node.args:
            evaluated_args.append(evaluate(arg, variables))

        # Call the function
        _, _, func = FUNCTIONS[node.name]
        try:
            result = func(*evaluated_args)
        except Exception:
            raise ExprError(f"error in function '{node.name}'", node.name_pos)

        return float(result)

    raise ExprError("unknown node type", 0)
