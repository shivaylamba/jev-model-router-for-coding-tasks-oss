"""Tokenizer for formula expressions."""

from dataclasses import dataclass

from calc.errors import ExprError


@dataclass(frozen=True)
class Token:
    kind: str
    value: str
    pos: int


class Tokenizer:
    def __init__(self, text):
        self.text = text
        self.pos = 0
        self.length = len(text)

    def tokenize(self):
        tokens = []
        while self.pos < self.length:
            ch = self.text[self.pos]

            if ch in ' \t':
                self.pos += 1
                continue

            # Number
            if ch.isdigit() or ch == '.':
                start = self.pos
                # Check for number
                match = self._match_number()
                if match:
                    tokens.append(Token('NUMBER', match, start))
                    continue
                # If it started with '.' and didn't match, it's just a '.'
                if ch == '.':
                    raise ExprError(f"unexpected character '{ch}'", self.pos)

            # Name
            if ch.isalpha() or ch == '_':
                start = self.pos
                while self.pos < self.length and (self.text[self.pos].isalnum() or self.text[self.pos] == '_'):
                    self.pos += 1
                tokens.append(Token('NAME', self.text[start:self.pos], start))
                continue

            # Operators and punctuation
            if ch in '+-*/%^(),':
                kind_map = {'+': 'PLUS', '-': 'MINUS', '*': 'STAR', '/': 'SLASH',
                            '%': 'PERCENT', '^': 'CARET', '(': 'LPAREN', ')': 'RPAREN', ',': 'COMMA'}
                tokens.append(Token(kind_map[ch], ch, self.pos))
                self.pos += 1
                continue

            raise ExprError(f"unexpected character '{ch}'", self.pos)

        # End of input token
        tokens.append(Token('EOF', '', self.pos))
        return tokens

    def _match_number(self):
        """Try to match a number at current position. Return string or None."""
        start = self.pos
        text = self.text

        # Integer part
        if self.pos < self.length and text[self.pos].isdigit():
            while self.pos < self.length and text[self.pos].isdigit():
                self.pos += 1

        # Fractional part
        if self.pos < self.length and text[self.pos] == '.':
            next_pos = self.pos + 1
            if next_pos < self.length and text[next_pos].isdigit():
                self.pos = next_pos
                while self.pos < self.length and text[self.pos].isdigit():
                    self.pos += 1

        # Exponent part
        if self.pos < self.length and text[self.pos] in 'eE':
            exp_start = self.pos
            next_pos = self.pos + 1
            if next_pos < self.length and text[next_pos] in '+-':
                next_pos += 1
            if next_pos < self.length and text[next_pos].isdigit():
                self.pos = next_pos
                while self.pos < self.length and text[self.pos].isdigit():
                    self.pos += 1
            else:
                # No digits after e/E, don't include it in the number
                self.pos = exp_start

        if self.pos == start:
            return None
        return text[start:self.pos]
