"""Tests for calc.evaluate against the SPEC.md contract."""

import unittest

from calc import ExprError, evaluate


def expect_error(expr, position, variables=None):
    """Assert evaluate(expr) raises ExprError at exactly `position`."""
    try:
        evaluate(expr, vars if False else variables)
    except ExprError as e:
        assert e.position == position, (
            f"{expr!r}: expected position {position}, got {e.position}"
        )
        return
    raise AssertionError(f"expected ExprError for {expr!r}")


class ArithmeticTest(unittest.TestCase):
    def test_basic_operators(self):
        self.assertEqual(evaluate("2+3"), 5.0)
        self.assertEqual(evaluate("6-2"), 4.0)
        self.assertEqual(evaluate("2*3"), 6.0)
        self.assertEqual(evaluate("6/2"), 3.0)
        self.assertEqual(evaluate("10%3"), 1.0)
        self.assertEqual(evaluate("2^3"), 8.0)

    def test_precedence(self):
        self.assertEqual(evaluate("2+3*4"), 14.0)
        self.assertEqual(evaluate("(2+3)*4"), 20.0)
        self.assertEqual(evaluate("2*3+4*5"), 26.0)

    def test_power_right_associative(self):
        self.assertEqual(evaluate("2^3^2"), 512.0)
        self.assertEqual(evaluate("2^2^3"), 256.0)

    def test_unary_binds_less_tightly_than_power(self):
        self.assertEqual(evaluate("-2^2"), -4.0)
        self.assertEqual(evaluate("2^-1"), 0.5)
        self.assertEqual(evaluate("-2^-2"), -0.25)
        self.assertEqual(evaluate("--2"), 2.0)

    def test_left_associativity(self):
        self.assertEqual(evaluate("10 - 4 - 3"), 3.0)
        self.assertEqual(evaluate("16 / 4 / 2"), 2.0)

    def test_precedence_mixed(self):
        self.assertEqual(evaluate("2 + 3 * 4 ^ 2"), 50.0)
        self.assertEqual(evaluate("(2 + 3) * 4"), 20.0)

    def test_returns_float(self):
        self.assertIsInstance(evaluate("2"), float)
        self.assertIsInstance(evaluate("4/2"), float)
        self.assertIsInstance(evaluate("x", {"x": 5}), float)

    def test_numbers(self):
        self.assertEqual(evaluate(".5"), 0.5)
        self.assertEqual(evaluate("3.5"), 3.5)
        self.assertEqual(evaluate("1e3"), 1000.0)
        self.assertEqual(evaluate("2.5E-2"), 0.025)
        self.assertEqual(evaluate("5"), 5.0)
        self.assertEqual(evaluate("2e+3"), 2000.0)

    def test_number_edge_tokens(self):
        # "5." -> number 5 then stray "." at position 1
        expect_error("5.", 1)
        # "2e" -> number 2 then name "e" starting at position 1
        expect_error("2e", 1)

    def test_modulo_floored(self):
        self.assertEqual(evaluate("-7 % 3"), 2.0)
        self.assertEqual(evaluate("7 % -3"), -2.0)

    def test_constants(self):
        self.assertAlmostEqual(evaluate("pi"), 3.141592653589793)
        self.assertAlmostEqual(evaluate("e"), 2.718281828459045)

    def test_variables(self):
        self.assertEqual(evaluate("x*2 + y", {"x": 3, "y": 4}), 10.0)
        self.assertIsInstance(evaluate("x", {"x": 5}), float)
        # variables override constants
        self.assertEqual(evaluate("pi", {"pi": 3}), 3.0)


class FunctionTest(unittest.TestCase):
    def test_builtin_functions(self):
        self.assertEqual(evaluate("abs(-5)"), 5.0)
        self.assertEqual(evaluate("sqrt(4)"), 2.0)
        self.assertEqual(evaluate("min(1,2,3)"), 1.0)
        self.assertEqual(evaluate("max(1,2)"), 2.0)
        self.assertEqual(evaluate("round(3.5)"), 4.0)
        self.assertEqual(evaluate("hypot(3,4)"), 5.0)

    def test_whitespace_before_paren_still_call(self):
        self.assertEqual(evaluate("sqrt (9)"), 3.0)

    def test_unknown_function(self):
        expect_error("foo(1)", 0)

    def test_arity_errors_at_name(self):
        expect_error("sqrt(1,2)", 0)
        expect_error("sqrt()", 0)
        expect_error("hypot(1)", 0)
        expect_error("hypot(3,4,5)", 0)
        expect_error("min()", 0)

    def test_zero_arg_call_ok_when_allowed(self):
        # min/max require at least 1 arg; covered above. No zero-arg builtins exist.
        pass


class SyntaxErrorPositionTest(unittest.TestCase):
    """Error positions from the SPEC.md table."""

    def check(self, expr, position):
        expect_error(expr, position)

    def test_empty_and_blank(self):
        self.check("", 0)
        self.check("   ", 3)

    def test_trailing_operator(self):
        self.check("1 +", 3)

    def test_unclosed_paren(self):
        self.check("(1 + 2", 6)

    def test_unexpected_close_paren(self):
        self.check("1 + 2)", 5)

    def test_two_operands(self):
        self.check("2 3", 2)
        self.check("2x", 1)
        self.check("2e", 1)

    def test_number_dot_edge(self):
        self.check("5.", 1)

    def test_double_operator(self):
        self.check("1 * * 2", 4)

    def test_trailing_comma(self):
        self.check("min(1,)", 6)

    def test_comma_outside_call(self):
        self.check("1, 2", 1)

    def test_bad_character(self):
        self.check("3 $ 4", 2)

    def test_no_implicit_multiplication(self):
        self.check("2(3)", 1)
        self.check("(1)(2)", 3)


class EvalErrorPositionTest(unittest.TestCase):
    def check(self, expr, position, variables=None):
        with self.assertRaises(ExprError) as ctx:
            evaluate(expr, variables)
        self.assertEqual(
            ctx.exception.position,
            position,
            f"{expr!r}: expected position {position}, got {ctx.exception.position}",
        )

    def test_unknown_name(self):
        self.check("unknown_name + 1", 0)
        self.check("min(unknown_name, 2)", 4)

    def test_unknown_function(self):
        self.check("foo(1)", 0)

    def test_arity_checked_before_arg_eval(self):
        # arity wrong AND argument unknown: arity error wins, at name pos
        self.check("sqrt(unknown_name, 2)", 0)

    def test_function_failure_at_name(self):
        self.check("sqrt(-1)", 0)
        self.check("1 + sqrt(-1)", 4)

    def test_division_and_modulo_by_zero(self):
        self.check("1 / 0", 2)
        self.check("1 % 0", 2)

    def test_bad_powers(self):
        self.check("0^-1", 1)
        self.check("(-8)^(1/3)", 4)
        self.check("10^400", 2)

    def test_syntax_error_beats_eval_error(self):
        # whole formula parsed first: syntax error at end wins over earlier eval error
        self.check("unknown_name + (1 +", 20 - 1)

    def test_variables_override_constants(self):
        self.assertEqual(evaluate("pi", {"pi": 3}), 3.0)


if __name__ == "__main__":
    unittest.main()
