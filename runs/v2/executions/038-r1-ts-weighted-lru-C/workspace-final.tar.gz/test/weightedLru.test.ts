import { test } from "node:test";
import assert from "node:assert/strict";
import { WeightedLRU } from "../src/weightedLru.ts";

test("evicts least recently used entries until under the weight bound", () => {
  const evicted: string[] = [];
  const cache = new WeightedLRU<string, string>({
    maxWeight: 10,
    weigh: (v) => v.length,
    onEvict: (k) => evicted.push(k),
  });
  assert.equal(cache.set("a", "aa"), true); // 2
  assert.equal(cache.set("b", "bbbb"), true); // 4 -> 6
  cache.get("a"); // a is now most recent
  assert.equal(cache.set("c", "ccccc"), true); // 5 -> 11, evicts b
  assert.deepEqual(evicted, ["b"]);
  assert.equal(cache.has("b"), false);
  assert.equal(cache.totalWeight, 7);
  assert.equal(cache.size, 2);
  assert.deepEqual(cache.keys(), ["a", "c"]);
});

test("default weight is 1 per entry", () => {
  const cache = new WeightedLRU<string, number>({ maxWeight: 2 });
  assert.equal(cache.set("a", 1), true);
  assert.equal(cache.set("b", 2), true);
  assert.equal(cache.set("c", 3), true); // evicts a, the least recently used
  assert.deepEqual(cache.keys(), ["b", "c"]); // c stays (never evicts what was just set)
  assert.equal(cache.totalWeight, 2);
});

test("replacement drops the old weight and does not call onEvict", () => {
  const evicted: string[] = [];
  const cache = new WeightedLRU<string, string>({
    maxWeight: 10,
    weigh: (v) => v.length,
    onEvict: (k) => evicted.push(k),
  });
  cache.set("a", "aaaa"); // 4
  assert.equal(cache.set("a", "a"), true); // replaces down to 1
  assert.equal(cache.get("a"), "a");
  assert.equal(cache.totalWeight, 1);
  cache.set("b", "bbbbbbbb"); // 8 -> 9
  assert.deepEqual(evicted, []);
});

test("an entry heavier than maxWeight is rejected and nothing changes", () => {
  const evicted: string[] = [];
  const cache = new WeightedLRU<string, string>({
    maxWeight: 10,
    weigh: (v) => v.length,
    onEvict: (k) => evicted.push(k),
  });
  cache.set("a", "aaaa"); // 4
  assert.equal(cache.set("b", "bbbbbbbbbbbb"), false); // 12 > 10
  assert.equal(cache.get("b"), undefined);
  assert.deepEqual(cache.keys(), ["a"]); // existing entry kept
  assert.equal(cache.totalWeight, 4);
  assert.deepEqual(evicted, []);
  assert.equal(cache.size, 1);
});

test("weigh returning a negative, NaN or infinite number throws and stores nothing", () => {
  for (const [label, bad] of [
    ["negative", () => -1],
    ["NaN", () => NaN],
    ["infinity", () => Infinity],
  ] as const) {
    const cache = new WeightedLRU<string, number>({
      maxWeight: 10,
      weigh: (v) => (v === 2 ? bad() : 1), // weight 2 triggers the bad weigh
    });
    cache.set("a", 1); // weight 1, valid
    assert.throws(() => cache.set("b", 2), RangeError, label);
    assert.deepEqual(cache.keys(), ["a"], label);
    assert.equal(cache.totalWeight, 1, label);
  }
});

test("rejects a bad maxWeight", () => {
  for (const bad of [0, -1, NaN, Infinity, -Infinity]) {
    assert.throws(
      () => new WeightedLRU({ maxWeight: bad }),
      RangeError,
      `maxWeight ${bad}`,
    );
  }
});

test("set never evicts the entry just set", () => {
  const cache = new WeightedLRU<string, number>({ maxWeight: 10, weigh: () => 4 });
  cache.set("a", 1);
  cache.set("b", 2); // 8
  cache.set("c", 3); // 12 -> evicts a; c (weight 4) must never be evicted
  assert.equal(cache.has("c"), true);
  assert.deepEqual(cache.keys(), ["b", "c"]);
  assert.equal(cache.totalWeight, 8);
});

test("get counts hits and misses and refreshes recency", () => {
  const cache = new WeightedLRU<string, string>({
    maxWeight: 10,
    weigh: (v) => v.length,
  });
  cache.set("a", "aa"); // 2
  cache.set("b", "bb"); // 4
  assert.equal(cache.get("missing"), undefined);
  assert.equal(cache.get("a"), "aa"); // a now most recent
  cache.set("c", "cccccc"); // 6 -> 10, no eviction (just set is never evicted)
  assert.equal(cache.get("c"), "cccccc"); // 6 -> still 10, evicts b? no, total 10 <= 10
  const stats = cache.stats();
  assert.equal(stats.hits, 2); // get("a") and get("c")
  assert.equal(stats.misses, 1); // get("missing")
  assert.equal(cache.totalWeight, 10);
});

test("peek and has do not touch recency or stats", () => {
  const cache = new WeightedLRU<string, number>({ maxWeight: 2, weigh: () => 1 });
  cache.set("a", 1);
  cache.set("b", 2);
  assert.equal(cache.peek("a"), 1);
  assert.equal(cache.has("a"), true);
  // a still least recently used -> evicted on next set
  cache.set("c", 3);
  assert.equal(cache.has("a"), false);
  assert.equal(cache.has("b"), true);
  assert.equal(cache.has("c"), true);
  const stats = cache.stats();
  assert.equal(stats.hits, 0);
  assert.equal(stats.misses, 0);
});

test("delete and clear do not call onEvict and keep stats", () => {
  const evicted: string[] = [];
  const cache = new WeightedLRU<string, number>({
    maxWeight: 10,
    weigh: () => 3,
    onEvict: (k) => evicted.push(k),
  });
  cache.set("a", 1);
  cache.set("b", 2);
  cache.set("c", 3);
  assert.equal(cache.delete("b"), true);
  assert.equal(cache.delete("b"), false);
  assert.equal(cache.totalWeight, 6);
  const statsAfterDelete = cache.stats();
  cache.clear();
  assert.equal(cache.size, 0);
  assert.equal(cache.totalWeight, 0);
  assert.deepEqual(evicted, []);
  assert.deepEqual(cache.stats(), statsAfterDelete);
});

test("keys are ordered from least to most recently used", () => {
  const cache = new WeightedLRU<string, number>({ maxWeight: 10, weigh: () => 1 });
  cache.set("a", 1);
  cache.set("b", 2);
  cache.set("c", 3);
  cache.get("a");
  assert.deepEqual(cache.keys(), ["b", "c", "a"]);
});

test("supports fractional and zero weights", () => {
  const cache = new WeightedLRU<string, number>({
    maxWeight: 1.5,
    weigh: (v) => v * 0.5,
  });
  assert.equal(cache.set("a", 1), true); // 0.5
  assert.equal(cache.set("b", 1), true); // 1.0
  assert.equal(cache.set("c", 1), true); // 1.5, no eviction
  assert.equal(cache.set("d", 1), true); // 2.0, evicts a
  assert.equal(cache.has("a"), false);
  const zero = new WeightedLRU<string, number>({ maxWeight: 10 });
  zero.set("x", 5);
  assert.equal(zero.totalWeight, 1); // default weight 1
});