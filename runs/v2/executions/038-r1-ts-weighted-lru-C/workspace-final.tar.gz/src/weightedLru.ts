/**
 * Options for {@link WeightedLRU}.
 */
export interface WeightedLRUOptions<K, V> {
  /** Maximum total weight the cache may hold. Must be a positive finite number. */
  maxWeight: number;
  /**
   * Returns an entry's weight (default: 1 for every entry). May be 0 or
   * fractional; a negative, NaN or infinite result causes `set` to throw.
   */
  weigh?: (value: V, key: K) => number;
  /** Called for each entry removed to make room, least recently used first. */
  onEvict?: (key: K, value: V) => void;
}

/**
 * A least-recently-used cache bounded by the total weight of its entries.
 * A Map keeps insertion order, so re-inserting a key moves it to the end
 * (most recently used) and the first key is always the oldest.
 */
export class WeightedLRU<K, V> {
  readonly maxWeight: number;
  readonly #weigh: (value: V, key: K) => number;
  readonly #onEvict: ((key: K, value: V) => void) | undefined;
  #entries = new Map<K, Entry<V>>();
  #totalWeight = 0;
  #hits = 0;
  #misses = 0;
  #evictions = 0;

  constructor(options: WeightedLRUOptions<K, V>) {
    const { maxWeight, weigh, onEvict } = options;
    if (!Number.isFinite(maxWeight) || maxWeight <= 0) {
      throw new RangeError(`maxWeight must be a positive finite number, got ${maxWeight}`);
    }
    this.maxWeight = maxWeight;
    this.#weigh = weigh ?? (() => 1);
    this.#onEvict = onEvict;
  }

  get size(): number {
    return this.#entries.size;
  }

  get totalWeight(): number {
    return this.#totalWeight;
  }

  /**
   * Stores `value` for `key` as the most recently used entry, replacing any
   * existing value for the key (its old weight no longer counts), then evicts
   * the least recently used entries until `totalWeight <= maxWeight`. Returns
   * whether the entry was stored.
   */
  set(key: K, value: V): boolean {
    const weight = this.#weigh(value, key);
    if (!Number.isFinite(weight) || weight < 0) {
      throw new RangeError(
        `weigh must return a non-negative finite number, got ${weight} for key ${String(key)}`,
      );
    }

    // An entry heavier than the whole cache can never fit; leave the cache
    // exactly as it was (an existing entry for `key` is kept).
    if (weight > this.maxWeight) {
      return false;
    }

    const existing = this.#entries.get(key);
    if (existing !== undefined) {
      this.#totalWeight -= existing.weight;
      existing.weight = weight;
      existing.value = value;
      this.#totalWeight += weight;
      // Re-insert to move the key to the most recently used end.
      this.#entries.delete(key);
      this.#entries.set(key, existing);
    } else {
      this.#entries.set(key, { value, weight });
      this.#totalWeight += weight;
    }

    // Evict least recently used entries until under the weight bound. The
    // entry just set always satisfies `weight <= maxWeight`, so it sits at the
    // most-recent end and can never be the oldest one that gets removed.
    while (this.#totalWeight > this.maxWeight) {
      const oldestKey = this.#entries.keys().next().value as K;
      const oldest = this.#entries.get(oldestKey) as Entry<V>;
      this.#entries.delete(oldestKey);
      this.#totalWeight -= oldest.weight;
      this.#evictions++;
      this.#onEvict?.(oldestKey, oldest.value);
    }

    return true;
  }

  /** Returns the value for `key`, or undefined. A hit makes it MRU and counts as a hit. */
  get(key: K): V | undefined {
    const entry = this.#entries.get(key);
    if (entry === undefined) {
      this.#misses++;
      return undefined;
    }
    this.#hits++;
    // Re-insert to move the key to the most recently used end.
    this.#entries.delete(key);
    this.#entries.set(key, entry);
    return entry.value;
  }

  /** Returns the value for `key` without touching recency or stats. */
  peek(key: K): V | undefined {
    return this.#entries.get(key)?.value;
  }

  has(key: K): boolean {
    return this.#entries.has(key);
  }

  delete(key: K): boolean {
    const entry = this.#entries.get(key);
    if (entry === undefined) {
      return false;
    }
    this.#entries.delete(key);
    this.#totalWeight -= entry.weight;
    return true;
  }

  /** Removes every entry; stats are kept. */
  clear(): void {
    this.#entries.clear();
    this.#totalWeight = 0;
  }

  /** The keys, from least to most recently used. */
  keys(): K[] {
    return [...this.#entries.keys()];
  }

  stats(): { hits: number; misses: number; evictions: number } {
    return { hits: this.#hits, misses: this.#misses, evictions: this.#evictions };
  }
}

interface Entry<V> {
  value: V;
  weight: number;
}