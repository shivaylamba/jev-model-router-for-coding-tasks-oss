"""URL helpers for the link checker."""


def split_url(url):
    """Split a URL into (base, query, fragment).

    The query is the text after the first "?" (without the "?") and the
    fragment is the text after the first "#". Missing parts are "".

    >>> split_url("https://x.test/a?b=1#top")
    ('https://x.test/a', 'b=1', 'top')
    """
    base, _, fragment = url.partition("#")
    base, _, query = base.partition("?")
    return base, query, fragment


_SAFE = frozenset("ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                  "abcdefghijklmnopqrstuvwxyz"
                  "0123456789-._~")
_HEX = frozenset("0123456789abcdefABCDEF")


def _decode_component(s):
    """Decode one query component: '+' to space, then %XX escapes as UTF-8.

    A "%" not followed by two hex digits is kept as-is. Bytes that don't
    form valid UTF-8 become U+FFFD.
    """
    s = s.replace("+", " ")
    out = bytearray()
    i = 0
    n = len(s)
    while i < n:
        if s[i] == "%" and i + 2 < n and s[i + 1] in _HEX and s[i + 2] in _HEX:
            out.append(int(s[i + 1:i + 3], 16))
            i += 3
        else:
            out.extend(s[i].encode("utf-8"))
            i += 1
    return out.decode("utf-8", errors="replace")


def _encode_component(s):
    """Percent-encode one component: keep the RFC 3986 unreserved set, '+' for
    space, everything else as uppercase %XX of its UTF-8 bytes."""
    out = []
    for byte in s.encode("utf-8"):
        if byte == 0x20:
            out.append("+")
        elif byte < 128 and chr(byte) in _SAFE:
            out.append(chr(byte))
        else:
            out.append("%%%02X" % byte)
    return "".join(out)


def parse_query(query):
    """Split a query string into an ordered dict of key -> list of values.

    Unlike urllib.parse.parse_qs, bare keys are preserved (value None), keys
    keep their first-appearance order, and nothing is lost on round trips.

    >>> parse_query("a=1&flag&a=2")
    {'a': ['1', '2'], 'flag': [None]}
    """
    if query.startswith("?"):
        query = query[1:]
    params = {}
    for segment in query.split("&"):
        if not segment:
            continue
        key, sep, value = segment.partition("=")
        dk = _decode_component(key)
        params.setdefault(dk, []).append(
            _decode_component(value) if sep else None)
    return params


def build_query(params):
    """Encode an ordered dict of key -> str/None/list back into a query string.

    Keys go in mapping order, list values in list order (each its own pair;
    an empty list writes nothing). None writes a bare key, "''" writes "key=".
    """
    parts = []
    for key, value in params.items():
        if isinstance(value, list):
            for item in value:
                parts.append(_build_pair(key, item))
        else:
            parts.append(_build_pair(key, value))
    return "&".join(parts)


def _build_pair(key, value):
    if value is None:
        return _encode_component(key)
    if isinstance(value, str):
        return _encode_component(key) + "=" + _encode_component(value)
    raise TypeError("query value must be str, None, or a list of those, "
                    "got %r" % (value,))
