import { test } from "node:test";
import assert from "node:assert/strict";
import { Editor } from "../src/editor.ts";

test("starts with the cursor at the end", () => {
  const editor = new Editor("hello");
  assert.deepEqual(editor.selection, { start: 5, end: 5 });
});

test("insert replaces the selection", () => {
  const editor = new Editor("hello world");
  editor.select(6, 11);
  editor.insert("there");
  assert.equal(editor.text, "hello there");
  assert.deepEqual(editor.selection, { start: 11, end: 11 });
});

test("select clamps and orders", () => {
  const editor = new Editor("abc");
  editor.select(10, -2);
  assert.deepEqual(editor.selection, { start: 0, end: 3 });
});

test("deleteBackward and deleteForward", () => {
  const editor = new Editor("abcd");
  editor.select(2);
  editor.deleteBackward();
  assert.equal(editor.text, "acd");
  editor.deleteForward();
  assert.equal(editor.text, "ad");
  assert.deepEqual(editor.selection, { start: 1, end: 1 });
});

// Undo / Redo API
test("undo restores text and selection", () => {
  const editor = new Editor("hello");
  editor.select(5);
  editor.insert(" world");
  assert.equal(editor.text, "hello world");
  const didUndo = editor.undo();
  assert.equal(didUndo, true);
  assert.equal(editor.text, "hello");
  assert.deepEqual(editor.selection, { start: 5, end: 5 });
});

test("redo restores text and selection after undo", () => {
  const editor = new Editor("hello");
  editor.select(5);
  editor.insert(" world");
  editor.undo();
  const didRedo = editor.redo();
  assert.equal(didRedo, true);
  assert.equal(editor.text, "hello world");
  assert.deepEqual(editor.selection, { start: 11, end: 11 });
});

test("undo returns false when nothing to undo", () => {
  const editor = new Editor("hello");
  assert.equal(editor.undo(), false);
  assert.equal(editor.text, "hello");
});

test("redo returns false when nothing to redo", () => {
  const editor = new Editor("hello");
  editor.insert(" world");
  editor.undo();
  editor.redo();
  assert.equal(editor.redo(), false);
});

test("canUndo and canRedo", () => {
  const editor = new Editor("hi");
  assert.equal(editor.canUndo(), false);
  assert.equal(editor.canRedo(), false);
  editor.insert("!");
  assert.equal(editor.canUndo(), true);
  assert.equal(editor.canRedo(), false);
  editor.undo();
  assert.equal(editor.canUndo(), false);
  assert.equal(editor.canRedo(), true);
});

// No-op edits
test("no-op insert creates no undo step", () => {
  const editor = new Editor("hi");
  editor.select(1);
  editor.insert("");
  assert.equal(editor.canUndo(), false);
});

test("no-op deleteBackward at start creates no step", () => {
  const editor = new Editor("hi");
  editor.select(0);
  editor.deleteBackward();
  assert.equal(editor.canUndo(), false);
});

test("no-op deleteForward at end creates no step", () => {
  const editor = new Editor("hi");
  editor.select(2);
  editor.deleteForward();
  assert.equal(editor.canUndo(), false);
});

// Selection changes do not affect history
test("select does not create undo step or clear redo", () => {
  const editor = new Editor("hello");
  editor.select(5);
  editor.insert(" world");
  editor.undo();
  assert.equal(editor.canRedo(), true);
  editor.select(2);
  assert.equal(editor.canRedo(), true);
  assert.equal(editor.canUndo(), false);
});

// Typing groups
test("typing groups within 1000 ms", () => {
  let t = 0;
  const clock = () => t;
  const editor = new Editor("", { clock });
  editor.insert("a");
  t = 500;
  editor.insert("b");
  t = 999;
  editor.insert("c");
  assert.equal(editor.text, "abc");
  editor.undo();
  assert.equal(editor.text, "");
  assert.equal(editor.canUndo(), false);
});

test("exactly 1000 ms starts a new typing group", () => {
  let t = 0;
  const clock = () => t;
  const editor = new Editor("", { clock });
  editor.insert("a");
  t = 1000;
  editor.insert("b");
  assert.equal(editor.text, "ab");
  editor.undo();
  assert.equal(editor.text, "a");
  assert.equal(editor.canUndo(), true);
  editor.undo();
  assert.equal(editor.text, "");
});

test("non-empty selection insert is not typing", () => {
  let t = 0;
  const clock = () => t;
  const editor = new Editor("ab", { clock });
  editor.select(0, 2);
  editor.insert("x");
  assert.equal(editor.text, "x");
  editor.undo();
  assert.equal(editor.text, "ab");
});

test("multi-character insert is not typing", () => {
  let t = 0;
  const clock = () => t;
  const editor = new Editor("", { clock });
  editor.insert("ab");
  assert.equal(editor.text, "ab");
  editor.undo();
  assert.equal(editor.text, "");
});

test("newline insert is not typing", () => {
  let t = 0;
  const clock = () => t;
  const editor = new Editor("", { clock });
  editor.insert("\n");
  assert.equal(editor.text, "\n");
  editor.undo();
  assert.equal(editor.text, "");
});

test("delete closes typing group", () => {
  let t = 0;
  const clock = () => t;
  const editor = new Editor("abc", { clock });
  editor.select(3);
  editor.insert("d");
  assert.equal(editor.text, "abcd");
  t = 100;
  editor.deleteBackward();
  // deletes the d we just typed → "abc"
  t = 200;
  editor.insert("e");
  // "e" replaces nothing at position 3 → "abce"
  assert.equal(editor.text, "abce");
  editor.undo();
  // undo insert "e" → "abc"
  assert.equal(editor.text, "abc");
  editor.undo();
  // undo deleteBackward → "abcd"
  assert.equal(editor.text, "abcd");
});

test("select closes typing group", () => {
  let t = 0;
  const clock = () => t;
  const editor = new Editor("abc", { clock });
  editor.insert("d");
  t = 100;
  editor.select(3);
  t = 200;
  editor.insert("e");
  assert.equal(editor.text, "abced");
  // "d" is a typing group, select closed it, "e" is its own step
  editor.undo();
  assert.equal(editor.text, "abcd");
  editor.undo();
  assert.equal(editor.text, "abc");
});

test("undo and redo close the typing group", () => {
  let t = 0;
  const clock = () => t;
  const editor = new Editor("", { clock });
  editor.insert("a");
  t = 500;
  editor.insert("b");
  // "ab" is one typing group
  editor.undo();
  assert.equal(editor.text, "");
  editor.redo();
  // redo restores "ab"
  t = 600;
  editor.insert("c");
  assert.equal(editor.text, "abc");
  // "c" is a new step, not part of the redo'd group
  editor.undo();
  assert.equal(editor.text, "ab");
  editor.undo();
  assert.equal(editor.text, "");
});

// Transactions
test("transact groups multiple changes into one step", () => {
  const editor = new Editor("hello");
  editor.transact(() => {
    editor.select(5);
    editor.insert(" ");
    editor.insert("world");
  });
  assert.equal(editor.text, "hello world");
  assert.equal(editor.canUndo(), true);
  editor.undo();
  assert.equal(editor.text, "hello");
  assert.equal(editor.canUndo(), false);
});

test("transact leaves redo stack alone when text unchanged", () => {
  const editor = new Editor("hello");
  editor.select(5);
  editor.insert(" world");
  editor.undo();
  assert.equal(editor.canRedo(), true);
  editor.transact(() => {
    editor.select(2);
  });
  assert.equal(editor.canRedo(), true);
  assert.equal(editor.canUndo(), false);
});

test("transact does not create step when text is unchanged but selection changed", () => {
  const editor = new Editor("hello");
  editor.transact(() => {
    editor.select(2, 4);
  });
  assert.equal(editor.canUndo(), false);
});

test("nested transact calls join the outermost", () => {
  const editor = new Editor("");
  editor.transact(() => {
    editor.insert("a");
    editor.transact(() => {
      editor.insert("b");
    });
  });
  assert.equal(editor.text, "ab");
  assert.equal(editor.canUndo(), true);
  editor.undo();
  assert.equal(editor.text, "");
  assert.equal(editor.canUndo(), false);
});

test("transact restores state on throw", () => {
  const editor = new Editor("hello");
  assert.throws(
    () =>
      editor.transact(() => {
        editor.insert(" world");
        throw new Error("boom");
      }),
    /boom/,
  );
  assert.equal(editor.text, "hello");
  assert.deepEqual(editor.selection, { start: 5, end: 5 });
  assert.equal(editor.canUndo(), false);
});

test("typing inside a transaction does not extend outside group", () => {
  let t = 0;
  const clock = () => t;
  const editor = new Editor("", { clock });
  editor.insert("a");
  t = 100;
  editor.transact(() => {
    editor.insert("b");
    t = 200;
    editor.insert("c");
  });
  assert.equal(editor.text, "abc");
  editor.undo();
  assert.equal(editor.text, "a");
  editor.undo();
  assert.equal(editor.text, "");
});

test("undo in transaction throws", () => {
  const editor = new Editor("ab");
  editor.insert("c");
  assert.throws(
    () =>
      editor.transact(() => {
        editor.undo();
      }),
    /Cannot call undo during a transaction/,
  );
});

test("redo in transaction throws", () => {
  const editor = new Editor("ab");
  editor.insert("c");
  editor.undo();
  assert.throws(
    () =>
      editor.transact(() => {
        editor.redo();
      }),
    /Cannot call redo during a transaction/,
  );
});

// History limit
test("historyLimit defaults to 100", () => {
  const editor = new Editor("");
  for (let i = 0; i < 150; i++) {
    editor.insert("x");
    editor.select(0);
  }
  let count = 0;
  while (editor.canUndo()) {
    editor.undo();
    count++;
  }
  assert.equal(count, 100);
});

test("historyLimit 0 disables undo", () => {
  const editor = new Editor("", { historyLimit: 0 });
  editor.insert("x");
  assert.equal(editor.canUndo(), false);
});

test("historyLimit must be integer >= 0", () => {
  assert.throws(() => new Editor("", { historyLimit: -1 }), RangeError);
  assert.throws(() => new Editor("", { historyLimit: 1.5 }), RangeError);
  assert.throws(() => new Editor("", { historyLimit: NaN }), RangeError);
});

test("historyLimit accepts 0 and positive integers", () => {
  assert.doesNotThrow(() => new Editor("", { historyLimit: 0 }));
  assert.doesNotThrow(() => new Editor("", { historyLimit: 5 }));
});

// Redo cleared by new changes
test("new change clears redo stack", () => {
  const editor = new Editor("");
  editor.insert("a");
  editor.insert("b");
  editor.undo();
  editor.undo();
  assert.equal(editor.canRedo(), true);
  editor.insert("c");
  assert.equal(editor.canRedo(), false);
});

test("no-op insert does not clear redo stack", () => {
  const editor = new Editor("hi");
  editor.select(2);
  editor.insert("a");
  editor.undo();
  assert.equal(editor.canRedo(), true);
  editor.select(2);
  editor.insert("");
  assert.equal(editor.canRedo(), true);
});

// Extended typing group keeps original before state
test("typing group preserves original before state", () => {
  let t = 0;
  const clock = () => t;
  const editor = new Editor("hello ", { clock });
  editor.select(6);
  editor.insert("w");
  t = 400;
  editor.insert("o");
  t = 800;
  editor.insert("r");
  t = 1200;
  editor.insert("l");
  t = 1600;
  editor.insert("d");
  assert.equal(editor.text, "hello world");
  editor.undo();
  assert.equal(editor.text, "hello ");
  assert.deepEqual(editor.selection, { start: 6, end: 6 });
});
