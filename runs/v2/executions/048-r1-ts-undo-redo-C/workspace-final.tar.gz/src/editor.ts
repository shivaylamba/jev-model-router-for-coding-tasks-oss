import {
  History,
  validateHistoryLimit,
  type Step,
} from "./history.ts";
import {
  isEmpty,
  normalizeSelection,
  replaceRange,
  type Selection,
} from "./text.ts";

export interface EditorOptions {
  /** Milliseconds clock used by undo grouping. Defaults to Date.now. */
  clock?: () => number;
  /** Maximum number of undo steps kept. Defaults to 100. */
  historyLimit?: number;
}

export class Editor {
  private content: string;
  private sel: Selection;
  private history: History;

  constructor(text: string = "", options: EditorOptions = {}) {
    const limit = validateHistoryLimit(
      options.historyLimit === undefined ? 100 : options.historyLimit,
    );
    this.history = new History({
      clock: options.clock ?? Date.now,
      limit,
    });
    this.content = text;
    this.sel = { start: text.length, end: text.length };
  }

  get text(): string {
    return this.content;
  }

  /** A copy of the current selection. */
  get selection(): Selection {
    return { ...this.sel };
  }

  /** Set the selection; offsets are clamped to the text and ordered. `end` defaults to `start`. */
  select(start: number, end: number = start): void {
    this.sel = normalizeSelection(this.content.length, start, end);
    this.history.closeTypingGroup();
  }

  /** Replace the selection with `str` and put the cursor right after it. */
  insert(str: string): void {
    const beforeText = this.content;
    const beforeSel = this.sel;
    const { start, end } = this.sel;
    this.content = replaceRange(this.content, start, end, str);
    const cursor = start + str.length;
    this.sel = { start: cursor, end: cursor };

    if (beforeText === this.content) return;

    const isTyping =
      isEmpty(beforeSel) && str.length === 1 && str !== "\n";
    this.history.record(
      beforeText,
      beforeSel,
      this.content,
      this.sel,
      isTyping,
    );
    if (!isTyping) {
      this.history.closeTypingGroup();
    }
  }

  /** Delete the selection, or the character before the cursor when the selection is empty. */
  deleteBackward(): void {
    const beforeText = this.content;
    const beforeSel = this.sel;
    const { start, end } = this.sel;
    if (!isEmpty(this.sel)) {
      this.content = replaceRange(this.content, start, end, "");
      this.sel = { start, end: start };
    } else if (start > 0) {
      this.content = replaceRange(this.content, start - 1, start, "");
      this.sel = { start: start - 1, end: start - 1 };
    }

    if (beforeText !== this.content) {
      this.history.record(
        beforeText,
        beforeSel,
        this.content,
        this.sel,
        false,
      );
    }
    this.history.closeTypingGroup();
  }

  /** Delete the selection, or the character after the cursor when the selection is empty. */
  deleteForward(): void {
    const beforeText = this.content;
    const beforeSel = this.sel;
    const { start, end } = this.sel;
    if (!isEmpty(this.sel)) {
      this.content = replaceRange(this.content, start, end, "");
      this.sel = { start, end: start };
    } else if (start < this.content.length) {
      this.content = replaceRange(this.content, start, start + 1, "");
    }

    if (beforeText !== this.content) {
      this.history.record(
        beforeText,
        beforeSel,
        this.content,
        this.sel,
        false,
      );
    }
    this.history.closeTypingGroup();
  }

  /** Revert the most recent undo step. */
  undo(): boolean {
    if (this.history.isInTransaction) {
      throw new Error("Cannot call undo during a transaction");
    }
    const result = this.history.undo(this.content, this.sel);
    if (!result) return false;
    this.content = result.text;
    this.sel = result.sel;
    return true;
  }

  /** Re-apply the most recently undone step. */
  redo(): boolean {
    if (this.history.isInTransaction) {
      throw new Error("Cannot call redo during a transaction");
    }
    const result = this.history.redo(this.content, this.sel);
    if (!result) return false;
    this.content = result.text;
    this.sel = result.sel;
    return true;
  }

  canUndo(): boolean {
    return this.history.canUndo;
  }

  canRedo(): boolean {
    return this.history.canRedo;
  }

  /** Run `fn` as a single undo step. */
  transact<T>(fn: () => T): T {
    if (this.history.isInTransaction) {
      return fn();
    }

    const savedText = this.content;
    const savedSel = this.sel;
    const isOutermost = this.history.beginTransaction(this.content, this.sel);
    let result: T;
    try {
      result = fn();
    } catch (e) {
      if (isOutermost) {
        this.history.abortTransaction();
      }
      this.content = savedText;
      this.sel = savedSel;
      throw e;
    }

    if (isOutermost) {
      const record = this.history.endTransaction(this.content, this.sel);
      if (record) {
        this.history.record(
          record.beforeText,
          record.beforeSel,
          record.afterText,
          record.afterSel,
          false,
        );
      }
    }
    return result;
  }
}
