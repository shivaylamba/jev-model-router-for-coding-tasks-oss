import type { Selection } from "./text.ts";

export interface Step {
  beforeText: string;
  beforeSel: Selection;
  afterText: string;
  afterSel: Selection;
  typing: boolean;
  lastTime: number;
}

export interface HistoryOptions {
  clock: () => number;
  limit: number;
}

/** TYPING_GROUP_TIMEOUT in milliseconds. */
const TIMEOUT = 1000;

export function validateHistoryLimit(limit: unknown): number {
  if (!Number.isInteger(limit) || (limit as number) < 0) {
    throw new RangeError("historyLimit must be an integer >= 0");
  }
  return limit as number;
}

export function isEmptyStep(step: Step): boolean {
  return (
    step.beforeText === step.afterText &&
    step.beforeSel.start === step.afterSel.start &&
    step.beforeSel.end === step.afterSel.end
  );
}

export class History {
  private undoStack: Step[] = [];
  private redoStack: Step[] = [];
  private clock: () => number;
  private limit: number;
  private inTransaction: boolean = false;
  /** Snapshot at the start of the outermost transaction. */
  private transaction?: { text: string; sel: Selection };

  constructor(options: HistoryOptions) {
    this.clock = options.clock;
    this.limit = options.limit;
  }

  get canUndo(): boolean {
    return this.undoStack.length > 0;
  }

  get canRedo(): boolean {
    return this.redoStack.length > 0;
  }

  /** Add a new step or extend the current typing group. Returns the step that was added/extended, or null. */
  record(
    beforeText: string,
    beforeSel: Selection,
    afterText: string,
    afterSel: Selection,
    isTyping: boolean,
  ): Step | null {
    if (this.inTransaction) return null;

    const now = this.clock();
    const step: Step = {
      beforeText,
      beforeSel,
      afterText,
      afterSel,
      typing: false,
      lastTime: now,
    };

    if (isTyping) {
      const last = this.undoStack[this.undoStack.length - 1];
      if (last && last.typing && now - last.lastTime < TIMEOUT) {
        last.afterText = afterText;
        last.afterSel = afterSel;
        last.lastTime = now;
        this.clearRedo();
        return last;
      }
      step.typing = true;
    }

    this.pushUndo(step);
    this.clearRedo();
    return step;
  }

  undo(currentText: string, currentSel: Selection): { text: string; sel: Selection; step: Step } | null {
    const step = this.undoStack.pop();
    if (!step) return null;
    step.typing = false;
    this.redoStack.push(step);
    return { text: step.beforeText, sel: step.beforeSel, step };
  }

  redo(currentText: string, currentSel: Selection): { text: string; sel: Selection; step: Step } | null {
    const step = this.redoStack.pop();
    if (!step) return null;
    this.undoStack.push(step);
    return { text: step.afterText, sel: step.afterSel, step };
  }

  /** Close the current typing group so it can no longer be extended. */
  closeTypingGroup(): void {
    const last = this.undoStack[this.undoStack.length - 1];
    if (last) last.typing = false;
  }

  /** Start a transaction. Returns true if this is the outermost one. */
  beginTransaction(text: string, sel: Selection): boolean {
    if (this.inTransaction) return false;
    this.inTransaction = true;
    this.transaction = { text, sel };
    return true;
  }

  /** End the outermost transaction. Returns the step to record, or null if not outermost / no change. */
  endTransaction(
    afterText: string,
    afterSel: Selection,
  ): { beforeText: string; beforeSel: Selection; afterText: string; afterSel: Selection } | null {
    if (!this.inTransaction || !this.transaction) return null;
    const beforeText = this.transaction.text;
    const beforeSel = this.transaction.sel;
    this.inTransaction = false;
    this.transaction = undefined;
    if (beforeText === afterText) return null;
    return { beforeText, beforeSel, afterText, afterSel };
  }

  /** Abandon the transaction without creating a step. */
  abortTransaction(): void {
    this.inTransaction = false;
    this.transaction = undefined;
  }

  get isInTransaction(): boolean {
    return this.inTransaction;
  }

  private pushUndo(step: Step): void {
    if (this.limit === 0) return;
    if (this.undoStack.length >= this.limit) {
      this.undoStack.shift();
    }
    this.undoStack.push(step);
  }

  private clearRedo(): void {
    this.redoStack.length = 0;
  }
}
