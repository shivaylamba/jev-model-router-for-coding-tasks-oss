export const MINUTES_PER_DAY = 24 * 60;

/** Format minutes after midnight as zero-padded 24-hour "HH:MM". */
export function formatClock(minutes: number): string {
  if (!Number.isInteger(minutes) || minutes < 0 || minutes >= MINUTES_PER_DAY) {
    throw new RangeError(`minutes out of range: ${minutes}`);
  }
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return `${String(hours).padStart(2, "0")}:${String(mins).padStart(2, "0")}`;
}

// 12-hour: hour (1-12), optional ":MM", optional space, then am/pm (any case),
// e.g. "7:30 pm", "7pm", "9 Am". Groups: [1]=hour [2]=MM(optional) [3]=meridian.
const AMPM_RE = /^(\d{1,2})(?::(\d{2}))?\s*([ap]m)$/i;
// 24-hour: hour (0-23) ":" MM (exactly two digits). Groups: [1]=hour [2]=minute.
const H24_RE = /^(\d{1,2}):(\d{2})$/;

/** Parse a clock time as minutes after midnight. Accepts 24-hour "H:MM" and
 * 12-hour "H[:MM] am|pm" forms (ignoring surrounding whitespace and letter
 * case). Throws RangeError for an out-of-range number and SyntaxError for any
 * text that doesn't match one of the accepted shapes. */
export function parseClock(input: string): number {
  const text = input.trim();
  if (text === "") throw new SyntaxError(`invalid time: ${input}`);

  const ampm = text.match(AMPM_RE);
  if (ampm) {
    const hours = Number(ampm[1]);
    const minutes = ampm[2] === undefined ? 0 : Number(ampm[2]);
    if (hours < 1 || hours > 12) throw new RangeError(`hours out of range: ${input}`);
    if (minutes > 59) throw new RangeError(`minutes out of range: ${input}`);
    // 12am -> 0, 12pm -> 12, rest shift pm by 12.
    let hour24 = hours % 12;
    if (ampm[3].toLowerCase() === "pm") hour24 += 12;
    return hour24 * 60 + minutes;
  }

  const h24 = text.match(H24_RE);
  if (h24) {
    const hours = Number(h24[1]);
    const minutes = Number(h24[2]);
    if (hours > 23) throw new RangeError(`hours out of range: ${input}`);
    if (minutes > 59) throw new RangeError(`minutes out of range: ${input}`);
    return hours * 60 + minutes;
  }

  throw new SyntaxError(`invalid time: ${input}`);
}
