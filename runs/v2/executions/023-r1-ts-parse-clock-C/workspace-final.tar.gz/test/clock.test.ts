import { test } from "node:test";
import assert from "node:assert/strict";
import { formatClock, parseClock } from "../src/clock.ts";

test("formatClock pads hours and minutes", () => {
  assert.equal(formatClock(0), "00:00");
  assert.equal(formatClock(19 * 60 + 5), "19:05");
});

test("formatClock rejects out-of-range minutes", () => {
  assert.throws(() => formatClock(1440), RangeError);
});

test("parseClock handles 24-hour times", () => {
  assert.equal(parseClock("19:30"), 1170);
  assert.equal(parseClock("7:05"), 425);
  assert.equal(parseClock("00:00"), 0);
  assert.equal(parseClock("23:59"), 1439);
});

test("parseClock handles 12-hour times", () => {
  assert.equal(parseClock("7:30 pm"), 1170);
  assert.equal(parseClock("7pm"), 1140);
  assert.equal(parseClock("9 Am"), 540);
  assert.equal(parseClock("12:15 am"), 15);
  assert.equal(parseClock("12pm"), 720);
  assert.equal(parseClock("12am"), 0);
});

test("parseClock ignores surrounding whitespace", () => {
  assert.equal(parseClock("  7pm  "), 1140);
  assert.equal(parseClock("\t19:30\n"), 1170);
});

test("parseClock throws RangeError for out-of-range numbers", () => {
  for (const bad of ["24:00", "7:60", "13pm", "0am", "7:60pm"]) {
    assert.throws(() => parseClock(bad), RangeError, bad);
  }
});

test("parseClock throws SyntaxError for non-matching text", () => {
  for (const bad of ["", "7", "7:5", "noon", "7:30 p.m."]) {
    assert.throws(() => parseClock(bad), SyntaxError, bad);
  }
});
