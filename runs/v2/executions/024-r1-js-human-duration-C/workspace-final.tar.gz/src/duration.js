/**
 * Units, largest first. `ms` is the length of one unit in milliseconds.
 * The `name` is the singular long form; `abbr` is the compact form.
 */
const UNITS = [
  { name: "day", abbr: "d", ms: 86_400_000 },
  { name: "hour", abbr: "h", ms: 3_600_000 },
  { name: "minute", abbr: "m", ms: 60_000 },
  { name: "second", abbr: "s", ms: 1_000 },
  { name: "millisecond", abbr: "ms", ms: 1 },
];

const RANK = new Map(UNITS.map((u, i) => [u.abbr, i]));

const STYLES = ["long", "compact"];

/**
 * Format a duration in milliseconds as a readable string.
 * @param {number} ms
 * @param {{ units?: number, style?: "long"|"compact", smallest?: string }} [options]
 * @returns {string}
 */
export function formatDuration(ms, options = {}) {
  if (typeof ms !== "number") {
    throw new TypeError(`ms must be a number, got ${typeof ms}`);
  }
  if (!Number.isFinite(ms) || ms < 0) {
    throw new RangeError(`ms must be a finite non-negative number, got ${ms}`);
  }

  const units = options.units === undefined ? 2 : options.units;
  if (!Number.isInteger(units) || units < 1) {
    throw new RangeError(`units must be a positive integer, got ${units}`);
  }

  const style = options.style === undefined ? "long" : options.style;
  if (!STYLES.includes(style)) {
    throw new RangeError(`style must be one of ${STYLES.join(", ")}, got ${style}`);
  }

  const smallest = options.smallest === undefined ? "s" : options.smallest;
  if (!RANK.has(smallest)) {
    throw new RangeError(
      `smallest must be one of ${[...RANK.keys()].join(", ")}, got ${smallest}`,
    );
  }

  // Floor once before splitting; below the last shown unit we drop, never round.
  let remaining = Math.floor(ms);
  const lastIndex = RANK.get(smallest);

  const counts = [];
  for (let i = 0; i <= lastIndex; i++) {
    const u = UNITS[i];
    counts.push(Math.floor(remaining / u.ms));
    remaining %= u.ms;
  }

  // Largest non-zero units only — zeros are skipped and don't count toward the cap.
  const parts = [];
  for (let i = 0; i <= lastIndex && parts.length < units; i++) {
    const count = counts[i];
    if (count > 0) {
      parts.push([count, i]);
    }
  }

  if (parts.length === 0) {
    // Value is less than one `smallest` unit: return zero in that unit.
    const u = UNITS[lastIndex];
    return style === "long" ? `0 ${pluralize(u.name, 0)}` : `0${u.abbr}`;
  }

  if (style === "long") {
    return parts
      .map(([count, i]) => `${count} ${pluralize(UNITS[i].name, count)}`)
      .join(", ");
  }
  return parts.map(([count, i]) => `${count}${UNITS[i].abbr}`).join(" ");
}

/** Singular only when the count is exactly 1. */
function pluralize(name, count) {
  return count === 1 ? name : `${name}s`;
}