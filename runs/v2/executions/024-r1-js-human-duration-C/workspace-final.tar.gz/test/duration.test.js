import { test } from "node:test";
import assert from "node:assert/strict";
import { formatDuration } from "../src/duration.js";

test("splits into the largest non-zero units, most significant first", () => {
  assert.equal(formatDuration(90_061_000), "1 day, 1 hour");
  assert.equal(formatDuration(3_600_000), "1 hour");
  assert.equal(formatDuration(1_500), "1 second");
});

test("skips zero units and they don't count toward the cap", () => {
  // 1 day + 5 minutes (no hours, no seconds) with the default cap of 2.
  assert.equal(formatDuration(86_700_000), "1 day, 5 minutes");
});

test("units caps the number of shown units", () => {
  assert.equal(formatDuration(90_060_000, { units: 3 }), "1 day, 1 hour, 1 minute");
  assert.equal(formatDuration(3_705_000, { units: 1 }), "1 hour");
});

test("drops the remainder below the last shown unit, never rounding", () => {
  assert.equal(formatDuration(3_599_999.999), "59 minutes, 59 seconds");
});

test("singular only when the count is 1", () => {
  assert.equal(formatDuration(3_661_000, { units: 3 }), "1 hour, 1 minute, 1 second");
  assert.equal(formatDuration(122_000), "2 minutes, 2 seconds");
});

test("milliseconds never show by default", () => {
  assert.equal(formatDuration(1_500), "1 second");
});

test("smallest allows a smaller unit to appear", () => {
  assert.equal(formatDuration(1_500, { smallest: "ms" }), "1 second, 500 milliseconds");
});

test("compact style", () => {
  assert.equal(formatDuration(90_061_000, { style: "compact", units: 4 }), "1d 1h 1m 1s");
  assert.equal(formatDuration(1500, { smallest: "ms", style: "compact" }), "1s 500ms");
});

test("returns zero in the smallest unit when nothing would show", () => {
  assert.equal(formatDuration(500), "0 seconds");
  assert.equal(formatDuration(500, { smallest: "m" }), "0 minutes");
  assert.equal(formatDuration(500, { style: "compact" }), "0s");
  assert.equal(formatDuration(500, { smallest: "m", style: "compact" }), "0m");
});

test("floors a non-integral input before splitting", () => {
  assert.equal(
    formatDuration(3_599_999.999, { smallest: "ms", units: 3 }),
    "59 minutes, 59 seconds, 999 milliseconds",
  );
});

test("throws TypeError for a non-number ms", () => {
  assert.throws(() => formatDuration("1500"), TypeError);
  assert.throws(() => formatDuration(null), TypeError);
});

test("throws RangeError for negative, NaN or Infinity ms", () => {
  assert.throws(() => formatDuration(-1), RangeError);
  assert.throws(() => formatDuration(NaN), RangeError);
  assert.throws(() => formatDuration(Infinity), RangeError);
});

test("throws RangeError for an invalid units option", () => {
  assert.throws(() => formatDuration(1000, { units: 0 }), RangeError);
  assert.throws(() => formatDuration(1000, { units: -2 }), RangeError);
  assert.throws(() => formatDuration(1000, { units: 2.5 }), RangeError);
});

test("throws RangeError for an invalid style option", () => {
  assert.throws(() => formatDuration(1000, { style: "brief" }), RangeError);
});

test("throws RangeError for an invalid smallest option", () => {
  assert.throws(() => formatDuration(1000, { smallest: "minutes" }), RangeError);
});

test("accepts every smallest unit", () => {
  assert.equal(formatDuration(86_461_000, { smallest: "d" }), "1 day");
  assert.equal(formatDuration(3_700_000, { smallest: "h" }), "1 hour");
  assert.equal(formatDuration(61_000, { smallest: "m" }), "1 minute");
  assert.equal(formatDuration(1_500, { smallest: "ms" }), "1 second, 500 milliseconds");
});