import { test } from "node:test";
import assert from "node:assert/strict";
import { parseIni, stringifyIni } from "../src/ini.js";

test("parses a basic section and key", () => {
  assert.deepEqual(parseIni("[server]\nport = 8080\n"), {
    server: { port: "8080" },
  });
});

test("keys before the first header go in the empty section", () => {
  assert.deepEqual(parseIni("name = api\n[server]\nport = 8080\n"), {
    "": { name: "api" },
    server: { port: "8080" },
  });
});

test("the empty section is omitted when it has no keys", () => {
  assert.deepEqual(parseIni("[a]\nx = 1\n"), { a: { x: "1" } });
});

test("duplicate sections merge and duplicate keys take the last value", () => {
  const text = "[s]\na = 1\n[t]\nb = 2\n[s]\na = 3\nc = 4\n";
  assert.deepEqual(parseIni(text), { s: { a: "3", c: "4" }, t: { b: "2" } });
});

test("comments and blank lines are ignored", () => {
  const text = "; comment\n\n# comment\n[s]\nport = 8080 ; not a comment\n";
  assert.deepEqual(parseIni(text), { s: { port: "8080 ; not a comment" } });
});

test("an empty section still appears; a dotted name is not nesting", () => {
  assert.deepEqual(parseIni("[server.http]\n[empty]\n"), {
    "server.http": {},
    empty: {},
  });
});

test("quoted values keep whitespace and decode escapes", () => {
  const text = '[s]\nmotd = " hi \\"there\\" \\\\ \\n \\t "\nempty = ""\n';
  assert.deepEqual(parseIni(text), { s: { motd: ' hi "there" \\ \n \t ', empty: "" } });
});

test("whitespace inside quotes is kept and unquoted values are trimmed", () => {
  assert.deepEqual(parseIni('[s]\na =   spaced   \nb = " padded "\n'), {
    s: { a: "spaced", b: " padded " },
  });
});

test("backslash continues the value onto the next line", () => {
  const text = "[s]\nnote = first\\\nsecond \\\n[not a header]\n";
  assert.deepEqual(parseIni(text), { s: { note: "first second [not a header]" } });
});

test("continuation swallows comment-looking lines", () => {
  assert.deepEqual(parseIni("[s]\na = one\\\n; two\n"), { s: { a: "one ; two" } });
});

test("CRLF line endings parse the same as LF", () => {
  assert.deepEqual(parseIni("[s]\r\nport = 8080\r\n"), parseIni("[s]\nport = 8080\n"));
});

test("empty value is allowed; empty key is a syntax error", () => {
  assert.deepEqual(parseIni("[s]\na =\n"), { s: { a: "" } });
  assert.throws(() => parseIni("[s]\n= value\n"), (e) => e instanceof SyntaxError && e.line === 2);
});

test("section header errors report the offending line", () => {
  assert.throws(() => parseIni("[s]\nx = 1\n[]\n"), (e) => e instanceof SyntaxError && e.line === 3);
  assert.throws(() => parseIni("[s]\nx = 1\n[unterminated\n"), (e) => e.line === 3);
});

test("a line with no = is a syntax error at its line", () => {
  assert.throws(() => parseIni("[s]\njust some words\n"), (e) => e instanceof SyntaxError && e.line === 2);
});

test("quoted-value errors report the offending line", () => {
  assert.throws(() => parseIni("[s]\na = one\nb = \"bad \\q\"\n"), (e) => e.line === 3);
  assert.throws(() => parseIni("[s]\nb = \"unterminated\n"), (e) => e.line === 2);
  assert.throws(() => parseIni("[s]\nb = \"ok\" trailing\n"), (e) => e.line === 2);
});

test("continuation on the last line points at the backslash line", () => {
  assert.throws(() => parseIni("[s]\na = one\nb = two\\\n"), (e) => e.line === 3);
});

test("round trip: parseIni(stringifyIni(data)) returns the data", () => {
  const data = {
    "": { name: "api" },
    server: { port: "8080", motd: ' hi "there" \\ \n\t ' },
    "server.http": { empty: "", plain: "8080 ; keep" },
  };
  assert.deepEqual(parseIni(stringifyIni(data)), data);
});
