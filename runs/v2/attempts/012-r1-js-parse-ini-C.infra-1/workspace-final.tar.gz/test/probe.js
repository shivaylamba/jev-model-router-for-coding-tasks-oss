const lines = ["a", "b"];
console.log("LINES: " + lines.length);
