/**
 * INI reading and writing. See docs/INI_FORMAT.md for the dialect.
 */

function quote(value) {
  const escaped = value
    .replace(/\\/g, "\\\\")
    .replace(/"/g, '\\"')
    .replace(/\n/g, "\\n")
    .replace(/\t/g, "\\t");
  return `"${escaped}"`;
}

function needsQuotes(value) {
  return value !== value.trim() || /["\\\n\t]/.test(value) || value.startsWith('"');
}

/**
 * Serialize { section: { key: value } } to INI text. Keys of the "" section
 * are written first, without a header. Values are converted with String().
 */
export function stringifyIni(data) {
  const lines = [];
  const sections = Object.keys(data);
  const ordered = sections.includes("") ? ["", ...sections.filter((s) => s !== "")] : sections;
  for (const section of ordered) {
    if (section !== "") {
      if (lines.length > 0) lines.push("");
      lines.push(`[${section}]`);
    }
    for (const [key, raw] of Object.entries(data[section])) {
      const value = String(raw);
      lines.push(`${key} = ${needsQuotes(value) ? quote(value) : value}`);
    }
  }
  return lines.join("\n") + "\n";
}

const ESCAPES = { '"': '"', '\\': '\\', n: '\n', t: '\t' };

function iniError(message, line) {
  const err = new SyntaxError(message + " (line " + line + ")");
  err.line = line;
  return err;
}

// Parse a quoted value. `value` starts with the opening quote. Throws on bad
// escape, missing closing quote, or non-whitespace after the closing quote.
function parseQuoted(value, line) {
  let out = "";
  let i = 1;
  let closed = false;
  while (i < value.length) {
    const ch = value[i];
    if (ch === '"') {
      closed = true;
      i++;
      break;
    }
    if (ch === '\\') {
      if (i + 1 >= value.length) throw iniError("missing closing quote", line);
      const esc = ESCAPES[value[i + 1]];
      if (esc === undefined) throw iniError("invalid escape \\" + value[i + 1], line);
      out += esc;
      i += 2;
    } else {
      out += ch;
      i += 1;
    }
  }
  if (!closed) throw iniError("missing closing quote", line);
  for (let k = i; k < value.length; k++) {
    if (value[k] !== ' ' && value[k] !== '\t') {
      throw iniError("unexpected characters after closing quote", line);
    }
  }
  return out;
}

/**
 * Parse INI text into { section: { key: value } }. Sections appear in the
 * order first encountered; keys before the first header go in the "" section.
 * Throws a SyntaxError with a 1-based numeric `line` property on bad input.
 */
export function parseIni(text) {
  const result = {};
  let current = null;
  const lines = text.split(/\r?\n/);
  // A trailing newline ends the last line; it does not start a new one.
  if (lines.length > 0 && lines[lines.length - 1] === "") lines.pop();

  const ensureSection = (name) => {
    if (!Object.prototype.hasOwnProperty.call(result, name)) result[name] = {};
    return result[name];
  };

  for (let index = 0; index < lines.length; index++) {
    const lineNumber = index + 1;
    const trimmed = lines[index].trim();
    if (trimmed === "" || trimmed.startsWith(";") || trimmed.startsWith("#")) continue;

    if (trimmed.startsWith("[")) {
      if (!trimmed.endsWith("]")) throw iniError("unterminated section header", lineNumber);
      const name = trimmed.slice(1, -1).trim();
      if (name === "") throw iniError("empty section name", lineNumber);
      current = ensureSection(name);
      continue;
    }

    const eq = trimmed.indexOf("=");
    if (eq === -1) throw iniError('expected "key = value"', lineNumber);
    const key = trimmed.slice(0, eq).trim();
    if (key === "") throw iniError('missing key before "="', lineNumber);
    if (current === null) current = ensureSection("");
    const value = trimmed.slice(eq + 1).trim();

    if (value.startsWith('"')) {
      current[key] = parseQuoted(value, lineNumber);
      continue;
    }

    let acc = value;
    while (acc.endsWith("\\")) {
      acc = acc.slice(0, -1).trimEnd();
      index++;
      if (index >= lines.length) throw iniError("line continuation reaches end of file", index);
      acc += " " + lines[index].trim();
    }
    current[key] = acc;
  }

  return result;
}

  return result;
}
