/**
 * Largest-first unit definitions. `value` is the size in milliseconds.
 */
const UNITS = [
  { value: 86400000, long: "day", abbr: "d" },
  { value: 3600000, long: "hour", abbr: "h" },
  { value: 60000, long: "minute", abbr: "m" },
  { value: 1000, long: "second", abbr: "s" },
  { value: 1, long: "millisecond", abbr: "ms" },
];

/** Every valid `smallest` abbreviation, in the same order as UNITS. */
const SMALLEST = new Set(["d", "h", "m", "s", "ms"]);

function pluralize(word, n) {
  return n === 1 ? word : `${word}s`;
}

/**
 * Format a millisecond duration as a readable string.
 *
 * The duration is floored to a whole number of milliseconds, then split into
 * units from largest (day) to smallest (millisecond). Zero units are skipped;
 * units smaller than `smallest` never appear, and anything below the last
 * shown unit is dropped (never rounded).
 *
 * @param {number} ms
 * @param {{
 *   units?: number,
 *   style?: "long" | "compact",
 *   smallest?: "d" | "h" | "m" | "s" | "ms",
 * }} [options]
 * @returns {string}
 */
export function formatDuration(ms, options = {}) {
  if (typeof ms !== "number") {
    throw new TypeError("ms must be a number");
  }
  if (Number.isNaN(ms) || !Number.isFinite(ms) || ms < 0) {
    throw new RangeError("ms must be a finite, non-negative number");
  }

  const { units = 2, style = "long", smallest = "s" } = options ?? {};

  if (!Number.isInteger(units) || units < 1) {
    throw new RangeError("units must be a positive integer");
  }
  if (style !== "long" && style !== "compact") {
    throw new RangeError("style must be 'long' or 'compact'");
  }
  if (!SMALLEST.has(smallest)) {
    throw new RangeError("smallest must be one of 'd', 'h', 'm', 's', 'ms'");
  }

  // Only units at least as coarse as `smallest` may appear. UNITS is ordered
  // largest first, so this is every index up to and including `smallest`'s.
  const smallestIndex = UNITS.findIndex((u) => u.abbr === smallest);

  let remaining = Math.floor(ms);
  const parts = [];
  for (let i = 0; i <= smallestIndex; i++) {
    const unit = UNITS[i];
    if (remaining >= unit.value) {
      parts.push({ value: Math.floor(remaining / unit.value), unit });
      remaining %= unit.value;
    }
  }

  const shown = parts.slice(0, units);
  if (shown.length === 0) {
    const zero = UNITS[smallestIndex];
    return style === "compact"
      ? `0${zero.abbr}`
      : `0 ${pluralize(zero.long, 0)}`;
  }

  if (style === "compact") {
    return shown.map((p) => `${p.value}${p.unit.abbr}`).join(" ");
  }
  return shown.map((p) => `${p.value} ${pluralize(p.unit.long, p.value)}`).join(", ");
}