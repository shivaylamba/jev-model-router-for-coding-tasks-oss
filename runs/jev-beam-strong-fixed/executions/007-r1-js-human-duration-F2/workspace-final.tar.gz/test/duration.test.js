import { test } from "node:test";
import assert from "node:assert/strict";
import { formatDuration } from "../src/duration.js";

test("long style, default options", () => {
  assert.equal(formatDuration(90061000), "1 day, 1 hour"); // 1d 1h 1m 1s; minute+second dropped by units
  assert.equal(formatDuration(90061000, { units: 4 }), "1 day, 1 hour, 1 minute, 1 second");
  assert.equal(formatDuration(3905000), "1 hour, 5 minutes");
  assert.equal(formatDuration(3599999), "59 minutes, 59 seconds"); // floor ms, never rounded
  assert.equal(formatDuration(1500), "1 second"); // ms hidden by default smallest
});

test("units caps the number of shown (largest non-zero) units", () => {
  assert.equal(formatDuration(90061000, { units: 1 }), "1 day");
  assert.equal(formatDuration(90061000, { units: 3 }), "1 day, 1 hour, 1 minute");
});

test("zero units are skipped and do not count", () => {
  assert.equal(formatDuration(86700000), "1 day, 5 minutes"); // 1d 5m (hour skipped)
  assert.equal(formatDuration(86700000, { units: 2 }), "1 day, 5 minutes");
});

test("smallest hides finer units or reveals them", () => {
  assert.equal(formatDuration(1500, { smallest: "ms" }), "1 second, 500 milliseconds");
  assert.equal(formatDuration(900000, { smallest: "h" }), "0 hours"); // 15m < 1h
  assert.equal(formatDuration(7234000, { smallest: "m" }), "2 hours"); // seconds dropped
});

test("compact style", () => {
  assert.equal(formatDuration(90061000, { style: "compact" }), "1d 1h");
  assert.equal(formatDuration(1500, { smallest: "ms", style: "compact" }), "1s 500ms");
  assert.equal(formatDuration(60000, { style: "compact" }), "1m");
});

test("zero is printed in the smallest unit", () => {
  assert.equal(formatDuration(0), "0 seconds");
  assert.equal(formatDuration(0, { smallest: "m" }), "0 minutes");
  assert.equal(formatDuration(0, { style: "compact" }), "0s");
  assert.equal(formatDuration(500), "0 seconds"); // < 1 second
  assert.equal(formatDuration(500, { smallest: "ms" }), "500 milliseconds");
  assert.equal(formatDuration(0, { smallest: "ms" }), "0 milliseconds");
});

test("singular only when the number is 1", () => {
  assert.equal(formatDuration(86400000), "1 day");
  assert.equal(formatDuration(172800000), "2 days");
  assert.equal(formatDuration(1000), "1 second");
  assert.equal(formatDuration(2000), "2 seconds");
  assert.equal(formatDuration(1000, { smallest: "ms" }), "1 second");
});

test("ms must be a number (TypeError)", () => {
  for (const bad of ["1000", null, undefined, {}, []]) {
    assert.throws(() => formatDuration(bad), TypeError);
  }
});

test("negative, NaN and Infinity ms are rejected (RangeError)", () => {
  assert.throws(() => formatDuration(-1), RangeError);
  assert.throws(() => formatDuration(NaN), RangeError);
  assert.throws(() => formatDuration(Infinity), RangeError);
  assert.throws(() => formatDuration(-Infinity), RangeError);
});

test("invalid option values are rejected (RangeError)", () => {
  assert.throws(() => formatDuration(1000, { units: 0 }), RangeError);
  assert.throws(() => formatDuration(1000, { units: 1.5 }), RangeError);
  assert.throws(() => formatDuration(1000, { units: "2" }), RangeError);
  assert.throws(() => formatDuration(1000, { style: "short" }), RangeError);
  assert.throws(() => formatDuration(1000, { smallest: "w" }), RangeError);
});