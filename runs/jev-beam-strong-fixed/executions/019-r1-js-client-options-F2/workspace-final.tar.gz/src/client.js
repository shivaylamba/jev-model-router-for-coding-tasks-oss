import { deprecate } from "./deprecate.js";

const DEFAULT_TIMEOUT_MS = 5000;
const DEFAULT_RETRIES = 0;
const ALLOWED_KEYS = new Set(["baseUrl", "token", "timeoutMs", "retries", "headers"]);

function isPlainObject(value) {
  if (value === null || typeof value !== "object") return false;
  const proto = Object.getPrototypeOf(value);
  return proto === Object.prototype || proto === null;
}

function validateBaseUrl(baseUrl) {
  if (typeof baseUrl !== "string" || baseUrl === "") {
    throw new TypeError("baseUrl must be a non-empty string");
  }
}

function validateTimeoutMs(timeoutMs) {
  if (typeof timeoutMs !== "number" || !Number.isFinite(timeoutMs) || timeoutMs <= 0) {
    throw new RangeError("timeoutMs must be a finite number greater than 0");
  }
}

function validateRetries(retries) {
  if (typeof retries !== "number" || !Number.isInteger(retries) || retries < 0) {
    throw new RangeError("retries must be an integer >= 0");
  }
}

/** Reject any options-object key that isn't one of the supported options. */
function validateKeys(options) {
  for (const key of Object.keys(options)) {
    if (!ALLOWED_KEYS.has(key)) {
      throw new TypeError(`unknown createClient option "${key}"`);
    }
  }
}

/**
 * Build and normalize the frozen options for a client from a raw map of
 * options. An option whose value is `undefined` counts as not given, so its
 * default applies.
 */
function normalizeOptions(raw) {
  const { baseUrl, token, timeoutMs = DEFAULT_TIMEOUT_MS, retries = DEFAULT_RETRIES, headers = {} } = raw;
  validateBaseUrl(baseUrl);
  validateTimeoutMs(timeoutMs);
  validateRetries(retries);
  return Object.freeze({
    baseUrl: baseUrl.replace(/\/+$/, ""),
    token,
    timeoutMs,
    retries,
    headers: { ...headers },
  });
}

/**
 * Create an API client.
 *
 * Options form:
 * @param {object} [options]
 * @param {string} options.baseUrl  e.g. "https://api.internal.example"; a trailing slash is ignored
 * @param {string} [options.token]  bearer token; no Authorization header when omitted
 * @param {number} [options.timeoutMs=5000]
 * @param {number} [options.retries=0]
 * @param {object} [options.headers={}]  extra headers added to every request description
 *
 * Deprecated positional form: createClient(baseUrl, token, timeoutMs, retries).
 */
export function createClient(...args) {
  const [first] = args;

  let raw;
  if (typeof first === "string") {
    deprecate(
      "CLIENT_POSITIONAL_ARGS",
      "createClient(arg, ...) positional arguments are deprecated; pass a single options object instead"
    );
    raw = { baseUrl: first, token: args[1], timeoutMs: args[2], retries: args[3] };
  } else if (isPlainObject(first)) {
    validateKeys(first);
    raw = first;
  } else {
    throw new TypeError("createClient expects an options object (or, deprecated, a baseUrl string)");
  }

  const options = normalizeOptions(raw);

  return {
    options,
    /**
     * Describe a request and pass it to `transport`, returning whatever the transport returns.
     */
    request(transport, method, path, body) {
      const headers = { ...options.headers, accept: "application/json" };
      if (options.token) headers.authorization = `Bearer ${options.token}`;
      if (body !== undefined) headers["content-type"] = "application/json";
      return transport({
        method,
        url: options.baseUrl + (path.startsWith("/") ? path : `/${path}`),
        headers,
        body: body === undefined ? undefined : JSON.stringify(body),
        timeoutMs: options.timeoutMs,
        retries: options.retries,
      });
    },
  };
}