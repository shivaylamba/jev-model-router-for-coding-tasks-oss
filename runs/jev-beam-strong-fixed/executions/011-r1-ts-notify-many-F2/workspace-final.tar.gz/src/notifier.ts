export interface Transport {
  send(recipient: string, message: string): void;
}

/** Records every send in memory. Handy in tests and dry runs. */
export class MemoryTransport implements Transport {
  sent: Array<{ recipient: string; message: string }> = [];

  send(recipient: string, message: string): void {
    this.sent.push({ recipient, message });
  }
}

export class Notifier {
  private transport: Transport;

  constructor(transport: Transport) {
    this.transport = transport;
  }

  /**
   * Send `message` to one or more recipients. A single string behaves as before.
   * For an array, each recipient is trimmed before sending and the message is
   * delivered to every recipient in the order given, but duplicates (matching
   * case-insensitively after trimming) are only sent once, keeping the first
   * spelling encountered. Throws TypeError if any recipient is empty or only
   * whitespace, before anything is sent, so a bad list never results in a
   * partial send.
   *
   * @returns the number of messages actually sent (1 for a single string, 0 for
   * an empty array).
   */
  notify(recipients: string | readonly string[], message: string): number {
    const list = Array.isArray(recipients) ? recipients : [recipients];

    for (const recipient of list) {
      if (recipient.trim() === "") {
        throw new TypeError("recipient must be a non-empty string");
      }
    }

    let count = 0;
    const seen = new Map<string, string>();
    for (const recipient of list) {
      const to = recipient.trim();
      const key = to.toLowerCase();
      if (seen.has(key)) continue;
      seen.set(key, to);
      this.transport.send(to, message);
      count += 1;
    }
    return count;
  }
}
