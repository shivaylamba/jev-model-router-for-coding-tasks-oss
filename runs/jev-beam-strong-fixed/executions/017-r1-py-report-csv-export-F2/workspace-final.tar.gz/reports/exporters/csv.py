"""Comma-separated values, for machines rather than people.

Uses raw cell values (no display formatting): ints as plain digits, floats with
exactly two decimals, booleans as true/false, null as an empty field."""


def _format(value):
    """Format a raw cell value for CSV."""
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return format(value, ".2f")
    return str(value)


def _quote(field):
    """Quote a field if it contains a comma, a double quote or a line break."""
    if any(ch in field for ch in ',"\n\r'):
        return '"' + field.replace('"', '""') + '"'
    return field


class CsvExporter:
    name = "csv"
    extension = ".csv"

    def export(self, report):
        lines = [",".join(_quote(c.label) for c in report.columns)]
        lines += [
            ",".join(_quote(_format(report.cell(row, c))) for c in report.columns)
            for row in report.rows
        ]
        return "\n".join(lines) + "\n"