import { percentOf } from "./money.ts";
import type { Bundle, Coupon, CouponStatus, Discount, Order, Totals } from "./types.ts";
import { BUNDLES } from "./bundles.ts";

export const VOLUME_MIN_QUANTITY = 10;
export const VOLUME_PERCENT = 10;
export const FREE_SHIPPING_THRESHOLD = 5000;
export const SHIPPING_FEE = 499;
export const TAX_PERCENT = 8;

export type PricedLine = {
  sku: string;
  unitPrice: number;
  quantity: number;
  gross: number;
  bundled: number;
};

export type PricingContext = {
  order: Order;
  coupon: Coupon | undefined;
  lines: PricedLine[];
  subtotal: number;
  discounts: Discount[];
  couponStatus: CouponStatus;
  shipping: number;
  tax: number;
};

export type PricingRule = {
  name: string;
  apply(ctx: PricingContext): void;
};

export function merchandiseTotal(ctx: PricingContext): number {
  const totalDiscounts = ctx.discounts.reduce((sum, d) => sum + d.amount, 0);
  return ctx.subtotal - totalDiscounts;
}

function findLinesBySku(ctx: PricingContext, sku: string): number[] {
  const indices: number[] = [];
  for (let i = 0; i < ctx.lines.length; i++) {
    if (ctx.lines[i].sku === sku) {
      indices.push(i);
    }
  }
  return indices;
}

export function createPricer(rules: PricingRule[]) {
  return (order: Order, coupon?: Coupon): Totals => {
    for (const line of order.lines) {
      if (!Number.isInteger(line.quantity) || line.quantity < 1) {
        throw new RangeError(`bad quantity for ${line.sku}: ${line.quantity}`);
      }
      if (!Number.isInteger(line.unitPrice) || line.unitPrice < 0) {
        throw new RangeError(`bad unit price for ${line.sku}: ${line.unitPrice}`);
      }
    }

    const lines: PricedLine[] = order.lines.map((line) => ({
      sku: line.sku,
      unitPrice: line.unitPrice,
      quantity: line.quantity,
      gross: line.unitPrice * line.quantity,
      bundled: 0,
    }));

    const subtotal = lines.reduce((sum, line) => sum + line.gross, 0);

    const ctx: PricingContext = {
      order,
      coupon,
      lines,
      subtotal,
      discounts: [],
      couponStatus: "none",
      shipping: 0,
      tax: 0,
    };

    for (const rule of rules) {
      rule.apply(ctx);
    }

    const merchandise = merchandiseTotal(ctx);

    return {
      subtotal,
      discounts: ctx.discounts,
      merchandise,
      shipping: ctx.shipping,
      tax: ctx.tax,
      total: merchandise + ctx.shipping + ctx.tax,
      coupon: ctx.couponStatus,
    };
  };
}

export function bundleRule(bundles: Bundle[]): PricingRule {
  return {
    name: "bundle",
    apply(ctx): void {
      for (const bundle of bundles) {
        let maxCopies = Infinity;
        for (const sku of bundle.skus) {
          let available = 0;
          for (const lineIdx of findLinesBySku(ctx, sku)) {
            const line = ctx.lines[lineIdx];
            available += line.quantity - line.bundled;
          }
          if (available === 0) {
            maxCopies = 0;
            break;
          }
          maxCopies = Math.min(maxCopies, available);
        }

        if (maxCopies === 0 || maxCopies === Infinity) {
          continue;
        }

        const lineTakes = new Map<number, number>();

        for (let copy = 0; copy < maxCopies; copy++) {
          for (const sku of bundle.skus) {
            for (const lineIdx of findLinesBySku(ctx, sku)) {
              const line = ctx.lines[lineIdx];
              if (line.quantity - line.bundled > 0) {
                lineTakes.set(lineIdx, (lineTakes.get(lineIdx) || 0) + 1);
                line.bundled++;
                break;
              }
            }
          }
        }

        let totalDiscount = 0;
        for (const [lineIdx, count] of lineTakes) {
          const line = ctx.lines[lineIdx];
          totalDiscount += percentOf(line.unitPrice * count, bundle.percent);
        }

        if (totalDiscount > 0) {
          ctx.discounts.push({ rule: `bundle:${bundle.id}`, amount: totalDiscount });
        }
      }
    },
  };
}

export const volumeRule: PricingRule = {
  name: "volume",
  apply(ctx): void {
    let volume = 0;
    for (const line of ctx.lines) {
      if (line.quantity >= VOLUME_MIN_QUANTITY) {
        const unbundled = line.quantity - line.bundled;
        if (unbundled > 0) {
          volume += percentOf(line.unitPrice * unbundled, VOLUME_PERCENT);
        }
      }
    }
    if (volume > 0) {
      ctx.discounts.push({ rule: "volume", amount: volume });
    }
  },
};

export const couponRule: PricingRule = {
  name: "coupon",
  apply(ctx): void {
    if (!ctx.coupon) {
      ctx.couponStatus = "none";
      return;
    }

    const hasBundleDiscount = ctx.discounts.some((d) => d.rule.startsWith("bundle:"));
    if (ctx.coupon.exclusive && hasBundleDiscount) {
      ctx.couponStatus = "excluded";
      return;
    }

    const merchandise = merchandiseTotal(ctx);
    if (merchandise < (ctx.coupon.minSubtotal ?? 0)) {
      ctx.couponStatus = "below-minimum";
      return;
    }

    const off =
      ctx.coupon.kind === "percent"
        ? percentOf(merchandise, ctx.coupon.value)
        : Math.min(ctx.coupon.value, merchandise);

    ctx.couponStatus = "applied";
    if (off > 0) {
      ctx.discounts.push({ rule: `coupon:${ctx.coupon.code}`, amount: off });
    }
  },
};

export const shippingRule: PricingRule = {
  name: "shipping",
  apply(ctx): void {
    if (ctx.order.lines.length === 0) {
      ctx.shipping = 0;
      return;
    }
    const merchandise = merchandiseTotal(ctx);
    ctx.shipping = merchandise >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_FEE;
  },
};

export const taxRule: PricingRule = {
  name: "tax",
  apply(ctx): void {
    ctx.tax = percentOf(merchandiseTotal(ctx), TAX_PERCENT);
  },
};

export const defaultRules: PricingRule[] = [
  bundleRule(BUNDLES),
  volumeRule,
  couponRule,
  shippingRule,
  taxRule,
];
