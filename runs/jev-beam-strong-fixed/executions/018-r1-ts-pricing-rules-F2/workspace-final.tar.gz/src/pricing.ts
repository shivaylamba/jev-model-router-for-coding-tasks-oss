import { createPricer, defaultRules } from "./rules.ts";

export {
  VOLUME_MIN_QUANTITY,
  VOLUME_PERCENT,
  FREE_SHIPPING_THRESHOLD,
  SHIPPING_FEE,
  TAX_PERCENT,
} from "./rules.ts";

/** Price an order. See docs/PRICING.md for the rules. */
export const orderTotal = createPricer(defaultRules);
