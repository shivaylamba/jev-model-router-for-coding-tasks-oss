"""Asyncio rate limiter: per-key token buckets plus a global concurrency cap.

See SPEC.md for the full behaviour.
"""

import asyncio
import itertools

from ratelimit.bucket import TokenBucket


class _Request:
    __slots__ = (
        "key",
        "seq",
        "granted",
        "cancelled_applied",
        "done",
        "_waiter",
    )

    def __init__(self, key, seq, done):
        self.key = key
        self.seq = seq
        self.granted = False
        self.cancelled_applied = False
        self.done = done
        self._waiter = None


class RateLimiter:
    def __init__(self, rate, burst, max_concurrent, *, clock, sleep):
        if rate <= 0:
            raise ValueError("rate must be positive")
        if burst < 1:
            raise ValueError("burst must be at least 1")
        if max_concurrent < 1:
            raise ValueError("max_concurrent must be at least 1")
        self.rate = rate
        self.burst = burst
        self.max_concurrent = max_concurrent
        self._clock = clock
        self._sleep = sleep
        self._buckets = {}
        self._queues = {}
        self._in_use = 0
        self._seq = itertools.count()

    async def acquire(self, key):
        """Wait until a request for `key` is granted (one token and one slot)."""
        if key not in self._buckets:
            self._buckets[key] = TokenBucket(self.rate, self.burst, self._clock)
        if key not in self._queues:
            self._queues[key] = []

        loop = asyncio.get_running_loop()
        req = _Request(key, next(self._seq), loop.create_future())
        self._queues[key].append(req)
        req._waiter = loop.create_future()

        try:
            while not req.granted:
                self._grant_pass()
                if req.granted:
                    break

                q = self._queues.get(key, [])
                is_head = bool(q) and q[0] is req
                bucket = self._buckets[key]

                if is_head and bucket.available() < 1:
                    delay = bucket.time_until_available()
                    try:
                        await self._sleep(delay)
                    except asyncio.CancelledError:
                        self._cancel_request(req)
                        raise
                    # loop again, computing a fresh pass / delay
                    continue

                # Wait without sleeping: for a slot, or for promotion to head.
                if req._waiter.done():
                    req._waiter = loop.create_future()
                waiter = req._waiter
                try:
                    await waiter
                except asyncio.CancelledError:
                    self._cancel_request(req)
                    raise

            # Granted: make sure the await returns promptly once granted.
            if not req.done.done():
                req.done.set_result(None)
            await req.done
            return
        except asyncio.CancelledError:
            self._cancel_request(req)
            raise

    def release(self):
        """Free one slot."""
        if self._in_use <= 0:
            raise RuntimeError("no slot held")
        self._in_use -= 1
        self._grant_pass()

    def limit(self, key):
        """Async context manager: acquire on entry, release on exit."""
        return _LimitContextManager(self, key)

    @property
    def in_use(self):
        return self._in_use

    def tokens(self, key):
        bucket = self._buckets.get(key)
        if bucket is None:
            return float(self.burst)
        return float(bucket.available())

    def waiting(self, key=None):
        if key is None:
            return sum(len(q) for q in self._queues.values())
        return len(self._queues.get(key, []))

    # ---- internals ----

    def _nudge(self, req):
        if getattr(req, "_waiter", None) is not None and not req._waiter.done():
            try:
                req._waiter.set_result(None)
            except (RuntimeError, asyncio.InvalidStateError):
                pass

    def _grant_pass(self):
        while True:
            best = None
            for key, q in list(self._queues.items()):
                if not q:
                    continue
                if self._in_use >= self.max_concurrent:
                    continue
                head = q[0]
                bucket = self._buckets.get(key)
                if bucket is None:
                    continue
                if bucket.available() < 1:
                    continue
                if best is None or head.seq < best[0].seq:
                    best = (head, key)
            if best is None:
                break

            head, key = best
            q = self._queues.get(key, [])
            if not q or q[0] is not head:
                # stale; avoid looping forever
                break

            q.pop(0)
            bucket = self._buckets[key]
            bucket.try_take()
            self._in_use += 1
            head.granted = True
            if not head.done.done():
                try:
                    head.done.set_result(None)
                except RuntimeError:
                    pass
            self._nudge(head)

            # Promote the next request for this key, if any.
            if q:
                self._nudge(q[0])

    def _cancel_request(self, req):
        if req.cancelled_applied:
            return
        req.cancelled_applied = True
        if req.granted:
            # Undo the grant.
            if self._in_use > 0:
                self._in_use -= 1
            bucket = self._buckets.get(req.key)
            if bucket is not None:
                bucket.put_back()
            req.granted = False
        else:
            q = self._queues.get(req.key)
            if q and req in q:
                was_head = (q[0] is req)
                q.remove(req)
                if was_head and q:
                    self._nudge(q[0])
        self._grant_pass()


class _LimitContextManager:
    def __init__(self, limiter, key):
        self._limiter = limiter
        self._key = key

    async def __aenter__(self):
        await self._limiter.acquire(self._key)
        return self

    async def __aexit__(self, exc_type, exc, tb):
        self._limiter.release()
        return False
