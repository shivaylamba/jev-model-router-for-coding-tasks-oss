"""Tests for the asyncio RateLimiter using the fake clock."""

import asyncio
import unittest

try:
    from tests.fake_time import FakeTime, settle
except Exception:  # pragma: no cover - alternate import path
    from fake_time import FakeTime, settle

from ratelimit import RateLimiter


def run(coro):
    return asyncio.run(coro)


class RateLimiterTests(unittest.TestCase):
    def test_constructor_validation(self):
        ft = FakeTime()
        for bad in (dict(rate=0), dict(burst=0), dict(max_concurrent=0)):
            kwargs = dict(rate=2.0, burst=2, max_concurrent=2, clock=ft.clock, sleep=ft.sleep)
            kwargs.update(bad)
            with self.assertRaises(ValueError):
                RateLimiter(**kwargs)
        with self.assertRaises(ValueError):
            RateLimiter(rate=-1, burst=2, max_concurrent=2, clock=ft.clock, sleep=ft.sleep)
        with self.assertRaises(ValueError):
            RateLimiter(rate=2.0, burst=0, max_concurrent=2, clock=ft.clock, sleep=ft.sleep)
        with self.assertRaises(ValueError):
            RateLimiter(rate=2.0, burst=2, max_concurrent=-1, clock=ft.clock, sleep=ft.sleep)

    def test_release_with_nothing_held_raises(self):
        ft = FakeTime()
        lim = RateLimiter(rate=2.0, burst=2, max_concurrent=2, clock=ft.clock, sleep=ft.sleep)
        with self.assertRaises(RuntimeError):
            lim.release()

    def test_tokens_never_used(self):
        ft = FakeTime()
        ft.now = 10.0
        lim = RateLimiter(rate=2.0, burst=3, max_concurrent=2, clock=ft.clock, sleep=ft.sleep)
        self.assertEqual(lim.tokens("nope"), 3.0)

    def test_basic_limit(self):
        async def scenario():
            ft = FakeTime()
            lim = RateLimiter(rate=2.0, burst=2, max_concurrent=2, clock=ft.clock, sleep=ft.sleep)
            async with lim.limit("k"):
                self.assertEqual(lim.in_use, 1)
            self.assertEqual(lim.in_use, 0)

        run(scenario())

    def test_immediate_grant_no_sleep(self):
        async def scenario():
            ft = FakeTime()
            lim = RateLimiter(rate=2.0, burst=2, max_concurrent=2, clock=ft.clock, sleep=ft.sleep)
            self.assertEqual(lim.in_use, 0)
            await lim.acquire("k")
            self.assertEqual(ft.sleep_calls, [])
            self.assertEqual(lim.in_use, 1)
            lim.release()
            self.assertEqual(lim.in_use, 0)

        run(scenario())

    def test_token_wait_exact_delay(self):
        async def scenario():
            ft = FakeTime()
            lim = RateLimiter(rate=2.0, burst=1, max_concurrent=10, clock=ft.clock, sleep=ft.sleep)
            await lim.acquire("k")  # consumes the only token
            async def second():
                await lim.acquire("k")

            t = asyncio.create_task(second())
            await settle()
            self.assertEqual(ft.sleep_calls, [0.5])
            await ft.advance(0.5)
            await t
            self.assertEqual(lim.in_use, 2)

        run(scenario())

    def test_slot_only_no_sleep(self):
        async def scenario():
            ft = FakeTime()
            lim = RateLimiter(rate=10.0, burst=5, max_concurrent=1, clock=ft.clock, sleep=ft.sleep)
            await lim.acquire("a")  # holds the only slot
            async def second():
                await lim.acquire("b")

            t = asyncio.create_task(second())
            await settle()
            self.assertEqual(ft.sleep_calls, [])
            self.assertEqual(lim.waiting(), 1)
            lim.release()  # frees slot -> grant pass grants b
            await settle()
            self.assertTrue(t.done())
            self.assertEqual(lim.in_use, 1)
            await t
            lim.release()
            self.assertEqual(lim.in_use, 0)

        run(scenario())

    def test_remaining_delay_recompute(self):
        async def scenario():
            ft = FakeTime()
            # sleep that can return early: wrap FakeTime.sleep? Use a custom sleep that yields once.
            async def early_sleep(delay):
                # emulate a sleep that returns immediately without time passing
                await asyncio.sleep(0)

            lim = RateLimiter(rate=2.0, burst=1, max_concurrent=10, clock=ft.clock, sleep=early_sleep)
            await lim.acquire("k")  # token consumed
            async def second():
                await lim.acquire("k")

            t = asyncio.create_task(second())
            await asyncio.sleep(0)
            await asyncio.sleep(0)
            # clock has not advanced; limiter should have called early_sleep once with 0.5,
            # then looped and called again with 0.5 (remaining unchanged)
            # Give the task a chance to loop a couple of times
            for _ in range(10):
                await asyncio.sleep(0)
            t.cancel()
            try:
                await t
            except asyncio.CancelledError:
                pass
            # No strict assertion on internal counts; just ensure no hang occurred.

        run(scenario())

    def test_cancellation_ungranted(self):
        async def scenario():
            ft = FakeTime()
            lim = RateLimiter(rate=2.0, burst=1, max_concurrent=10, clock=ft.clock, sleep=ft.sleep)
            await lim.acquire("k")  # token consumed
            async def second():
                await lim.acquire("k")

            t = asyncio.create_task(second())
            await settle()
            self.assertEqual(lim.waiting("k"), 1)
            t.cancel()
            try:
                await t
            except asyncio.CancelledError:
                pass
            await settle()
            self.assertEqual(lim.waiting("k"), 0)
            self.assertEqual(lim.tokens("k"), 0.0)

        run(scenario())

    def test_cancellation_promotes_next_head(self):
        async def scenario():
            ft = FakeTime()
            lim = RateLimiter(rate=2.0, burst=1, max_concurrent=10, clock=ft.clock, sleep=ft.sleep)
            await lim.acquire("k")  # token consumed
            t2 = asyncio.create_task(lim.acquire("k"))
            t3 = asyncio.create_task(lim.acquire("k"))
            await settle()
            self.assertEqual(lim.waiting("k"), 2)
            t2.cancel()
            try:
                await t2
            except asyncio.CancelledError:
                pass
            await settle()
            self.assertEqual(lim.waiting("k"), 1)
            t3.cancel()
            try:
                await t3
            except asyncio.CancelledError:
                pass

        run(scenario())

    def test_granted_then_cancelled_undoes(self):
        async def scenario():
            ft = FakeTime()
            lim = RateLimiter(rate=10.0, burst=5, max_concurrent=1, clock=ft.clock, sleep=ft.sleep)
            await lim.acquire("a")  # holds slot
            async def getb():
                await lim.acquire("b")

            tb = asyncio.create_task(getb())
            await settle()
            self.assertEqual(lim.waiting(), 1)

            # free a's slot: grant pass grants b synchronously
            lim.release()
            await settle() if False else None
            # tb may not have resumed yet; cancel before resume
            self.assertEqual(lim.in_use, 1)
            tb.cancel()
            try:
                await tb
            except asyncio.CancelledError:
                pass
            await settle()
            self.assertEqual(lim.in_use, 0)
            self.assertEqual(lim.tokens("b"), 5.0)

        run(scenario())

    def test_grant_pass_across_keys_earliest(self):
        async def scenario():
            ft = FakeTime()
            lim = RateLimiter(rate=10.0, burst=5, max_concurrent=1, clock=ft.clock, sleep=ft.sleep)
            await lim.acquire("a")  # holds slot
            order = []

            async def get(key):
                await lim.acquire(key)
                order.append(key)

            tb = asyncio.create_task(get("b"))
            await settle()
            tc = asyncio.create_task(get("c"))
            await settle()
            # release grants b (created earlier) first
            lim.release()
            await settle()
            self.assertTrue(tb.done())
            self.assertFalse(tc.done())
            await tb
            lim.release()
            await settle()
            self.assertTrue(tc.done())
            await tc

        run(scenario())

    def test_limit_releases_on_exception(self):
        async def scenario():
            ft = FakeTime()
            lim = RateLimiter(rate=10.0, burst=5, max_concurrent=2, clock=ft.clock, sleep=ft.sleep)
            try:
                async with lim.limit("k"):
                    raise ValueError("boom")
            except ValueError:
                pass
            self.assertEqual(lim.in_use, 0)

        run(scenario())

    def test_partial_key_waiting(self):
        async def scenario():
            ft = FakeTime()
            lim = RateLimiter(rate=1.0, burst=1, max_concurrent=10, clock=ft.clock, sleep=ft.sleep)
            await lim.acquire("x")
            await lim.acquire("y")
            self.assertEqual(lim.waiting(), 0)
            self.assertEqual(lim.waiting("x"), 0)
            self.assertEqual(lim.waiting("y"), 0)

        run(scenario())


if __name__ == "__main__":
    unittest.main()
