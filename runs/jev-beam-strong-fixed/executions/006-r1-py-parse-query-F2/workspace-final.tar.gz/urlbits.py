"""URL helpers for the link checker."""


def split_url(url):
    """Split a URL into (base, query, fragment).

    The query is the text after the first "?" (without the "?") and the
    fragment is the text after the first "#". Missing parts are "".

    >>> split_url("https://x.test/a?b=1#top")
    ('https://x.test/a', 'b=1', 'top')
    """
    base, _, fragment = url.partition("#")
    base, _, query = base.partition("?")
    return base, query, fragment


def _unquote(segment):
    """Decode "+" as space then remove %XX escapes (either hex case).

    A "%" not followed by two hex digits is kept as-is. Bytes that are not
    valid UTF-8 become U+FFFD.
    """
    segment = segment.replace("+", " ")
    out = bytearray()
    i = 0
    n = len(segment)
    while i < n:
        ch = segment[i]
        if ch == "%" and i + 2 < n and _is_hex(segment[i + 1]) and _is_hex(segment[i + 2]):
            out.append(int(segment[i + 1 : i + 3], 16))
            i += 3
        else:
            # Append the character as the bytes of its UTF-8 encoding so that
            # multibyte literals in the source survive round-tripping.
            out += ch.encode("utf-8")
            i += 1
    return out.decode("utf-8", errors="replace")


def _is_hex(ch):
    return ch in "0123456789abcdefABCDEF"


def parse_query(query):
    """Split a query string into an ordered dict of key -> list of values.

    A bare key (no "=") maps to None; "x=" maps to "". Keys appear in
    first-appearance order; values for a key keep their relative order.

    >>> parse_query("a=1&flag&a=2")
    {'a': ['1', '2'], 'flag': [None]}
    """
    params = {}
    if query.startswith("?"):
        query = query[1:]
    for segment in query.split("&"):
        if not segment:
            continue
        key, sep, value = segment.partition("=")
        if sep:
            value = _unquote(value)
        else:
            value = None
        key = _unquote(key)
        params.setdefault(key, []).append(value)
    return params


_UNRESERVED = frozenset("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~")


def _quote(text):
    """Percent-encode `text`, leaving unreserved chars and spaces->"+" as-is."""
    out = []
    for b in text.encode("utf-8"):
        ch = chr(b)
        if ch in _UNRESERVED:
            out.append(ch)
        elif ch == " ":
            out.append("+")
        else:
            out.append(f"%{b:02X}")
    return "".join(out)


def build_query(params):
    """Serialize an ordered mapping of parameters into a query string.

    Values may be a str, None (bare key), or a list of str/None. None writes
    the bare key, "" writes "key=". Raises TypeError for any non-str/None
    value.

    >>> build_query({"q": "a b&c"})
    'q=a+b%26c'
    """
    pairs = []
    for key, values in params.items():
        if not isinstance(key, str):
            raise TypeError(f"parameter names must be str, got {type(key).__name__}")
        if isinstance(values, list):
            if not values:
                continue
            for value in values:
                pairs.append(_build_pair(key, value))
        else:
            pairs.append(_build_pair(key, values))
    return "&".join(pairs)


def _build_pair(key, value):
    if value is None:
        return _quote(key)
    if not isinstance(value, str):
        raise TypeError(f"parameter values must be str or None, got {type(value).__name__}")
    return f"{_quote(key)}={_quote(value)}"
