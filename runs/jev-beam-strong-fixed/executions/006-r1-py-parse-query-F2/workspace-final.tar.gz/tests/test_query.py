import unittest

from urlbits import parse_query, build_query


class ParseQueryTest(unittest.TestCase):
    def test_documented_example(self):
        self.assertEqual(parse_query("a=1&flag&a=2"), {"a": ["1", "2"], "flag": [None]})

    def test_optional_leading_question(self):
        self.assertEqual(parse_query("?b=1&x="), {"b": ["1"], "x": [""]})

    def test_empty_segments_skipped(self):
        self.assertEqual(parse_query("a=1&&b=2"), {"a": ["1"], "b": ["2"]})
        self.assertEqual(parse_query(""), {})
        self.assertEqual(parse_query("&"), {})

    def test_bare_key_and_empty_value(self):
        self.assertEqual(parse_query("x="), {"x": [""]})
        self.assertEqual(parse_query("flag"), {"flag": [None]})

    def test_order_preserved(self):
        self.assertEqual(list(parse_query("z=1&a=2&z=3")), ["z", "a"])

    def test_plus_becomes_space(self):
        self.assertEqual(parse_query("q=a+b+c"), {"q": ["a b c"]})

    def test_percent_decoding_both_hex_cases(self):
        self.assertEqual(parse_query("q=a_%2B_b"), {"q": ["a_+_b"]})
        self.assertEqual(parse_query("q=a_%2b_b"), {"q": ["a_+_b"]})

    def test_percent_utf8_decoding(self):
        self.assertEqual(parse_query("caf%C3%A9=1"), {"café": ["1"]})

    def test_lone_percent_kept(self):
        self.assertEqual(parse_query("pct=100%"), {"pct": ["100%"]})
        self.assertEqual(parse_query("100%25"), {"100%": [None]})

    def test_invalid_utf8_becomes_replacement_char(self):
        self.assertEqual(parse_query("x=%FF"), {"x": ["�"]})


class BuildQueryTest(unittest.TestCase):
    def test_documented_example(self):
        self.assertEqual(build_query({"q": "a b&c"}), "q=a+b%26c")

    def test_none_writes_bare_key_empty_string_writes_equals(self):
        self.assertEqual(build_query({"a": None, "b": ""}), "a&b=")

    def test_empty_list_writes_nothing(self):
        self.assertEqual(build_query({"a": [], "b": "1"}), "b=1")

    def test_list_order_and_none_items(self):
        self.assertEqual(build_query({"a": ["1", None, "2"]}), "a=1&a&a=2")

    def test_unreserved_characters_left_as_is(self):
        self.assertEqual(build_query({"x": "AZaz09-._~"}), "x=AZaz09-._~")

    def test_raises_type_error(self):
        with self.assertRaises(TypeError):
            build_query({"a": 1})
        with self.assertRaises(TypeError):
            build_query({"a": ["str", 5]})
        with self.assertRaises(TypeError):
            build_query({1: "x"})


class RoundTripTest(unittest.TestCase):
    def test_parse_of_build(self):
        for params in [
            {"a": ["1", "2"], "flag": [None]},
            {"q": ["a b&c", ""], "x": ["100%"]},
            {"k": [None, None]},
            {"café": ["naïve"], "sp ace": ["x+y"]},
        ]:
            self.assertEqual(parse_query(build_query(params)), params)

    def test_build_of_parse_for_canonical_strings(self):
        for s in [
            "a=1&a=2&flag",
            "q=a+b%26c",
            "x=",
            "100%25",
            "a=1&b=2",
            "caf%C3%A9=%C3%A9t%C3%A9",
        ]:
            self.assertEqual(build_query(parse_query(s)), s)


if __name__ == "__main__":
    unittest.main()