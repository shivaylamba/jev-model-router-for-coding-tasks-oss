"""Text statistics."""
import re

def word_counts(text):
    """Return dict mapping each lowercase word to its count.

    Words are runs of letters, digits or apostrophes; everything else separates words.
    """
    words = re.findall(r"[A-Za-z0-9']+", text.lower())
    counts = {}
    for w in words:
        counts[w] = counts.get(w, 0) + 1
    return counts
