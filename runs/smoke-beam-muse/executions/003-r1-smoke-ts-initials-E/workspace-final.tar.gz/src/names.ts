export function fullName(first: string, last: string): string {
  return `${first} ${last}`.trim();
}

export function initials(name: string): string {
  if (!name || !name.trim()) return "";
  return name
    .trim()
    .split(/[\s-]+/)
    .filter(Boolean)
    .map((word) => word[0]!.toUpperCase())
    .join("");
}
