"""Text statistics."""

import re

_WORD_RE = re.compile(r"(?:[^\W_]|')+")


def word_counts(text):
    """Return a dict mapping each lowercase word to its occurrence count.

    Words are maximal runs of letters, digits or apostrophes; any other
    character separates words.
    """
    counts = {}
    for word in _WORD_RE.findall(text):
        word = word.lower()
        counts[word] = counts.get(word, 0) + 1
    return counts
