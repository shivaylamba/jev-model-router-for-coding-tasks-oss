"""Text statistics."""
import re
from collections import Counter


def word_counts(text):
    """Return a dict mapping each lowercase word to its frequency.

    Words are runs of letters, digits or apostrophes; all other
    characters act as separators.
    """
    return dict(Counter(re.findall(r"[a-z0-9']+", text.lower())))
