def parse_duration(text):
    """Parse a duration such as "1h30m" into a number of seconds.

    Units: d (days), h (hours), m (minutes), s (seconds). Case does not matter.
    Parts may be separated by spaces ("2d 4h"), a space may sit between a number and
    its unit ("1 h"), and numbers may be decimals ("1.5h").
    Parts must go from the largest unit to the smallest and a unit may appear once.
    The result is an int when it is a whole number of seconds, otherwise a float.
    Raise ValueError for anything else: an empty string, a number with no unit,
    an unknown unit, a repeated unit, or units out of order.
    """
    units = {"d": 86400, "h": 3600, "m": 60, "s": 1}
    order = {"d": 0, "h": 1, "m": 2, "s": 3}

    # Spaces are optional everywhere, so strip them all: "2d 4h" -> "2d4h",
    # "1 h" -> "1h". An empty string yields '' and fails below.
    text = "".join(text.split())
    if not text:
        raise ValueError("empty duration")

    total = 0.0
    seen = set()
    previous_order = -1

    i = 0
    while i < len(text):
        # Read a number (may be a decimal).
        start = i
        while i < len(text) and (text[i].isdigit() or text[i] == "."):
            i += 1
        raw_number = text[start:i]
        if not raw_number or raw_number == ".":
            raise ValueError(f"invalid number in {text!r}")
        try:
            number = float(raw_number)
        except ValueError:
            raise ValueError(f"invalid number {raw_number!r}")

        # Read the following unit character.
        if i >= len(text) or text[i].lower() not in units:
            raise ValueError(f"number without unit in {text!r}")
        unit = text[i].lower()
        i += 1

        if unit in seen:
            raise ValueError(f"repeated unit {unit!r}")
        if order[unit] < previous_order:
            raise ValueError(f"units out of order in {text!r}")
        seen.add(unit)
        previous_order = order[unit]

        total += number * units[unit]

    if total == int(total):
        return int(total)
    return total
