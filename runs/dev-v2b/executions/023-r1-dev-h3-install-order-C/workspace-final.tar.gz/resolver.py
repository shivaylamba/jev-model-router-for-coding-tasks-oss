class MissingDependency(Exception):
    """Raised when a package depends on one that is not in the input. args[0] is its name."""

class CycleError(Exception):
    """Raised for circular dependencies.

    `.cycle` lists the packages of one cycle, starting at the alphabetically smallest
    package in it and following the dependency edges, so for a -> b -> c -> a it is
    ["a", "b", "c"], and for a package that depends on itself it is ["a"].
    """
    def __init__(self, cycle):
        super().__init__(" -> ".join(cycle))
        self.cycle = cycle

def resolve(packages):
    """Return an install order for `packages`, a dict of name -> list of dependencies.

    Every package comes after all of its dependencies. When several packages are
    ready to install, the alphabetically smallest goes first, so the result is the
    same every time. Raises MissingDependency or CycleError as described above;
    it must never hang or hit the recursion limit, however deep the graph is.
    """

    deps = {}
    for name in packages:
        deps[name] = []
        for dep in packages[name]:
            if dep not in packages:
                raise MissingDependency(dep)
            deps[name].append(dep)

    visited = [False] * len(deps)
    names = sorted(deps)
    idx = {name: i for i, name in enumerate(names)}
    state = {}  # name -> 1 (in stack) | 2 (done)

    # iterative DFS with explicit stack; detects cycles via state dict
    order = []
    for root in names:
        if state.get(root) == 2:
            continue
        stack = [(root, iter(deps[root]))]
        state[root] = 1
        path = [root]
        while stack:
            node, it = stack[-1]
            advanced = False
            for dep in it:
                if state.get(dep) == 1:
                    # cycle found: extract from path
                    cycle_start = path.index(dep)
                    cycle = path[cycle_start:]
                    # rotate so alphabetically smallest is first
                    smallest = min(cycle)
                    si = cycle.index(smallest)
                    cycle = cycle[si:] + cycle[:si]
                    raise CycleError(cycle)
                if state.get(dep) != 2:
                    state[dep] = 1
                    path.append(dep)
                    stack.append((dep, iter(deps[dep])))
                    advanced = True
                    break
            if not advanced:
                state[node] = 2
                order.append(node)
                path.pop()
                stack.pop()

    return order
