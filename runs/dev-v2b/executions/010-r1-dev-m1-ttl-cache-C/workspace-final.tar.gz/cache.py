from collections import OrderedDict


class TTLCache:
    """A small cache with a size limit and per-entry expiry.

    TTLCache(max_size, ttl, clock) where clock() returns the current time in seconds.

    - set(key, value): store the value; it expires `ttl` seconds after this call.
      Setting an existing key replaces the value and restarts its expiry.
    - get(key, default=None): return the value, or default if missing or expired.
      A successful get makes the key the most recently used.
    - When a set would exceed max_size, expired entries are dropped first; if it is
      still full, the least recently used entry is evicted.
    - len(cache) counts only entries that have not expired.
    - `key in cache` is True only for entries that have not expired, and does not
      change which entry is least recently used.
    """

    def __init__(self, max_size, ttl, clock):
        self.max_size = max_size
        self.ttl = ttl
        self.clock = clock
        # key -> (value, expiry_time)
        self._data = OrderedDict()

    def _is_expired(self, key):
        return self._data[key][1] <= self.clock()

    def _evict_expired(self):
        now = self.clock()
        for key in [k for k, (_, exp) in self._data.items() if exp <= now]:
            del self._data[key]

    def set(self, key, value):
        now = self.clock()
        expiry = now + self.ttl
        if key in self._data:
            self._data[key] = (value, expiry)
            self._data.move_to_end(key)
        else:
            self._data[key] = (value, expiry)
        if len(self._data) > self.max_size:
            self._evict_expired()
            while len(self._data) > self.max_size:
                self._data.popitem(last=False)

    def get(self, key, default=None):
        if key not in self._data:
            return default
        if self._is_expired(key):
            del self._data[key]
            return default
        self._data.move_to_end(key)
        return self._data[key][0]

    def __contains__(self, key):
        if key not in self._data:
            return False
        if self._is_expired(key):
            del self._data[key]
            return False
        return True

    def __len__(self):
        self._evict_expired()
        return len(self._data)
