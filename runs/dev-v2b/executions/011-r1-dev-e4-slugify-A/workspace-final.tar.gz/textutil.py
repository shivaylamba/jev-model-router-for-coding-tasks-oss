def slugify(text):
    """Turn a title into a URL slug.

    - lowercase
    - letters and digits are kept; every run of other characters becomes one hyphen
    - no leading or trailing hyphen
    - an input with no letters or digits gives the empty string
    """
    slug = []
    pending_hyphen = False

    for ch in text.lower():
        if ch.isalnum():
            if pending_hyphen and slug:
                slug.append("-")
            slug.append(ch)
            pending_hyphen = False
        else:
            pending_hyphen = True

    return "".join(slug)
