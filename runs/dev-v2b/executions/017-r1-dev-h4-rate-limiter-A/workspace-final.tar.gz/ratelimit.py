class RateLimiter:
    """Allow at most `limit` requests per key in any `window` seconds.

    RateLimiter(limit, window, clock) where clock() returns the time in seconds.

    - allow(key) returns True and records the request if fewer than `limit` requests
      from that key were allowed in the last `window` seconds. A request allowed at
      time t stops counting at exactly t + window. Otherwise it returns False, and a
      refused request does not count against the key.
    - The limit holds for every window of that length, not only for windows that
      start at a multiple of `window`.
    - tracked_keys() returns how many keys still have an allowed request inside the
      window. Keys with none must be forgotten, so memory does not grow with the
      number of clients ever seen.
    """

    def __init__(self, limit, window, clock):
        self.limit = limit
        self.window = window
        self.clock = clock
        # key -> list of timestamps of allowed requests still inside the window,
        # oldest first.
        self.requests = {}

    def allow(self, key):
        now = self.clock()
        timestamps = self._pruned(key, now)
        if len(timestamps) >= self.limit:
            return False
        timestamps.append(now)
        self.requests[key] = timestamps
        return True

    def tracked_keys(self):
        now = self.clock()
        for key in list(self.requests):
            self._pruned(key, now)
        return len(self.requests)

    def _pruned(self, key, now):
        # Drop requests at or before now - window: a request made at t counts
        # over [t, t + window) and stops counting at exactly t + window.
        # Old entries form a prefix of the list and can never re-enter the
        # window, so once removed they stay removed.
        cutoff = now - self.window
        timestamps = self.requests.get(key)
        if timestamps is None:
            return []
        first_live = 0
        while first_live < len(timestamps) and timestamps[first_live] <= cutoff:
            first_live += 1
        if first_live == len(timestamps):
            del self.requests[key]
            return []
        if first_live:
            del timestamps[:first_live]
        return timestamps
