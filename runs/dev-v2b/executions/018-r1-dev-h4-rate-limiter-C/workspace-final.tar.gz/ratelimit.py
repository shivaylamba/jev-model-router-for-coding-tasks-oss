from collections import deque


class RateLimiter:
    """Allow at most `limit` requests per key in any `window` seconds.

    RateLimiter(limit, window, clock) where clock() returns the time in seconds.

    - allow(key) returns True and records the request if fewer than `limit` requests
      from that key were allowed in the last `window` seconds. A request allowed at
      time t stops counting at exactly t + window. Otherwise it returns False, and a
      refused request does not count against the key.
    - The limit holds for every window of that length, not only for windows that
      start at a multiple of `window`.
    - tracked_keys() returns how many keys still have an allowed request inside the
      window. Keys with none must be forgotten, so memory does not grow with the
      number of clients ever seen.
    """

    def __init__(self, limit, window, clock):
        self.limit = limit
        self.window = window
        self.clock = clock
        self.requests = {}

    def allow(self, key):
        now = self.clock()
        timestamps = self._live_timestamps(key, now)
        if len(timestamps) >= self.limit:
            return False
        timestamps.append(now)
        # _live_timestamps may have dropped the key when its last request
        # expired; re-register it so the just-allowed request is tracked.
        self.requests[key] = timestamps
        return True

    def tracked_keys(self):
        now = self.clock()
        # Pruning here (not only in allow) also purges keys that simply went
        # idle, so memory stays bounded even if they never call allow again.
        self._prune(now)
        return len(self.requests)

    def _live_timestamps(self, key, now):
        timestamps = self.requests.get(key)
        if timestamps is None:
            timestamps = self.requests[key] = deque()
        cutoff = now - self.window
        # A request allowed at t stops counting at exactly t + window.
        while timestamps and timestamps[0] <= cutoff:
            timestamps.popleft()
        if not timestamps:
            del self.requests[key]
        return timestamps

    def _prune(self, now):
        for key in list(self.requests):
            self._live_timestamps(key, now)
