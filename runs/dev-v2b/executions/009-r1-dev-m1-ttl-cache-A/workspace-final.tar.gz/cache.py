from collections import OrderedDict


class TTLCache:
    """A small cache with a size limit and per-entry expiry.

    TTLCache(max_size, ttl, clock) where clock() returns the current time in seconds.

    - set(key, value): store the value; it expires `ttl` seconds after this call.
      Setting an existing key replaces the value and restarts its expiry.
    - get(key, default=None): return the value, or default if missing or expired.
      A successful get makes the key the most recently used.
    - When a set would exceed max_size, expired entries are dropped first; if it is
      still full, the least recently used entry is evicted.
    - len(cache) counts only entries that have not expired.
    - `key in cache` is True only for entries that have not expired, and does not
      change which entry is least recently used.
    """

    def __init__(self, max_size, ttl, clock):
        self._max_size = max_size
        self._ttl = ttl
        self._clock = clock
        # Maps key -> (value, expiry_time); iteration order is LRU -> MRU.
        self._entries = OrderedDict()

    def _expired(self, expiry, now):
        return now >= expiry

    def _drop_expired(self, now):
        for key in [k for k, (_, exp) in self._entries.items() if self._expired(exp, now)]:
            del self._entries[key]

    def set(self, key, value):
        now = self._clock()
        self._drop_expired(now)
        if key in self._entries:
            del self._entries[key]
        elif len(self._entries) >= self._max_size:
            self._entries.popitem(last=False)  # evict least recently used
        self._entries[key] = (value, now + self._ttl)

    def get(self, key, default=None):
        now = self._clock()
        entry = self._entries.get(key)
        if entry is None or self._expired(entry[1], now):
            return default
        self._entries.move_to_end(key)
        return entry[0]

    def __len__(self):
        now = self._clock()
        return sum(1 for _, exp in self._entries.values() if not self._expired(exp, now))

    def __contains__(self, key):
        entry = self._entries.get(key)
        return entry is not None and not self._expired(entry[1], self._clock())
