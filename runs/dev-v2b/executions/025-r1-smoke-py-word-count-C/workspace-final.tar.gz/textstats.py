"""Text statistics."""
import re

_WORD_RE = re.compile(r"[A-Za-z0-9']+")


def word_counts(text):
    """Return a dict mapping each lowercase word to how many times it appears.

    Words are runs of letters, digits, or apostrophes; everything else
    separates words.
    """
    counts = {}
    for word in _WORD_RE.findall(text):
        word = word.lower()
        counts[word] = counts.get(word, 0) + 1
    return counts
