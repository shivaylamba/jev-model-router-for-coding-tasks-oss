def free_slots(meetings, day_start, day_end, min_minutes=1):
    """Return the free intervals in a working day.

    Times are minutes since midnight. `meetings` is a list of (start, end) pairs in
    any order; they may overlap, touch, sit inside one another, or run outside the
    working day. A meeting with end <= start is ignored.

    The result is a sorted list of (start, end) pairs inside [day_start, day_end]
    during which no meeting is running, each at least `min_minutes` long. Meetings
    that touch (one ends when the next starts) leave no free time between them.
    """

    slots = []
    # Filter out invalid meetings and clamp to working day
    valid = []
    for start, end in meetings:
        if end <= start:
            continue
        s = max(start, day_start)
        e = min(end, day_end)
        if s < e:
            valid.append((s, e))
    ordered = sorted(valid)
    cursor = day_start
    for start, end in ordered:
        if start > cursor and start - cursor >= min_minutes:
            slots.append((cursor, start))
        if end > cursor:
            cursor = end
    if day_end - cursor >= min_minutes:
        slots.append((cursor, day_end))
    return slots
