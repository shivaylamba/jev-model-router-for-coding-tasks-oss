from .discounts import apply_discount
from .tax import add_tax


def checkout(lines, discount_percent=0, tax_rate="0"):
    subtotal = apply_discount(lines, discount_percent)
    total = add_tax(subtotal, tax_rate)
    return f"{total:.2f}"
