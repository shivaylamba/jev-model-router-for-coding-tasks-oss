from decimal import Decimal, ROUND_HALF_UP


def round_cents(amount):
    return amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def discounted_line_total(price, quantity, percent):
    line = Decimal(str(price)) * quantity
    factor = Decimal("1") - Decimal(str(percent)) / Decimal("100")
    return round_cents(line * factor)


def apply_discount(lines, percent):
    """Apply the percentage discount to each line separately, round each
    discounted line to the nearest cent (halves up), and return the subtotal."""
    return sum((discounted_line_total(p, q, percent) for p, q in lines), Decimal("0"))
