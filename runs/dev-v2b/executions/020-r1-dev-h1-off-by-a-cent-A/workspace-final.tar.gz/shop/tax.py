from decimal import Decimal

from .discounts import round_cents


def add_tax(amount, rate):
    return amount + round_cents(Decimal(amount) * Decimal(str(rate)))
