from .discounts import discounted_line_total
from .tax import add_tax


def checkout(lines, discount_percent=0, tax_rate="0"):
    subtotal = sum(
        discounted_line_total(price, quantity, discount_percent)
        for price, quantity in lines
    )
    total = add_tax(subtotal, tax_rate)
    return f"{total:.2f}"
