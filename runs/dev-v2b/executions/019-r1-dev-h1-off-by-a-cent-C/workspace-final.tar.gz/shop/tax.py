from decimal import Decimal

from .discounts import round_cent


def add_tax(amount, rate):
    tax = round_cent(Decimal(str(amount)) * Decimal(str(rate)))
    return Decimal(str(amount)) + tax
