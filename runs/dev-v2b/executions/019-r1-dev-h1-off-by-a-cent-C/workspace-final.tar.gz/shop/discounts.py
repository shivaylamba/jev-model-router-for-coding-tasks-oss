from decimal import Decimal, ROUND_HALF_UP

CENT = Decimal("0.01")


def round_cent(amount):
    return amount.quantize(CENT, rounding=ROUND_HALF_UP)


def discounted_line_total(price, quantity, percent):
    line = Decimal(str(price)) * quantity
    discounted = line * (1 - Decimal(str(percent)) / 100)
    return round_cent(discounted)


def apply_discount(amount, percent):
    discounted = Decimal(str(amount)) * (1 - Decimal(str(percent)) / 100)
    return round_cent(discounted)
